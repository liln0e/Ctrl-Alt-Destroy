; HEADER_BLOCK_START
; BambuStudio 02.06.00.51
; model printing time: 44m 53s; total estimated time: 51m 8s
; total layer number: 25
; total filament length [mm] : 12667.99
; total filament volume [cm^3] : 30470.09
; total filament weight [g] : 38.39
; filament_density: 1.26,1.26
; filament_diameter: 1.75,1.75
; max_z_height: 5.00
; filament: 2
; HEADER_BLOCK_END

; CONFIG_BLOCK_START
; accel_to_decel_enable = 0
; accel_to_decel_factor = 50%
; activate_air_filtration = 0,0
; additional_cooling_fan_speed = 70,70
; additional_fan_full_speed_layer = 0,0
; apply_scarf_seam_on_circles = 1
; auxiliary_fan = 1
; avoid_crossing_wall_includes_support = 0
; bed_custom_model = 
; bed_custom_texture = 
; bed_exclude_area = 0x0,18x0,18x28,0x28
; bed_temperature_formula = by_first_filament
; before_layer_change_gcode = 
; best_object_pos = 0.5,0.5
; bottom_color_penetration_layers = 3
; bottom_shell_layers = 3
; bottom_shell_thickness = 0
; bottom_surface_density = 100%
; bottom_surface_pattern = monotonic
; bridge_angle = 0
; bridge_flow = 1
; bridge_no_support = 0
; bridge_speed = 50
; brim_object_gap = 0.1
; brim_type = auto_brim
; brim_width = 5
; chamber_temperatures = 0,0
; change_filament_gcode = ;=P1S 20251031=\nM620 S[next_extruder]A\nM204 S9000\nG1 Z{max_layer_z + 3.0} F1200\n\nG1 X70 F21000\nG1 Y245\nG1 Y265 F3000\nM400\nM106 P1 S0\nM106 P2 S0\n{if old_filament_temp > 142 && next_extruder < 255}\nM104 S[old_filament_temp]\n{endif}\n{if long_retractions_when_cut[previous_extruder]}\nM620.11 S1 I[previous_extruder] E-{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\n{else}\nM620.11 S0\n{endif}\nM400\nG1 X90 F3000\nG1 Y255 F4000\nG1 X100 F5000\nG1 X120 F15000\nG1 X20 Y50 F21000\nG1 Y-3\n{if toolchange_count == 2}\n; get travel path for change filament\nM620.1 X[travel_point_1_x] Y[travel_point_1_y] F21000 P0\nM620.1 X[travel_point_2_x] Y[travel_point_2_y] F21000 P1\nM620.1 X[travel_point_3_x] Y[travel_point_3_y] F21000 P2\n{endif}\nM620.1 E F{flush_volumetric_speeds[previous_extruder]/2.4053*60} T{flush_temperatures[previous_extruder]}\nT[next_extruder]\nM620.1 E F{flush_volumetric_speeds[next_extruder]/2.4053*60} T{flush_temperatures[next_extruder]}\n\n{if next_extruder < 255}\n{if long_retractions_when_cut[previous_extruder]}\nM620.11 S1 I[previous_extruder] E{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nM628 S1\nG92 E0\nG1 E{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nM400\nM629 S1\n{else}\nM620.11 S0\n{endif}\nG92 E0\n{if flush_length_1 > 1}\nM83\n; FLUSH_START\n; always use highest temperature to flush\nM400\n{if filament_type[next_extruder] == "PETG"}\nM109 S260\n{elsif filament_type[next_extruder] == "PVA"}\nM109 S210\n{else}\nM109 S{flush_temperatures[next_extruder]}\n{endif}\n{if flush_length_1 > 23.7}\nG1 E23.7 F{flush_volumetric_speeds[previous_extruder]/2.4053*60} ; do not need pulsatile flushing for start part\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\n{else}\nG1 E{flush_length_1} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\n{endif}\n; FLUSH_END\nG1 E-[old_retract_length_toolchange] F1800\nG1 E[old_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_2 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_3 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_4 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\n; FLUSH_END\n{endif}\n; FLUSH_START\nM400\nM109 S[new_filament_temp]\nG1 E2 F{flush_volumetric_speeds[next_extruder]/2.4053*60} ;Compensate for filament spillage during waiting temperature\n; FLUSH_END\nM400\nG92 E0\nG1 E-[new_retract_length_toolchange] F1800\nM106 P1 S255\nM400 S3\n\nG1 X70 F5000\nG1 X90 F3000\nG1 Y255 F4000\nG1 X105 F5000\nG1 Y265 F5000\nG1 X70 F10000\nG1 X100 F5000\nG1 X70 F10000\nG1 X100 F5000\n\nG1 X70 F10000\nG1 X80 F15000\nG1 X60\nG1 X80\nG1 X60\nG1 X80 ; shake to put down garbage\nG1 X100 F5000\nG1 X165 F15000; wipe and shake\nG1 Y256 ; move Y to aside, prevent collision\nM400\nG1 Z{max_layer_z + 3.0} F3000\n{if layer_z <= (initial_layer_print_height + 0.001)}\nM204 S[initial_layer_acceleration]\n{else}\nM204 S[default_acceleration]\n{endif}\n{else}\nG1 X[x_after_toolchange] Y[y_after_toolchange] Z[z_after_toolchange] F12000\n{endif}\nM621 S[next_extruder]A\n
; circle_compensation_manual_offset = 0
; circle_compensation_speed = 200,200
; close_additional_fan_first_x_layers = 1,1
; close_fan_the_first_x_layers = 1,1
; complete_print_exhaust_fan_speed = 70,70
; cool_plate_temp = 35,35
; cool_plate_temp_initial_layer = 35,35
; cooling_filter_enabled = 0
; cooling_perimeter_transition_distance = 10,10
; cooling_slowdown_logic = uniform_cooling,uniform_cooling
; counter_coef_1 = 0,0
; counter_coef_2 = 0.008,0.008
; counter_coef_3 = -0.041,-0.041
; counter_limit_max = 0.033,0.033
; counter_limit_min = -0.035,-0.035
; curr_bed_type = Textured PEI Plate
; default_acceleration = 10000
; default_filament_colour = ;
; default_filament_profile = "Bambu PLA Basic @BBL P1S 0.4 nozzle"
; default_jerk = 0
; default_nozzle_volume_type = Standard
; default_print_profile = 0.20mm Standard @BBL X1C
; deretraction_speed = 30
; detect_floating_vertical_shell = 1
; detect_narrow_internal_solid_infill = 1
; detect_overhang_wall = 1
; detect_thin_wall = 0
; diameter_limit = 50,50
; different_settings_to_system = enable_support;;;
; draft_shield = disabled
; during_print_exhaust_fan_speed = 70,70
; elefant_foot_compensation = 0.15
; embedding_wall_into_infill = 0
; enable_arc_fitting = 1
; enable_circle_compensation = 0
; enable_filament_dynamic_map = 0
; enable_height_slowdown = 0
; enable_long_retraction_when_cut = 2
; enable_mixed_color_sublayer = 0
; enable_overhang_bridge_fan = 1,1
; enable_overhang_speed = 1
; enable_pre_heating = 0
; enable_pressure_advance = 0,0
; enable_prime_tower = 0
; enable_support = 1
; enable_support_ironing = 0
; enable_tower_interface_features = 0
; enable_wrapping_detection = 0
; enforce_support_layers = 0
; eng_plate_temp = 0,0
; eng_plate_temp_initial_layer = 0,0
; ensure_vertical_shell_thickness = enabled
; exclude_object = 1
; extruder_ams_count = 1#0|4#0;1#0|4#0
; extruder_clearance_dist_to_rod = 33
; extruder_clearance_height_to_lid = 90
; extruder_clearance_height_to_rod = 34
; extruder_clearance_max_radius = 68
; extruder_colour = #018001
; extruder_max_nozzle_count = 1
; extruder_nozzle_stats = Standard#1
; extruder_offset = 0x2
; extruder_printable_area = 
; extruder_type = Direct Drive
; extruder_variant_list = "Direct Drive Standard,Direct Drive High Flow"
; fan_cooling_layer_time = 100,100
; fan_direction = left
; fan_max_speed = 100,100
; fan_min_speed = 100,100
; filament_adaptive_volumetric_speed = 0,0
; filament_adhesiveness_category = 100,100
; filament_bridge_speed = 25,25
; filament_change_length = 5,5
; filament_change_length_nc = 10,10
; filament_colour = #00AE42;#A0A0A0
; filament_colour_type = 1;1
; filament_cooling_before_tower = 0,0
; filament_cost = 24.99,24.99
; filament_density = 1.26,1.26
; filament_dev_ams_drying_ams_limitations = 1;0;1;0
; filament_dev_ams_drying_heat_distortion_temperature = 45,45
; filament_dev_ams_drying_temperature = 45,45,45,45,45,45,45,45
; filament_dev_ams_drying_time = 12,12,12,12,12,12,12,12
; filament_dev_chamber_drying_bed_temperature = 70,70
; filament_dev_chamber_drying_time = 12,12
; filament_dev_drying_cooling_temperature = 45,45
; filament_dev_drying_softening_temperature = 50,50
; filament_diameter = 1.75,1.75
; filament_enable_overhang_speed = 1,1
; filament_end_gcode = "; filament end gcode \n\n";"; filament end gcode \n\n"
; filament_extruder_compatibility = 0,0
; filament_extruder_variant = "Direct Drive Standard";"Direct Drive Standard"
; filament_flow_ratio = 0.98,0.98
; filament_flush_temp = 0,0
; filament_flush_volumetric_speed = 0,0
; filament_ids = GFA00;GFA00
; filament_is_mixed = 0,0
; filament_is_support = 0,0
; filament_long_retractions_when_cut = 1,1
; filament_map = 1,1
; filament_map_2 = 0,0
; filament_map_mode = Auto For Flush
; filament_max_volumetric_speed = 21,21
; filament_metal_stickiness = None,None
; filament_minimal_purge_on_wipe_tower = 15,15
; filament_mixed_components = ;
; filament_mixed_gradient = 0,0
; filament_mixed_gradient_range = ;
; filament_mixed_sublayer_ratios = ;
; filament_multi_colour = #00AE42;#A0A0A0
; filament_notes = 
; filament_nozzle_map = 0,0
; filament_overhang_1_4_speed = 0,0
; filament_overhang_2_4_speed = 50,50
; filament_overhang_3_4_speed = 30,30
; filament_overhang_4_4_speed = 10,10
; filament_overhang_totally_speed = 10,10
; filament_pre_cooling_temperature = 0,0
; filament_pre_cooling_temperature_nc = 0,0
; filament_prime_volume = 30,30
; filament_prime_volume_nc = 60,60
; filament_printable = 3,3
; filament_ramming_travel_time = 0,0
; filament_ramming_travel_time_nc = 0,0
; filament_ramming_volumetric_speed = -1,-1
; filament_ramming_volumetric_speed_nc = -1,-1
; filament_retract_length_nc = 14,14
; filament_retraction_distances_when_cut = 18,18
; filament_scarf_gap = 0%,0%
; filament_scarf_height = 10%,10%
; filament_scarf_length = 10,10
; filament_scarf_seam_type = none,none
; filament_self_index = 1,2
; filament_settings_id = "Bambu PLA Basic @BBL P1S 0.4 nozzle";"Bambu PLA Basic @BBL P1S 0.4 nozzle"
; filament_shrink = 100%,100%
; filament_soluble = 0,0
; filament_start_gcode = "; filament start gcode\n{if  (bed_temperature[current_extruder] >55)||(bed_temperature_initial_layer[current_extruder] >55)}M106 P3 S200\n{elsif(bed_temperature[current_extruder] >50)||(bed_temperature_initial_layer[current_extruder] >50)}M106 P3 S150\n{elsif(bed_temperature[current_extruder] >45)||(bed_temperature_initial_layer[current_extruder] >45)}M106 P3 S50\n{endif}\nM142 P1 R35 S40\n{if activate_air_filtration[current_extruder] && support_air_filtration}\nM106 P3 S{during_print_exhaust_fan_speed_num[current_extruder]} \n{endif}";"; filament start gcode\n{if  (bed_temperature[current_extruder] >55)||(bed_temperature_initial_layer[current_extruder] >55)}M106 P3 S200\n{elsif(bed_temperature[current_extruder] >50)||(bed_temperature_initial_layer[current_extruder] >50)}M106 P3 S150\n{elsif(bed_temperature[current_extruder] >45)||(bed_temperature_initial_layer[current_extruder] >45)}M106 P3 S50\n{endif}\nM142 P1 R35 S40\n{if activate_air_filtration[current_extruder] && support_air_filtration}\nM106 P3 S{during_print_exhaust_fan_speed_num[current_extruder]} \n{endif}"
; filament_tower_interface_pre_extrusion_dist = 10,10
; filament_tower_interface_pre_extrusion_length = 0,0
; filament_tower_interface_print_temp = -1,-1
; filament_tower_interface_purge_volume = 20,20
; filament_tower_ironing_area = 4,4
; filament_type = PLA;PLA
; filament_velocity_adaptation_factor = 1,1
; filament_vendor = "Bambu Lab";"Bambu Lab"
; filament_volume_map = 0,0
; filename_format = {input_filename_base}_{filament_type[0]}_{print_time}.gcode
; fill_multiline = 1
; filter_out_gap_fill = 0
; first_layer_print_sequence = 0
; first_x_layer_fan_speed = 0,0
; first_x_layer_part_fan_speed = 0,0
; flush_into_infill = 0
; flush_into_objects = 0
; flush_into_support = 1
; flush_multiplier = 1
; flush_volumes_matrix = 0,354,224,0
; flush_volumes_vector = 140,140,140,140
; full_fan_speed_layer = 0,0
; fuzzy_skin = none
; fuzzy_skin_first_layer = 0
; fuzzy_skin_mode = displacement
; fuzzy_skin_noise_type = classic
; fuzzy_skin_octaves = 4
; fuzzy_skin_persistence = 0.5
; fuzzy_skin_point_distance = 0.3
; fuzzy_skin_scale = 1
; fuzzy_skin_thickness = 0.2
; gap_infill_speed = 250
; gcode_add_line_number = 0
; gcode_flavor = marlin
; grab_length = 0
; group_algo_with_time = 0
; has_filament_switcher = 0
; has_scarf_joint_seam = 0
; head_wrap_detect_zone = 
; hole_coef_1 = 0,0
; hole_coef_2 = -0.008,-0.008
; hole_coef_3 = 0.23415,0.23415
; hole_limit_max = 0.22,0.22
; hole_limit_min = 0.088,0.088
; host_type = octoprint
; hot_plate_temp = 55,55
; hot_plate_temp_initial_layer = 55,55
; hotend_cooling_rate = 2
; hotend_heating_rate = 2
; impact_strength_z = 13.8,13.8
; independent_support_layer_height = 1
; infill_combination = 0
; infill_direction = 45
; infill_instead_top_bottom_surfaces = 0
; infill_jerk = 9
; infill_lock_depth = 1
; infill_rotate_step = 0
; infill_shift_step = 0.4
; infill_wall_overlap = 15%
; inherits_group = "0.20mm Standard @BBL X1C";;;
; initial_layer_acceleration = 500
; initial_layer_flow_ratio = 1
; initial_layer_infill_speed = 105
; initial_layer_jerk = 9
; initial_layer_line_width = 0.5
; initial_layer_print_height = 0.2
; initial_layer_speed = 50
; initial_layer_travel_acceleration = 6000
; inner_wall_acceleration = 0
; inner_wall_jerk = 9
; inner_wall_line_width = 0.45
; inner_wall_speed = 300
; interface_shells = 0
; interlocking_beam = 0
; interlocking_beam_layer_count = 2
; interlocking_beam_width = 0.8
; interlocking_boundary_avoidance = 2
; interlocking_depth = 2
; interlocking_orientation = 22.5
; internal_bridge_support_thickness = 0.8
; internal_solid_infill_line_width = 0.42
; internal_solid_infill_pattern = zig-zag
; internal_solid_infill_speed = 250
; ironing_direction = 45
; ironing_fan_speed = -1,-1
; ironing_flow = 10%
; ironing_inset = 0.21
; ironing_pattern = zig-zag
; ironing_spacing = 0.15
; ironing_speed = 30
; ironing_type = no ironing
; is_infill_first = 0
; layer_change_gcode = ; layer num/total_layer_count: {layer_num+1}/[total_layer_count]\n; update layer progress\nM73 L{layer_num+1}\nM991 S0 P{layer_num} ;notify layer change
; layer_height = 0.2
; line_width = 0.42
; locked_skeleton_infill_pattern = zigzag
; locked_skin_infill_pattern = crosszag
; long_retractions_when_cut = 0
; long_retractions_when_ec = 0,0
; machine_end_gcode = ;===== date: 20230428 =====================\nM400 ; wait for buffer to clear\nG92 E0 ; zero the extruder\nG1 E-0.8 F1800 ; retract\nG1 Z{max_layer_z + 0.5} F900 ; lower z a little\nG1 X65 Y245 F12000 ; move to safe pos \nG1 Y265 F3000\n\nG1 X65 Y245 F12000\nG1 Y265 F3000\nM140 S0 ; turn off bed\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off remote part cooling fan\nM106 P3 S0 ; turn off chamber cooling fan\n\nG1 X100 F12000 ; wipe\n; pull back filament to AMS\nM620 S255\nG1 X20 Y50 F12000\nG1 Y-3\nT255\nG1 X65 F12000\nG1 Y265\nG1 X100 F12000 ; wipe\nM621 S255\nM104 S0 ; turn off hotend\n\nM622.1 S1 ; for prev firware, default turned on\nM1002 judge_flag timelapse_record_flag\nM622 J1\n    M400 ; wait all motion done\n    M991 S0 P-1 ;end smooth timelapse at safe pos\n    M400 S3 ;wait for last picture to be taken\nM623; end of "timelapse_record_flag"\n\nM400 ; wait all motion done\nM17 S\nM17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom\n{if (max_layer_z + 100.0) < 250}\n    G1 Z{max_layer_z + 100.0} F600\n    G1 Z{max_layer_z +98.0}\n{else}\n    G1 Z250 F600\n    G1 Z248\n{endif}\nM400 P100\nM17 R ; restore z current\n\nM220 S100  ; Reset feedrate magnitude\nM201.2 K1.0 ; Reset acc magnitude\nM73.2   R1.0 ;Reset left time magnitude\nM1002 set_gcode_claim_speed_level : 0\n\nM17 X0.8 Y0.8 Z0.5 ; lower motor current to 45% power\n
; machine_hotend_change_time = 0
; machine_load_filament_time = 29
; machine_max_acceleration_e = 5000,5000
; machine_max_acceleration_extruding = 20000,20000
; machine_max_acceleration_retracting = 5000,5000
; machine_max_acceleration_travel = 9000,9000
; machine_max_acceleration_x = 20000,20000
; machine_max_acceleration_y = 20000,20000
; machine_max_acceleration_z = 500,500
; machine_max_jerk_e = 2.5,2.5
; machine_max_jerk_x = 9,9
; machine_max_jerk_y = 9,9
; machine_max_jerk_z = 3,3
; machine_max_speed_e = 30,30
; machine_max_speed_x = 500,500
; machine_max_speed_y = 500,500
; machine_max_speed_z = 20,20
; machine_min_extruding_rate = 0
; machine_min_travel_rate = 0
; machine_pause_gcode = M400 U1
; machine_prepare_compensation_time = 260
; machine_start_gcode = ;===== machine: P1S-0.4 ========================\n;===== date: 20251031 =====================\n;===== turn on the HB fan & MC board fan =================\nM104 S75 ;set extruder temp to turn on the HB fan and prevent filament oozing from nozzle\nM710 A1 S255 ;turn on MC fan by default(P1S)\n;===== reset machine status =================\nM290 X40 Y40 Z2.6666666\nG91\nM17 Z0.4 ; lower the z-motor current\nG380 S2 Z30 F300 ; G380 is same as G38; lower the hotbed , to prevent the nozzle is below the hotbed\nG380 S2 Z-25 F300 ;\nG1 Z5 F300;\nG90\nM17 X1.2 Y1.2 Z0.75 ; reset motor current to default\nM960 S5 P1 ; turn on logo lamp\nG90\nM220 S100 ;Reset Feedrate\nM221 S100 ;Reset Flowrate\nM73.2   R1.0 ;Reset left time magnitude\nM1002 set_gcode_claim_speed_level : 5\nM221 X0 Y0 Z0 ; turn off soft endstop to prevent protential logic problem\nG29.1 Z{+0.0} ; clear z-trim value first\nM204 S10000 ; init ACC set to 10m/s^2\n\n;===== heatbed preheat ====================\nM1002 gcode_claim_action:54\nM140 S[bed_temperature_initial_layer_single] ;set bed temp\nM190 S[bed_temperature_initial_layer_single] ;wait for bed temp\n\n\n\n;=============turn on fans to prevent PLA jamming=================\n{if filament_type[initial_extruder]=="PLA"}\n    {if (bed_temperature[initial_extruder] >45)||(bed_temperature_initial_layer[initial_extruder] >45)}\n    M106 P3 S180\n    {endif};Prevent PLA from jamming\n{endif}\nM106 P2 S100 ; turn on big fan ,to cool down toolhead\n\n;===== prepare print temperature and material ==========\nM104 S[nozzle_temperature_initial_layer] ;set extruder temp\nG91\nG0 Z10 F1200\nG90\nG28 X\nM975 S1 ; turn on\nG1 X60 F12000\nG1 Y245\nG1 Y265 F3000\nM620 M\nM620 S[initial_extruder]A   ; switch material if AMS exist\n    M109 S[nozzle_temperature_initial_layer]\n    G1 X120 F12000\n\n    G1 X20 Y50 F12000\n    G1 Y-3\n    T[initial_extruder]\n    G1 X54 F12000\n    G1 Y265\n    M400\nM621 S[initial_extruder]A\nM620.1 E F{flush_volumetric_speeds[initial_no_support_extruder]/2.4053*60} T{flush_temperatures[initial_no_support_extruder]}\n\n\nM412 S1 ; ===turn on filament runout detection===\n\nM109 S250 ;set nozzle to common flush temp\nM106 P1 S0\nG92 E0\nG1 E50 F200\nM400\nM104 S[nozzle_temperature_initial_layer]\nG92 E0\nG1 E50 F200\nM400\nM106 P1 S255\nG92 E0\nG1 E5 F300\nM109 S{nozzle_temperature_initial_layer[initial_extruder]-20} ; drop nozzle temp, make filament shink a bit\nG92 E0\nG1 E-0.5 F300\n\nG1 X70 F9000\nG1 X76 F15000\nG1 X65 F15000\nG1 X76 F15000\nG1 X65 F15000; shake to put down garbage\nG1 X80 F6000\nG1 X95 F15000\nG1 X80 F15000\nG1 X165 F15000; wipe and shake\nM400\nM106 P1 S0\n;===== prepare print temperature and material end =====\n\n\n;===== wipe nozzle ===============================\nM1002 gcode_claim_action : 14\nM975 S1\nM106 S255\nG1 X65 Y230 F18000\nG1 Y264 F6000\nM109 S{nozzle_temperature_initial_layer[initial_extruder]-20}\nG1 X100 F18000 ; first wipe mouth\n\nG0 X135 Y253 F20000  ; move to exposed steel surface edge\nG28 Z P0 T300; home z with low precision,permit 300deg temperature\nG29.2 S0 ; turn off ABL\nG0 Z5 F20000\n\nG1 X60 Y265\nG92 E0\nG1 E-0.5 F300 ; retrack more\nG1 X100 F5000; second wipe mouth\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X90 F5000\nG0 X128 Y261 Z-1.5 F20000  ; move to exposed steel surface and stop the nozzle\nM104 S140 ; set temp down to heatbed acceptable\nM106 S255 ; turn on fan (G28 has turn off fan)\n\nM221 S; push soft endstop status\nM221 Z0 ;turn off Z axis endstop\nG0 Z0.5 F20000\nG0 X125 Y259.5 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y262.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y260.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y262.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y260.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y261.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y261.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 X128\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\n\nM109 S140 ; wait nozzle temp down to heatbed acceptable\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\n\nM221 R; pop softend status\nG1 Z10 F1200\nM400\nG1 Z10\nG1 F30000\nG1 X230 Y15\nG29.2 S1 ; turn on ABL\n;G28 ; home again after hard wipe mouth\nM106 S0 ; turn off fan , too noisy\n;===== wipe nozzle end ================================\n\n\n;===== bed leveling ==================================\nM1002 judge_flag g29_before_print_flag\nM622 J1\n\n    M1002 gcode_claim_action : 1\n    G29 A X{first_layer_print_min[0]} Y{first_layer_print_min[1]} I{first_layer_print_size[0]} J{first_layer_print_size[1]}\n    M400\n    M500 ; save cali data\n\nM623\n;===== bed leveling end ================================\n\n;===== home after wipe mouth============================\nM1002 judge_flag g29_before_print_flag\nM622 J0\n\n    M1002 gcode_claim_action : 13\n    G28\n\nM623\n;===== home after wipe mouth end =======================\n\nM975 S1 ; turn on vibration supression\n\n\n;=============turn on fans to prevent PLA jamming=================\n{if filament_type[initial_extruder]=="PLA"}\n    {if (bed_temperature[initial_extruder] >45)||(bed_temperature_initial_layer[initial_extruder] >45)}\n    M106 P3 S180\n    {endif};Prevent PLA from jamming\n{endif}\nM106 P2 S100 ; turn on big fan ,to cool down toolhead\n\n\nM104 S{nozzle_temperature_initial_layer[initial_extruder]} ; set extrude temp earlier, to reduce wait time\n\n;===== mech mode fast check============================\nG1 X128 Y128 Z10 F20000\nM400 P200\nM970.3 Q1 A7 B30 C80  H15 K0\nM974 Q1 S2 P0\n\nG1 X128 Y128 Z10 F20000\nM400 P200\nM970.3 Q0 A7 B30 C90 Q0 H15 K0\nM974 Q0 S2 P0\n\nM975 S1\nG1 F30000\nG1 X230 Y15\nG28 X ; re-home XY\n;===== fmech mode fast check============================\n\n\n;===== nozzle load line ===============================\nM975 S1\nG90\nM83\nT1000\nG1 X18.0 Y1.0 Z0.8 F18000;Move to start position\nM109 S{nozzle_temperature_initial_layer[initial_extruder]}\nG1 Z0.2\nG0 E2 F300\nG0 X240 E15 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nG0 Y11 E0.700 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\nG0 X239.5\nG0 E0.2\nG0 Y1.5 E0.700\nG0 X18 E15 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nM400\n\n;===== for Textured PEI Plate , lower the nozzle as the nozzle was touching topmost of the texture when homing ==\n;curr_bed_type={curr_bed_type}\n{if curr_bed_type=="Textured PEI Plate"}\nG29.1 Z{-0.04} ; for Textured PEI Plate\n{endif}\n;========turn off light and wait extrude temperature =============\nM1002 gcode_claim_action : 0\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off big fan\nM106 P3 S0 ; turn off chamber fan\n\nM975 S1 ; turn on mech mode supression\n
; machine_switch_extruder_time = 0
; machine_unload_filament_time = 28
; master_extruder_id = 1
; max_bridge_length = 0
; max_layer_height = 0.28
; max_travel_detour_distance = 0
; min_bead_width = 85%
; min_feature_size = 25%
; min_layer_height = 0.08
; minimum_sparse_infill_area = 15
; mmu_segmented_region_interlocking_depth = 0
; mmu_segmented_region_max_width = 0
; monotonic_travel_into_wall = 0%
; no_slow_down_for_cooling_on_outwalls = 0,0
; nozzle_diameter = 0.4
; nozzle_flush_dataset = 0
; nozzle_height = 4.2
; nozzle_temperature = 220,220
; nozzle_temperature_initial_layer = 220,220
; nozzle_temperature_range_high = 240,240
; nozzle_temperature_range_low = 190,190
; nozzle_type = stainless_steel
; nozzle_volume = 107
; nozzle_volume_type = Standard
; only_one_wall_first_layer = 0
; ooze_prevention = 0
; other_layers_print_sequence = 0
; other_layers_print_sequence_nums = 0
; outer_wall_acceleration = 5000
; outer_wall_jerk = 9
; outer_wall_line_width = 0.42
; outer_wall_speed = 200
; overhang_1_4_speed = 0
; overhang_2_4_speed = 50
; overhang_3_4_speed = 30
; overhang_4_4_speed = 10
; overhang_fan_speed = 100,100
; overhang_fan_threshold = 50%,50%
; overhang_threshold_participating_cooling = 95%,95%
; overhang_totally_speed = 10
; override_filament_scarf_seam_setting = 0
; override_process_overhang_speed = 0,0
; physical_extruder_map = 0
; post_process = 
; pre_start_fan_time = 0,0
; precise_outer_wall = 0
; precise_z_height = 0
; pressure_advance = 0.02,0.02
; prime_tower_brim_width = 3
; prime_tower_enable_framework = 0
; prime_tower_extra_rib_length = 0
; prime_tower_fillet_wall = 1
; prime_tower_flat_ironing = 0
; prime_tower_infill_gap = 150%
; prime_tower_lift_height = -1
; prime_tower_lift_speed = 90
; prime_tower_max_speed = 90
; prime_tower_rib_wall = 1
; prime_tower_rib_width = 8
; prime_tower_skip_points = 1
; prime_tower_width = 35
; prime_volume_mode = Default
; print_compatible_printers = "Bambu Lab X1 Carbon 0.4 nozzle";"Bambu Lab X1 0.4 nozzle";"Bambu Lab P1S 0.4 nozzle";"Bambu Lab X1E 0.4 nozzle"
; print_extruder_id = 1
; print_extruder_variant = "Direct Drive Standard"
; print_flow_ratio = 1
; print_in_clockwise = 0
; print_sequence = by layer
; print_settings_id = 0.20mm Standard @BBL X1C - Copiar
; printable_area = 0x0,256x0,256x256,0x256
; printable_height = 250
; printer_extruder_id = 1
; printer_extruder_variant = "Direct Drive Standard"
; printer_model = Bambu Lab P1S
; printer_notes = 
; printer_settings_id = Bambu Lab P1S 0.4 nozzle
; printer_structure = corexy
; printer_technology = FFF
; printer_variant = 0.4
; printhost_authorization_type = key
; printhost_ssl_ignore_revoke = 0
; printing_by_object_gcode = 
; process_notes = 
; raft_contact_distance = 0.1
; raft_expansion = 1.5
; raft_first_layer_density = 90%
; raft_first_layer_expansion = -1
; raft_layers = 0
; reduce_crossing_wall = 0
; reduce_fan_stop_start_freq = 1,1
; reduce_infill_retraction_mode = Auto
; required_nozzle_HRC = 3,3
; resolution = 0.012
; retract_before_wipe = 0%
; retract_length_toolchange = 2
; retract_lift_above = 0
; retract_lift_below = 249
; retract_restart_extra = 0
; retract_restart_extra_toolchange = 0
; retract_when_changing_layer = 1
; retraction_distances_when_cut = 18
; retraction_distances_when_ec = 0,0
; retraction_length = 0.8
; retraction_minimum_travel = 1
; retraction_speed = 30
; role_base_wipe_speed = 1
; scan_first_layer = 0
; scarf_angle_threshold = 155
; seam_gap = 15%
; seam_placement_away_from_overhangs = 0
; seam_position = aligned
; seam_slope_conditional = 1
; seam_slope_entire_loop = 0
; seam_slope_gap = 0
; seam_slope_inner_walls = 1
; seam_slope_min_length = 10
; seam_slope_start_height = 10%
; seam_slope_steps = 10
; seam_slope_type = none
; silent_mode = 0
; single_extruder_multi_material = 1
; skeleton_infill_density = 15%
; skeleton_infill_line_width = 0.45
; skin_infill_density = 15%
; skin_infill_depth = 2
; skin_infill_line_width = 0.45
; skirt_distance = 2
; skirt_height = 1
; skirt_loops = 0
; slice_closing_radius = 0.049
; slicing_mode = regular
; slow_down_for_layer_cooling = 1,1
; slow_down_layer_time = 4,4
; slow_down_min_speed = 20,20
; slowdown_end_acc = 100000
; slowdown_end_height = 400
; slowdown_end_speed = 1000
; slowdown_start_acc = 100000
; slowdown_start_height = 0
; slowdown_start_speed = 1000
; small_perimeter_speed = 50%
; small_perimeter_threshold = 0
; smooth_coefficient = 150
; smooth_speed_discontinuity_area = 1
; solid_infill_filament = 0
; sparse_infill_acceleration = 100%
; sparse_infill_anchor = 400%
; sparse_infill_anchor_max = 20
; sparse_infill_density = 15%
; sparse_infill_filament = 0
; sparse_infill_lattice_angle_1 = -45
; sparse_infill_lattice_angle_2 = 45
; sparse_infill_line_width = 0.45
; sparse_infill_pattern = grid
; sparse_infill_speed = 270
; spiral_mode = 0
; spiral_mode_max_xy_smoothing = 200%
; spiral_mode_smooth = 0
; standby_temperature_delta = -5
; start_end_points = 30x-3,54x245
; supertack_plate_temp = 45,45
; supertack_plate_temp_initial_layer = 45,45
; support_air_filtration = 0
; support_angle = 0
; support_base_pattern = default
; support_base_pattern_spacing = 2.5
; support_bottom_interface_spacing = 0.5
; support_bottom_z_distance = 0.2
; support_chamber_temp_control = 0
; support_cooling_filter = 0
; support_critical_regions_only = 0
; support_expansion = 0
; support_filament = 0
; support_interface_bottom_layers = 2
; support_interface_filament = 0
; support_interface_loop_pattern = 0
; support_interface_not_for_body = 1
; support_interface_pattern = auto
; support_interface_spacing = 0.5
; support_interface_speed = 80
; support_interface_top_layers = 2
; support_ironing_direction = 0
; support_ironing_flow = 10%
; support_ironing_inset = 0
; support_ironing_pattern = zig-zag
; support_ironing_spacing = 0.15
; support_ironing_speed = 30
; support_line_width = 0.42
; support_object_first_layer_gap = 0.2
; support_object_skip_flush = 0
; support_object_xy_distance = 0.35
; support_on_build_plate_only = 0
; support_remove_small_overhang = 1
; support_speed = 150
; support_style = default
; support_threshold_angle = 30
; support_top_z_distance = 0.2
; support_type = tree(auto)
; symmetric_infill_y_axis = 0
; temperature_vitrification = 45,45
; template_custom_gcode = 
; textured_plate_temp = 55,55
; textured_plate_temp_initial_layer = 55,55
; thick_bridges = 0
; thumbnail_size = 50x50
; time_lapse_gcode = ;========Date 20250206========\n; SKIPPABLE_START\n; SKIPTYPE: timelapse\nM622.1 S1 ; for prev firmware, default turned on\nM1002 judge_flag timelapse_record_flag\nM622 J1\n{if timelapse_type == 0} ; timelapse without wipe tower\nM971 S11 C10 O0\nM1004 S5 P1  ; external shutter\n{elsif timelapse_type == 1} ; timelapse with wipe tower\nG92 E0\nG1 X65 Y245 F20000 ; move to safe pos\nG17\nG2 Z{layer_z} I0.86 J0.86 P1 F20000\nG1 Y265 F3000\nM400\nM1004 S5 P1  ; external shutter\nM400 P300\nM971 S11 C11 O0\nG92 E0\nG1 X100 F5000\nG1 Y255 F20000\n{endif}\nM623\n; SKIPPABLE_END
; timelapse_type = 0
; top_area_threshold = 200%
; top_color_penetration_layers = 5
; top_one_wall_type = all top
; top_shell_layers = 5
; top_shell_thickness = 1
; top_solid_infill_flow_ratio = 1
; top_surface_acceleration = 2000
; top_surface_density = 100%
; top_surface_jerk = 9
; top_surface_line_width = 0.42
; top_surface_pattern = monotonicline
; top_surface_speed = 200
; top_z_overrides_xy_distance = 0
; travel_acceleration = 10000
; travel_jerk = 9
; travel_short_distance_acceleration = 250
; travel_speed = 500
; travel_speed_z = 0
; tree_support_branch_angle = 45
; tree_support_branch_diameter = 2
; tree_support_branch_diameter_angle = 5
; tree_support_branch_distance = 5
; tree_support_wall_count = -1
; upward_compatible_machine = "Bambu Lab P1P 0.4 nozzle";"Bambu Lab X1 0.4 nozzle";"Bambu Lab X1 Carbon 0.4 nozzle";"Bambu Lab X1E 0.4 nozzle";"Bambu Lab A1 0.4 nozzle";"Bambu Lab H2D 0.4 nozzle";"Bambu Lab H2D Pro 0.4 nozzle";"Bambu Lab H2S 0.4 nozzle";"Bambu Lab P2S 0.4 nozzle";"Bambu Lab H2C 0.4 nozzle";"Bambu Lab X2D 0.4 nozzle"
; use_firmware_retraction = 0
; use_relative_e_distances = 1
; vertical_shell_speed = 80%
; volumetric_speed_coefficients = "0 0 0 0 0 0";"0 0 0 0 0 0"
; wall_distribution_count = 1
; wall_filament = 0
; wall_generator = classic
; wall_loops = 2
; wall_sequence = inner wall/outer wall
; wall_transition_angle = 10
; wall_transition_filter_deviation = 25%
; wall_transition_length = 100%
; wipe = 1
; wipe_distance = 2
; wipe_speed = 80%
; wipe_tower_no_sparse_layers = 0
; wipe_tower_rotation_angle = 0
; wipe_tower_x = 165
; wipe_tower_y = 220.697
; wrapping_detection_gcode = 
; wrapping_detection_layers = 20
; wrapping_exclude_area = 
; xy_contour_compensation = 0
; xy_hole_compensation = 0
; z_direction_outwall_speed_continuous = 0
; z_hop = 0.4
; z_hop_types = Auto Lift
; CONFIG_BLOCK_END

; EXECUTABLE_BLOCK_START
M73 P0 R51
M201 X20000 Y20000 Z500 E5000
M203 X500 Y500 Z20 E30
M204 P20000 R5000 T20000
M205 X9.00 Y9.00 Z3.00 E2.50
M106 S0
M106 P2 S0
; FEATURE: Custom
;===== machine: P1S-0.4 ========================
;===== date: 20251031 =====================
;===== turn on the HB fan & MC board fan =================
M104 S75 ;set extruder temp to turn on the HB fan and prevent filament oozing from nozzle
M710 A1 S255 ;turn on MC fan by default(P1S)
;===== reset machine status =================
M290 X40 Y40 Z2.6666666
G91
M17 Z0.4 ; lower the z-motor current
G380 S2 Z30 F300 ; G380 is same as G38; lower the hotbed , to prevent the nozzle is below the hotbed
G380 S2 Z-25 F300 ;
G1 Z5 F300;
G90
M17 X1.2 Y1.2 Z0.75 ; reset motor current to default
M960 S5 P1 ; turn on logo lamp
G90
M220 S100 ;Reset Feedrate
M221 S100 ;Reset Flowrate
M73.2   R1.0 ;Reset left time magnitude
M1002 set_gcode_claim_speed_level : 5
M221 X0 Y0 Z0 ; turn off soft endstop to prevent protential logic problem
G29.1 Z0 ; clear z-trim value first
M204 S10000 ; init ACC set to 10m/s^2

;===== heatbed preheat ====================
M1002 gcode_claim_action:54
M140 S55 ;set bed temp
M190 S55 ;wait for bed temp



;=============turn on fans to prevent PLA jamming=================

    
    M106 P3 S180
    ;Prevent PLA from jamming

M106 P2 S100 ; turn on big fan ,to cool down toolhead

;===== prepare print temperature and material ==========
M104 S220 ;set extruder temp
G91
G0 Z10 F1200
G90
G28 X
M975 S1 ; turn on
G1 X60 F12000
G1 Y245
G1 Y265 F3000
M620 M
M620 S1A   ; switch material if AMS exist
    M109 S220
    G1 X120 F12000

    G1 X20 Y50 F12000
    G1 Y-3
    T1
    G1 X54 F12000
    G1 Y265
    M400
M621 S1A
M620.1 E F523.843 T240


M412 S1 ; ===turn on filament runout detection===

M109 S250 ;set nozzle to common flush temp
M106 P1 S0
G92 E0
M73 P1 R50
G1 E50 F200
M400
M104 S220
G92 E0
M73 P9 R46
G1 E50 F200
M400
M106 P1 S255
G92 E0
G1 E5 F300
M109 S200 ; drop nozzle temp, make filament shink a bit
G92 E0
M73 P10 R45
G1 E-0.5 F300

G1 X70 F9000
G1 X76 F15000
G1 X65 F15000
G1 X76 F15000
G1 X65 F15000; shake to put down garbage
G1 X80 F6000
G1 X95 F15000
G1 X80 F15000
G1 X165 F15000; wipe and shake
M400
M106 P1 S0
;===== prepare print temperature and material end =====


;===== wipe nozzle ===============================
M1002 gcode_claim_action : 14
M975 S1
M106 S255
G1 X65 Y230 F18000
G1 Y264 F6000
M109 S200
G1 X100 F18000 ; first wipe mouth

G0 X135 Y253 F20000  ; move to exposed steel surface edge
G28 Z P0 T300; home z with low precision,permit 300deg temperature
G29.2 S0 ; turn off ABL
G0 Z5 F20000

G1 X60 Y265
G92 E0
G1 E-0.5 F300 ; retrack more
G1 X100 F5000; second wipe mouth
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X90 F5000
G0 X128 Y261 Z-1.5 F20000  ; move to exposed steel surface and stop the nozzle
M104 S140 ; set temp down to heatbed acceptable
M106 S255 ; turn on fan (G28 has turn off fan)

M221 S; push soft endstop status
M221 Z0 ;turn off Z axis endstop
G0 Z0.5 F20000
G0 X125 Y259.5 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y262.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y260.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y262.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y260.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y261.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y261.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 X128
G2 I0.5 J0 F300
G2 I0.5 J0 F300
G2 I0.5 J0 F300
G2 I0.5 J0 F300

M109 S140 ; wait nozzle temp down to heatbed acceptable
G2 I0.5 J0 F3000
G2 I0.5 J0 F3000
G2 I0.5 J0 F3000
G2 I0.5 J0 F3000

M221 R; pop softend status
G1 Z10 F1200
M400
G1 Z10
G1 F30000
G1 X230 Y15
G29.2 S1 ; turn on ABL
;G28 ; home again after hard wipe mouth
M106 S0 ; turn off fan , too noisy
;===== wipe nozzle end ================================


;===== bed leveling ==================================
M1002 judge_flag g29_before_print_flag
M622 J1

    M1002 gcode_claim_action : 1
    G29 A X28 Y93 I200 J70
    M400
    M500 ; save cali data

M623
;===== bed leveling end ================================

;===== home after wipe mouth============================
M1002 judge_flag g29_before_print_flag
M622 J0

    M1002 gcode_claim_action : 13
    G28

M623
;===== home after wipe mouth end =======================

M975 S1 ; turn on vibration supression


;=============turn on fans to prevent PLA jamming=================

    
    M106 P3 S180
    ;Prevent PLA from jamming

M106 P2 S100 ; turn on big fan ,to cool down toolhead


M104 S220 ; set extrude temp earlier, to reduce wait time

;===== mech mode fast check============================
G1 X128 Y128 Z10 F20000
M400 P200
M970.3 Q1 A7 B30 C80  H15 K0
M974 Q1 S2 P0

G1 X128 Y128 Z10 F20000
M400 P200
M970.3 Q0 A7 B30 C90 Q0 H15 K0
M974 Q0 S2 P0

M975 S1
M73 P11 R45
G1 F30000
G1 X230 Y15
G28 X ; re-home XY
;===== fmech mode fast check============================


;===== nozzle load line ===============================
M975 S1
G90
M83
T1000
G1 X18.0 Y1.0 Z0.8 F18000;Move to start position
M109 S220
G1 Z0.2
G0 E2 F300
G0 X240 E15 F6033.27
G0 Y11 E0.700 F1508.32
G0 X239.5
G0 E0.2
G0 Y1.5 E0.700
G0 X18 E15 F6033.27
M400

;===== for Textured PEI Plate , lower the nozzle as the nozzle was touching topmost of the texture when homing ==
;curr_bed_type=Textured PEI Plate

G29.1 Z-0.04 ; for Textured PEI Plate

;========turn off light and wait extrude temperature =============
M1002 gcode_claim_action : 0
M106 S0 ; turn off fan
M106 P2 S0 ; turn off big fan
M106 P3 S0 ; turn off chamber fan

M975 S1 ; turn on mech mode supression
; MACHINE_START_GCODE_END
; filament start gcode
M106 P3 S150

M142 P1 R35 S40
;VT1 H-1
G90
G21
M83 ; use relative distances for extrusion
M981 S1 P20000 ;open spaghetti detector
; CHANGE_LAYER
; Z_HEIGHT: 0.2
; LAYER_HEIGHT: 0.2
G1 E-.8 F1800
; layer num/total_layer_count: 1/25
; update layer progress
M73 L1
M991 S0 P0 ;notify layer change
M106 S0
M106 P2 S0
M204 S6000
G1 Z.4 F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.857 Y141.4
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.5
G1 F3000
M204 S500
G1 X110.857 Y141.857 E.01702
G1 X99.143 Y141.857 E.43631
G1 X99.143 Y110.143 E1.18123
G1 X110.857 Y110.143 E.43631
G1 X110.857 Y141.34 E1.16197
M204 S6000
G1 X110.4 Y141.4 F30000
; FEATURE: Outer wall
G1 F3000
M204 S500
G1 X99.6 Y141.4 E.40226
G1 X99.6 Y110.6 E1.14718
G1 X110.4 Y110.6 E.40226
G1 X110.4 Y141.34 E1.14495
; WIPE_START
G1 X108.4 Y141.351 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X101.092 Y139.149 Z.6 F30000
G1 X51.029 Y124.062 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F3000
M204 S500
G1 X51.033 Y124.034 E.00105
G3 X60.478 Y115.212 I10.679 J1.967 E.51554
G1 X60.962 Y115.179 E.01807
G3 X55.86 Y135.146 I.748 J10.827 E1.52785
G3 X52.434 Y131.642 I6.201 J-9.489 E.184
G3 X50.899 Y125.013 I9.279 J-5.641 E.25777
G1 X51.021 Y124.121 E.03352
M204 S6000
G1 X51.482 Y124.124 F30000
; FEATURE: Outer wall
G1 F3000
M204 S500
G1 X51.489 Y124.118 E.00037
G3 X60.53 Y115.667 I10.225 J1.877 E.49369
G1 X60.993 Y115.635 E.01729
G3 X70.834 Y121.006 I.735 J10.354 E.44112
G1 X71.25 Y121.856 E.03526
G3 X51.361 Y125.055 I-9.536 J4.138 E1.41
G1 X51.474 Y124.183 E.03274
; WIPE_START
G1 X51.489 Y124.118 E-.02564
G1 X51.696 Y123.194 E-.35967
M73 P12 R45
G1 X51.987 Y122.312 E-.35273
G1 X52.01 Y122.259 E-.02196
; WIPE_END
M73 P12 R44
G1 E-.04 F1800
M204 S6000
G1 X59.543 Y121.032 Z.6 F30000
G1 X223.305 Y94.356 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F3000
M204 S500
G1 X223.463 Y94.676 E.0133
G2 X226.685 Y95.539 I2.044 J-1.183 E.13796
G1 X227.146 Y95.207 E.02116
G1 X227.143 Y160.143 E2.41861
G1 X28.857 Y160.143 E7.3854
G1 X28.854 Y95.204 E2.41873
G1 X29.319 Y95.541 E.02139
G2 X32.538 Y92.313 I1.175 J-2.048 E.22994
G1 X32.199 Y91.849 E.0214
G2 X32.987 Y91.857 I.611 J-21.381 E.02932
G1 X222.514 Y91.857 E7.05919
G2 X223.801 Y91.849 I.444 J-30.63 E.04793
G1 X223.462 Y92.313 E.02141
G2 X223.287 Y94.298 I2.045 J1.18 E.07663
M204 S6000
G1 X223.719 Y94.163 F30000
; FEATURE: Outer wall
G1 F3000
M204 S500
G1 X223.713 Y94.15 E.00051
G3 X223.628 Y93.169 I1.783 J-.65 E.03709
G3 X225.211 Y91.741 I1.671 J.261 E.08594
G3 X225.789 Y91.741 I.289 J3.299 E.02154
G3 X227.118 Y92.594 I-.045 J1.532 E.06181
G3 X227.259 Y93.789 I-2.694 J.924 E.04514
G3 X226.725 Y94.947 I-1.668 J-.067 E.04874
G3 X223.854 Y94.45 I-1.228 J-1.447 E.12373
G1 X223.744 Y94.217 E.0096
; WIPE_START
G1 X223.713 Y94.15 E-.028
G1 X223.627 Y93.83 E-.12596
G1 X223.598 Y93.5 E-.12595
G1 X223.628 Y93.169 E-.12603
G1 X223.714 Y92.849 E-.12612
G1 X223.857 Y92.547 E-.12673
G1 X224.014 Y92.332 E-.10122
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X216.382 Y92.405 Z.6 F30000
G1 X32.283 Y94.157 Z.6
G1 Z.2
G1 E.8 F1800
G1 F3000
M204 S500
G1 X32.141 Y94.447 E.01201
G3 X30.5 Y95.401 I-1.649 J-.945 E.07405
G3 X28.879 Y94.403 I-.019 J-1.784 E.07478
G3 X28.882 Y92.594 I2.573 J-.9 E.06868
G3 X30.211 Y91.741 I1.374 J.678 E.0618
G3 X30.789 Y91.741 I.289 J3.299 E.02154
G3 X31.946 Y92.277 I-.08 J1.69 E.04869
G3 X32.296 Y94.099 I-1.453 J1.224 E.07223
; WIPE_START
G1 X32.141 Y94.447 E-.14446
G1 X31.957 Y94.722 E-.12603
G1 X31.722 Y94.957 E-.12592
G1 X31.451 Y95.147 E-.12593
G1 X31.15 Y95.287 E-.12605
G1 X30.866 Y95.363 E-.11161
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X38.497 Y95.209 Z.6 F30000
G1 X227.601 Y91.399 Z.6
G1 Z.2
G1 E.8 F1800
G1 F3000
M204 S500
G2 X227.702 Y93.007 I19.53 J-.419 E.06003
G3 X227.65 Y94.452 I-6.437 J.491 E.05399
G2 X227.6 Y95.964 I16.897 J1.315 E.05636
G1 X227.6 Y160.6 E2.40744
G1 X28.4 Y160.6 E7.41944
G1 X28.4 Y95.964 E2.40744
G2 X28.294 Y93.959 I-18.573 J-.022 E.07483
G3 X28.354 Y92.512 I6.785 J-.443 E.05404
G2 X28.399 Y91.399 I-15.653 J-1.186 E.04151
G2 X30.016 Y91.297 I-.434 J-19.754 E.06036
G3 X30.972 Y91.295 I.485 J4.783 E.03569
G2 X32.987 Y91.4 I1.972 J-18.501 E.07518
G1 X222.514 Y91.4 E7.05916
G2 X225.028 Y91.295 I.418 J-20.175 E.09377
G3 X226.481 Y91.353 I.461 J6.715 E.05429
G2 X227.541 Y91.398 I1.196 J-15.613 E.03953
M204 S6000
G1 X227.152 Y91.619 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.131691
G1 F3000
M204 S500
G1 X227.405 Y92.654 E.0077
M204 S6000
G1 X227.419 Y92.54 F30000
; LINE_WIDTH: 0.356931
G1 F3000
M204 S500
G2 X227.04 Y91.617 I-10.09 J3.605 E.02554
M204 S6000
G1 X226.46 Y91.581 F30000
; LINE_WIDTH: 0.355275
G1 F3000
M204 S500
G3 X227.383 Y91.96 I-3.587 J10.04 E.02539
M204 S6000
G1 X227.38 Y91.848 F30000
; LINE_WIDTH: 0.132022
G1 F3000
M204 S500
G1 X226.345 Y91.595 E.00774
; WIPE_START
G1 X227.38 Y91.848 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X224.648 Y91.596 Z.6 F30000
G1 Z.2
G1 E.8 F1800
; LINE_WIDTH: 0.125512
G1 F3000
M204 S500
G1 X224.555 Y91.615 E.00064
G2 X224.192 Y91.7 I.557 J3.178 E.00251
M204 S6000
G1 X224.385 Y91.591 F30000
; LINE_WIDTH: 0.118714
G1 F3000
M204 S500
G2 X224.065 Y91.921 I2.882 J3.121 E.00284
; WIPE_START
G1 X224.385 Y91.591 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X222.539 Y92.032 Z.6 F30000
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.5
G1 F6300
M204 S500
G1 X222.964 Y92.457 E.02239
G1 X222.917 Y92.556 E.00408
G1 X222.811 Y92.95 E.0152
G1 X222.098 Y92.237 E.03754
G1 X221.452 Y92.237 E.02408
G1 X222.979 Y93.765 E.08045
; WIPE_START
G1 X221.565 Y92.35 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X226.389 Y95.881 Z.6 F30000
G1 Z.2
M73 P13 R44
G1 E.8 F1800
G1 F6300
M204 S500
G1 X226.757 Y96.25 E.0194
G1 X226.757 Y96.896 E.02408
G1 X226.05 Y96.189 E.03725
G1 X225.978 Y96.208 E.00278
G1 X225.462 Y96.247 E.01928
G1 X226.757 Y97.543 E.06825
G1 X226.757 Y98.189 E.02408
G1 X224.687 Y96.119 E.10905
G1 X224.566 Y96.086 E.00465
G3 X222.881 Y94.313 I.914 J-2.556 E.09452
G1 X220.806 Y92.237 E.10934
G1 X220.159 Y92.237 E.02408
G1 X226.757 Y98.835 E.34755
G1 X226.757 Y99.482 E.02407
G1 X219.513 Y92.237 E.3816
G1 X218.866 Y92.237 E.02408
G1 X226.757 Y100.128 E.41565
G1 X226.757 Y100.774 E.02407
G1 X218.22 Y92.237 E.44969
G1 X217.574 Y92.237 E.02408
G1 X226.757 Y101.421 E.48374
G1 X226.757 Y102.067 E.02408
G1 X216.927 Y92.237 E.51779
G1 X216.281 Y92.237 E.02408
G1 X226.757 Y102.714 E.55184
G1 X226.757 Y103.36 E.02408
G1 X215.634 Y92.237 E.58588
G1 X214.988 Y92.237 E.02408
G1 X226.757 Y104.006 E.61993
G1 X226.757 Y104.653 E.02407
G1 X214.341 Y92.237 E.65398
G1 X213.695 Y92.237 E.02408
G1 X226.757 Y105.299 E.68803
G1 X226.757 Y105.946 E.02408
G1 X213.049 Y92.237 E.72207
G1 X212.402 Y92.237 E.02408
G1 X226.757 Y106.592 E.75612
G1 X226.757 Y107.238 E.02408
G1 X211.756 Y92.237 E.79017
G1 X211.109 Y92.237 E.02408
G1 X226.757 Y107.885 E.82422
G1 X226.757 Y108.531 E.02407
G1 X210.463 Y92.237 E.85826
G1 X209.817 Y92.237 E.02408
G1 X226.757 Y109.177 E.89231
G1 X226.757 Y109.824 E.02408
G1 X209.17 Y92.237 E.92636
G1 X208.524 Y92.237 E.02408
G1 X226.757 Y110.47 E.9604
G1 X226.757 Y111.117 E.02408
G1 X207.877 Y92.237 E.99445
G1 X207.231 Y92.237 E.02408
G1 X226.757 Y111.763 E1.0285
G1 X226.757 Y112.409 E.02407
G1 X206.585 Y92.237 E1.06255
G1 X205.938 Y92.237 E.02408
G1 X226.757 Y113.056 E1.09659
G1 X226.757 Y113.702 E.02408
G1 X205.292 Y92.237 E1.13064
G1 X204.645 Y92.237 E.02408
G1 X226.757 Y114.348 E1.16469
G1 X226.757 Y114.995 E.02408
G1 X203.999 Y92.237 E1.19874
G1 X203.353 Y92.237 E.02408
G1 X226.757 Y115.641 E1.23278
G1 X226.756 Y116.288 E.02408
G1 X202.706 Y92.237 E1.26683
G1 X202.06 Y92.237 E.02408
G1 X226.756 Y116.934 E1.30088
G1 X226.756 Y117.58 E.02407
G1 X201.413 Y92.237 E1.33493
G1 X200.767 Y92.237 E.02408
G1 X226.756 Y118.227 E1.36897
G1 X226.756 Y118.873 E.02408
G1 X200.121 Y92.237 E1.40302
G1 X199.474 Y92.237 E.02408
G1 X226.756 Y119.519 E1.43707
G1 X226.756 Y120.166 E.02408
G1 X198.828 Y92.237 E1.47112
G1 X198.181 Y92.237 E.02408
G1 X226.756 Y120.812 E1.50516
G1 X226.756 Y121.459 E.02407
G1 X197.535 Y92.237 E1.53921
G1 X196.888 Y92.237 E.02408
G1 X226.756 Y122.105 E1.57326
G1 X226.756 Y122.751 E.02408
G1 X196.242 Y92.237 E1.6073
G1 X195.596 Y92.237 E.02408
G1 X226.756 Y123.398 E1.64135
G1 X226.756 Y124.044 E.02408
G1 X194.949 Y92.237 E1.6754
G1 X194.303 Y92.237 E.02408
G1 X226.756 Y124.69 E1.70945
G1 X226.756 Y125.337 E.02407
G1 X193.656 Y92.237 E1.74349
G1 X193.01 Y92.237 E.02408
G1 X226.756 Y125.983 E1.77754
G1 X226.756 Y126.63 E.02408
G1 X192.364 Y92.237 E1.81159
G1 X191.717 Y92.237 E.02408
G1 X226.756 Y127.276 E1.84564
G1 X226.756 Y127.922 E.02408
G1 X191.071 Y92.237 E1.87968
G1 X190.424 Y92.237 E.02408
G1 X226.756 Y128.569 E1.91373
G1 X226.756 Y129.215 E.02408
G1 X189.778 Y92.237 E1.94778
G1 X189.132 Y92.237 E.02408
G1 X226.756 Y129.862 E1.98183
G1 X226.756 Y130.508 E.02408
G1 X188.485 Y92.237 E2.01587
G1 X187.839 Y92.237 E.02408
G1 X226.756 Y131.154 E2.04992
G1 X226.756 Y131.801 E.02408
G1 X187.192 Y92.237 E2.08397
G1 X186.546 Y92.237 E.02408
G1 X226.756 Y132.447 E2.11801
G1 X226.756 Y133.093 E.02408
G1 X185.9 Y92.237 E2.15206
G1 X185.253 Y92.237 E.02408
G1 X226.756 Y133.74 E2.18611
G1 X226.756 Y134.386 E.02408
G1 X184.607 Y92.237 E2.22016
G1 X183.96 Y92.237 E.02408
G1 X226.756 Y135.033 E2.2542
G1 X226.756 Y135.679 E.02408
G1 X183.314 Y92.237 E2.28825
G1 X182.668 Y92.237 E.02408
G1 X226.756 Y136.325 E2.3223
G1 X226.756 Y136.972 E.02408
G1 X182.021 Y92.237 E2.35635
G1 X181.375 Y92.237 E.02408
G1 X226.755 Y137.618 E2.39039
G1 X226.755 Y138.264 E.02408
G1 X180.728 Y92.237 E2.42444
G1 X180.082 Y92.237 E.02408
G1 X226.755 Y138.911 E2.45849
G1 X226.755 Y139.557 E.02408
G1 X179.435 Y92.237 E2.49254
G1 X178.789 Y92.237 E.02408
G1 X226.755 Y140.204 E2.52658
G1 X226.755 Y140.85 E.02408
G1 X178.143 Y92.237 E2.56063
G1 X177.496 Y92.237 E.02408
G1 X226.755 Y141.496 E2.59468
G1 X226.755 Y142.143 E.02408
G1 X176.85 Y92.237 E2.62872
M73 P13 R43
G1 X176.203 Y92.237 E.02408
G1 X226.755 Y142.789 E2.66277
M73 P14 R43
G1 X226.755 Y143.435 E.02408
G1 X175.557 Y92.237 E2.69682
G1 X174.911 Y92.237 E.02408
G1 X226.755 Y144.082 E2.73087
G1 X226.755 Y144.728 E.02408
G1 X174.264 Y92.237 E2.76491
G1 X173.618 Y92.237 E.02408
G1 X226.755 Y145.375 E2.79896
G1 X226.755 Y146.021 E.02408
G1 X172.971 Y92.237 E2.83301
G1 X172.325 Y92.237 E.02408
G1 X226.755 Y146.667 E2.86706
G1 X226.755 Y147.314 E.02408
G1 X171.679 Y92.237 E2.9011
G1 X171.032 Y92.237 E.02408
G1 X226.755 Y147.96 E2.93515
G1 X226.755 Y148.606 E.02408
G1 X170.386 Y92.237 E2.9692
G1 X169.739 Y92.237 E.02408
G1 X226.755 Y149.253 E3.00325
G1 X226.755 Y149.899 E.02407
G1 X169.093 Y92.237 E3.03729
G1 X168.447 Y92.237 E.02408
G1 X226.755 Y150.546 E3.07134
G1 X226.755 Y151.192 E.02408
G1 X167.8 Y92.237 E3.10539
G1 X167.154 Y92.237 E.02408
G1 X226.755 Y151.838 E3.13943
G1 X226.755 Y152.485 E.02408
G1 X166.507 Y92.237 E3.17348
G1 X165.861 Y92.237 E.02408
G1 X226.755 Y153.131 E3.20753
G1 X226.755 Y153.777 E.02407
G1 X165.214 Y92.237 E3.24158
G1 X164.568 Y92.237 E.02408
G1 X226.755 Y154.424 E3.27562
G1 X226.755 Y155.07 E.02408
G1 X163.922 Y92.237 E3.30967
G1 X163.275 Y92.237 E.02408
G1 X226.755 Y155.717 E3.34372
G1 X226.755 Y156.363 E.02408
G1 X162.629 Y92.237 E3.37777
G1 X161.982 Y92.237 E.02408
G1 X226.755 Y157.009 E3.41181
G1 X226.755 Y157.656 E.02408
G1 X161.336 Y92.237 E3.44586
G1 X160.69 Y92.237 E.02408
G1 X226.754 Y158.302 E3.47991
G1 X226.754 Y158.949 E.02407
G1 X160.043 Y92.237 E3.51396
G1 X159.397 Y92.237 E.02408
G1 X226.754 Y159.595 E3.548
G1 X226.754 Y159.754 E.00594
G1 X226.268 Y159.754 E.01813
G1 X158.75 Y92.237 E3.55641
G1 X158.104 Y92.237 E.02408
G1 X225.621 Y159.754 E3.55641
G1 X224.975 Y159.754 E.02408
G1 X157.458 Y92.237 E3.55641
G1 X156.811 Y92.237 E.02408
G1 X224.328 Y159.754 E3.55641
G1 X223.682 Y159.754 E.02408
G1 X156.165 Y92.237 E3.55641
G1 X155.518 Y92.237 E.02408
G1 X223.035 Y159.754 E3.55641
G1 X222.389 Y159.754 E.02408
G1 X154.872 Y92.237 E3.55641
G1 X154.226 Y92.237 E.02408
G1 X221.743 Y159.754 E3.55641
G1 X221.096 Y159.754 E.02408
G1 X153.579 Y92.237 E3.5564
G1 X152.933 Y92.237 E.02408
G1 X220.45 Y159.754 E3.5564
G1 X219.803 Y159.754 E.02408
M73 P15 R43
G1 X152.286 Y92.237 E3.5564
G1 X151.64 Y92.237 E.02408
G1 X219.157 Y159.754 E3.5564
G1 X218.511 Y159.754 E.02408
G1 X150.994 Y92.237 E3.5564
G1 X150.347 Y92.237 E.02408
G1 X217.864 Y159.754 E3.5564
G1 X217.218 Y159.754 E.02408
G1 X149.701 Y92.237 E3.5564
G1 X149.054 Y92.237 E.02408
G1 X216.571 Y159.754 E3.5564
G1 X215.925 Y159.754 E.02408
G1 X148.408 Y92.237 E3.5564
G1 X147.761 Y92.237 E.02408
G1 X215.279 Y159.754 E3.5564
G1 X214.632 Y159.754 E.02408
G1 X147.115 Y92.237 E3.5564
G1 X146.469 Y92.237 E.02408
G1 X213.986 Y159.754 E3.5564
G1 X213.339 Y159.754 E.02408
G1 X145.822 Y92.237 E3.5564
G1 X145.176 Y92.237 E.02408
G1 X212.693 Y159.754 E3.5564
G1 X212.047 Y159.754 E.02408
G1 X144.529 Y92.237 E3.5564
G1 X143.883 Y92.237 E.02408
G1 X211.4 Y159.754 E3.5564
G1 X210.754 Y159.754 E.02408
G1 X143.237 Y92.237 E3.5564
G1 X142.59 Y92.237 E.02408
G1 X210.107 Y159.754 E3.5564
G1 X209.461 Y159.754 E.02408
G1 X141.944 Y92.237 E3.5564
G1 X141.297 Y92.237 E.02408
G1 X208.815 Y159.754 E3.5564
G1 X208.168 Y159.754 E.02408
G1 X140.651 Y92.237 E3.5564
G1 X140.005 Y92.237 E.02408
G1 X207.522 Y159.754 E3.5564
G1 X206.875 Y159.754 E.02408
G1 X139.358 Y92.237 E3.5564
G1 X138.712 Y92.237 E.02408
G1 X206.229 Y159.754 E3.5564
G1 X205.582 Y159.754 E.02408
G1 X138.065 Y92.237 E3.5564
G1 X137.419 Y92.237 E.02408
G1 X204.936 Y159.754 E3.5564
G1 X204.29 Y159.754 E.02408
G1 X136.773 Y92.237 E3.5564
G1 X136.126 Y92.237 E.02408
G1 X203.643 Y159.754 E3.5564
G1 X202.997 Y159.754 E.02408
G1 X135.48 Y92.237 E3.5564
M73 P15 R42
G1 X134.833 Y92.237 E.02408
G1 X202.35 Y159.754 E3.5564
G1 X201.704 Y159.754 E.02408
G1 X134.187 Y92.237 E3.5564
M73 P16 R42
G1 X133.541 Y92.237 E.02408
G1 X201.058 Y159.754 E3.5564
G1 X200.411 Y159.754 E.02408
G1 X132.894 Y92.237 E3.5564
G1 X132.248 Y92.237 E.02408
G1 X199.765 Y159.754 E3.5564
G1 X199.118 Y159.754 E.02408
G1 X131.601 Y92.237 E3.5564
G1 X130.955 Y92.237 E.02408
G1 X198.472 Y159.754 E3.5564
G1 X197.826 Y159.754 E.02408
G1 X130.308 Y92.237 E3.5564
G1 X129.662 Y92.237 E.02408
G1 X197.179 Y159.754 E3.5564
G1 X196.533 Y159.754 E.02408
G1 X129.016 Y92.237 E3.5564
G1 X128.369 Y92.237 E.02408
G1 X195.886 Y159.754 E3.5564
G1 X195.24 Y159.754 E.02408
G1 X127.723 Y92.237 E3.5564
G1 X127.076 Y92.237 E.02408
G1 X194.594 Y159.754 E3.5564
G1 X193.947 Y159.754 E.02408
G1 X126.43 Y92.237 E3.5564
G1 X125.784 Y92.237 E.02408
G1 X193.301 Y159.754 E3.5564
G1 X192.654 Y159.754 E.02408
G1 X125.137 Y92.237 E3.5564
G1 X124.491 Y92.237 E.02408
G1 X192.008 Y159.754 E3.5564
G1 X191.361 Y159.754 E.02408
G1 X123.844 Y92.237 E3.5564
G1 X123.198 Y92.237 E.02408
G1 X190.715 Y159.754 E3.5564
G1 X190.069 Y159.754 E.02408
G1 X122.552 Y92.237 E3.5564
G1 X121.905 Y92.237 E.02408
G1 X189.422 Y159.754 E3.5564
G1 X188.776 Y159.754 E.02408
G1 X121.259 Y92.237 E3.5564
G1 X120.612 Y92.237 E.02408
G1 X188.129 Y159.754 E3.5564
G1 X187.483 Y159.754 E.02408
G1 X119.966 Y92.237 E3.5564
G1 X119.32 Y92.237 E.02408
G1 X186.837 Y159.754 E3.5564
G1 X186.19 Y159.754 E.02408
G1 X118.673 Y92.237 E3.5564
G1 X118.027 Y92.237 E.02408
G1 X185.544 Y159.754 E3.5564
G1 X184.897 Y159.754 E.02408
G1 X117.38 Y92.237 E3.5564
G1 X116.734 Y92.237 E.02408
G1 X184.251 Y159.754 E3.5564
G1 X183.605 Y159.754 E.02408
G1 X116.088 Y92.237 E3.5564
M73 P17 R42
G1 X115.441 Y92.237 E.02408
G1 X182.958 Y159.754 E3.5564
G1 X182.312 Y159.754 E.02408
G1 X114.795 Y92.237 E3.5564
G1 X114.148 Y92.237 E.02408
G1 X181.665 Y159.754 E3.5564
G1 X181.019 Y159.754 E.02408
G1 X113.502 Y92.237 E3.5564
G1 X112.855 Y92.237 E.02408
G1 X180.373 Y159.754 E3.5564
G1 X179.726 Y159.754 E.02408
G1 X112.209 Y92.237 E3.5564
G1 X111.563 Y92.237 E.02408
G1 X179.08 Y159.754 E3.5564
G1 X178.433 Y159.754 E.02408
G1 X110.916 Y92.237 E3.5564
G1 X110.27 Y92.237 E.02408
G1 X177.787 Y159.754 E3.5564
G1 X177.14 Y159.754 E.02408
G1 X109.623 Y92.237 E3.5564
G1 X108.977 Y92.237 E.02408
G1 X176.494 Y159.754 E3.5564
G1 X175.848 Y159.754 E.02408
G1 X108.331 Y92.237 E3.5564
G1 X107.684 Y92.237 E.02408
G1 X175.201 Y159.754 E3.5564
G1 X174.555 Y159.754 E.02408
G1 X107.038 Y92.237 E3.5564
G1 X106.391 Y92.237 E.02408
G1 X173.908 Y159.754 E3.5564
G1 X173.262 Y159.754 E.02408
G1 X105.745 Y92.237 E3.5564
G1 X105.099 Y92.237 E.02408
G1 X172.616 Y159.754 E3.5564
G1 X171.969 Y159.754 E.02408
G1 X104.452 Y92.237 E3.5564
G1 X103.806 Y92.237 E.02408
G1 X171.323 Y159.754 E3.5564
G1 X170.676 Y159.754 E.02408
G1 X103.159 Y92.237 E3.5564
G1 X102.513 Y92.237 E.02408
G1 X170.03 Y159.754 E3.5564
G1 X169.384 Y159.754 E.02408
G1 X101.867 Y92.237 E3.5564
G1 X101.22 Y92.237 E.02408
G1 X168.737 Y159.754 E3.5564
G1 X168.091 Y159.754 E.02408
G1 X100.574 Y92.237 E3.5564
M73 P17 R41
G1 X99.927 Y92.237 E.02408
G1 X167.444 Y159.754 E3.5564
G1 X166.798 Y159.754 E.02408
G1 X99.281 Y92.237 E3.5564
G1 X98.634 Y92.237 E.02408
G1 X166.152 Y159.754 E3.5564
M73 P18 R41
G1 X165.505 Y159.754 E.02408
G1 X97.988 Y92.237 E3.5564
G1 X97.342 Y92.237 E.02408
G1 X164.859 Y159.754 E3.5564
G1 X164.212 Y159.754 E.02408
G1 X96.695 Y92.237 E3.5564
G1 X96.049 Y92.237 E.02408
G1 X163.566 Y159.754 E3.5564
G1 X162.919 Y159.754 E.02408
G1 X95.402 Y92.237 E3.5564
G1 X94.756 Y92.237 E.02408
G1 X162.273 Y159.754 E3.5564
G1 X161.627 Y159.754 E.02408
G1 X94.11 Y92.237 E3.5564
G1 X93.463 Y92.237 E.02408
G1 X160.98 Y159.754 E3.5564
G1 X160.334 Y159.754 E.02408
G1 X111.246 Y110.666 E2.58568
G1 X111.246 Y111.313 E.02408
G1 X159.687 Y159.754 E2.55163
G1 X159.041 Y159.754 E.02408
G1 X111.246 Y111.959 E2.51758
G1 X111.246 Y112.605 E.02408
G1 X158.395 Y159.754 E2.48354
G1 X157.748 Y159.754 E.02408
G1 X111.246 Y113.252 E2.44949
G1 X111.246 Y113.898 E.02408
G1 X157.102 Y159.754 E2.41544
G1 X156.455 Y159.754 E.02408
G1 X111.246 Y114.545 E2.38139
G1 X111.246 Y115.191 E.02408
G1 X155.809 Y159.754 E2.34734
G1 X155.163 Y159.754 E.02408
G1 X111.246 Y115.837 E2.31329
G1 X111.246 Y116.484 E.02408
G1 X154.516 Y159.754 E2.27924
G1 X153.87 Y159.754 E.02408
G1 X111.246 Y117.13 E2.24519
G1 X111.246 Y117.777 E.02408
G1 X153.223 Y159.754 E2.21114
G1 X152.577 Y159.754 E.02408
G1 X111.246 Y118.423 E2.17709
G1 X111.246 Y119.069 E.02408
G1 X151.931 Y159.754 E2.14305
G1 X151.284 Y159.754 E.02408
G1 X111.246 Y119.716 E2.109
G1 X111.246 Y120.362 E.02408
G1 X150.638 Y159.754 E2.07495
G1 X149.991 Y159.754 E.02408
G1 X111.246 Y121.009 E2.0409
G1 X111.246 Y121.655 E.02408
G1 X149.345 Y159.754 E2.00685
G1 X148.698 Y159.754 E.02408
G1 X111.246 Y122.301 E1.9728
M73 P19 R41
G1 X111.246 Y122.948 E.02408
G1 X148.052 Y159.754 E1.93875
G1 X147.406 Y159.754 E.02408
G1 X111.246 Y123.594 E1.9047
G1 X111.246 Y124.241 E.02408
G1 X146.759 Y159.754 E1.87065
G1 X146.113 Y159.754 E.02408
G1 X111.246 Y124.887 E1.8366
G1 X111.246 Y125.534 E.02408
G1 X145.466 Y159.754 E1.80256
G1 X144.82 Y159.754 E.02408
G1 X111.246 Y126.18 E1.76851
G1 X111.246 Y126.826 E.02408
G1 X144.174 Y159.754 E1.73446
G1 X143.527 Y159.754 E.02408
G1 X111.246 Y127.473 E1.70041
G1 X111.246 Y128.119 E.02408
G1 X142.881 Y159.754 E1.66636
G1 X142.234 Y159.754 E.02408
G1 X111.246 Y128.766 E1.63231
G1 X111.246 Y129.412 E.02408
G1 X141.588 Y159.754 E1.59826
G1 X140.942 Y159.754 E.02408
G1 X111.246 Y130.058 E1.56421
G1 X111.246 Y130.705 E.02408
G1 X140.295 Y159.754 E1.53016
G1 X139.649 Y159.754 E.02408
G1 X111.246 Y131.351 E1.49611
G1 X111.246 Y131.998 E.02408
G1 X139.002 Y159.754 E1.46207
G1 X138.356 Y159.754 E.02408
G1 X111.246 Y132.644 E1.42802
G1 X111.246 Y133.29 E.02408
G1 X137.71 Y159.754 E1.39397
G1 X137.063 Y159.754 E.02408
G1 X111.246 Y133.937 E1.35992
G1 X111.246 Y134.583 E.02408
G1 X136.417 Y159.754 E1.32587
G1 X135.77 Y159.754 E.02408
G1 X111.246 Y135.23 E1.29182
G1 X111.246 Y135.876 E.02408
G1 X135.124 Y159.754 E1.25777
G1 X134.478 Y159.754 E.02408
G1 X111.246 Y136.522 E1.22372
G1 X111.246 Y137.169 E.02408
G1 X133.831 Y159.754 E1.18967
G1 X133.185 Y159.754 E.02408
G1 X111.246 Y137.815 E1.15562
G1 X111.246 Y138.462 E.02408
G1 X132.538 Y159.754 E1.12157
G1 X131.892 Y159.754 E.02408
G1 X111.246 Y139.108 E1.08753
G1 X111.246 Y139.755 E.02408
G1 X131.245 Y159.754 E1.05348
G1 X130.599 Y159.754 E.02408
G1 X111.246 Y140.401 E1.01943
G1 X111.246 Y141.047 E.02408
G1 X129.953 Y159.754 E.98538
G1 X129.306 Y159.754 E.02408
G1 X111.246 Y141.694 E.95133
G1 X111.246 Y142.246 E.02055
G1 X111.151 Y142.246 E.00352
M73 P19 R40
G1 X128.66 Y159.754 E.92226
G1 X128.013 Y159.754 E.02408
G1 X110.505 Y142.246 E.92226
G1 X109.858 Y142.246 E.02408
G1 X127.367 Y159.754 E.92226
G1 X126.721 Y159.754 E.02408
G1 X109.212 Y142.246 E.92226
G1 X108.565 Y142.246 E.02408
G1 X126.074 Y159.754 E.92226
G1 X125.428 Y159.754 E.02408
G1 X107.919 Y142.246 E.92226
G1 X107.273 Y142.246 E.02408
G1 X124.781 Y159.754 E.92226
G1 X124.135 Y159.754 E.02408
G1 X106.626 Y142.246 E.92226
G1 X105.98 Y142.246 E.02408
M73 P20 R40
G1 X123.489 Y159.754 E.92226
G1 X122.842 Y159.754 E.02408
G1 X105.333 Y142.246 E.92226
G1 X104.687 Y142.246 E.02408
G1 X122.196 Y159.754 E.92226
G1 X121.549 Y159.754 E.02408
G1 X104.04 Y142.246 E.92226
G1 X103.394 Y142.246 E.02408
G1 X120.903 Y159.754 E.92226
G1 X120.257 Y159.754 E.02408
G1 X102.748 Y142.246 E.92226
G1 X102.101 Y142.246 E.02408
G1 X119.61 Y159.754 E.92226
G1 X118.964 Y159.754 E.02408
G1 X101.455 Y142.246 E.92226
G1 X100.808 Y142.246 E.02408
G1 X118.317 Y159.754 E.92226
G1 X117.671 Y159.754 E.02408
G1 X100.162 Y142.246 E.92226
G1 X99.516 Y142.246 E.02408
G1 X117.23 Y159.96 E.9331
; WIPE_START
G1 X115.816 Y158.546 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X113.302 Y151.339 Z.6 F30000
G1 X92.611 Y92.032 Z.6
G1 Z.2
G1 E.8 F1800
G1 F6300
M204 S500
G1 X110.334 Y109.754 E.93353
G1 X109.687 Y109.754 E.02408
G1 X92.17 Y92.237 E.92269
G1 X91.524 Y92.237 E.02408
G1 X109.041 Y109.754 E.92269
G1 X108.395 Y109.754 E.02408
G1 X90.878 Y92.237 E.92269
G1 X90.231 Y92.237 E.02408
G1 X107.748 Y109.754 E.92269
G1 X107.102 Y109.754 E.02408
G1 X89.585 Y92.237 E.92269
G1 X88.938 Y92.237 E.02408
G1 X106.455 Y109.754 E.92269
G1 X105.809 Y109.754 E.02408
G1 X88.292 Y92.237 E.92269
G1 X87.646 Y92.237 E.02408
G1 X105.163 Y109.754 E.92269
G1 X104.516 Y109.754 E.02408
G1 X86.999 Y92.237 E.92269
G1 X86.353 Y92.237 E.02408
G1 X103.87 Y109.754 E.92269
G1 X103.223 Y109.754 E.02408
G1 X85.706 Y92.237 E.92269
G1 X85.06 Y92.237 E.02408
G1 X102.577 Y109.754 E.92269
G1 X101.931 Y109.754 E.02408
G1 X84.414 Y92.237 E.92269
G1 X83.767 Y92.237 E.02408
G1 X101.284 Y109.754 E.92269
G1 X100.638 Y109.754 E.02408
G1 X83.121 Y92.237 E.92269
G1 X82.474 Y92.237 E.02408
G1 X99.991 Y109.754 E.92269
G1 X99.345 Y109.754 E.02408
G1 X81.828 Y92.237 E.92269
G1 X81.181 Y92.237 E.02408
G1 X98.754 Y109.81 E.92564
G1 X98.754 Y110.457 E.02408
G1 X80.535 Y92.237 E.95969
G1 X79.889 Y92.237 E.02408
G1 X98.754 Y111.103 E.99374
G1 X98.754 Y111.75 E.02408
G1 X79.242 Y92.237 E1.02779
G1 X78.596 Y92.237 E.02408
G1 X98.754 Y112.396 E1.06184
G1 X98.754 Y113.042 E.02408
G1 X77.949 Y92.237 E1.09588
G1 X77.303 Y92.237 E.02408
G1 X98.754 Y113.689 E1.12993
G1 X98.754 Y114.335 E.02408
G1 X76.657 Y92.237 E1.16398
G1 X76.01 Y92.237 E.02408
G1 X98.754 Y114.982 E1.19803
G1 X98.754 Y115.628 E.02408
G1 X75.364 Y92.237 E1.23208
G1 X74.717 Y92.237 E.02408
G1 X98.754 Y116.274 E1.26613
G1 X98.754 Y116.921 E.02408
G1 X74.071 Y92.237 E1.30018
G1 X73.425 Y92.237 E.02408
G1 X98.754 Y117.567 E1.33423
G1 X98.754 Y118.214 E.02408
G1 X72.778 Y92.237 E1.36828
G1 X72.132 Y92.237 E.02408
G1 X98.754 Y118.86 E1.40232
G1 X98.754 Y119.506 E.02408
G1 X71.485 Y92.237 E1.43637
G1 X70.839 Y92.237 E.02408
G1 X98.754 Y120.153 E1.47042
G1 X98.754 Y120.799 E.02408
G1 X70.193 Y92.237 E1.50447
G1 X69.546 Y92.237 E.02408
G1 X98.754 Y121.446 E1.53852
G1 X98.754 Y122.092 E.02408
G1 X68.9 Y92.237 E1.57257
G1 X68.253 Y92.237 E.02408
G1 X98.754 Y122.739 E1.60662
G1 X98.754 Y123.385 E.02408
G1 X67.607 Y92.237 E1.64067
G1 X66.961 Y92.237 E.02408
G1 X98.754 Y124.031 E1.67472
G1 X98.754 Y124.678 E.02408
G1 X66.314 Y92.237 E1.70877
G1 X65.668 Y92.237 E.02408
G1 X98.754 Y125.324 E1.74281
G1 X98.754 Y125.971 E.02408
G1 X65.021 Y92.237 E1.77686
G1 X64.375 Y92.237 E.02408
G1 X98.754 Y126.617 E1.81091
G1 X98.754 Y127.263 E.02408
G1 X63.728 Y92.237 E1.84496
G1 X63.082 Y92.237 E.02408
G1 X98.754 Y127.91 E1.87901
G1 X98.754 Y128.556 E.02408
G1 X62.436 Y92.237 E1.91306
G1 X61.789 Y92.237 E.02408
G1 X98.754 Y129.203 E1.94711
G1 X98.754 Y129.849 E.02408
G1 X61.143 Y92.237 E1.98116
G1 X60.496 Y92.237 E.02408
G1 X98.754 Y130.495 E2.01521
G1 X98.754 Y131.142 E.02408
G1 X59.85 Y92.237 E2.04926
G1 X59.204 Y92.237 E.02408
G1 X98.754 Y131.788 E2.0833
G1 X98.754 Y132.435 E.02408
G1 X58.557 Y92.237 E2.11735
M73 P21 R40
G1 X57.911 Y92.237 E.02408
G1 X98.754 Y133.081 E2.1514
G1 X98.754 Y133.727 E.02408
G1 X57.264 Y92.237 E2.18545
G1 X56.618 Y92.237 E.02408
G1 X98.754 Y134.374 E2.2195
G1 X98.754 Y135.02 E.02408
G1 X55.972 Y92.237 E2.25355
G1 X55.325 Y92.237 E.02408
G1 X98.754 Y135.667 E2.2876
G1 X98.754 Y136.313 E.02408
G1 X54.679 Y92.237 E2.32165
G1 X54.032 Y92.237 E.02408
G1 X98.754 Y136.959 E2.3557
G1 X98.754 Y137.606 E.02408
G1 X53.386 Y92.237 E2.38974
G1 X52.74 Y92.237 E.02408
G1 X98.754 Y138.252 E2.42379
G1 X98.754 Y138.899 E.02408
G1 X52.093 Y92.237 E2.45784
G1 X51.447 Y92.237 E.02408
G1 X98.754 Y139.545 E2.49189
G1 X98.754 Y140.192 E.02408
G1 X50.8 Y92.237 E2.52594
G1 X50.154 Y92.237 E.02408
G1 X98.754 Y140.838 E2.55999
G1 X98.754 Y141.484 E.02408
G1 X49.507 Y92.237 E2.59404
G1 X48.861 Y92.237 E.02408
G1 X116.378 Y159.754 E3.5564
G1 X115.732 Y159.754 E.02408
G1 X48.215 Y92.237 E3.5564
G1 X47.568 Y92.237 E.02408
G1 X115.085 Y159.754 E3.5564
G1 X114.439 Y159.754 E.02408
G1 X46.922 Y92.237 E3.5564
G1 X46.275 Y92.237 E.02408
G1 X113.792 Y159.754 E3.5564
G1 X113.146 Y159.754 E.02408
G1 X45.629 Y92.237 E3.5564
G1 X44.983 Y92.237 E.02408
G1 X112.5 Y159.754 E3.5564
G1 X111.853 Y159.754 E.02408
G1 X44.336 Y92.237 E3.5564
G1 X43.69 Y92.237 E.02408
G1 X111.207 Y159.754 E3.5564
G1 X110.56 Y159.754 E.02408
G1 X71.74 Y120.934 E2.04481
G1 X71.802 Y121.059 E.00519
G3 X72.241 Y122.081 I-5.383 J2.92 E.04149
G1 X109.914 Y159.754 E1.98439
G1 X109.268 Y159.754 E.02408
G1 X72.548 Y123.035 E1.93417
G3 X72.744 Y123.877 I-4.515 J1.495 E.03227
G1 X108.621 Y159.754 E1.88979
G1 X107.975 Y159.754 E.02408
G1 X72.87 Y124.649 E1.84914
G1 X72.934 Y125.361 E.0266
G1 X107.328 Y159.754 E1.81167
G1 X106.682 Y159.754 E.02408
G1 X72.946 Y126.019 E1.777
G3 X72.933 Y126.652 I-3.478 J.247 E.02364
G1 X106.036 Y159.754 E1.74363
G1 X105.389 Y159.754 E.02408
G1 X72.879 Y127.245 E1.71243
G3 X72.801 Y127.813 I-3.15 J-.143 E.0214
G1 X104.743 Y159.754 E1.68249
G1 X104.096 Y159.754 E.02408
G1 X72.701 Y128.359 E1.65374
G3 X72.573 Y128.877 I-2.902 J-.442 E.01992
G1 X103.45 Y159.754 E1.62643
G1 X102.803 Y159.754 E.02408
M73 P21 R39
G1 X72.431 Y129.382 E1.59983
G3 X72.263 Y129.861 I-2.704 J-.681 E.01891
G1 X102.157 Y159.754 E1.57464
G1 X101.511 Y159.754 E.02408
G1 X72.085 Y130.328 E1.54998
G3 X71.883 Y130.774 I-2.539 J-.881 E.01822
G1 X100.864 Y159.754 E1.52654
G1 X100.218 Y159.754 E.02408
G1 X71.671 Y131.207 E1.50369
G3 X71.441 Y131.624 I-2.393 J-1.052 E.01774
G1 X99.571 Y159.754 E1.48176
G1 X98.925 Y159.754 E.02408
M73 P22 R39
G1 X71.196 Y132.026 E1.46059
G3 X70.94 Y132.416 I-2.264 J-1.206 E.01741
G1 X98.279 Y159.754 E1.44003
G1 X97.632 Y159.754 E.02408
G1 X70.665 Y132.787 E1.42047
G3 X70.385 Y133.154 I-2.147 J-1.35 E.0172
G1 X96.986 Y159.754 E1.40116
G1 X96.339 Y159.754 E.02408
G1 X70.08 Y133.495 E1.38317
G1 X69.776 Y133.837 E.01705
G1 X95.693 Y159.754 E1.36517
G1 X95.047 Y159.754 E.02408
G1 X69.444 Y134.151 E1.34862
G1 X69.109 Y134.464 E.01703
G1 X94.4 Y159.754 E1.33218
G1 X93.754 Y159.754 E.02408
G1 X68.755 Y134.755 E1.31681
G1 X68.391 Y135.038 E.01716
G1 X93.107 Y159.754 E1.30193
G1 X92.461 Y159.754 E.02408
G1 X68.013 Y135.306 E1.28779
G1 X67.618 Y135.558 E.01743
G1 X91.815 Y159.754 E1.27451
G1 X91.168 Y159.754 E.02408
G1 X67.215 Y135.802 E1.26169
G1 X66.79 Y136.022 E.01786
G1 X90.522 Y159.754 E1.25007
G1 X89.875 Y159.754 E.02408
G1 X66.359 Y136.238 E1.2387
G1 X65.9 Y136.425 E.01847
G1 X89.229 Y159.754 E1.22884
G1 X88.582 Y159.754 E.02408
G1 X65.438 Y136.61 E1.21913
G1 X64.942 Y136.761 E.01929
G1 X87.936 Y159.754 E1.21118
G1 X87.29 Y159.754 E.02408
G1 X64.443 Y136.908 E1.20344
G1 X63.908 Y137.019 E.02036
G1 X86.643 Y159.754 E1.19758
G1 X85.997 Y159.754 E.02408
G1 X63.362 Y137.12 E1.19227
G1 X62.782 Y137.186 E.02175
G1 X85.35 Y159.754 E1.18877
G1 X84.704 Y159.754 E.02408
G1 X62.177 Y137.228 E1.18658
G1 X61.545 Y137.242 E.02355
G1 X84.058 Y159.754 E1.18583
G1 X83.411 Y159.754 E.02408
G1 X60.86 Y137.203 E1.18786
G3 X60.137 Y137.126 I.06 J-4.002 E.02713
G1 X82.765 Y159.754 E1.19191
G1 X82.118 Y159.754 E.02408
G1 X59.359 Y136.995 E1.19881
G1 X58.491 Y136.773 E.03339
G1 X81.472 Y159.754 E1.21051
G1 X80.826 Y159.754 E.02408
G1 X57.083 Y136.011 E1.25064
; WIPE_START
G1 X58.497 Y137.426 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X61.442 Y130.384 Z.6 F30000
G1 X67.267 Y116.461 Z.6
G1 Z.2
G1 E.8 F1800
G1 F6300
M204 S500
G1 X43.043 Y92.237 E1.27595
G1 X42.397 Y92.237 E.02408
G1 X65.62 Y115.461 E1.22327
G1 X64.669 Y115.156 E.0372
G1 X41.751 Y92.237 E1.20722
G1 X41.104 Y92.237 E.02408
G1 X63.832 Y114.966 E1.19719
G2 X63.067 Y114.847 I-1.034 J4.132 E.02889
G1 X40.458 Y92.237 E1.19092
G1 X39.811 Y92.237 E.02408
G1 X62.35 Y114.777 E1.18723
G1 X61.69 Y114.763 E.0246
G1 X39.165 Y92.237 E1.1865
G1 X38.519 Y92.237 E.02408
G1 X61.064 Y114.783 E1.18756
G1 X60.459 Y114.824 E.02259
G1 X37.872 Y92.237 E1.18974
G1 X37.226 Y92.237 E.02408
G1 X59.9 Y114.912 E1.19434
G2 X59.349 Y115.007 I.247 J3.061 E.02085
G1 X36.579 Y92.237 E1.19938
G1 X35.933 Y92.237 E.02408
G1 X58.834 Y115.139 E1.20631
G2 X58.328 Y115.279 I.513 J2.845 E.0196
G1 X35.287 Y92.237 E1.21368
G1 X34.64 Y92.237 E.02408
G1 X57.851 Y115.448 E1.2226
G2 X57.381 Y115.624 I.729 J2.661 E.01873
G1 X33.994 Y92.237 E1.23189
M73 P23 R39
G1 X33.347 Y92.237 E.02408
G1 X56.938 Y115.829 E1.24264
G2 X56.499 Y116.036 I.913 J2.505 E.01811
G1 X33.106 Y92.643 E1.2322
G3 X33.244 Y93.427 I-2.177 J.787 E.0298
G1 X56.089 Y116.272 E1.20336
G1 X55.68 Y116.509 E.01762
G1 X33.196 Y94.025 E1.18431
G1 X33.086 Y94.434 E.01575
G1 X33.046 Y94.522 E.00361
G1 X55.298 Y116.774 E1.17214
G1 X54.919 Y117.042 E.01728
G1 X32.829 Y94.951 E1.16361
G1 X32.553 Y95.322 E.01721
G1 X54.562 Y117.331 E1.15931
G1 X54.213 Y117.628 E.01708
G1 X32.223 Y95.638 E1.1583
G1 X31.838 Y95.899 E.01734
G1 X53.878 Y117.94 E1.16097
G1 X53.559 Y118.267 E.01703
G1 X31.39 Y96.098 E1.16772
G1 X30.977 Y96.209 E.01592
G1 X30.864 Y96.218 E.00423
G1 X53.247 Y118.601 E1.17898
G1 X52.957 Y118.957 E.01711
G1 X30.226 Y96.226 E1.19734
G1 X30.021 Y96.208 E.00765
G1 X29.556 Y96.083 E.01795
G1 X29.328 Y95.975 E.00939
G1 X52.667 Y119.314 E1.22939
G1 X52.408 Y119.701 E.01735
G1 X29.243 Y96.536 E1.22019
G1 X29.243 Y97.182 E.02408
G1 X52.148 Y120.088 E1.2065
G2 X51.913 Y120.5 I2.139 J1.488 E.01768
G1 X29.243 Y97.829 E1.19416
G1 X29.243 Y98.475 E.02408
G1 X51.685 Y120.917 E1.18212
G2 X51.479 Y121.358 I2.263 J1.328 E.01813
G1 X29.243 Y99.122 E1.17126
G1 X29.243 Y99.768 E.02408
G1 X51.283 Y121.809 E1.16098
G2 X51.108 Y122.279 I2.54 J1.218 E.01873
G1 X29.243 Y100.415 E1.15171
G1 X29.243 Y101.061 E.02408
G1 X50.947 Y122.765 E1.14326
G2 X50.81 Y123.274 I2.718 J1.008 E.01966
G1 X29.243 Y101.708 E1.13601
G1 X29.243 Y102.354 E.02408
G1 X50.688 Y123.799 E1.12961
G2 X50.596 Y124.354 I2.992 J.78 E.02097
G1 X29.243 Y103 E1.12477
G1 X29.243 Y103.647 E.02408
G1 X50.518 Y124.922 E1.12066
G2 X50.485 Y125.536 I3.343 J.487 E.02291
G1 X29.243 Y104.293 E1.11892
G1 X29.243 Y104.94 E.02408
G1 X50.472 Y126.169 E1.11821
G1 X50.503 Y126.846 E.02525
G1 X29.243 Y105.586 E1.11983
G1 X29.243 Y106.233 E.02408
G1 X50.587 Y127.576 E1.12426
G2 X50.725 Y128.361 I4.367 J-.366 E.02972
G1 X29.243 Y106.879 E1.13155
G1 X29.243 Y107.525 E.02408
G1 X50.945 Y129.227 E1.14312
G1 X51.202 Y130.006 E.03057
G1 X51.297 Y130.226 E.00892
G1 X29.243 Y108.172 E1.16168
G1 X29.243 Y108.818 E.02408
G1 X51.899 Y131.475 E1.1934
G1 X52.101 Y131.844 E.01567
G2 X54.814 Y134.884 I9.662 J-5.891 E.15257
G1 X55.65 Y135.474 E.03813
G1 X56.239 Y135.814 E.02532
G1 X80.179 Y159.754 E1.26105
G1 X79.533 Y159.754 E.02408
G1 X29.243 Y109.465 E2.64896
G1 X29.243 Y110.111 E.02408
G1 X78.886 Y159.754 E2.61491
G1 X78.24 Y159.754 E.02408
G1 X29.243 Y110.758 E2.58086
G1 X29.243 Y111.404 E.02408
G1 X77.594 Y159.754 E2.54681
G1 X76.947 Y159.754 E.02408
G1 X29.243 Y112.051 E2.51276
G1 X29.243 Y112.697 E.02408
G1 X76.301 Y159.754 E2.47871
G1 X75.654 Y159.754 E.02408
G1 X29.243 Y113.343 E2.44466
G1 X29.243 Y113.99 E.02408
G1 X75.008 Y159.754 E2.41061
G1 X74.361 Y159.754 E.02408
G1 X29.243 Y114.636 E2.37656
G1 X29.243 Y115.283 E.02408
G1 X73.715 Y159.754 E2.3425
G1 X73.069 Y159.754 E.02408
G1 X29.243 Y115.929 E2.30845
G1 X29.243 Y116.576 E.02408
G1 X72.422 Y159.754 E2.2744
M73 P23 R38
G1 X71.776 Y159.754 E.02408
G1 X29.244 Y117.222 E2.24035
G1 X29.244 Y117.869 E.02408
G1 X71.129 Y159.754 E2.2063
G1 X70.483 Y159.754 E.02408
G1 X29.244 Y118.515 E2.17225
G1 X29.244 Y119.161 E.02408
G1 X69.837 Y159.754 E2.1382
G1 X69.19 Y159.754 E.02408
G1 X29.244 Y119.808 E2.10415
G1 X29.244 Y120.454 E.02408
G1 X68.544 Y159.754 E2.0701
G1 X67.897 Y159.754 E.02408
G1 X29.244 Y121.101 E2.03605
G1 X29.244 Y121.747 E.02408
G1 X67.251 Y159.754 E2.002
G1 X66.605 Y159.754 E.02408
G1 X29.244 Y122.394 E1.96795
G1 X29.244 Y123.04 E.02408
G1 X65.958 Y159.754 E1.9339
G1 X65.312 Y159.754 E.02408
G1 X29.244 Y123.686 E1.89985
G1 X29.244 Y124.333 E.02408
G1 X64.665 Y159.754 E1.8658
G1 X64.019 Y159.754 E.02408
G1 X29.244 Y124.979 E1.83175
G1 X29.244 Y125.626 E.02408
G1 X63.373 Y159.754 E1.79769
G1 X62.726 Y159.754 E.02408
G1 X29.244 Y126.272 E1.76364
M73 P24 R38
G1 X29.244 Y126.919 E.02408
G1 X62.08 Y159.754 E1.72959
G1 X61.433 Y159.754 E.02408
G1 X29.244 Y127.565 E1.69554
G1 X29.244 Y128.212 E.02408
G1 X60.787 Y159.754 E1.66149
G1 X60.14 Y159.754 E.02408
G1 X29.244 Y128.858 E1.62744
G1 X29.244 Y129.504 E.02408
G1 X59.494 Y159.754 E1.59339
G1 X58.848 Y159.754 E.02408
G1 X29.244 Y130.151 E1.55934
G1 X29.244 Y130.797 E.02408
G1 X58.201 Y159.754 E1.52529
G1 X57.555 Y159.754 E.02408
G1 X29.244 Y131.444 E1.49124
G1 X29.244 Y132.09 E.02408
G1 X56.908 Y159.754 E1.45719
G1 X56.262 Y159.754 E.02408
G1 X29.244 Y132.737 E1.42314
G1 X29.244 Y133.383 E.02408
G1 X55.616 Y159.754 E1.38909
G1 X54.969 Y159.754 E.02408
G1 X29.244 Y134.03 E1.35504
G1 X29.244 Y134.676 E.02408
G1 X54.323 Y159.754 E1.32099
G1 X53.676 Y159.754 E.02408
G1 X29.244 Y135.322 E1.28694
G1 X29.244 Y135.969 E.02408
G1 X53.03 Y159.754 E1.25288
G1 X52.384 Y159.754 E.02408
G1 X29.244 Y136.615 E1.21883
G1 X29.244 Y137.262 E.02408
G1 X51.737 Y159.754 E1.18478
G1 X51.091 Y159.754 E.02408
G1 X29.245 Y137.908 E1.15073
G1 X29.245 Y138.555 E.02408
G1 X50.444 Y159.754 E1.11668
G1 X49.798 Y159.754 E.02408
G1 X29.245 Y139.201 E1.08263
G1 X29.245 Y139.847 E.02408
G1 X49.152 Y159.754 E1.04858
G1 X48.505 Y159.754 E.02408
G1 X29.245 Y140.494 E1.01453
G1 X29.245 Y141.14 E.02408
G1 X47.859 Y159.754 E.98048
G1 X47.212 Y159.754 E.02408
G1 X29.245 Y141.787 E.94643
G1 X29.245 Y142.433 E.02408
G1 X46.566 Y159.754 E.91238
G1 X45.92 Y159.754 E.02408
G1 X29.245 Y143.08 E.87833
G1 X29.245 Y143.726 E.02408
G1 X45.273 Y159.754 E.84428
G1 X44.627 Y159.754 E.02408
G1 X29.245 Y144.373 E.81023
G1 X29.245 Y145.019 E.02408
G1 X43.98 Y159.754 E.77618
G1 X43.334 Y159.754 E.02408
G1 X29.245 Y145.665 E.74212
G1 X29.245 Y146.312 E.02408
G1 X42.687 Y159.754 E.70807
G1 X42.041 Y159.754 E.02408
G1 X29.245 Y146.958 E.67402
G1 X29.245 Y147.605 E.02408
G1 X41.395 Y159.754 E.63997
G1 X40.748 Y159.754 E.02408
G1 X29.245 Y148.251 E.60592
G1 X29.245 Y148.898 E.02408
G1 X40.102 Y159.754 E.57187
G1 X39.455 Y159.754 E.02408
G1 X29.245 Y149.544 E.53782
G1 X29.245 Y150.191 E.02408
G1 X38.809 Y159.754 E.50377
G1 X38.163 Y159.754 E.02408
G1 X29.245 Y150.837 E.46972
G1 X29.245 Y151.483 E.02408
G1 X37.516 Y159.754 E.43567
G1 X36.87 Y159.754 E.02408
G1 X29.245 Y152.13 E.40162
G1 X29.245 Y152.776 E.02408
G1 X36.223 Y159.754 E.36757
G1 X35.577 Y159.754 E.02408
G1 X29.245 Y153.423 E.33352
G1 X29.245 Y154.069 E.02408
G1 X34.931 Y159.754 E.29947
G1 X34.284 Y159.754 E.02408
G1 X29.245 Y154.716 E.26542
G1 X29.245 Y155.362 E.02408
G1 X33.638 Y159.754 E.23137
G1 X32.991 Y159.754 E.02408
G1 X29.245 Y156.008 E.19731
M73 P25 R38
G1 X29.245 Y156.655 E.02408
G1 X32.345 Y159.754 E.16326
G1 X31.699 Y159.754 E.02408
G1 X29.245 Y157.301 E.12921
G1 X29.245 Y157.948 E.02408
G1 X31.052 Y159.754 E.09516
G1 X30.406 Y159.754 E.02408
G1 X29.246 Y158.594 E.06111
G1 X29.246 Y159.241 E.02408
G1 X29.965 Y159.96 E.0379
; WIPE_START
G1 X29.246 Y159.241 E-.38663
G1 X29.246 Y158.594 E-.24565
G1 X29.483 Y158.832 E-.12773
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X29.417 Y151.2 Z.6 F30000
G1 X28.925 Y94.94 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.120132
G1 F3000
M204 S500
G3 X28.591 Y94.616 I2.803 J-3.233 E.00293
M204 S6000
G1 X28.701 Y94.811 F30000
; LINE_WIDTH: 0.125909
G1 F3000
M204 S500
G3 X28.596 Y94.353 I6.199 J-1.666 E.00318
; WIPE_START
G1 X28.701 Y94.811 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X28.595 Y92.655 Z.6 F30000
G1 Z.2
G1 E.8 F1800
; LINE_WIDTH: 0.131657
G1 F3000
M204 S500
G1 X28.848 Y91.619 E.00771
M204 S6000
G1 X28.96 Y91.617 F30000
; LINE_WIDTH: 0.356915
G1 F3000
M204 S500
G2 X28.581 Y92.54 I9.694 J4.52 E.02554
; WIPE_START
G1 X28.769 Y92.051 E-.39906
G1 X28.96 Y91.617 E-.36094
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X29.539 Y91.581 Z.6 F30000
G1 Z.2
G1 E.8 F1800
; LINE_WIDTH: 0.355373
G1 F3000
M204 S500
G2 X28.617 Y91.96 I3.615 J10.104 E.02538
M204 S6000
G1 X28.62 Y91.848 F30000
; LINE_WIDTH: 0.131964
G1 F3000
M204 S500
G1 X29.655 Y91.595 E.00774
; WIPE_START
G1 X28.62 Y91.848 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X31.352 Y91.596 Z.6 F30000
G1 Z.2
G1 E.8 F1800
; LINE_WIDTH: 0.125563
G1 F3000
M204 S500
G3 X31.808 Y91.7 I-1.246 J6.465 E.00315
M204 S6000
G1 X31.614 Y91.591 F30000
; LINE_WIDTH: 0.118779
G1 F3000
M204 S500
G3 X31.935 Y91.921 I-2.821 J3.065 E.00285
; WIPE_START
G1 X31.614 Y91.591 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X39.245 Y91.722 Z.6 F30000
G1 X227.068 Y94.948 Z.6
G1 Z.2
G1 E.8 F1800
; LINE_WIDTH: 0.11313
G1 F3000
M204 S500
G1 X227.162 Y94.864 E.00073
; LINE_WIDTH: 0.141464
G1 X227.229 Y94.793 E.00078
; LINE_WIDTH: 0.177496
G1 X227.289 Y94.728 E.00098
; LINE_WIDTH: 0.204903
G1 X227.411 Y94.591 E.00242
M204 S6000
G1 X227.404 Y94.354 F30000
; LINE_WIDTH: 0.124257
G1 F3000
M204 S500
G1 X227.388 Y94.429 E.00051
G3 X227.3 Y94.814 I-3.702 J-.646 E.00262
; CHANGE_LAYER
; Z_HEIGHT: 0.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X227.388 Y94.429 E-.63615
G1 X227.404 Y94.354 E-.12385
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 2/25
; update layer progress
M73 L2
M991 S0 P1 ;notify layer change
M106 S255
M106 P2 S178
; open powerlost recovery
M1003 S1
M204 S10000
G17
G3 Z.6 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z.8 F30000
G1 X51.287 Y124.063 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.505 Y123.14 E.03146
G3 X60.507 Y115.466 I10.206 J2.854 E.41629
G1 X61.47 Y115.4 E.03202
G3 X51.28 Y124.123 I.241 J10.594 E1.72695
M204 S250
G1 X51.674 Y124.152 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.037 J1.843 E.3999
G1 X61.479 Y115.792 E.02856
G3 X51.663 Y124.211 I.232 J10.202 E1.5399
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37595
G1 X52.171 Y122.363 E-.35313
G1 X52.203 Y122.288 E-.03091
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.053 Z.8 F30000
G1 X223.514 Y94.189 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.527 Y94.218 E.00107
G2 X227.227 Y94.688 I1.971 J-.716 E.15247
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.727 J-1.188 E.24389
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.432 Y93.864 I1.186 J1.729 E.07952
G1 X223.5 Y94.13 E.0091
M204 S250
G1 X223.903 Y94.081 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.466 Y91.792 I1.605 J-.582 E.0994
G3 X226.085 Y91.892 I-.024 J2.114 E.01934
G3 X223.924 Y94.137 I-.578 J1.607 E.20899
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.1358
G1 X223.789 Y93.5 E-.1133
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11332
G1 X224.189 Y92.4 E-.11332
G1 X224.297 Y92.293 E-.05762
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z.8 F30000
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02175
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24921
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07628
G1 X227.039 Y92.075 E-.03913
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z.8 F30000
G1 X32.106 Y94.076 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X31.985 Y94.357 E.00942
G3 X30.466 Y91.792 I-1.478 J-.857 E.2185
G3 X31.085 Y91.892 I-.024 J2.114 E.01934
G3 X32.133 Y94.023 I-.578 J1.608 E.08069
; WIPE_START
M204 S10000
G1 X31.985 Y94.357 E-.13887
G1 X31.811 Y94.6 E-.11345
G1 X31.6 Y94.811 E-.11334
G1 X31.355 Y94.982 E-.11331
G1 X31.085 Y95.108 E-.11333
G1 X30.797 Y95.185 E-.11331
G1 X30.654 Y95.197 E-.05439
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z.8 F30000
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.191 J1.73 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02175
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08591
G1 X28.888 Y92.147 E-.13943
G1 X28.773 Y92.312 E-.07623
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24921
G1 X28.974 Y91.602 E-.14117
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z.8 F30000
G1 X227.79 Y91.21 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z.8 F30000
G1 Z.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.3277
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281527
G2 X225.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.244285
G2 X225.14 Y91.516 I-.336 J5.785 E.0115
; LINE_WIDTH: 0.283902
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327688
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X224.469 Y91.619 E.00873
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y92.469 Z.8 F30000
G1 Z.4
G1 E.8 F1800
; LINE_WIDTH: 0.354364
G1 F15000
G1 X227.441 Y92.808 E.00874
; LINE_WIDTH: 0.327676
G1 X227.463 Y92.974 E.00389
; LINE_WIDTH: 0.283908
G1 X227.484 Y93.14 E.00329
; LINE_WIDTH: 0.244295
G3 X227.486 Y93.841 I-5.786 J.364 E.0115
; LINE_WIDTH: 0.281523
G3 X227.463 Y94.026 I-2.138 J-.178 E.00363
; LINE_WIDTH: 0.327686
G1 X227.441 Y94.192 E.00389
; LINE_WIDTH: 0.354377
G1 X227.381 Y94.531 E.00874
; WIPE_START
G1 X227.441 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.329 Y101.824 Z.8 F30000
G1 X226.471 Y160.234 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42058
G1 F15000
G1 X227.065 Y159.641 E.02584
G1 X227.065 Y159.106 E.01644
G1 X226.106 Y160.065 E.0417
G1 X225.572 Y160.065 E.01644
G1 X227.065 Y158.572 E.06495
G1 X227.065 Y158.038 E.01644
G1 X225.038 Y160.065 E.08819
G1 X224.504 Y160.065 E.01644
G1 X227.065 Y157.504 E.11144
G1 X227.065 Y156.97 E.01644
G1 X223.97 Y160.065 E.13468
G1 X223.436 Y160.065 E.01644
G1 X227.065 Y156.436 E.15793
G1 X227.065 Y155.902 E.01644
G1 X222.902 Y160.065 E.18117
G1 X222.368 Y160.065 E.01644
G1 X227.065 Y155.368 E.20442
M73 P25 R37
G1 X227.065 Y154.834 E.01644
G1 X221.834 Y160.065 E.22766
G1 X221.3 Y160.065 E.01644
G1 X227.065 Y154.3 E.25091
G1 X227.065 Y153.766 E.01644
G1 X220.766 Y160.065 E.27415
G1 X220.231 Y160.065 E.01644
G1 X227.065 Y153.231 E.2974
G1 X227.065 Y152.697 E.01644
G1 X219.697 Y160.065 E.32064
G1 X219.163 Y160.065 E.01644
G1 X227.065 Y152.163 E.34388
G1 X227.065 Y151.629 E.01644
G1 X218.629 Y160.065 E.36713
G1 X218.095 Y160.065 E.01644
G1 X227.065 Y151.095 E.39037
G1 X227.065 Y150.561 E.01644
G1 X217.561 Y160.065 E.41362
G1 X217.027 Y160.065 E.01644
G1 X227.065 Y150.027 E.43686
G1 X227.065 Y149.493 E.01644
G1 X216.493 Y160.065 E.46011
G1 X215.959 Y160.065 E.01644
G1 X227.065 Y148.959 E.48335
G1 X227.065 Y148.425 E.01644
G1 X215.425 Y160.065 E.5066
G1 X214.891 Y160.065 E.01644
G1 X227.065 Y147.891 E.52984
G1 X227.065 Y147.356 E.01644
G1 X214.356 Y160.065 E.55309
G1 X213.822 Y160.065 E.01644
G1 X227.065 Y146.822 E.57633
G1 X227.065 Y146.288 E.01644
G1 X213.288 Y160.065 E.59957
G1 X212.754 Y160.065 E.01644
G1 X227.065 Y145.754 E.62282
G1 X227.065 Y145.22 E.01644
G1 X212.22 Y160.065 E.64606
G1 X211.686 Y160.065 E.01644
G1 X227.065 Y144.686 E.66931
G1 X227.065 Y144.152 E.01644
G1 X211.152 Y160.065 E.69255
G1 X210.618 Y160.065 E.01644
G1 X227.065 Y143.618 E.7158
G1 X227.065 Y143.084 E.01644
G1 X210.084 Y160.065 E.73904
G1 X209.55 Y160.065 E.01644
G1 X227.065 Y142.55 E.76229
G1 X227.065 Y142.015 E.01644
G1 X209.015 Y160.065 E.78553
G1 X208.481 Y160.065 E.01644
G1 X227.065 Y141.481 E.80878
G1 X227.065 Y140.947 E.01644
G1 X207.947 Y160.065 E.83202
G1 X207.413 Y160.065 E.01644
G1 X227.065 Y140.413 E.85527
G1 X227.065 Y139.879 E.01644
G1 X206.879 Y160.065 E.87851
G1 X206.345 Y160.065 E.01644
G1 X227.065 Y139.345 E.90175
G1 X227.065 Y138.811 E.01644
G1 X205.811 Y160.065 E.925
G1 X205.277 Y160.065 E.01644
G1 X227.065 Y138.277 E.94824
G1 X227.065 Y137.743 E.01644
G1 X204.743 Y160.065 E.97149
G1 X204.209 Y160.065 E.01644
G1 X227.065 Y137.209 E.99473
G1 X227.065 Y136.675 E.01644
G1 X203.675 Y160.065 E1.01798
G1 X203.14 Y160.065 E.01644
G1 X227.065 Y136.14 E1.04122
G1 X227.065 Y135.606 E.01644
G1 X202.606 Y160.065 E1.06447
G1 X202.072 Y160.065 E.01644
G1 X227.065 Y135.072 E1.08771
G1 X227.065 Y134.538 E.01644
G1 X201.538 Y160.065 E1.11096
G1 X201.004 Y160.065 E.01644
G1 X227.065 Y134.004 E1.1342
G1 X227.065 Y133.47 E.01644
G1 X200.47 Y160.065 E1.15745
G1 X199.936 Y160.065 E.01644
G1 X227.065 Y132.936 E1.18069
G1 X227.065 Y132.402 E.01644
G1 X199.402 Y160.065 E1.20393
G1 X198.868 Y160.065 E.01644
G1 X227.065 Y131.868 E1.22718
G1 X227.065 Y131.334 E.01644
G1 X198.334 Y160.065 E1.25042
G1 X197.8 Y160.065 E.01644
G1 X227.065 Y130.8 E1.27367
G1 X227.065 Y130.265 E.01644
G1 X197.265 Y160.065 E1.29691
G1 X196.731 Y160.065 E.01644
G1 X227.065 Y129.731 E1.32016
G1 X227.065 Y129.197 E.01644
G1 X196.197 Y160.065 E1.3434
G1 X195.663 Y160.065 E.01644
G1 X227.065 Y128.663 E1.36665
G1 X227.065 Y128.129 E.01644
G1 X195.129 Y160.065 E1.38989
G1 X194.595 Y160.065 E.01644
G1 X227.065 Y127.595 E1.41314
G1 X227.065 Y127.061 E.01644
G1 X194.061 Y160.065 E1.43638
G1 X193.527 Y160.065 E.01644
G1 X227.065 Y126.527 E1.45962
G1 X227.065 Y125.993 E.01644
G1 X192.993 Y160.065 E1.48287
G1 X192.459 Y160.065 E.01644
G1 X227.065 Y125.459 E1.50611
G1 X227.065 Y124.925 E.01644
G1 X191.925 Y160.065 E1.52936
G1 X191.39 Y160.065 E.01644
G1 X227.065 Y124.39 E1.5526
G1 X227.065 Y123.856 E.01644
G1 X190.856 Y160.065 E1.57585
G1 X190.322 Y160.065 E.01644
G1 X227.065 Y123.322 E1.59909
G1 X227.065 Y122.788 E.01644
G1 X189.788 Y160.065 E1.62234
G1 X189.254 Y160.065 E.01644
G1 X227.065 Y122.254 E1.64558
G1 X227.065 Y121.72 E.01644
G1 X188.72 Y160.065 E1.66883
G1 X188.186 Y160.065 E.01644
G1 X227.065 Y121.186 E1.69207
G1 X227.065 Y120.652 E.01644
G1 X187.652 Y160.065 E1.71532
G1 X187.118 Y160.065 E.01644
G1 X227.065 Y120.118 E1.73856
G1 X227.065 Y119.584 E.01644
G1 X186.584 Y160.065 E1.7618
G1 X186.05 Y160.065 E.01644
G1 X227.065 Y119.05 E1.78505
G1 X227.065 Y118.515 E.01644
G1 X185.515 Y160.065 E1.80829
G1 X184.981 Y160.065 E.01644
G1 X227.065 Y117.981 E1.83154
G1 X227.065 Y117.447 E.01644
G1 X184.447 Y160.065 E1.85478
G1 X183.913 Y160.065 E.01644
G1 X227.065 Y116.913 E1.87803
G1 X227.065 Y116.379 E.01644
G1 X183.379 Y160.065 E1.90127
G1 X182.845 Y160.065 E.01644
G1 X227.065 Y115.845 E1.92452
G1 X227.065 Y115.311 E.01644
G1 X182.311 Y160.065 E1.94776
G1 X181.777 Y160.065 E.01644
G1 X227.065 Y114.777 E1.97101
G1 X227.065 Y114.243 E.01644
G1 X181.243 Y160.065 E1.99425
G1 X180.709 Y160.065 E.01644
G1 X227.065 Y113.709 E2.0175
G1 X227.065 Y113.175 E.01644
G1 X180.175 Y160.065 E2.04074
M73 P26 R37
G1 X179.64 Y160.065 E.01644
G1 X227.065 Y112.64 E2.06398
G1 X227.065 Y112.106 E.01644
G1 X179.106 Y160.065 E2.08723
G1 X178.572 Y160.065 E.01644
G1 X227.065 Y111.572 E2.11047
G1 X227.065 Y111.038 E.01644
G1 X178.038 Y160.065 E2.13372
G1 X177.504 Y160.065 E.01644
G1 X227.065 Y110.504 E2.15696
G1 X227.065 Y109.97 E.01644
G1 X176.97 Y160.065 E2.18021
G1 X176.436 Y160.065 E.01644
G1 X227.065 Y109.436 E2.20345
G1 X227.065 Y108.902 E.01644
G1 X175.902 Y160.065 E2.2267
G1 X175.368 Y160.065 E.01644
G1 X227.065 Y108.368 E2.24994
G1 X227.065 Y107.834 E.01644
G1 X174.834 Y160.065 E2.27319
G1 X174.3 Y160.065 E.01644
G1 X227.065 Y107.3 E2.29643
G1 X227.065 Y106.765 E.01644
G1 X173.765 Y160.065 E2.31967
G1 X173.231 Y160.065 E.01644
G1 X227.065 Y106.231 E2.34292
G1 X227.065 Y105.697 E.01644
G1 X172.697 Y160.065 E2.36616
G1 X172.163 Y160.065 E.01644
G1 X227.065 Y105.163 E2.38941
G1 X227.065 Y104.629 E.01644
G1 X171.629 Y160.065 E2.41265
G1 X171.095 Y160.065 E.01644
G1 X227.065 Y104.095 E2.4359
G1 X227.065 Y103.561 E.01644
G1 X170.561 Y160.065 E2.45914
G1 X170.027 Y160.065 E.01644
G1 X227.065 Y103.027 E2.48239
G1 X227.065 Y102.493 E.01644
G1 X169.493 Y160.065 E2.50563
G1 X168.959 Y160.065 E.01644
G1 X227.065 Y101.959 E2.52888
G1 X227.065 Y101.425 E.01644
G1 X168.425 Y160.065 E2.55212
G1 X167.89 Y160.065 E.01644
G1 X227.065 Y100.89 E2.57537
G1 X227.065 Y100.356 E.01644
G1 X167.356 Y160.065 E2.59861
G1 X166.822 Y160.065 E.01644
G1 X227.065 Y99.822 E2.62185
G1 X227.065 Y99.288 E.01644
G1 X166.288 Y160.065 E2.6451
G1 X165.754 Y160.065 E.01644
G1 X227.065 Y98.754 E2.66834
G1 X227.065 Y98.22 E.01644
G1 X165.22 Y160.065 E2.69159
G1 X164.686 Y160.065 E.01644
G1 X227.065 Y97.686 E2.71483
G1 X227.065 Y97.152 E.01644
G1 X164.152 Y160.065 E2.73808
G1 X163.618 Y160.065 E.01644
G1 X227.065 Y96.618 E2.76132
G1 X227.065 Y96.084 E.01644
G1 X163.084 Y160.065 E2.78457
G1 X162.549 Y160.065 E.01644
G1 X227.065 Y95.55 E2.80781
G1 X227.065 Y95.37 E.00551
G3 X226.271 Y95.809 I-1.781 J-2.288 E.028
G1 X162.015 Y160.065 E2.79654
G1 X161.481 Y160.065 E.01644
G1 X225.617 Y95.929 E2.79131
G1 X225.5 Y95.939 E.00363
G1 X225.107 Y95.905 E.01213
G1 X160.947 Y160.065 E2.79236
G1 X160.413 Y160.065 E.01644
G1 X224.682 Y95.796 E2.79708
G1 X224.315 Y95.628 E.0124
G1 X159.879 Y160.065 E2.80438
G1 X159.345 Y160.065 E.01644
G1 X223.996 Y95.413 E2.81374
G3 X223.72 Y95.156 I.592 J-.913 E.01169
G1 X158.811 Y160.065 E2.82495
G1 X158.277 Y160.065 E.01644
G1 X223.484 Y94.857 E2.83794
G3 X223.292 Y94.515 I.875 J-.715 E.01214
G1 X157.743 Y160.065 E2.85284
G1 X157.209 Y160.065 E.01644
G1 X223.151 Y94.122 E2.86994
G3 X223.079 Y93.661 I1.52 J-.476 E.01443
G1 X156.674 Y160.065 E2.89002
G1 X156.14 Y160.065 E.01644
G1 X223.095 Y93.11 E2.91399
G1 X223.098 Y93.077 E.00103
G3 X223.386 Y92.285 I2.388 J.42 E.02603
G1 X155.606 Y160.065 E2.94987
G1 X155.072 Y160.065 E.01644
G1 X223.202 Y91.935 E2.96511
G1 X222.667 Y91.935 E.01644
G1 X154.538 Y160.065 E2.96511
G1 X154.004 Y160.065 E.01644
G1 X222.133 Y91.935 E2.96511
G1 X221.599 Y91.935 E.01644
G1 X153.47 Y160.065 E2.96511
G1 X152.936 Y160.065 E.01644
G1 X221.065 Y91.935 E2.96511
G1 X220.531 Y91.935 E.01644
G1 X152.402 Y160.065 E2.96511
G1 X151.868 Y160.065 E.01644
G1 X219.997 Y91.935 E2.96511
G1 X219.463 Y91.935 E.01644
G1 X151.334 Y160.065 E2.96511
G1 X150.799 Y160.065 E.01644
G1 X218.929 Y91.935 E2.96511
G1 X218.395 Y91.935 E.01644
G1 X150.265 Y160.065 E2.96511
G1 X149.731 Y160.065 E.01644
G1 X217.861 Y91.935 E2.96511
G1 X217.327 Y91.935 E.01644
G1 X149.197 Y160.065 E2.96511
G1 X148.663 Y160.065 E.01644
G1 X216.792 Y91.935 E2.96511
G1 X216.258 Y91.935 E.01644
G1 X148.129 Y160.065 E2.96511
G1 X147.595 Y160.065 E.01644
G1 X215.724 Y91.935 E2.96511
G1 X215.19 Y91.935 E.01644
G1 X147.061 Y160.065 E2.96511
G1 X146.527 Y160.065 E.01644
G1 X214.656 Y91.935 E2.96511
G1 X214.122 Y91.935 E.01644
G1 X145.993 Y160.065 E2.96511
G1 X145.459 Y160.065 E.01644
G1 X213.588 Y91.935 E2.96511
G1 X213.054 Y91.935 E.01644
G1 X144.924 Y160.065 E2.96511
G1 X144.39 Y160.065 E.01644
G1 X212.52 Y91.935 E2.96511
G1 X211.986 Y91.935 E.01644
G1 X143.856 Y160.065 E2.96511
G1 X143.322 Y160.065 E.01644
G1 X211.452 Y91.935 E2.96511
G1 X210.917 Y91.935 E.01644
G1 X142.788 Y160.065 E2.96511
G1 X142.254 Y160.065 E.01644
G1 X210.383 Y91.935 E2.96511
G1 X209.849 Y91.935 E.01644
G1 X141.72 Y160.065 E2.96511
G1 X141.186 Y160.065 E.01644
G1 X209.315 Y91.935 E2.96511
G1 X208.781 Y91.935 E.01644
G1 X140.652 Y160.065 E2.96511
G1 X140.118 Y160.065 E.01644
G1 X208.247 Y91.935 E2.96511
G1 X207.713 Y91.935 E.01644
G1 X139.584 Y160.065 E2.96511
G1 X139.049 Y160.065 E.01644
G1 X207.179 Y91.935 E2.96511
G1 X206.645 Y91.935 E.01644
G1 X138.515 Y160.065 E2.96511
G1 X137.981 Y160.065 E.01644
G1 X206.111 Y91.935 E2.96511
G1 X205.577 Y91.935 E.01644
G1 X137.447 Y160.065 E2.96511
G1 X136.913 Y160.065 E.01644
G1 X205.042 Y91.935 E2.96511
G1 X204.508 Y91.935 E.01644
G1 X136.379 Y160.065 E2.96511
G1 X135.845 Y160.065 E.01644
G1 X203.974 Y91.935 E2.96511
G1 X203.44 Y91.935 E.01644
G1 X135.311 Y160.065 E2.96511
G1 X134.777 Y160.065 E.01644
G1 X202.906 Y91.935 E2.96511
G1 X202.372 Y91.935 E.01644
G1 X134.243 Y160.065 E2.96511
G1 X133.709 Y160.065 E.01644
G1 X201.838 Y91.935 E2.96511
G1 X201.304 Y91.935 E.01644
G1 X133.174 Y160.065 E2.96511
M73 P27 R37
G1 X132.64 Y160.065 E.01644
G1 X200.77 Y91.935 E2.96511
G1 X200.236 Y91.935 E.01644
G1 X132.106 Y160.065 E2.96511
G1 X131.572 Y160.065 E.01644
G1 X199.702 Y91.935 E2.96511
G1 X199.167 Y91.935 E.01644
G1 X131.038 Y160.065 E2.96511
G1 X130.504 Y160.065 E.01644
G1 X198.633 Y91.935 E2.96511
G1 X198.099 Y91.935 E.01644
G1 X129.97 Y160.065 E2.96511
G1 X129.436 Y160.065 E.01644
G1 X197.565 Y91.935 E2.96511
G1 X197.031 Y91.935 E.01644
G1 X128.902 Y160.065 E2.96511
G1 X128.368 Y160.065 E.01644
G1 X196.497 Y91.935 E2.96511
G1 X195.963 Y91.935 E.01644
G1 X127.834 Y160.065 E2.96511
G1 X127.299 Y160.065 E.01644
G1 X195.429 Y91.935 E2.96511
G1 X194.895 Y91.935 E.01644
G1 X126.765 Y160.065 E2.96511
G1 X126.231 Y160.065 E.01644
G1 X194.361 Y91.935 E2.96511
G1 X193.827 Y91.935 E.01644
G1 X125.697 Y160.065 E2.96511
G1 X125.163 Y160.065 E.01644
G1 X193.292 Y91.935 E2.96511
G1 X192.758 Y91.935 E.01644
G1 X124.629 Y160.065 E2.96511
G1 X124.095 Y160.065 E.01644
G1 X192.224 Y91.935 E2.96511
G1 X191.69 Y91.935 E.01644
G1 X123.561 Y160.065 E2.96511
G1 X123.027 Y160.065 E.01644
G1 X191.156 Y91.935 E2.96511
G1 X190.622 Y91.935 E.01644
G1 X122.493 Y160.065 E2.96511
G1 X121.958 Y160.065 E.01644
G1 X190.088 Y91.935 E2.96511
G1 X189.554 Y91.935 E.01644
G1 X121.424 Y160.065 E2.96511
G1 X120.89 Y160.065 E.01644
G1 X189.02 Y91.935 E2.96511
G1 X188.486 Y91.935 E.01644
G1 X120.356 Y160.065 E2.96511
G1 X119.822 Y160.065 E.01644
G1 X187.952 Y91.935 E2.96511
G1 X187.417 Y91.935 E.01644
G1 X119.288 Y160.065 E2.96511
G1 X118.754 Y160.065 E.01644
G1 X186.883 Y91.935 E2.96511
G1 X186.349 Y91.935 E.01644
G1 X118.22 Y160.065 E2.96511
G1 X117.686 Y160.065 E.01644
G1 X185.815 Y91.935 E2.96511
G1 X185.281 Y91.935 E.01644
G1 X117.152 Y160.065 E2.96511
G1 X116.618 Y160.065 E.01644
G1 X184.747 Y91.935 E2.96511
G1 X184.213 Y91.935 E.01644
G1 X116.083 Y160.065 E2.96511
G1 X115.549 Y160.065 E.01644
G1 X183.679 Y91.935 E2.96511
G1 X183.145 Y91.935 E.01644
G1 X115.015 Y160.065 E2.96511
G1 X114.481 Y160.065 E.01644
G1 X182.611 Y91.935 E2.96511
G1 X182.077 Y91.935 E.01644
G1 X113.947 Y160.065 E2.96511
G1 X113.413 Y160.065 E.01644
G1 X181.542 Y91.935 E2.96511
G1 X181.008 Y91.935 E.01644
G1 X112.879 Y160.065 E2.96511
G1 X112.345 Y160.065 E.01644
G1 X180.474 Y91.935 E2.96511
G1 X179.94 Y91.935 E.01644
G1 X111.811 Y160.065 E2.96511
G1 X111.277 Y160.065 E.01644
G1 X179.406 Y91.935 E2.96511
G1 X178.872 Y91.935 E.01644
G1 X110.743 Y160.065 E2.96511
G1 X110.208 Y160.065 E.01644
G1 X178.338 Y91.935 E2.96511
G1 X177.804 Y91.935 E.01644
G1 X109.674 Y160.065 E2.96511
G1 X109.14 Y160.065 E.01644
G1 X177.27 Y91.935 E2.96511
G1 X176.736 Y91.935 E.01644
G1 X108.606 Y160.065 E2.96511
G1 X108.072 Y160.065 E.01644
G1 X176.201 Y91.935 E2.96511
G1 X175.667 Y91.935 E.01644
G1 X107.538 Y160.065 E2.96511
G1 X107.004 Y160.065 E.01644
G1 X175.133 Y91.935 E2.96511
M73 P27 R36
G1 X174.599 Y91.935 E.01644
G1 X106.47 Y160.065 E2.96511
G1 X105.936 Y160.065 E.01644
G1 X174.065 Y91.935 E2.96511
G1 X173.531 Y91.935 E.01644
G1 X105.402 Y160.065 E2.96511
G1 X104.868 Y160.065 E.01644
G1 X172.997 Y91.935 E2.96511
G1 X172.463 Y91.935 E.01644
G1 X104.333 Y160.065 E2.96511
G1 X103.799 Y160.065 E.01644
G1 X171.929 Y91.935 E2.96511
G1 X171.395 Y91.935 E.01644
G1 X103.265 Y160.065 E2.96511
G1 X102.731 Y160.065 E.01644
G1 X170.861 Y91.935 E2.96511
G1 X170.326 Y91.935 E.01644
G1 X102.197 Y160.065 E2.96511
G1 X101.663 Y160.065 E.01644
G1 X169.792 Y91.935 E2.96511
G1 X169.258 Y91.935 E.01644
G1 X101.129 Y160.065 E2.96511
G1 X100.595 Y160.065 E.01644
G1 X168.724 Y91.935 E2.96511
G1 X168.19 Y91.935 E.01644
G1 X100.061 Y160.065 E2.96511
G1 X99.527 Y160.065 E.01644
G1 X167.656 Y91.935 E2.96511
G1 X167.122 Y91.935 E.01644
G1 X98.993 Y160.065 E2.96511
G1 X98.458 Y160.065 E.01644
G1 X166.588 Y91.935 E2.96511
G1 X166.054 Y91.935 E.01644
G1 X97.924 Y160.065 E2.96511
G1 X97.39 Y160.065 E.01644
G1 X165.52 Y91.935 E2.96511
G1 X164.986 Y91.935 E.01644
G1 X96.856 Y160.065 E2.96511
G1 X96.322 Y160.065 E.01644
G1 X164.451 Y91.935 E2.96511
G1 X163.917 Y91.935 E.01644
G1 X95.788 Y160.065 E2.96511
G1 X95.254 Y160.065 E.01644
G1 X163.383 Y91.935 E2.96511
G1 X162.849 Y91.935 E.01644
G1 X94.72 Y160.065 E2.96511
G1 X94.186 Y160.065 E.01644
G1 X162.315 Y91.935 E2.96511
M73 P28 R36
G1 X161.781 Y91.935 E.01644
G1 X93.652 Y160.065 E2.96511
G1 X93.118 Y160.065 E.01644
G1 X161.247 Y91.935 E2.96511
G1 X160.713 Y91.935 E.01644
G1 X92.583 Y160.065 E2.96511
G1 X92.049 Y160.065 E.01644
G1 X110.179 Y141.935 E.78902
G1 X109.645 Y141.935 E.01644
G1 X91.515 Y160.065 E.78902
G1 X90.981 Y160.065 E.01644
G1 X109.111 Y141.935 E.78902
G1 X108.576 Y141.935 E.01644
G1 X90.447 Y160.065 E.78902
G1 X89.913 Y160.065 E.01644
G1 X108.042 Y141.935 E.78902
G1 X107.508 Y141.935 E.01644
G1 X89.379 Y160.065 E.78902
G1 X88.845 Y160.065 E.01644
G1 X106.974 Y141.935 E.78902
G1 X106.44 Y141.935 E.01644
G1 X88.311 Y160.065 E.78902
G1 X87.777 Y160.065 E.01644
G1 X105.906 Y141.935 E.78902
G1 X105.372 Y141.935 E.01644
G1 X87.243 Y160.065 E.78902
G1 X86.708 Y160.065 E.01644
G1 X104.838 Y141.935 E.78902
G1 X104.304 Y141.935 E.01644
G1 X86.174 Y160.065 E.78902
G1 X85.64 Y160.065 E.01644
G1 X103.77 Y141.935 E.78902
G1 X103.236 Y141.935 E.01644
G1 X85.106 Y160.065 E.78902
G1 X84.572 Y160.065 E.01644
G1 X102.701 Y141.935 E.78902
G1 X102.167 Y141.935 E.01644
G1 X84.038 Y160.065 E.78902
G1 X83.504 Y160.065 E.01644
G1 X101.633 Y141.935 E.78902
G1 X101.099 Y141.935 E.01644
G1 X82.97 Y160.065 E.78902
G1 X82.436 Y160.065 E.01644
G1 X100.565 Y141.935 E.78902
G1 X100.031 Y141.935 E.01644
G1 X81.902 Y160.065 E.78902
G1 X81.368 Y160.065 E.01644
G1 X99.497 Y141.935 E.78902
G1 X99.065 Y141.935 E.0133
G1 X99.065 Y141.833 E.00314
G1 X80.833 Y160.065 E.79346
G1 X80.299 Y160.065 E.01644
G1 X99.065 Y141.299 E.8167
G1 X99.065 Y140.765 E.01644
G1 X79.765 Y160.065 E.83994
G1 X79.231 Y160.065 E.01644
G1 X99.065 Y140.231 E.86319
G1 X99.065 Y139.697 E.01644
G1 X78.697 Y160.065 E.88643
G1 X78.163 Y160.065 E.01644
G1 X99.065 Y139.163 E.90968
G1 X99.065 Y138.629 E.01644
G1 X77.629 Y160.065 E.93292
G1 X77.095 Y160.065 E.01644
G1 X99.065 Y138.095 E.95617
G1 X99.065 Y137.561 E.01644
G1 X76.561 Y160.065 E.97941
G1 X76.027 Y160.065 E.01644
G1 X99.065 Y137.027 E1.00266
G1 X99.065 Y136.493 E.01644
G1 X75.492 Y160.065 E1.0259
G1 X74.958 Y160.065 E.01644
G1 X99.065 Y135.958 E1.04915
G1 X99.065 Y135.424 E.01644
G1 X74.424 Y160.065 E1.07239
G1 X73.89 Y160.065 E.01644
G1 X99.065 Y134.89 E1.09564
G1 X99.065 Y134.356 E.01644
G1 X73.356 Y160.065 E1.11888
G1 X72.822 Y160.065 E.01644
G1 X99.065 Y133.822 E1.14212
G1 X99.065 Y133.288 E.01644
G1 X72.288 Y160.065 E1.16537
G1 X71.754 Y160.065 E.01644
G1 X99.065 Y132.754 E1.18861
G1 X99.065 Y132.22 E.01644
G1 X71.22 Y160.065 E1.21186
G1 X70.686 Y160.065 E.01644
G1 X99.065 Y131.686 E1.2351
G1 X99.065 Y131.152 E.01644
G1 X70.152 Y160.065 E1.25835
G1 X69.617 Y160.065 E.01644
G1 X99.065 Y130.618 E1.28159
G1 X99.065 Y130.083 E.01644
G1 X69.083 Y160.065 E1.30484
G1 X68.549 Y160.065 E.01644
G1 X99.065 Y129.549 E1.32808
G1 X99.065 Y129.015 E.01644
G1 X68.015 Y160.065 E1.35133
G1 X67.481 Y160.065 E.01644
G1 X99.065 Y128.481 E1.37457
G1 X99.065 Y127.947 E.01644
G1 X66.947 Y160.065 E1.39781
G1 X66.413 Y160.065 E.01644
G1 X99.065 Y127.413 E1.42106
G1 X99.065 Y126.879 E.01644
G1 X65.879 Y160.065 E1.4443
G1 X65.345 Y160.065 E.01644
G1 X99.065 Y126.345 E1.46755
G1 X99.065 Y125.811 E.01644
G1 X64.811 Y160.065 E1.49079
G1 X64.277 Y160.065 E.01644
G1 X99.065 Y125.277 E1.51404
G1 X99.065 Y124.742 E.01644
G1 X63.742 Y160.065 E1.53728
G1 X63.208 Y160.065 E.01644
G1 X99.065 Y124.208 E1.56053
G1 X99.065 Y123.674 E.01644
G1 X62.674 Y160.065 E1.58377
G1 X62.14 Y160.065 E.01644
G1 X99.065 Y123.14 E1.60702
G1 X99.065 Y122.606 E.01644
G1 X61.606 Y160.065 E1.63026
G1 X61.072 Y160.065 E.01644
G1 X99.065 Y122.072 E1.65351
G1 X99.065 Y121.538 E.01644
G1 X60.538 Y160.065 E1.67675
G1 X60.004 Y160.065 E.01644
G1 X99.065 Y121.004 E1.69999
G1 X99.065 Y120.47 E.01644
G1 X59.47 Y160.065 E1.72324
G1 X58.936 Y160.065 E.01644
G1 X99.065 Y119.936 E1.74648
G1 X99.065 Y119.402 E.01644
G1 X58.402 Y160.065 E1.76973
G1 X57.867 Y160.065 E.01644
G1 X99.065 Y118.867 E1.79297
G1 X99.065 Y118.333 E.01644
G1 X57.333 Y160.065 E1.81622
G1 X56.799 Y160.065 E.01644
G1 X99.065 Y117.799 E1.83946
G1 X99.065 Y117.265 E.01644
G1 X56.265 Y160.065 E1.86271
G1 X55.731 Y160.065 E.01644
G1 X99.065 Y116.731 E1.88595
G1 X99.065 Y116.197 E.01644
G1 X55.197 Y160.065 E1.9092
G1 X54.663 Y160.065 E.01644
G1 X99.065 Y115.663 E1.93244
G1 X99.065 Y115.129 E.01644
G1 X54.129 Y160.065 E1.95569
G1 X53.595 Y160.065 E.01644
G1 X99.065 Y114.595 E1.97893
G1 X99.065 Y114.061 E.01644
G1 X53.061 Y160.065 E2.00217
G1 X52.527 Y160.065 E.01644
G1 X99.065 Y113.527 E2.02542
G1 X99.065 Y112.992 E.01644
G1 X51.992 Y160.065 E2.04866
G1 X51.458 Y160.065 E.01644
G1 X99.065 Y112.458 E2.07191
G1 X99.065 Y111.924 E.01644
G1 X50.924 Y160.065 E2.09515
G1 X50.39 Y160.065 E.01644
G1 X99.065 Y111.39 E2.1184
G1 X99.065 Y110.856 E.01644
G1 X49.856 Y160.065 E2.14164
G1 X49.322 Y160.065 E.01644
G1 X117.451 Y91.935 E2.96511
G1 X117.985 Y91.935 E.01644
G1 X99.856 Y110.065 E.78902
G1 X100.39 Y110.065 E.01644
G1 X118.52 Y91.935 E.78902
G1 X119.054 Y91.935 E.01644
G1 X100.924 Y110.065 E.78902
G1 X101.458 Y110.065 E.01644
G1 X119.588 Y91.935 E.78902
G1 X120.122 Y91.935 E.01644
G1 X101.992 Y110.065 E.78902
G1 X102.527 Y110.065 E.01644
G1 X120.656 Y91.935 E.78902
G1 X121.19 Y91.935 E.01644
G1 X103.061 Y110.065 E.78902
G1 X103.595 Y110.065 E.01644
G1 X121.724 Y91.935 E.78902
G1 X122.258 Y91.935 E.01644
G1 X104.129 Y110.065 E.78902
G1 X104.663 Y110.065 E.01644
G1 X122.792 Y91.935 E.78902
G1 X123.326 Y91.935 E.01644
G1 X105.197 Y110.065 E.78902
G1 X105.731 Y110.065 E.01644
G1 X123.86 Y91.935 E.78902
G1 X124.395 Y91.935 E.01644
G1 X106.265 Y110.065 E.78902
G1 X106.799 Y110.065 E.01644
G1 X124.929 Y91.935 E.78902
G1 X125.463 Y91.935 E.01644
G1 X107.333 Y110.065 E.78902
G1 X107.867 Y110.065 E.01644
G1 X125.997 Y91.935 E.78902
G1 X126.531 Y91.935 E.01644
G1 X108.402 Y110.065 E.78902
G1 X108.936 Y110.065 E.01644
G1 X127.065 Y91.935 E.78902
G1 X127.599 Y91.935 E.01644
G1 X109.47 Y110.065 E.78902
G1 X110.004 Y110.065 E.01644
G1 X128.133 Y91.935 E.78902
G1 X128.667 Y91.935 E.01644
G1 X110.538 Y110.065 E.78902
G1 X110.935 Y110.065 E.01223
G1 X110.935 Y110.201 E.00421
G1 X129.201 Y91.935 E.79497
G1 X129.735 Y91.935 E.01644
G1 X110.935 Y110.735 E.81822
G1 X110.935 Y111.27 E.01644
G1 X130.27 Y91.935 E.84146
G1 X130.804 Y91.935 E.01644
G1 X110.935 Y111.804 E.86471
G1 X110.935 Y112.338 E.01644
G1 X131.338 Y91.935 E.88795
G1 X131.872 Y91.935 E.01644
G1 X110.935 Y112.872 E.91119
G1 X110.935 Y113.406 E.01644
G1 X132.406 Y91.935 E.93444
G1 X132.94 Y91.935 E.01644
G1 X110.935 Y113.94 E.95768
G1 X110.935 Y114.474 E.01644
G1 X133.474 Y91.935 E.98093
G1 X134.008 Y91.935 E.01644
G1 X110.935 Y115.008 E1.00417
G1 X110.935 Y115.542 E.01644
G1 X134.542 Y91.935 E1.02742
G1 X135.076 Y91.935 E.01644
G1 X110.935 Y116.076 E1.05066
G1 X110.935 Y116.61 E.01644
G1 X135.611 Y91.935 E1.07391
G1 X136.145 Y91.935 E.01644
G1 X110.935 Y117.145 E1.09715
G1 X110.935 Y117.679 E.01644
G1 X136.679 Y91.935 E1.1204
G1 X137.213 Y91.935 E.01644
G1 X110.935 Y118.213 E1.14364
G1 X110.935 Y118.747 E.01644
G1 X137.747 Y91.935 E1.16689
G1 X138.281 Y91.935 E.01644
G1 X110.935 Y119.281 E1.19013
G1 X110.935 Y119.815 E.01644
G1 X138.815 Y91.935 E1.21337
G1 X139.349 Y91.935 E.01644
M73 P29 R36
G1 X110.935 Y120.349 E1.23662
G1 X110.935 Y120.883 E.01644
G1 X139.883 Y91.935 E1.25986
G1 X140.417 Y91.935 E.01644
G1 X110.935 Y121.417 E1.28311
G1 X110.935 Y121.951 E.01644
G1 X140.951 Y91.935 E1.30635
G1 X141.486 Y91.935 E.01644
G1 X110.935 Y122.486 E1.3296
G1 X110.935 Y123.02 E.01644
G1 X142.02 Y91.935 E1.35284
G1 X142.554 Y91.935 E.01644
G1 X110.935 Y123.554 E1.37609
G1 X110.935 Y124.088 E.01644
G1 X143.088 Y91.935 E1.39933
G1 X143.622 Y91.935 E.01644
G1 X110.935 Y124.622 E1.42258
G1 X110.935 Y125.156 E.01644
G1 X144.156 Y91.935 E1.44582
G1 X144.69 Y91.935 E.01644
G1 X110.935 Y125.69 E1.46907
G1 X110.935 Y126.224 E.01644
G1 X145.224 Y91.935 E1.49231
G1 X145.758 Y91.935 E.01644
G1 X110.935 Y126.758 E1.51555
G1 X110.935 Y127.292 E.01644
G1 X146.292 Y91.935 E1.5388
G1 X146.826 Y91.935 E.01644
G1 X110.935 Y127.826 E1.56204
G1 X110.935 Y128.361 E.01644
G1 X147.361 Y91.935 E1.58529
G1 X147.895 Y91.935 E.01644
G1 X110.935 Y128.895 E1.60853
G1 X110.935 Y129.429 E.01644
G1 X148.429 Y91.935 E1.63178
G1 X148.963 Y91.935 E.01644
G1 X110.935 Y129.963 E1.65502
G1 X110.935 Y130.497 E.01644
G1 X149.497 Y91.935 E1.67827
G1 X150.031 Y91.935 E.01644
G1 X110.935 Y131.031 E1.70151
G1 X110.935 Y131.565 E.01644
G1 X150.565 Y91.935 E1.72476
G1 X151.099 Y91.935 E.01644
G1 X110.935 Y132.099 E1.748
G1 X110.935 Y132.633 E.01644
G1 X151.633 Y91.935 E1.77124
G1 X152.167 Y91.935 E.01644
G1 X110.935 Y133.167 E1.79449
G1 X110.935 Y133.701 E.01644
G1 X152.701 Y91.935 E1.81773
G1 X153.236 Y91.935 E.01644
G1 X110.935 Y134.236 E1.84098
G1 X110.935 Y134.77 E.01644
G1 X153.77 Y91.935 E1.86422
G1 X154.304 Y91.935 E.01644
G1 X110.935 Y135.304 E1.88747
G1 X110.935 Y135.838 E.01644
G1 X154.838 Y91.935 E1.91071
G1 X155.372 Y91.935 E.01644
G1 X110.935 Y136.372 E1.93396
G1 X110.935 Y136.906 E.01644
G1 X155.906 Y91.935 E1.9572
G1 X156.44 Y91.935 E.01644
G1 X110.935 Y137.44 E1.98045
G1 X110.935 Y137.974 E.01644
G1 X156.974 Y91.935 E2.00369
G1 X157.508 Y91.935 E.01644
G1 X110.935 Y138.508 E2.02694
G1 X110.935 Y139.042 E.01644
G1 X158.042 Y91.935 E2.05018
G1 X158.576 Y91.935 E.01644
G1 X110.935 Y139.576 E2.07342
G1 X110.935 Y140.111 E.01644
G1 X159.111 Y91.935 E2.09667
G1 X159.645 Y91.935 E.01644
G1 X110.935 Y140.645 E2.11991
G1 X110.935 Y141.179 E.01644
G1 X160.348 Y91.766 E2.15054
G1 X110.678 Y91.766 F30000
G1 F15000
G1 X71.411 Y131.032 E1.70895
G2 X71.859 Y130.051 I-5.152 J-2.941 E.03324
G1 X109.974 Y91.935 E1.65885
G1 X109.44 Y91.935 E.01644
G1 X72.154 Y129.221 E1.62275
G1 X72.362 Y128.479 E.02371
G1 X108.906 Y91.935 E1.59045
G1 X108.372 Y91.935 E.01644
G1 X72.484 Y127.823 E1.56191
G2 X72.572 Y127.201 I-3.363 J-.792 E.01935
G1 X107.838 Y91.935 E1.53484
G1 X107.304 Y91.935 E.01644
G1 X72.625 Y126.614 E1.50926
G2 X72.636 Y126.069 I-2.979 J-.33 E.01679
G1 X106.77 Y91.935 E1.48555
G1 X106.235 Y91.935 E.01644
G1 X72.636 Y125.535 E1.46231
G2 X72.594 Y125.043 I-2.716 J-.016 E.01522
G1 X105.701 Y91.935 E1.44089
G1 X105.167 Y91.935 E.01644
G1 X72.549 Y124.553 E1.41959
G2 X72.47 Y124.099 I-2.527 J.209 E.01422
G1 X104.633 Y91.935 E1.39982
G1 X104.099 Y91.935 E.01644
G1 X72.386 Y123.648 E1.38019
G2 X72.278 Y123.222 I-2.386 J.38 E.01354
G1 X103.565 Y91.935 E1.36165
G1 X103.031 Y91.935 E.01644
G1 X72.161 Y122.805 E1.34349
G2 X72.031 Y122.401 I-2.277 J.513 E.01307
G1 X102.497 Y91.935 E1.32593
G1 X101.963 Y91.935 E.01644
G1 X71.883 Y122.015 E1.3091
G2 X71.735 Y121.629 I-2.199 J.626 E.01273
G1 X101.429 Y91.935 E1.29232
G1 X100.895 Y91.935 E.01644
G1 X71.559 Y121.27 E1.27671
G1 X71.384 Y120.912 E.01229
G1 X100.36 Y91.935 E1.26111
G1 X99.826 Y91.935 E.01644
G1 X71.194 Y120.568 E1.24613
G1 X70.992 Y120.236 E.01196
G1 X99.292 Y91.935 E1.23168
G1 X98.758 Y91.935 E.01644
G1 X70.79 Y119.903 E1.21722
G2 X70.563 Y119.596 I-1.817 J1.104 E.01177
G1 X98.224 Y91.935 E1.20385
G1 X97.69 Y91.935 E.01644
G1 X70.336 Y119.289 E1.1905
G2 X70.099 Y118.992 I-1.748 J1.146 E.01171
G1 X97.156 Y91.935 E1.17755
G1 X96.622 Y91.935 E.01644
G1 X69.848 Y118.71 E1.16526
G1 X69.596 Y118.427 E.01164
G1 X96.088 Y91.935 E1.15298
G1 X95.554 Y91.935 E.01644
G1 X69.326 Y118.163 E1.14148
G1 X69.05 Y117.905 E.01163
G1 X95.02 Y91.935 E1.13026
G1 X94.485 Y91.935 E.01644
G1 X68.771 Y117.65 E1.11915
G1 X68.47 Y117.417 E.01171
G1 X93.951 Y91.935 E1.10899
G1 X93.417 Y91.935 E.01644
G1 X68.169 Y117.183 E1.09883
G2 X67.856 Y116.962 I-1.368 J1.606 E.01181
G1 X92.883 Y91.935 E1.08921
G1 X92.349 Y91.935 E.01644
G1 X67.531 Y116.754 E1.08014
G1 X67.205 Y116.545 E.0119
G1 X91.815 Y91.935 E1.07107
G1 X91.281 Y91.935 E.01644
G1 X66.855 Y116.361 E1.06305
G1 X66.503 Y116.179 E.01219
G1 X90.747 Y91.935 E1.05512
G1 X90.213 Y91.935 E.01644
G1 X66.14 Y116.008 E1.04767
G1 X65.761 Y115.853 E.01261
G1 X89.679 Y91.935 E1.04094
G1 X89.144 Y91.935 E.01644
G1 X65.381 Y115.698 E1.03421
G2 X64.973 Y115.573 I-.895 J2.189 E.01317
G1 X88.61 Y91.935 E1.02875
G1 X88.076 Y91.935 E.01644
G1 X64.563 Y115.448 E1.02332
G2 X64.133 Y115.345 I-.781 J2.308 E.01365
G1 X87.542 Y91.935 E1.01883
G1 X87.008 Y91.935 E.01644
G1 X63.69 Y115.253 E1.01483
G2 X63.232 Y115.178 I-.642 J2.474 E.01433
G1 X86.474 Y91.935 E1.01155
G1 X85.94 Y91.935 E.01644
G1 X62.752 Y115.123 E1.00916
M73 P29 R35
G2 X62.257 Y115.085 I-.458 J2.696 E.01532
G1 X85.406 Y91.935 E1.0075
G1 X84.872 Y91.935 E.01644
G1 X61.734 Y115.073 E1.00698
G2 X61.188 Y115.085 I-.205 J3 E.01685
G1 X84.338 Y91.935 E1.00753
G1 X83.804 Y91.935 E.01644
G1 X60.614 Y115.125 E1.00923
G2 X59.994 Y115.211 I.162 J3.443 E.0193
G1 X83.269 Y91.935 E1.01299
G1 X82.735 Y91.935 E.01644
G1 X59.341 Y115.329 E1.01815
G1 X58.624 Y115.513 E.0228
G1 X82.201 Y91.935 E1.02614
G1 X81.667 Y91.935 E.01644
G1 X57.811 Y115.792 E1.03827
G1 X57.583 Y115.873 E.00743
G1 X56.864 Y116.205 E.0244
G1 X81.133 Y91.935 E1.05625
G1 X80.599 Y91.935 E.01644
G1 X55.577 Y116.957 E1.08899
G2 X52.922 Y119.491 I5.958 J8.9 E.11352
G1 X52.675 Y119.86 E.01365
G1 X28.935 Y143.599 E1.03318
G1 X28.935 Y144.133 E.01644
G1 X51.902 Y121.166 E.99956
G1 X51.489 Y122.114 E.03181
G1 X28.935 Y144.667 E.98157
G1 X28.935 Y145.201 E.01644
G1 X51.226 Y122.911 E.97013
G2 X51.047 Y123.624 I3.816 J1.336 E.02265
G1 X28.935 Y145.735 E.96235
G1 X28.935 Y146.269 E.01644
G1 X50.919 Y124.286 E.95676
G1 X50.834 Y124.905 E.01923
G1 X28.935 Y146.804 E.95306
G1 X28.935 Y147.338 E.01644
G1 X50.799 Y125.474 E.95153
G2 X50.776 Y126.031 I3.04 J.402 E.01717
G1 X28.935 Y147.872 E.95054
G1 X28.935 Y148.406 E.01644
G1 X50.799 Y126.542 E.95156
G2 X50.827 Y127.048 I2.788 J.1 E.01562
G1 X28.935 Y148.94 E.95278
G1 X28.935 Y149.474 E.01644
G1 X50.892 Y127.518 E.95558
G2 X50.957 Y127.987 I2.629 J-.125 E.01459
G1 X28.935 Y150.008 E.95841
G1 X28.935 Y150.542 E.01644
G1 X51.057 Y128.42 E.96279
G1 X51.158 Y128.854 E.0137
G1 X28.935 Y151.076 E.96716
G1 X28.935 Y151.61 E.01644
G1 X51.283 Y129.263 E.97261
G1 X51.416 Y129.664 E.01301
G1 X28.935 Y152.144 E.97838
G1 X28.935 Y152.679 E.01644
G1 X51.56 Y130.053 E.98469
G1 X51.722 Y130.426 E.01249
G1 X28.935 Y153.213 E.99173
G1 X28.935 Y153.747 E.01644
G1 X51.884 Y130.798 E.99876
G2 X52.072 Y131.144 I1.986 J-.856 E.01214
G1 X28.935 Y154.281 E1.00695
G1 X28.935 Y154.815 E.01644
G1 X52.261 Y131.489 E1.01518
G2 X52.461 Y131.823 I1.927 J-.929 E.012
G1 X28.935 Y155.349 E1.02389
G1 X28.935 Y155.883 E.01644
G1 X52.676 Y132.142 E1.03324
G1 X52.891 Y132.462 E.01184
G1 X28.935 Y156.417 E1.04258
G1 X28.935 Y156.951 E.01644
G1 X53.127 Y132.76 E1.05285
G1 X53.366 Y133.054 E.01168
G1 X28.935 Y157.485 E1.06328
G1 X28.935 Y158.019 E.01644
G1 X53.612 Y133.343 E1.07395
G1 X53.876 Y133.613 E.01162
G1 X28.935 Y158.554 E1.08544
G1 X28.935 Y159.088 E.01644
G1 X54.14 Y133.883 E1.09693
G2 X54.418 Y134.139 I1.538 J-1.397 E.01165
G1 X28.935 Y159.622 E1.10905
G1 X28.935 Y160.065 E.01363
G1 X29.026 Y160.065 E.00281
G1 X54.706 Y134.385 E1.11764
G1 X54.995 Y134.63 E.01166
G1 X29.561 Y160.065 E1.10694
G1 X30.095 Y160.065 E.01644
G1 X55.307 Y134.852 E1.09729
G1 X55.62 Y135.073 E.01179
G1 X30.629 Y160.065 E1.08767
G1 X31.163 Y160.065 E.01644
G1 X55.943 Y135.285 E1.07846
G1 X56.281 Y135.48 E.01203
G1 X31.697 Y160.065 E1.06995
G1 X32.231 Y160.065 E.01644
G1 X56.62 Y135.676 E1.06145
G2 X56.981 Y135.849 I1.131 J-1.89 E.01233
G1 X32.765 Y160.065 E1.0539
G1 X33.299 Y160.065 E.01644
G1 X57.346 Y136.018 E1.04656
G2 X57.721 Y136.177 I1.057 J-1.977 E.01256
G1 X33.833 Y160.065 E1.03965
G1 X34.367 Y160.065 E.01644
G1 X58.115 Y136.317 E1.03356
G1 X58.51 Y136.457 E.01287
G1 X34.902 Y160.065 E1.02746
G1 X35.436 Y160.065 E.01644
G1 X58.934 Y136.566 E1.02269
G1 X59.359 Y136.675 E.01351
G1 X35.97 Y160.065 E1.01795
G1 X36.504 Y160.065 E.01644
G1 X59.809 Y136.759 E1.01428
G1 X60.269 Y136.833 E.01434
G1 X37.038 Y160.065 E1.01106
G1 X37.572 Y160.065 E.01644
G1 X60.752 Y136.885 E1.00883
G1 X61.252 Y136.919 E.01542
G1 X38.106 Y160.065 E1.00734
G1 X38.64 Y160.065 E.01644
G1 X61.779 Y136.926 E1.00702
G1 X62.325 Y136.914 E.01682
G1 X39.174 Y160.065 E1.00757
G1 X39.708 Y160.065 E.01644
G1 X62.914 Y136.859 E1.00997
G2 X63.526 Y136.781 I-.118 J-3.39 E.01899
G1 X40.242 Y160.065 E1.01334
G1 X40.777 Y160.065 E.01644
G1 X64.2 Y136.641 E1.01944
G2 X64.938 Y136.438 I-.745 J-4.14 E.02358
G1 X41.311 Y160.065 E1.02829
G1 X41.845 Y160.065 E.01644
G1 X65.764 Y136.146 E1.04099
G2 X66.75 Y135.693 I-1.984 J-5.628 E.03344
G1 X42.379 Y160.065 E1.06068
G1 X42.913 Y160.065 E.01644
G1 X111.042 Y91.935 E2.96511
M73 P30 R35
G1 X111.576 Y91.935 E.01644
G1 X43.447 Y160.065 E2.96511
G1 X43.981 Y160.065 E.01644
G1 X112.11 Y91.935 E2.96511
G1 X112.645 Y91.935 E.01644
G1 X44.515 Y160.065 E2.96511
G1 X45.049 Y160.065 E.01644
G1 X113.179 Y91.935 E2.96511
G1 X113.713 Y91.935 E.01644
G1 X45.583 Y160.065 E2.96511
G1 X46.117 Y160.065 E.01644
G1 X114.247 Y91.935 E2.96511
G1 X114.781 Y91.935 E.01644
G1 X46.652 Y160.065 E2.96511
G1 X47.186 Y160.065 E.01644
G1 X115.315 Y91.935 E2.96511
G1 X115.849 Y91.935 E.01644
G1 X47.72 Y160.065 E2.96511
G1 X48.254 Y160.065 E.01644
G1 X116.383 Y91.935 E2.96511
G1 X116.917 Y91.935 E.01644
G1 X48.618 Y160.234 E2.97249
G1 X28.766 Y143.235 F30000
G1 F15000
G1 X80.065 Y91.935 E2.23263
G1 X79.531 Y91.935 E.01644
G1 X28.935 Y142.531 E2.202
G1 X28.935 Y141.997 E.01644
G1 X78.997 Y91.935 E2.17876
G1 X78.463 Y91.935 E.01644
G1 X28.935 Y141.463 E2.15552
G1 X28.935 Y140.929 E.01644
G1 X77.929 Y91.935 E2.13227
G1 X77.394 Y91.935 E.01644
G1 X28.935 Y140.394 E2.10903
G1 X28.935 Y139.86 E.01644
G1 X76.86 Y91.935 E2.08578
G1 X76.326 Y91.935 E.01644
G1 X28.935 Y139.326 E2.06254
G1 X28.935 Y138.792 E.01644
G1 X75.792 Y91.935 E2.03929
G1 X75.258 Y91.935 E.01644
G1 X28.935 Y138.258 E2.01605
G1 X28.935 Y137.724 E.01644
G1 X74.724 Y91.935 E1.9928
G1 X74.19 Y91.935 E.01644
G1 X28.935 Y137.19 E1.96956
G1 X28.935 Y136.656 E.01644
G1 X73.656 Y91.935 E1.94631
G1 X73.122 Y91.935 E.01644
G1 X28.935 Y136.122 E1.92307
G1 X28.935 Y135.588 E.01644
G1 X72.588 Y91.935 E1.89982
G1 X72.054 Y91.935 E.01644
G1 X28.935 Y135.054 E1.87658
G1 X28.935 Y134.519 E.01644
G1 X71.519 Y91.935 E1.85334
G1 X70.985 Y91.935 E.01644
G1 X28.935 Y133.985 E1.83009
G1 X28.935 Y133.451 E.01644
G1 X70.451 Y91.935 E1.80685
G1 X69.917 Y91.935 E.01644
G1 X28.935 Y132.917 E1.7836
G1 X28.935 Y132.383 E.01644
G1 X69.383 Y91.935 E1.76036
G1 X68.849 Y91.935 E.01644
G1 X28.935 Y131.849 E1.73711
G1 X28.935 Y131.315 E.01644
G1 X68.315 Y91.935 E1.71387
G1 X67.781 Y91.935 E.01644
G1 X28.935 Y130.781 E1.69062
G1 X28.935 Y130.247 E.01644
G1 X67.247 Y91.935 E1.66738
G1 X66.713 Y91.935 E.01644
G1 X28.935 Y129.713 E1.64413
G1 X28.935 Y129.179 E.01644
G1 X66.179 Y91.935 E1.62089
G1 X65.644 Y91.935 E.01644
G1 X28.935 Y128.644 E1.59764
G1 X28.935 Y128.11 E.01644
G1 X65.11 Y91.935 E1.5744
G1 X64.576 Y91.935 E.01644
G1 X28.935 Y127.576 E1.55116
G1 X28.935 Y127.042 E.01644
G1 X64.042 Y91.935 E1.52791
G1 X63.508 Y91.935 E.01644
G1 X28.935 Y126.508 E1.50467
G1 X28.935 Y125.974 E.01644
G1 X62.974 Y91.935 E1.48142
G1 X62.44 Y91.935 E.01644
G1 X28.935 Y125.44 E1.45818
G1 X28.935 Y124.906 E.01644
G1 X61.906 Y91.935 E1.43493
G1 X61.372 Y91.935 E.01644
G1 X28.935 Y124.372 E1.41169
G1 X28.935 Y123.838 E.01644
G1 X60.838 Y91.935 E1.38844
G1 X60.304 Y91.935 E.01644
G1 X28.935 Y123.304 E1.3652
G1 X28.935 Y122.769 E.01644
G1 X59.769 Y91.935 E1.34195
G1 X59.235 Y91.935 E.01644
G1 X28.935 Y122.235 E1.31871
G1 X28.935 Y121.701 E.01644
G1 X58.701 Y91.935 E1.29546
G1 X58.167 Y91.935 E.01644
G1 X28.935 Y121.167 E1.27222
G1 X28.935 Y120.633 E.01644
G1 X57.633 Y91.935 E1.24898
G1 X57.099 Y91.935 E.01644
G1 X28.935 Y120.099 E1.22573
G1 X28.935 Y119.565 E.01644
G1 X56.565 Y91.935 E1.20249
G1 X56.031 Y91.935 E.01644
G1 X28.935 Y119.031 E1.17924
G1 X28.935 Y118.497 E.01644
G1 X55.497 Y91.935 E1.156
G1 X54.963 Y91.935 E.01644
G1 X28.935 Y117.963 E1.13275
G1 X28.935 Y117.429 E.01644
G1 X54.429 Y91.935 E1.10951
G1 X53.894 Y91.935 E.01644
G1 X28.935 Y116.894 E1.08626
G1 X28.935 Y116.36 E.01644
G1 X53.36 Y91.935 E1.06302
G1 X52.826 Y91.935 E.01644
G1 X28.935 Y115.826 E1.03977
G1 X28.935 Y115.292 E.01644
G1 X52.292 Y91.935 E1.01653
G1 X51.758 Y91.935 E.01644
G1 X28.935 Y114.758 E.99329
G1 X28.935 Y114.224 E.01644
G1 X51.224 Y91.935 E.97004
G1 X50.69 Y91.935 E.01644
G1 X28.935 Y113.69 E.9468
G1 X28.935 Y113.156 E.01644
G1 X50.156 Y91.935 E.92355
G1 X49.622 Y91.935 E.01644
G1 X28.935 Y112.622 E.90031
G1 X28.935 Y112.088 E.01644
G1 X49.088 Y91.935 E.87706
G1 X48.554 Y91.935 E.01644
G1 X28.935 Y111.553 E.85382
G1 X28.935 Y111.019 E.01644
G1 X48.019 Y91.935 E.83057
G1 X47.485 Y91.935 E.01644
G1 X28.935 Y110.485 E.80733
G1 X28.935 Y109.951 E.01644
G1 X46.951 Y91.935 E.78408
G1 X46.417 Y91.935 E.01644
G1 X28.935 Y109.417 E.76084
G1 X28.935 Y108.883 E.01644
G1 X45.883 Y91.935 E.73759
G1 X45.349 Y91.935 E.01644
G1 X28.935 Y108.349 E.71435
G1 X28.935 Y107.815 E.01644
G1 X44.815 Y91.935 E.69111
G1 X44.281 Y91.935 E.01644
G1 X28.935 Y107.281 E.66786
G1 X28.935 Y106.747 E.01644
G1 X43.747 Y91.935 E.64462
G1 X43.213 Y91.935 E.01644
G1 X28.935 Y106.213 E.62137
G1 X28.935 Y105.678 E.01644
G1 X42.678 Y91.935 E.59813
G1 X42.144 Y91.935 E.01644
G1 X28.935 Y105.144 E.57488
G1 X28.935 Y104.61 E.01644
G1 X41.61 Y91.935 E.55164
G1 X41.076 Y91.935 E.01644
G1 X28.935 Y104.076 E.52839
G1 X28.935 Y103.542 E.01644
G1 X40.542 Y91.935 E.50515
G1 X40.008 Y91.935 E.01644
G1 X28.935 Y103.008 E.4819
G1 X28.935 Y102.474 E.01644
G1 X39.474 Y91.935 E.45866
G1 X38.94 Y91.935 E.01644
G1 X28.935 Y101.94 E.43541
G1 X28.935 Y101.406 E.01644
G1 X38.406 Y91.935 E.41217
G1 X37.872 Y91.935 E.01644
G1 X28.935 Y100.872 E.38893
G1 X28.935 Y100.338 E.01644
G1 X37.338 Y91.935 E.36568
G1 X36.803 Y91.935 E.01644
G1 X28.935 Y99.803 E.34244
G1 X28.935 Y99.269 E.01644
G1 X36.269 Y91.935 E.31919
G1 X35.735 Y91.935 E.01644
G1 X28.935 Y98.735 E.29595
G1 X28.935 Y98.201 E.01644
G1 X31.354 Y95.783 E.10526
G1 X31.334 Y95.792 E.00067
G3 X30.679 Y95.923 I-.7 J-1.792 E.02066
G1 X28.935 Y97.667 E.0759
G1 X28.935 Y97.133 E.01644
G1 X30.159 Y95.909 E.05327
G1 X29.726 Y95.808 E.01368
G1 X28.935 Y96.599 E.03442
G1 X28.935 Y96.065 E.01644
G1 X29.354 Y95.646 E.01821
G3 X29.03 Y95.436 I.433 J-1.024 E.01195
G1 X28.766 Y95.7 E.01149
; WIPE_START
G1 X29.03 Y95.436 E-.14186
G1 X29.354 Y95.646 E-.14677
G1 X28.935 Y96.065 E-.22491
G1 X28.935 Y96.599 E-.20296
G1 X29.016 Y96.518 E-.04351
; WIPE_END
G1 E-.04 F1800
G1 X28.619 Y94.531 Z.8 F30000
G1 Z.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354364
G1 F15000
G1 X28.559 Y94.192 E.00874
; LINE_WIDTH: 0.327696
G1 X28.537 Y94.026 E.00389
; LINE_WIDTH: 0.283928
G1 X28.516 Y93.86 E.00329
; LINE_WIDTH: 0.244295
G3 X28.514 Y93.159 I5.786 J-.364 E.0115
; LINE_WIDTH: 0.281527
G3 X28.537 Y92.974 I2.135 J.177 E.00363
; LINE_WIDTH: 0.327704
G1 X28.559 Y92.808 E.00389
; LINE_WIDTH: 0.354377
G1 X28.619 Y92.469 E.00873
G1 X29.469 Y91.619 F30000
; LINE_WIDTH: 0.354389
G1 F15000
G1 X29.808 Y91.559 E.00874
; LINE_WIDTH: 0.327703
G1 X29.974 Y91.537 E.00389
; LINE_WIDTH: 0.283907
G1 X30.14 Y91.516 E.00329
; LINE_WIDTH: 0.244285
G3 X30.841 Y91.514 I.364 J5.784 E.0115
; LINE_WIDTH: 0.281527
G3 X31.026 Y91.537 I-.178 J2.138 E.00363
; LINE_WIDTH: 0.3277
G1 X31.192 Y91.559 E.00389
; LINE_WIDTH: 0.354377
G1 X31.531 Y91.619 E.00874
G1 X32.315 Y92.151 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42058
G1 F15000
G1 X32.531 Y91.935 E.00941
G1 X33.065 Y91.935 E.01644
G1 X32.646 Y92.354 E.01821
G1 X32.808 Y92.726 E.01249
G1 X33.599 Y91.935 E.03442
G1 X34.133 Y91.935 E.01644
G1 X32.909 Y93.159 E.05327
G3 X32.923 Y93.679 I-1.465 J.3 E.01609
G1 X34.667 Y91.935 E.0759
G1 X35.201 Y91.935 E.01644
G1 X32.377 Y94.76 E.12292
; CHANGE_LAYER
; Z_HEIGHT: 0.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X33.791 Y93.346 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 3/25
; update layer progress
M73 L3
M991 S0 P2 ;notify layer change
G17
G3 Z.8 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z1 F30000
G1 X51.287 Y124.063 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.502 Y123.139 E.03146
G3 X60.507 Y115.466 I10.209 J2.86 E.41633
G1 X61.47 Y115.4 E.03202
G3 X51.277 Y124.122 I.241 J10.599 E1.72788
M204 S250
G1 X51.67 Y124.151 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.041 J1.848 E.39995
G1 X61.479 Y115.792 E.02856
G3 X51.66 Y124.21 I.232 J10.207 E1.54069
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.376
G1 X52.171 Y122.363 E-.35313
G1 X52.203 Y122.288 E-.03087
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.056 Z1 F30000
G1 X223.536 Y94.249 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.678 Y94.552 E.0111
G2 X227.227 Y94.688 I1.818 J-1.047 E.14052
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.729 J-1.187 E.2441
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.514 Y94.193 I1.183 J1.732 E.09086
M204 S250
G1 X223.9 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.456 Y91.793 I1.606 J-.582 E.09914
G3 X226.355 Y92.018 I.058 J1.678 E.02888
G3 X223.921 Y94.138 I-.849 J1.482 E.19995
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13583
G1 X223.789 Y93.5 E-.11332
G1 X223.815 Y93.203 E-.11331
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11332
G1 X224.189 Y92.4 E-.11331
G1 X224.297 Y92.293 E-.05759
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z1 F30000
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03913
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z1 F30000
G1 X32.108 Y94.083 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X32.111 Y94.086 E.00014
G3 X30.456 Y91.793 I-1.605 J-.586 E.22742
G3 X31.355 Y92.018 I.058 J1.678 E.02888
G3 X32.188 Y93.798 I-.849 J1.482 E.06431
G1 X32.125 Y94.025 E.00725
; WIPE_START
M204 S10000
G1 X32.111 Y94.086 E-.02393
G1 X31.982 Y94.355 E-.11343
G1 X31.811 Y94.6 E-.11332
G1 X31.6 Y94.811 E-.11335
M73 P31 R35
G1 X31.355 Y94.982 E-.11329
G1 X31.085 Y95.108 E-.11333
G1 X30.797 Y95.185 E-.11332
G1 X30.65 Y95.198 E-.05604
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z1 F30000
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.191 J1.73 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02175
G1 X29.258 Y91.602 E.02175
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08591
G1 X28.888 Y92.147 E-.13939
G1 X28.773 Y92.312 E-.07626
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24921
G1 X28.974 Y91.602 E-.14118
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z1 F30000
G1 X227.79 Y91.21 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z1 F30000
G1 Z.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354358
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327667
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281518
G2 X225.841 Y91.514 I-.363 J2.118 E.00363
; LINE_WIDTH: 0.244291
G2 X225.14 Y91.516 I-.336 J5.788 E.0115
; LINE_WIDTH: 0.283917
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327693
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X224.469 Y91.619 E.00873
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X223.301 Y91.766 Z1 F30000
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42058
G1 F15000
G1 X223.564 Y92.028 E.01144
G2 X223.354 Y92.353 I.814 J.758 E.01194
G1 X222.937 Y91.935 E.01816
G1 X222.403 Y91.935 E.01644
G1 X223.192 Y92.725 E.03436
G1 X223.091 Y93.157 E.01368
G1 X221.869 Y91.935 E.05319
G1 X221.335 Y91.935 E.01644
G1 X223.077 Y93.677 E.0758
G2 X223.208 Y94.334 I1.93 J-.045 E.02073
G1 X223.216 Y94.35 E.00055
G1 X220.801 Y91.935 E.1051
G1 X220.267 Y91.935 E.01644
G1 X227.065 Y98.733 E.29586
G1 X227.065 Y98.199 E.01644
G1 X224.65 Y95.784 E.1051
G2 X225.323 Y95.923 I.983 J-3.057 E.0212
G1 X227.065 Y97.665 E.0758
G1 X227.065 Y97.131 E.01644
G1 X225.843 Y95.909 E.05319
G1 X226.275 Y95.808 E.01368
G1 X227.065 Y96.597 E.03436
G1 X227.065 Y96.063 E.01644
G1 X226.647 Y95.646 E.01816
G2 X226.972 Y95.436 I-.434 J-1.024 E.01194
G1 X227.234 Y95.698 E.01144
; WIPE_START
G1 X226.972 Y95.436 E-.14125
G1 X226.647 Y95.646 E-.14674
G1 X227.065 Y96.063 E-.2242
G1 X227.065 Y96.597 E-.20295
G1 X226.981 Y96.514 E-.04485
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y94.531 Z1 F30000
G1 Z.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X227.441 Y94.192 E.00873
; LINE_WIDTH: 0.327699
G1 X227.463 Y94.026 E.00389
; LINE_WIDTH: 0.281511
G2 X227.486 Y93.841 I-2.138 J-.366 E.00363
; LINE_WIDTH: 0.244295
G2 X227.484 Y93.14 I-5.791 J-.336 E.0115
; LINE_WIDTH: 0.283908
G1 X227.463 Y92.974 E.00329
; LINE_WIDTH: 0.327676
G1 X227.441 Y92.808 E.00389
; LINE_WIDTH: 0.354361
G1 X227.381 Y92.469 E.00873
; WIPE_START
G1 X227.441 Y92.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.234 Y99.437 Z1 F30000
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42058
G1 F15000
G1 X219.733 Y91.935 E.32649
G1 X219.198 Y91.935 E.01644
G1 X227.065 Y99.802 E.34235
G1 X227.065 Y100.336 E.01644
G1 X218.664 Y91.935 E.3656
G1 X218.13 Y91.935 E.01644
G1 X227.065 Y100.87 E.38884
G1 X227.065 Y101.404 E.01644
G1 X217.596 Y91.935 E.41209
G1 X217.062 Y91.935 E.01644
G1 X227.065 Y101.938 E.43533
G1 X227.065 Y102.472 E.01644
G1 X216.528 Y91.935 E.45857
G1 X215.994 Y91.935 E.01644
G1 X227.065 Y103.006 E.48182
G1 X227.065 Y103.54 E.01644
G1 X215.46 Y91.935 E.50506
G1 X214.926 Y91.935 E.01644
G1 X227.065 Y104.074 E.52831
G1 X227.065 Y104.608 E.01644
G1 X214.392 Y91.935 E.55155
G1 X213.858 Y91.935 E.01644
G1 X227.065 Y105.142 E.5748
G1 X227.065 Y105.677 E.01644
G1 X213.323 Y91.935 E.59804
G1 X212.789 Y91.935 E.01644
G1 X227.065 Y106.211 E.62129
G1 X227.065 Y106.745 E.01644
G1 X212.255 Y91.935 E.64453
G1 X211.721 Y91.935 E.01644
G1 X227.065 Y107.279 E.66778
G1 X227.065 Y107.813 E.01644
G1 X211.187 Y91.935 E.69102
G1 X210.653 Y91.935 E.01644
G1 X227.065 Y108.347 E.71427
G1 X227.065 Y108.881 E.01644
G1 X210.119 Y91.935 E.73751
G1 X209.585 Y91.935 E.01644
G1 X227.065 Y109.415 E.76075
G1 X227.065 Y109.949 E.01644
G1 X209.051 Y91.935 E.784
G1 X208.517 Y91.935 E.01644
G1 X227.065 Y110.483 E.80724
G1 X227.065 Y111.017 E.01644
G1 X207.983 Y91.935 E.83049
G1 X207.448 Y91.935 E.01644
G1 X227.065 Y111.552 E.85373
G1 X227.065 Y112.086 E.01644
G1 X206.914 Y91.935 E.87698
G1 X206.38 Y91.935 E.01644
G1 X227.065 Y112.62 E.90022
G1 X227.065 Y113.154 E.01644
G1 X205.846 Y91.935 E.92347
G1 X205.312 Y91.935 E.01644
G1 X227.065 Y113.688 E.94671
G1 X227.065 Y114.222 E.01644
G1 X204.778 Y91.935 E.96996
G1 X204.244 Y91.935 E.01644
G1 X227.065 Y114.756 E.9932
G1 X227.065 Y115.29 E.01644
G1 X203.71 Y91.935 E1.01645
G1 X203.176 Y91.935 E.01644
G1 X227.065 Y115.824 E1.03969
G1 X227.065 Y116.358 E.01644
G1 X202.642 Y91.935 E1.06293
G1 X202.108 Y91.935 E.01644
G1 X227.065 Y116.892 E1.08618
G1 X227.065 Y117.427 E.01644
G1 X201.573 Y91.935 E1.10942
G1 X201.039 Y91.935 E.01644
G1 X227.065 Y117.961 E1.13267
G1 X227.065 Y118.495 E.01644
G1 X200.505 Y91.935 E1.15591
G1 X199.971 Y91.935 E.01644
G1 X227.065 Y119.029 E1.17916
G1 X227.065 Y119.563 E.01644
G1 X199.437 Y91.935 E1.2024
G1 X198.903 Y91.935 E.01644
G1 X227.065 Y120.097 E1.22565
G1 X227.065 Y120.631 E.01644
G1 X198.369 Y91.935 E1.24889
G1 X197.835 Y91.935 E.01644
G1 X227.065 Y121.165 E1.27214
G1 X227.065 Y121.699 E.01644
G1 X197.301 Y91.935 E1.29538
G1 X196.767 Y91.935 E.01644
G1 X227.065 Y122.233 E1.31863
G1 X227.065 Y122.767 E.01644
G1 X196.232 Y91.935 E1.34187
G1 X195.698 Y91.935 E.01644
G1 X227.065 Y123.302 E1.36511
G1 X227.065 Y123.836 E.01644
G1 X195.164 Y91.935 E1.38836
G1 X194.63 Y91.935 E.01644
G1 X227.065 Y124.37 E1.4116
G1 X227.065 Y124.904 E.01644
G1 X194.096 Y91.935 E1.43485
G1 X193.562 Y91.935 E.01644
G1 X227.065 Y125.438 E1.45809
G1 X227.065 Y125.972 E.01644
G1 X193.028 Y91.935 E1.48134
G1 X192.494 Y91.935 E.01644
G1 X227.065 Y126.506 E1.50458
G1 X227.065 Y127.04 E.01644
G1 X191.96 Y91.935 E1.52783
G1 X191.426 Y91.935 E.01644
G1 X227.065 Y127.574 E1.55107
G1 X227.065 Y128.108 E.01644
G1 X190.892 Y91.935 E1.57432
G1 X190.357 Y91.935 E.01644
G1 X227.065 Y128.643 E1.59756
G1 X227.065 Y129.177 E.01644
G1 X189.823 Y91.935 E1.6208
G1 X189.289 Y91.935 E.01644
G1 X227.065 Y129.711 E1.64405
G1 X227.065 Y130.245 E.01644
G1 X188.755 Y91.935 E1.66729
G1 X188.221 Y91.935 E.01644
G1 X227.065 Y130.779 E1.69054
G1 X227.065 Y131.313 E.01644
G1 X187.687 Y91.935 E1.71378
G1 X187.153 Y91.935 E.01644
G1 X227.065 Y131.847 E1.73703
G1 X227.065 Y132.381 E.01644
G1 X186.619 Y91.935 E1.76027
G1 X186.085 Y91.935 E.01644
G1 X227.065 Y132.915 E1.78352
G1 X227.065 Y133.449 E.01644
G1 X185.551 Y91.935 E1.80676
G1 X185.017 Y91.935 E.01644
G1 X227.065 Y133.983 E1.83001
G1 X227.065 Y134.518 E.01644
G1 X184.482 Y91.935 E1.85325
G1 X183.948 Y91.935 E.01644
G1 X227.065 Y135.052 E1.8765
G1 X227.065 Y135.586 E.01644
G1 X183.414 Y91.935 E1.89974
G1 X182.88 Y91.935 E.01644
G1 X227.065 Y136.12 E1.92298
G1 X227.065 Y136.654 E.01644
G1 X182.346 Y91.935 E1.94623
G1 X181.812 Y91.935 E.01644
G1 X227.065 Y137.188 E1.96947
G1 X227.065 Y137.722 E.01644
G1 X181.278 Y91.935 E1.99272
G1 X180.744 Y91.935 E.01644
G1 X227.065 Y138.256 E2.01596
G1 X227.065 Y138.79 E.01644
G1 X180.21 Y91.935 E2.03921
G1 X179.676 Y91.935 E.01644
G1 X227.065 Y139.324 E2.06245
G1 X227.065 Y139.858 E.01644
G1 X179.142 Y91.935 E2.0857
G1 X178.607 Y91.935 E.01644
G1 X227.065 Y140.393 E2.10894
G1 X227.065 Y140.927 E.01644
G1 X178.073 Y91.935 E2.13219
G1 X177.539 Y91.935 E.01644
G1 X227.065 Y141.461 E2.15543
G1 X227.065 Y141.995 E.01644
G1 X177.005 Y91.935 E2.17868
G1 X176.471 Y91.935 E.01644
G1 X227.065 Y142.529 E2.20192
G1 X227.065 Y143.063 E.01644
G1 X175.937 Y91.935 E2.22516
G1 X175.403 Y91.935 E.01644
G1 X227.065 Y143.597 E2.24841
G1 X227.065 Y144.131 E.01644
G1 X174.869 Y91.935 E2.27165
G1 X174.335 Y91.935 E.01644
G1 X227.065 Y144.665 E2.2949
G1 X227.065 Y145.199 E.01644
G1 X173.801 Y91.935 E2.31814
G1 X173.267 Y91.935 E.01644
G1 X227.065 Y145.733 E2.34139
M73 P31 R34
G1 X227.065 Y146.268 E.01644
G1 X172.732 Y91.935 E2.36463
G1 X172.198 Y91.935 E.01644
G1 X227.065 Y146.802 E2.38788
G1 X227.065 Y147.336 E.01644
G1 X171.664 Y91.935 E2.41112
G1 X171.13 Y91.935 E.01644
G1 X227.065 Y147.87 E2.43437
G1 X227.065 Y148.404 E.01644
G1 X170.596 Y91.935 E2.45761
G1 X170.062 Y91.935 E.01644
G1 X227.065 Y148.938 E2.48086
G1 X227.065 Y149.472 E.01644
G1 X169.528 Y91.935 E2.5041
G1 X168.994 Y91.935 E.01644
G1 X227.065 Y150.006 E2.52734
G1 X227.065 Y150.54 E.01644
G1 X168.46 Y91.935 E2.55059
G1 X167.926 Y91.935 E.01644
G1 X227.065 Y151.074 E2.57383
G1 X227.065 Y151.608 E.01644
G1 X167.392 Y91.935 E2.59708
G1 X166.857 Y91.935 E.01644
G1 X227.065 Y152.143 E2.62032
G1 X227.065 Y152.677 E.01644
G1 X166.323 Y91.935 E2.64357
G1 X165.789 Y91.935 E.01644
G1 X227.065 Y153.211 E2.66681
G1 X227.065 Y153.745 E.01644
G1 X165.255 Y91.935 E2.69006
G1 X164.721 Y91.935 E.01644
G1 X227.065 Y154.279 E2.7133
G1 X227.065 Y154.813 E.01644
G1 X164.187 Y91.935 E2.73655
G1 X163.653 Y91.935 E.01644
G1 X227.065 Y155.347 E2.75979
G1 X227.065 Y155.881 E.01644
G1 X163.119 Y91.935 E2.78304
G1 X162.585 Y91.935 E.01644
G1 X227.065 Y156.415 E2.80628
G1 X227.065 Y156.949 E.01644
G1 X162.051 Y91.935 E2.82952
G1 X161.517 Y91.935 E.01644
G1 X227.065 Y157.483 E2.85277
G1 X227.065 Y158.018 E.01644
G1 X160.982 Y91.935 E2.87601
G1 X160.448 Y91.935 E.01644
G1 X227.065 Y158.552 E2.89926
G1 X227.065 Y159.086 E.01644
G1 X159.914 Y91.935 E2.9225
G1 X159.38 Y91.935 E.01644
G1 X227.065 Y159.62 E2.94575
G1 X227.065 Y160.065 E.01369
G1 X226.975 Y160.065 E.00275
G1 X158.846 Y91.935 E2.96511
G1 X158.312 Y91.935 E.01644
G1 X226.441 Y160.065 E2.96511
G1 X225.907 Y160.065 E.01644
G1 X157.778 Y91.935 E2.96511
G1 X157.244 Y91.935 E.01644
G1 X225.373 Y160.065 E2.96511
G1 X224.839 Y160.065 E.01644
G1 X156.71 Y91.935 E2.96511
G1 X156.176 Y91.935 E.01644
G1 X224.305 Y160.065 E2.96511
G1 X223.771 Y160.065 E.01644
G1 X155.642 Y91.935 E2.96511
G1 X155.107 Y91.935 E.01644
G1 X223.237 Y160.065 E2.96511
G1 X222.703 Y160.065 E.01644
G1 X154.573 Y91.935 E2.96511
G1 X154.039 Y91.935 E.01644
G1 X222.169 Y160.065 E2.96511
G1 X221.635 Y160.065 E.01644
G1 X153.505 Y91.935 E2.96511
G1 X152.971 Y91.935 E.01644
G1 X221.1 Y160.065 E2.96511
G1 X220.566 Y160.065 E.01644
G1 X152.437 Y91.935 E2.96511
G1 X151.903 Y91.935 E.01644
M73 P32 R34
G1 X220.032 Y160.065 E2.96511
G1 X219.498 Y160.065 E.01644
G1 X151.369 Y91.935 E2.96511
G1 X150.835 Y91.935 E.01644
G1 X218.964 Y160.065 E2.96511
G1 X218.43 Y160.065 E.01644
G1 X150.301 Y91.935 E2.96511
G1 X149.766 Y91.935 E.01644
G1 X217.896 Y160.065 E2.96511
G1 X217.362 Y160.065 E.01644
G1 X149.232 Y91.935 E2.96511
G1 X148.698 Y91.935 E.01644
G1 X216.828 Y160.065 E2.96511
G1 X216.294 Y160.065 E.01644
G1 X148.164 Y91.935 E2.96511
G1 X147.63 Y91.935 E.01644
G1 X215.759 Y160.065 E2.96511
G1 X215.225 Y160.065 E.01644
G1 X147.096 Y91.935 E2.96511
G1 X146.562 Y91.935 E.01644
G1 X214.691 Y160.065 E2.96511
G1 X214.157 Y160.065 E.01644
G1 X146.028 Y91.935 E2.96511
G1 X145.494 Y91.935 E.01644
G1 X213.623 Y160.065 E2.96511
G1 X213.089 Y160.065 E.01644
G1 X144.96 Y91.935 E2.96511
G1 X144.426 Y91.935 E.01644
G1 X212.555 Y160.065 E2.96511
G1 X212.021 Y160.065 E.01644
G1 X143.891 Y91.935 E2.96511
G1 X143.357 Y91.935 E.01644
G1 X211.487 Y160.065 E2.96511
G1 X210.953 Y160.065 E.01644
G1 X142.823 Y91.935 E2.96511
G1 X142.289 Y91.935 E.01644
G1 X210.419 Y160.065 E2.96511
G1 X209.884 Y160.065 E.01644
G1 X141.755 Y91.935 E2.96511
G1 X141.221 Y91.935 E.01644
G1 X209.35 Y160.065 E2.96511
G1 X208.816 Y160.065 E.01644
G1 X140.687 Y91.935 E2.96511
G1 X140.153 Y91.935 E.01644
G1 X208.282 Y160.065 E2.96511
G1 X207.748 Y160.065 E.01644
G1 X139.619 Y91.935 E2.96511
G1 X139.085 Y91.935 E.01644
G1 X207.214 Y160.065 E2.96511
G1 X206.68 Y160.065 E.01644
G1 X138.551 Y91.935 E2.96511
G1 X138.016 Y91.935 E.01644
G1 X206.146 Y160.065 E2.96511
G1 X205.612 Y160.065 E.01644
G1 X137.482 Y91.935 E2.96511
G1 X136.948 Y91.935 E.01644
G1 X205.078 Y160.065 E2.96511
G1 X204.544 Y160.065 E.01644
G1 X136.414 Y91.935 E2.96511
G1 X135.88 Y91.935 E.01644
G1 X204.009 Y160.065 E2.96511
G1 X203.475 Y160.065 E.01644
G1 X135.346 Y91.935 E2.96511
G1 X134.812 Y91.935 E.01644
G1 X202.941 Y160.065 E2.96511
G1 X202.407 Y160.065 E.01644
G1 X134.278 Y91.935 E2.96511
G1 X133.744 Y91.935 E.01644
G1 X201.873 Y160.065 E2.96511
G1 X201.339 Y160.065 E.01644
G1 X133.21 Y91.935 E2.96511
G1 X132.676 Y91.935 E.01644
G1 X200.805 Y160.065 E2.96511
G1 X200.271 Y160.065 E.01644
G1 X132.141 Y91.935 E2.96511
G1 X131.607 Y91.935 E.01644
G1 X199.737 Y160.065 E2.96511
G1 X199.203 Y160.065 E.01644
G1 X131.073 Y91.935 E2.96511
G1 X130.539 Y91.935 E.01644
G1 X198.669 Y160.065 E2.96511
G1 X198.134 Y160.065 E.01644
G1 X130.005 Y91.935 E2.96511
G1 X129.471 Y91.935 E.01644
G1 X197.6 Y160.065 E2.96511
G1 X197.066 Y160.065 E.01644
G1 X128.937 Y91.935 E2.96511
G1 X128.403 Y91.935 E.01644
G1 X196.532 Y160.065 E2.96511
G1 X195.998 Y160.065 E.01644
G1 X127.869 Y91.935 E2.96511
G1 X127.335 Y91.935 E.01644
G1 X195.464 Y160.065 E2.96511
G1 X194.93 Y160.065 E.01644
G1 X126.801 Y91.935 E2.96511
G1 X126.266 Y91.935 E.01644
G1 X194.396 Y160.065 E2.96511
G1 X193.862 Y160.065 E.01644
G1 X125.732 Y91.935 E2.96511
G1 X125.198 Y91.935 E.01644
G1 X193.328 Y160.065 E2.96511
G1 X192.794 Y160.065 E.01644
G1 X124.664 Y91.935 E2.96511
G1 X124.13 Y91.935 E.01644
G1 X192.259 Y160.065 E2.96511
G1 X191.725 Y160.065 E.01644
G1 X123.596 Y91.935 E2.96511
G1 X123.062 Y91.935 E.01644
G1 X191.191 Y160.065 E2.96511
G1 X190.657 Y160.065 E.01644
G1 X122.528 Y91.935 E2.96511
G1 X121.994 Y91.935 E.01644
G1 X190.123 Y160.065 E2.96511
G1 X189.589 Y160.065 E.01644
G1 X121.46 Y91.935 E2.96511
G1 X120.926 Y91.935 E.01644
G1 X189.055 Y160.065 E2.96511
G1 X188.521 Y160.065 E.01644
G1 X120.391 Y91.935 E2.96511
G1 X119.857 Y91.935 E.01644
G1 X187.987 Y160.065 E2.96511
G1 X187.453 Y160.065 E.01644
G1 X119.323 Y91.935 E2.96511
G1 X118.789 Y91.935 E.01644
G1 X186.919 Y160.065 E2.96511
G1 X186.384 Y160.065 E.01644
G1 X118.255 Y91.935 E2.96511
G1 X117.721 Y91.935 E.01644
G1 X185.85 Y160.065 E2.96511
G1 X185.316 Y160.065 E.01644
G1 X117.187 Y91.935 E2.96511
G1 X116.653 Y91.935 E.01644
G1 X184.782 Y160.065 E2.96511
G1 X184.248 Y160.065 E.01644
G1 X116.119 Y91.935 E2.96511
G1 X115.585 Y91.935 E.01644
G1 X183.714 Y160.065 E2.96511
G1 X183.18 Y160.065 E.01644
G1 X115.051 Y91.935 E2.96511
G1 X114.516 Y91.935 E.01644
G1 X182.646 Y160.065 E2.96511
G1 X182.112 Y160.065 E.01644
G1 X113.982 Y91.935 E2.96511
G1 X113.448 Y91.935 E.01644
G1 X181.578 Y160.065 E2.96511
G1 X181.044 Y160.065 E.01644
G1 X112.914 Y91.935 E2.96511
G1 X112.38 Y91.935 E.01644
G1 X180.509 Y160.065 E2.96511
M73 P33 R34
G1 X179.975 Y160.065 E.01644
G1 X111.846 Y91.935 E2.96511
G1 X111.312 Y91.935 E.01644
G1 X179.441 Y160.065 E2.96511
G1 X178.907 Y160.065 E.01644
G1 X110.778 Y91.935 E2.96511
G1 X110.244 Y91.935 E.01644
G1 X178.373 Y160.065 E2.96511
G1 X177.839 Y160.065 E.01644
G1 X109.71 Y91.935 E2.96511
G1 X109.176 Y91.935 E.01644
G1 X177.305 Y160.065 E2.96511
G1 X176.771 Y160.065 E.01644
G1 X108.641 Y91.935 E2.96511
G1 X108.107 Y91.935 E.01644
G1 X176.237 Y160.065 E2.96511
G1 X175.703 Y160.065 E.01644
G1 X107.573 Y91.935 E2.96511
G1 X107.039 Y91.935 E.01644
G1 X175.169 Y160.065 E2.96511
G1 X174.634 Y160.065 E.01644
G1 X106.505 Y91.935 E2.96511
G1 X105.971 Y91.935 E.01644
G1 X174.1 Y160.065 E2.96511
G1 X173.566 Y160.065 E.01644
G1 X105.437 Y91.935 E2.96511
G1 X104.903 Y91.935 E.01644
G1 X173.032 Y160.065 E2.96511
G1 X172.498 Y160.065 E.01644
G1 X104.369 Y91.935 E2.96511
G1 X103.835 Y91.935 E.01644
G1 X171.964 Y160.065 E2.96511
G1 X171.43 Y160.065 E.01644
G1 X103.301 Y91.935 E2.96511
G1 X102.766 Y91.935 E.01644
G1 X170.896 Y160.065 E2.96511
G1 X170.362 Y160.065 E.01644
G1 X102.232 Y91.935 E2.96511
G1 X101.698 Y91.935 E.01644
G1 X169.828 Y160.065 E2.96511
G1 X169.293 Y160.065 E.01644
G1 X101.164 Y91.935 E2.96511
G1 X100.63 Y91.935 E.01644
G1 X168.759 Y160.065 E2.96511
G1 X168.225 Y160.065 E.01644
G1 X100.096 Y91.935 E2.96511
G1 X99.562 Y91.935 E.01644
G1 X167.691 Y160.065 E2.96511
G1 X167.157 Y160.065 E.01644
G1 X99.028 Y91.935 E2.96511
G1 X98.494 Y91.935 E.01644
G1 X166.623 Y160.065 E2.96511
G1 X166.089 Y160.065 E.01644
G1 X97.96 Y91.935 E2.96511
G1 X97.425 Y91.935 E.01644
G1 X165.555 Y160.065 E2.96511
G1 X165.021 Y160.065 E.01644
G1 X96.891 Y91.935 E2.96511
G1 X96.357 Y91.935 E.01644
G1 X164.487 Y160.065 E2.96511
G1 X163.953 Y160.065 E.01644
G1 X95.823 Y91.935 E2.96511
G1 X95.289 Y91.935 E.01644
G1 X163.418 Y160.065 E2.96511
G1 X162.884 Y160.065 E.01644
G1 X94.755 Y91.935 E2.96511
G1 X94.221 Y91.935 E.01644
G1 X162.35 Y160.065 E2.96511
G1 X161.816 Y160.065 E.01644
G1 X93.687 Y91.935 E2.96511
G1 X93.153 Y91.935 E.01644
G1 X161.282 Y160.065 E2.96511
G1 X160.748 Y160.065 E.01644
G1 X92.619 Y91.935 E2.96511
G1 X92.085 Y91.935 E.01644
G1 X110.214 Y110.065 E.78902
M73 P33 R33
G1 X109.68 Y110.065 E.01644
G1 X91.55 Y91.935 E.78902
G1 X91.016 Y91.935 E.01644
G1 X109.146 Y110.065 E.78902
G1 X108.612 Y110.065 E.01644
G1 X90.482 Y91.935 E.78902
G1 X89.948 Y91.935 E.01644
G1 X108.078 Y110.065 E.78902
G1 X107.543 Y110.065 E.01644
G1 X89.414 Y91.935 E.78902
G1 X88.88 Y91.935 E.01644
G1 X107.009 Y110.065 E.78902
G1 X106.475 Y110.065 E.01644
G1 X88.346 Y91.935 E.78902
G1 X87.812 Y91.935 E.01644
G1 X105.941 Y110.065 E.78902
G1 X105.407 Y110.065 E.01644
G1 X87.278 Y91.935 E.78902
G1 X86.744 Y91.935 E.01644
G1 X104.873 Y110.065 E.78902
G1 X104.339 Y110.065 E.01644
G1 X86.21 Y91.935 E.78902
G1 X85.675 Y91.935 E.01644
G1 X103.805 Y110.065 E.78902
G1 X103.271 Y110.065 E.01644
G1 X85.141 Y91.935 E.78902
G1 X84.607 Y91.935 E.01644
G1 X102.737 Y110.065 E.78902
G1 X102.203 Y110.065 E.01644
G1 X84.073 Y91.935 E.78902
G1 X83.539 Y91.935 E.01644
G1 X101.668 Y110.065 E.78902
G1 X101.134 Y110.065 E.01644
G1 X83.005 Y91.935 E.78902
G1 X82.471 Y91.935 E.01644
G1 X100.6 Y110.065 E.78902
G1 X100.066 Y110.065 E.01644
G1 X81.937 Y91.935 E.78902
G1 X81.403 Y91.935 E.01644
G1 X99.532 Y110.065 E.78902
G1 X99.065 Y110.065 E.01438
G1 X99.065 Y110.131 E.00205
G1 X80.869 Y91.935 E.79192
G1 X80.335 Y91.935 E.01644
G1 X99.065 Y110.665 E.81517
G1 X99.065 Y111.2 E.01644
G1 X79.8 Y91.935 E.83841
G1 X79.266 Y91.935 E.01644
G1 X99.065 Y111.734 E.86166
G1 X99.065 Y112.268 E.01644
G1 X78.732 Y91.935 E.8849
G1 X78.198 Y91.935 E.01644
G1 X99.065 Y112.802 E.90815
G1 X99.065 Y113.336 E.01644
G1 X77.664 Y91.935 E.93139
G1 X77.13 Y91.935 E.01644
G1 X99.065 Y113.87 E.95463
G1 X99.065 Y114.404 E.01644
G1 X76.596 Y91.935 E.97788
G1 X76.062 Y91.935 E.01644
G1 X99.065 Y114.938 E1.00112
G1 X99.065 Y115.472 E.01644
G1 X75.528 Y91.935 E1.02437
G1 X74.994 Y91.935 E.01644
G1 X99.065 Y116.006 E1.04761
G1 X99.065 Y116.54 E.01644
G1 X74.46 Y91.935 E1.07086
G1 X73.925 Y91.935 E.01644
G1 X99.065 Y117.075 E1.0941
G1 X99.065 Y117.609 E.01644
G1 X73.391 Y91.935 E1.11735
G1 X72.857 Y91.935 E.01644
G1 X99.065 Y118.143 E1.14059
G1 X99.065 Y118.677 E.01644
G1 X72.323 Y91.935 E1.16384
G1 X71.789 Y91.935 E.01644
G1 X99.065 Y119.211 E1.18708
G1 X99.065 Y119.745 E.01644
G1 X71.255 Y91.935 E1.21032
G1 X70.721 Y91.935 E.01644
G1 X99.065 Y120.279 E1.23357
G1 X99.065 Y120.813 E.01644
G1 X70.187 Y91.935 E1.25681
G1 X69.653 Y91.935 E.01644
G1 X99.065 Y121.347 E1.28006
G1 X99.065 Y121.881 E.01644
G1 X69.119 Y91.935 E1.3033
G1 X68.585 Y91.935 E.01644
G1 X99.065 Y122.415 E1.32655
G1 X99.065 Y122.95 E.01644
G1 X68.05 Y91.935 E1.34979
G1 X67.516 Y91.935 E.01644
G1 X99.065 Y123.484 E1.37304
G1 X99.065 Y124.018 E.01644
G1 X66.982 Y91.935 E1.39628
G1 X66.448 Y91.935 E.01644
G1 X99.065 Y124.552 E1.41953
G1 X99.065 Y125.086 E.01644
G1 X65.914 Y91.935 E1.44277
G1 X65.38 Y91.935 E.01644
G1 X99.065 Y125.62 E1.46602
G1 X99.065 Y126.154 E.01644
G1 X64.846 Y91.935 E1.48926
G1 X64.312 Y91.935 E.01644
G1 X99.065 Y126.688 E1.5125
G1 X99.065 Y127.222 E.01644
G1 X63.778 Y91.935 E1.53575
G1 X63.244 Y91.935 E.01644
G1 X99.065 Y127.756 E1.55899
M73 P34 R33
G1 X99.065 Y128.29 E.01644
G1 X62.71 Y91.935 E1.58224
G1 X62.175 Y91.935 E.01644
G1 X99.065 Y128.825 E1.60548
G1 X99.065 Y129.359 E.01644
G1 X61.641 Y91.935 E1.62873
G1 X61.107 Y91.935 E.01644
G1 X99.065 Y129.893 E1.65197
G1 X99.065 Y130.427 E.01644
G1 X60.573 Y91.935 E1.67522
G1 X60.039 Y91.935 E.01644
G1 X99.065 Y130.961 E1.69846
G1 X99.065 Y131.495 E.01644
G1 X59.505 Y91.935 E1.72171
G1 X58.971 Y91.935 E.01644
G1 X99.065 Y132.029 E1.74495
G1 X99.065 Y132.563 E.01644
G1 X58.437 Y91.935 E1.7682
G1 X57.903 Y91.935 E.01644
G1 X99.065 Y133.097 E1.79144
G1 X99.065 Y133.631 E.01644
G1 X57.369 Y91.935 E1.81468
G1 X56.835 Y91.935 E.01644
G1 X99.065 Y134.165 E1.83793
G1 X99.065 Y134.7 E.01644
G1 X56.3 Y91.935 E1.86117
G1 X55.766 Y91.935 E.01644
G1 X99.065 Y135.234 E1.88442
G1 X99.065 Y135.768 E.01644
G1 X55.232 Y91.935 E1.90766
G1 X54.698 Y91.935 E.01644
G1 X99.065 Y136.302 E1.93091
G1 X99.065 Y136.836 E.01644
G1 X54.164 Y91.935 E1.95415
G1 X53.63 Y91.935 E.01644
G1 X99.065 Y137.37 E1.9774
G1 X99.065 Y137.904 E.01644
G1 X53.096 Y91.935 E2.00064
G1 X52.562 Y91.935 E.01644
G1 X99.065 Y138.438 E2.02389
G1 X99.065 Y138.972 E.01644
G1 X52.028 Y91.935 E2.04713
G1 X51.494 Y91.935 E.01644
G1 X99.065 Y139.506 E2.07038
G1 X99.065 Y140.04 E.01644
G1 X50.96 Y91.935 E2.09362
G1 X50.425 Y91.935 E.01644
G1 X99.065 Y140.575 E2.11686
G1 X99.065 Y141.109 E.01644
G1 X49.891 Y91.935 E2.14011
G1 X49.357 Y91.935 E.01644
G1 X117.487 Y160.065 E2.96511
G1 X118.021 Y160.065 E.01644
G1 X99.891 Y141.935 E.78902
G1 X100.425 Y141.935 E.01644
G1 X118.555 Y160.065 E.78902
G1 X119.089 Y160.065 E.01644
G1 X100.96 Y141.935 E.78902
G1 X101.494 Y141.935 E.01644
G1 X119.623 Y160.065 E.78902
G1 X120.157 Y160.065 E.01644
G1 X102.028 Y141.935 E.78902
G1 X102.562 Y141.935 E.01644
G1 X120.691 Y160.065 E.78902
G1 X121.225 Y160.065 E.01644
G1 X103.096 Y141.935 E.78902
G1 X103.63 Y141.935 E.01644
G1 X121.759 Y160.065 E.78902
G1 X122.293 Y160.065 E.01644
G1 X104.164 Y141.935 E.78902
G1 X104.698 Y141.935 E.01644
G1 X122.828 Y160.065 E.78902
G1 X123.362 Y160.065 E.01644
G1 X105.232 Y141.935 E.78902
G1 X105.766 Y141.935 E.01644
G1 X123.896 Y160.065 E.78902
G1 X124.43 Y160.065 E.01644
G1 X106.3 Y141.935 E.78902
G1 X106.835 Y141.935 E.01644
G1 X124.964 Y160.065 E.78902
G1 X125.498 Y160.065 E.01644
G1 X107.369 Y141.935 E.78902
G1 X107.903 Y141.935 E.01644
G1 X126.032 Y160.065 E.78902
G1 X126.566 Y160.065 E.01644
G1 X108.437 Y141.935 E.78902
G1 X108.971 Y141.935 E.01644
G1 X127.1 Y160.065 E.78902
G1 X127.634 Y160.065 E.01644
G1 X109.505 Y141.935 E.78902
G1 X110.039 Y141.935 E.01644
G1 X128.168 Y160.065 E.78902
G1 X128.703 Y160.065 E.01644
G1 X110.573 Y141.935 E.78902
G1 X110.935 Y141.935 E.01114
G1 X110.935 Y141.763 E.00529
G1 X129.237 Y160.065 E.7965
G1 X129.771 Y160.065 E.01644
G1 X110.935 Y141.229 E.81975
G1 X110.935 Y140.695 E.01644
G1 X130.305 Y160.065 E.84299
G1 X130.839 Y160.065 E.01644
G1 X110.935 Y140.161 E.86624
G1 X110.935 Y139.627 E.01644
G1 X131.373 Y160.065 E.88948
G1 X131.907 Y160.065 E.01644
G1 X110.935 Y139.093 E.91273
G1 X110.935 Y138.559 E.01644
G1 X132.441 Y160.065 E.93597
G1 X132.975 Y160.065 E.01644
G1 X110.935 Y138.025 E.95922
G1 X110.935 Y137.491 E.01644
G1 X133.509 Y160.065 E.98246
G1 X134.043 Y160.065 E.01644
G1 X110.935 Y136.957 E1.00571
G1 X110.935 Y136.422 E.01644
G1 X134.578 Y160.065 E1.02895
G1 X135.112 Y160.065 E.01644
G1 X110.935 Y135.888 E1.05219
G1 X110.935 Y135.354 E.01644
G1 X135.646 Y160.065 E1.07544
G1 X136.18 Y160.065 E.01644
G1 X110.935 Y134.82 E1.09868
G1 X110.935 Y134.286 E.01644
G1 X136.714 Y160.065 E1.12193
G1 X137.248 Y160.065 E.01644
G1 X110.935 Y133.752 E1.14517
G1 X110.935 Y133.218 E.01644
G1 X137.782 Y160.065 E1.16842
G1 X138.316 Y160.065 E.01644
G1 X110.935 Y132.684 E1.19166
G1 X110.935 Y132.15 E.01644
G1 X138.85 Y160.065 E1.21491
G1 X139.384 Y160.065 E.01644
G1 X110.935 Y131.616 E1.23815
G1 X110.935 Y131.082 E.01644
G1 X139.918 Y160.065 E1.2614
G1 X140.453 Y160.065 E.01644
G1 X110.935 Y130.547 E1.28464
G1 X110.935 Y130.013 E.01644
G1 X140.987 Y160.065 E1.30788
G1 X141.521 Y160.065 E.01644
G1 X110.935 Y129.479 E1.33113
G1 X110.935 Y128.945 E.01644
G1 X142.055 Y160.065 E1.35437
G1 X142.589 Y160.065 E.01644
G1 X110.935 Y128.411 E1.37762
G1 X110.935 Y127.877 E.01644
G1 X143.123 Y160.065 E1.40086
G1 X143.657 Y160.065 E.01644
G1 X110.935 Y127.343 E1.42411
G1 X110.935 Y126.809 E.01644
G1 X144.191 Y160.065 E1.44735
G1 X144.725 Y160.065 E.01644
G1 X110.935 Y126.275 E1.4706
G1 X110.935 Y125.741 E.01644
G1 X145.259 Y160.065 E1.49384
G1 X145.793 Y160.065 E.01644
G1 X110.935 Y125.207 E1.51709
G1 X110.935 Y124.672 E.01644
G1 X146.328 Y160.065 E1.54033
G1 X146.862 Y160.065 E.01644
G1 X110.935 Y124.138 E1.56358
G1 X110.935 Y123.604 E.01644
G1 X147.396 Y160.065 E1.58682
G1 X147.93 Y160.065 E.01644
G1 X110.935 Y123.07 E1.61006
G1 X110.935 Y122.536 E.01644
G1 X148.464 Y160.065 E1.63331
G1 X148.998 Y160.065 E.01644
G1 X110.935 Y122.002 E1.65655
G1 X110.935 Y121.468 E.01644
G1 X149.532 Y160.065 E1.6798
G1 X150.066 Y160.065 E.01644
G1 X110.935 Y120.934 E1.70304
G1 X110.935 Y120.4 E.01644
G1 X150.6 Y160.065 E1.72629
G1 X151.134 Y160.065 E.01644
G1 X110.935 Y119.866 E1.74953
G1 X110.935 Y119.332 E.01644
G1 X151.668 Y160.065 E1.77278
G1 X152.203 Y160.065 E.01644
G1 X110.935 Y118.797 E1.79602
G1 X110.935 Y118.263 E.01644
G1 X152.737 Y160.065 E1.81927
G1 X153.271 Y160.065 E.01644
G1 X110.935 Y117.729 E1.84251
G1 X110.935 Y117.195 E.01644
G1 X153.805 Y160.065 E1.86576
G1 X154.339 Y160.065 E.01644
G1 X110.935 Y116.661 E1.889
G1 X110.935 Y116.127 E.01644
G1 X154.873 Y160.065 E1.91224
G1 X155.407 Y160.065 E.01644
G1 X110.935 Y115.593 E1.93549
G1 X110.935 Y115.059 E.01644
G1 X155.941 Y160.065 E1.95873
G1 X156.475 Y160.065 E.01644
G1 X110.935 Y114.525 E1.98198
G1 X110.935 Y113.991 E.01644
G1 X157.009 Y160.065 E2.00522
G1 X157.543 Y160.065 E.01644
G1 X110.935 Y113.457 E2.02847
G1 X110.935 Y112.922 E.01644
G1 X158.078 Y160.065 E2.05171
G1 X158.612 Y160.065 E.01644
G1 X110.935 Y112.388 E2.07496
G1 X110.935 Y111.854 E.01644
G1 X159.146 Y160.065 E2.0982
G1 X159.68 Y160.065 E.01644
G1 X110.935 Y111.32 E2.12145
G1 X110.935 Y110.786 E.01644
G1 X160.384 Y160.234 E2.15208
G1 X29.531 Y160.234 F30000
G1 F15000
G1 X28.935 Y159.639 E.02593
G1 X28.935 Y159.104 E.01644
G1 X29.896 Y160.065 E.04179
G1 X30.43 Y160.065 E.01644
G1 X28.935 Y158.57 E.06503
G1 X28.935 Y158.036 E.01644
G1 X30.964 Y160.065 E.08828
G1 X31.498 Y160.065 E.01644
G1 X28.935 Y157.502 E.11152
G1 X28.935 Y156.968 E.01644
G1 X32.032 Y160.065 E.13477
G1 X32.566 Y160.065 E.01644
G1 X28.935 Y156.434 E.15801
G1 X28.935 Y155.9 E.01644
G1 X33.1 Y160.065 E.18126
G1 X33.634 Y160.065 E.01644
G1 X28.935 Y155.366 E.2045
G1 X28.935 Y154.832 E.01644
G1 X34.168 Y160.065 E.22775
G1 X34.702 Y160.065 E.01644
G1 X28.935 Y154.298 E.25099
G1 X28.935 Y153.764 E.01644
G1 X35.236 Y160.065 E.27424
G1 X35.771 Y160.065 E.01644
G1 X28.935 Y153.229 E.29748
G1 X28.935 Y152.695 E.01644
G1 X36.305 Y160.065 E.32073
G1 X36.839 Y160.065 E.01644
G1 X28.935 Y152.161 E.34397
G1 X28.935 Y151.627 E.01644
G1 X37.373 Y160.065 E.36721
G1 X37.907 Y160.065 E.01644
G1 X28.935 Y151.093 E.39046
G1 X28.935 Y150.559 E.01644
G1 X38.441 Y160.065 E.4137
G1 X38.975 Y160.065 E.01644
G1 X28.935 Y150.025 E.43695
G1 X28.935 Y149.491 E.01644
G1 X39.509 Y160.065 E.46019
G1 X40.043 Y160.065 E.01644
G1 X28.935 Y148.957 E.48344
G1 X28.935 Y148.423 E.01644
G1 X40.577 Y160.065 E.50668
G1 X41.111 Y160.065 E.01644
G1 X28.935 Y147.889 E.52993
G1 X28.935 Y147.354 E.01644
G1 X41.646 Y160.065 E.55317
G1 X42.18 Y160.065 E.01644
G1 X28.935 Y146.82 E.57642
G1 X28.935 Y146.286 E.01644
G1 X42.714 Y160.065 E.59966
G1 X43.248 Y160.065 E.01644
G1 X28.935 Y145.752 E.6229
G1 X28.935 Y145.218 E.01644
G1 X43.782 Y160.065 E.64615
G1 X44.316 Y160.065 E.01644
G1 X28.935 Y144.684 E.66939
G1 X28.935 Y144.15 E.01644
G1 X44.85 Y160.065 E.69264
G1 X45.384 Y160.065 E.01644
G1 X28.935 Y143.616 E.71588
G1 X28.935 Y143.082 E.01644
G1 X45.918 Y160.065 E.73913
G1 X46.452 Y160.065 E.01644
G1 X28.935 Y142.548 E.76237
G1 X28.935 Y142.014 E.01644
G1 X46.986 Y160.065 E.78562
G1 X47.521 Y160.065 E.01644
G1 X28.935 Y141.479 E.80886
G1 X28.935 Y140.945 E.01644
G1 X48.055 Y160.065 E.83211
G1 X48.589 Y160.065 E.01644
G1 X28.935 Y140.411 E.85535
G1 X28.935 Y139.877 E.01644
G1 X49.123 Y160.065 E.8786
G1 X49.657 Y160.065 E.01644
G1 X28.935 Y139.343 E.90184
G1 X28.935 Y138.809 E.01644
G1 X50.191 Y160.065 E.92508
G1 X50.725 Y160.065 E.01644
G1 X28.935 Y138.275 E.94833
G1 X28.935 Y137.741 E.01644
G1 X51.259 Y160.065 E.97157
G1 X51.793 Y160.065 E.01644
G1 X28.935 Y137.207 E.99482
G1 X28.935 Y136.673 E.01644
G1 X52.327 Y160.065 E1.01806
G1 X52.861 Y160.065 E.01644
G1 X28.935 Y136.139 E1.04131
G1 X28.935 Y135.604 E.01644
G1 X53.396 Y160.065 E1.06455
G1 X53.93 Y160.065 E.01644
G1 X28.935 Y135.07 E1.0878
G1 X28.935 Y134.536 E.01644
G1 X54.464 Y160.065 E1.11104
G1 X54.998 Y160.065 E.01644
G1 X28.935 Y134.002 E1.13429
M73 P35 R33
G1 X28.935 Y133.468 E.01644
G1 X55.532 Y160.065 E1.15753
G1 X56.066 Y160.065 E.01644
G1 X28.935 Y132.934 E1.18078
G1 X28.935 Y132.4 E.01644
G1 X56.6 Y160.065 E1.20402
G1 X57.134 Y160.065 E.01644
G1 X28.935 Y131.866 E1.22726
G1 X28.935 Y131.332 E.01644
G1 X57.668 Y160.065 E1.25051
G1 X58.202 Y160.065 E.01644
G1 X28.935 Y130.798 E1.27375
G1 X28.935 Y130.264 E.01644
G1 X58.736 Y160.065 E1.297
G1 X59.271 Y160.065 E.01644
G1 X28.935 Y129.729 E1.32024
G1 X28.935 Y129.195 E.01644
G1 X59.805 Y160.065 E1.34349
G1 X60.339 Y160.065 E.01644
G1 X28.935 Y128.661 E1.36673
G1 X28.935 Y128.127 E.01644
G1 X60.873 Y160.065 E1.38998
G1 X61.407 Y160.065 E.01644
G1 X28.935 Y127.593 E1.41322
G1 X28.935 Y127.059 E.01644
G1 X61.941 Y160.065 E1.43647
G1 X62.475 Y160.065 E.01644
G1 X28.935 Y126.525 E1.45971
G1 X28.935 Y125.991 E.01644
G1 X63.009 Y160.065 E1.48295
G1 X63.543 Y160.065 E.01644
G1 X28.935 Y125.457 E1.5062
G1 X28.935 Y124.923 E.01644
G1 X64.077 Y160.065 E1.52944
G1 X64.611 Y160.065 E.01644
G1 X28.935 Y124.389 E1.55269
G1 X28.935 Y123.854 E.01644
G1 X65.146 Y160.065 E1.57593
G1 X65.68 Y160.065 E.01644
G1 X28.935 Y123.32 E1.59918
G1 X28.935 Y122.786 E.01644
G1 X66.214 Y160.065 E1.62242
G1 X66.748 Y160.065 E.01644
G1 X28.935 Y122.252 E1.64567
G1 X28.935 Y121.718 E.01644
G1 X67.282 Y160.065 E1.66891
G1 X67.816 Y160.065 E.01644
G1 X28.935 Y121.184 E1.69216
G1 X28.935 Y120.65 E.01644
G1 X68.35 Y160.065 E1.7154
G1 X68.884 Y160.065 E.01644
G1 X28.935 Y120.116 E1.73865
G1 X28.935 Y119.582 E.01644
G1 X69.418 Y160.065 E1.76189
G1 X69.952 Y160.065 E.01644
G1 X28.935 Y119.048 E1.78513
G1 X28.935 Y118.513 E.01644
G1 X70.487 Y160.065 E1.80838
G1 X71.021 Y160.065 E.01644
G1 X28.935 Y117.979 E1.83162
G1 X28.935 Y117.445 E.01644
G1 X71.555 Y160.065 E1.85487
G1 X72.089 Y160.065 E.01644
G1 X28.935 Y116.911 E1.87811
G1 X28.935 Y116.377 E.01644
G1 X72.623 Y160.065 E1.90136
G1 X73.157 Y160.065 E.01644
G1 X28.935 Y115.843 E1.9246
G1 X28.935 Y115.309 E.01644
G1 X73.691 Y160.065 E1.94785
G1 X74.225 Y160.065 E.01644
G1 X28.935 Y114.775 E1.97109
G1 X28.935 Y114.241 E.01644
G1 X74.759 Y160.065 E1.99434
G1 X75.293 Y160.065 E.01644
G1 X28.935 Y113.707 E2.01758
G1 X28.935 Y113.173 E.01644
G1 X75.827 Y160.065 E2.04083
G1 X76.362 Y160.065 E.01644
G1 X28.935 Y112.638 E2.06407
G1 X28.935 Y112.104 E.01644
G1 X76.896 Y160.065 E2.08731
G1 X77.43 Y160.065 E.01644
G1 X28.935 Y111.57 E2.11056
G1 X28.935 Y111.036 E.01644
G1 X77.964 Y160.065 E2.1338
G1 X78.498 Y160.065 E.01644
G1 X28.935 Y110.502 E2.15705
G1 X28.935 Y109.968 E.01644
G1 X79.032 Y160.065 E2.18029
G1 X79.566 Y160.065 E.01644
G1 X28.935 Y109.434 E2.20354
G1 X28.935 Y108.9 E.01644
G1 X80.27 Y160.234 E2.23417
G1 X117.122 Y160.234 F30000
G1 F15000
G1 X48.823 Y91.935 E2.97249
G1 X48.289 Y91.935 E.01644
G1 X116.418 Y160.065 E2.96511
G1 X115.884 Y160.065 E.01644
G1 X47.755 Y91.935 E2.96511
G1 X47.221 Y91.935 E.01644
G1 X115.35 Y160.065 E2.96511
G1 X114.816 Y160.065 E.01644
G1 X46.687 Y91.935 E2.96511
G1 X46.153 Y91.935 E.01644
G1 X114.282 Y160.065 E2.96511
G1 X113.748 Y160.065 E.01644
G1 X45.619 Y91.935 E2.96511
G1 X45.084 Y91.935 E.01644
G1 X113.214 Y160.065 E2.96511
G1 X112.68 Y160.065 E.01644
G1 X44.55 Y91.935 E2.96511
G1 X44.016 Y91.935 E.01644
G1 X112.146 Y160.065 E2.96511
G1 X111.612 Y160.065 E.01644
G1 X43.482 Y91.935 E2.96511
G1 X42.948 Y91.935 E.01644
G1 X111.077 Y160.065 E2.96511
G1 X110.543 Y160.065 E.01644
G1 X71.377 Y120.899 E1.70457
G1 X71.742 Y121.643 E.0255
G1 X71.837 Y121.892 E.00821
G1 X110.009 Y160.065 E1.66133
G1 X109.475 Y160.065 E.01644
G1 X72.14 Y122.73 E1.62488
G1 X72.348 Y123.472 E.02371
G1 X108.941 Y160.065 E1.59258
G1 X108.407 Y160.065 E.01644
G1 X72.476 Y124.134 E1.56379
G3 X72.568 Y124.76 I-3.384 J.818 E.01951
G1 X107.873 Y160.065 E1.53653
G1 X107.339 Y160.065 E.01644
G1 X72.622 Y125.348 E1.51095
G3 X72.636 Y125.896 I-2.995 J.351 E.0169
G1 X106.805 Y160.065 E1.48709
G1 X106.271 Y160.065 E.01644
G1 X72.636 Y126.43 E1.46384
G3 X72.597 Y126.925 I-2.73 J.034 E.0153
G1 X105.737 Y160.065 E1.4423
M73 P35 R32
G1 X105.202 Y160.065 E.01644
G1 X72.552 Y127.414 E1.421
G3 X72.475 Y127.871 I-2.543 J-.195 E.01428
G1 X104.668 Y160.065 E1.40111
G1 X104.134 Y160.065 E.01644
G1 X72.392 Y128.322 E1.38148
G3 X72.286 Y128.75 I-2.397 J-.366 E.01359
G1 X103.6 Y160.065 E1.36285
G1 X103.066 Y160.065 E.01644
G1 X72.169 Y129.168 E1.34469
G3 X72.041 Y129.573 I-2.285 J-.501 E.01311
G1 X102.532 Y160.065 E1.32704
G1 X101.998 Y160.065 E.01644
G1 X71.893 Y129.96 E1.31021
G1 X71.746 Y130.347 E.01274
G1 X101.464 Y160.065 E1.29338
G1 X100.93 Y160.065 E.01644
G1 X71.571 Y130.706 E1.27774
G1 X71.395 Y131.064 E.01229
G1 X100.396 Y160.065 E1.26214
G1 X99.862 Y160.065 E.01644
G1 X71.207 Y131.41 E1.24709
G1 X71.005 Y131.742 E.01196
G1 X99.327 Y160.065 E1.23263
G1 X98.793 Y160.065 E.01644
G1 X70.803 Y132.075 E1.21818
G3 X70.578 Y132.384 I-1.806 J-1.08 E.01178
G1 X98.259 Y160.065 E1.20473
G1 X97.725 Y160.065 E.01644
G1 X70.351 Y132.69 E1.19138
G3 X70.116 Y132.99 I-1.755 J-1.136 E.01172
G1 X97.191 Y160.065 E1.17836
G1 X96.657 Y160.065 E.01644
G1 X69.864 Y133.272 E1.16607
G1 X69.612 Y133.554 E.01164
G1 X96.123 Y160.065 E1.15379
G1 X95.589 Y160.065 E.01644
G1 X69.344 Y133.82 E1.14222
G1 X69.068 Y134.078 E.01163
G1 X95.055 Y160.065 E1.131
G1 X94.521 Y160.065 E.01644
G1 X68.791 Y134.335 E1.11982
G1 X68.49 Y134.568 E.01171
G1 X93.987 Y160.065 E1.10966
G1 X93.452 Y160.065 E.01644
G1 X68.189 Y134.801 E1.0995
G3 X67.878 Y135.024 I-1.374 J-1.592 E.0118
G1 X92.918 Y160.065 E1.08981
G1 X92.384 Y160.065 E.01644
G1 X67.552 Y135.232 E1.08074
G1 X67.226 Y135.441 E.0119
G1 X91.85 Y160.065 E1.07167
G1 X91.316 Y160.065 E.01644
G1 X66.878 Y135.627 E1.06357
G1 X66.527 Y135.809 E.01219
G1 X90.782 Y160.065 E1.05564
G1 X90.248 Y160.065 E.01644
G1 X66.165 Y135.982 E1.04812
G1 X65.786 Y136.137 E.01261
G1 X89.714 Y160.065 E1.04139
G1 X89.18 Y160.065 E.01644
G1 X65.406 Y136.291 E1.03466
G3 X65 Y136.419 I-.903 J-2.17 E.01313
G1 X88.646 Y160.065 E1.02911
G1 X88.112 Y160.065 E.01644
G1 X64.59 Y136.544 E1.02368
G3 X64.162 Y136.649 I-.792 J-2.295 E.0136
G1 X87.577 Y160.065 E1.01909
G1 X87.043 Y160.065 E.01644
G1 X63.72 Y136.741 E1.01509
G3 X63.263 Y136.819 I-.654 J-2.461 E.01427
G1 X86.509 Y160.065 E1.01171
G1 X85.975 Y160.065 E.01644
G1 X62.784 Y136.873 E1.00932
G3 X62.291 Y136.915 I-.472 J-2.678 E.01524
G1 X85.441 Y160.065 E1.00753
G1 X84.907 Y160.065 E.01644
G1 X61.769 Y136.926 E1.00701
G3 X61.225 Y136.917 I-.221 J-2.98 E.01675
G1 X84.373 Y160.065 E1.00742
G1 X83.839 Y160.065 E.01644
G1 X60.652 Y136.878 E1.00912
G3 X60.036 Y136.796 I.142 J-3.418 E.01916
G1 X83.305 Y160.065 E1.0127
G1 X82.771 Y160.065 E.01644
G1 X59.389 Y136.683 E1.01762
G1 X58.671 Y136.499 E.0228
G1 X82.237 Y160.065 E1.02561
G1 X81.702 Y160.065 E.01644
G1 X57.866 Y136.228 E1.03742
G3 X56.929 Y135.825 I1.734 J-5.327 E.03141
G1 X81.168 Y160.065 E1.05494
G1 X80.634 Y160.065 E.01644
G1 X55.697 Y135.127 E1.08531
G1 X55.004 Y134.638 E.0261
G3 X52.602 Y132.033 I6.522 J-8.421 E.10956
G1 X28.935 Y108.366 E1.03003
G1 X28.935 Y107.832 E.01644
G1 X51.87 Y130.767 E.99817
G1 X51.472 Y129.834 E.03122
G1 X28.935 Y107.298 E.98082
G1 X28.935 Y106.763 E.01644
G1 X51.209 Y129.037 E.96937
G1 X51.037 Y128.331 E.02237
G1 X28.935 Y106.229 E.96188
G1 X28.935 Y105.695 E.01644
G1 X50.913 Y127.673 E.95652
G1 X50.828 Y127.054 E.01923
G1 X28.935 Y105.161 E.95281
G1 X28.935 Y104.627 E.01644
G1 X50.797 Y126.489 E.95145
G3 X50.778 Y125.935 I3.02 J-.382 E.01707
G1 X28.935 Y104.093 E.95061
G1 X28.935 Y103.559 E.01644
G1 X50.801 Y125.424 E.95163
G3 X50.832 Y124.921 I2.773 J-.083 E.01554
G1 X28.935 Y103.025 E.95296
G1 X28.935 Y102.491 E.01644
G1 X50.896 Y124.452 E.95577
G3 X50.963 Y123.985 I2.588 J.136 E.01453
G1 X28.935 Y101.957 E.9587
G1 X28.935 Y101.423 E.01644
G1 X51.064 Y123.551 E.96308
G1 X51.164 Y123.118 E.0137
G1 X28.935 Y100.888 E.96745
G1 X28.935 Y100.354 E.01644
G1 X51.292 Y122.711 E.973
G1 X51.424 Y122.309 E.01301
G1 X28.935 Y99.82 E.97876
G1 X28.935 Y99.286 E.01644
G1 X51.571 Y121.922 E.98515
G1 X51.733 Y121.55 E.01249
M73 P36 R32
G1 X28.935 Y98.752 E.99219
G1 X28.935 Y98.218 E.01644
G1 X51.896 Y121.178 E.99927
G1 X52.085 Y120.833 E.01211
G1 X28.935 Y97.684 E1.00749
G1 X28.935 Y97.15 E.01644
G1 X52.273 Y120.488 E1.01572
G3 X52.475 Y120.156 I1.921 J.941 E.01198
G1 X28.935 Y96.616 E1.02451
G1 X28.935 Y96.082 E.01644
G1 X52.69 Y119.837 E1.03385
G1 X52.905 Y119.517 E.01184
G1 X28.935 Y95.548 E1.0432
G1 X28.935 Y95.37 E.00545
G2 X29.731 Y95.809 I1.774 J-2.276 E.02809
G1 X53.143 Y119.221 E1.0189
G1 X53.382 Y118.926 E.01168
G1 X30.385 Y95.929 E1.00088
G1 X30.5 Y95.939 E.00356
G1 X30.894 Y95.904 E.01219
G1 X53.629 Y118.639 E.98945
G1 X53.893 Y118.369 E.01162
G1 X31.32 Y95.796 E.98242
G1 X31.686 Y95.628 E.0124
G1 X54.157 Y118.099 E.97798
G3 X54.437 Y117.845 I1.531 J1.408 E.01165
G1 X32.005 Y95.412 E.9763
G2 X32.281 Y95.155 I-.592 J-.912 E.01169
G1 X54.725 Y117.599 E.97681
G3 X55.015 Y117.354 I1.488 J1.464 E.01168
G1 X32.517 Y94.856 E.97916
G2 X32.704 Y94.509 I-.739 J-.623 E.01222
G1 X55.328 Y117.133 E.98464
G1 X55.641 Y116.912 E.01179
G1 X32.849 Y94.12 E.99194
G2 X32.925 Y93.662 I-1.263 J-.444 E.01437
G1 X55.965 Y116.702 E1.00276
G1 X56.304 Y116.507 E.01203
G1 X32.905 Y93.108 E1.01837
G1 X32.902 Y93.077 E.00096
G2 X32.613 Y92.282 I-2.397 J.422 E.02616
G1 X56.642 Y116.311 E1.04581
G3 X57.005 Y116.14 I1.121 J1.899 E.01236
G1 X32.8 Y91.935 E1.05342
G1 X33.334 Y91.935 E.01644
G1 X57.37 Y115.971 E1.04607
G3 X57.747 Y115.814 I1.046 J1.986 E.01259
G1 X33.869 Y91.935 E1.03925
G1 X34.403 Y91.935 E.01644
G1 X58.141 Y115.674 E1.03315
G3 X58.537 Y115.535 I.958 J2.093 E.01291
G1 X34.937 Y91.935 E1.02711
G1 X35.471 Y91.935 E.01644
G1 X58.962 Y115.426 E1.02237
G1 X59.387 Y115.318 E.01351
G1 X36.005 Y91.935 E1.01764
G1 X36.539 Y91.935 E.01644
G1 X59.839 Y115.236 E1.01407
G1 X60.299 Y115.162 E.01434
G1 X37.073 Y91.935 E1.01085
G1 X37.607 Y91.935 E.01644
G1 X60.785 Y115.113 E1.00873
G1 X61.285 Y115.079 E.01542
G1 X38.141 Y91.935 E1.00724
G1 X38.675 Y91.935 E.01644
G1 X61.815 Y115.075 E1.00706
G1 X62.361 Y115.087 E.01682
G1 X39.209 Y91.935 E1.0076
G1 X39.744 Y91.935 E.01644
G1 X62.954 Y115.146 E1.01017
G3 X63.57 Y115.228 I-.141 J3.415 E.01915
G1 X40.278 Y91.935 E1.01374
G1 X40.812 Y91.935 E.01644
G1 X64.245 Y115.368 E1.01984
G3 X64.988 Y115.578 I-.776 J4.178 E.02381
G1 X41.346 Y91.935 E1.02896
G1 X41.88 Y91.935 E.01644
G1 X65.823 Y115.878 E1.04205
G3 X66.823 Y116.344 I-2.052 J5.711 E.034
G1 X42.244 Y91.766 E1.06971
; WIPE_START
G1 X43.659 Y93.18 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X36.089 Y92.206 Z1 F30000
G1 X31.531 Y91.619 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354354
G1 F15000
G1 X31.192 Y91.559 E.00874
; LINE_WIDTH: 0.327667
G1 X31.026 Y91.537 E.00389
; LINE_WIDTH: 0.281518
G2 X30.841 Y91.514 I-.363 J2.118 E.00363
; LINE_WIDTH: 0.244291
G2 X30.14 Y91.516 I-.336 J5.788 E.0115
; LINE_WIDTH: 0.283922
G1 X29.974 Y91.537 E.00329
; LINE_WIDTH: 0.327708
G1 X29.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X29.469 Y91.619 E.00874
G1 X28.619 Y92.469 F30000
; LINE_WIDTH: 0.354377
G1 F15000
G1 X28.559 Y92.808 E.00873
; LINE_WIDTH: 0.327704
G1 X28.537 Y92.974 E.00389
; LINE_WIDTH: 0.281527
G2 X28.514 Y93.159 I2.112 J.363 E.00363
; LINE_WIDTH: 0.244295
G2 X28.516 Y93.86 I5.789 J.336 E.0115
; LINE_WIDTH: 0.283917
G1 X28.537 Y94.026 E.00329
; LINE_WIDTH: 0.327693
G1 X28.559 Y94.192 E.00389
; LINE_WIDTH: 0.354386
G1 X28.619 Y94.531 E.00874
; CHANGE_LAYER
; Z_HEIGHT: 0.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X28.559 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 4/25
; update layer progress
M73 L4
M991 S0 P3 ;notify layer change
G17
G3 Z1 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z1.2 F30000
G1 X51.287 Y124.063 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.505 Y123.14 E.03146
G3 X60.507 Y115.466 I10.206 J2.854 E.41629
G1 X61.47 Y115.4 E.03202
G3 X51.28 Y124.123 I.241 J10.594 E1.72696
M204 S250
G1 X51.674 Y124.152 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.037 J1.843 E.3999
G1 X61.479 Y115.792 E.02856
G3 X51.663 Y124.211 I.232 J10.202 E1.5399
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37592
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03092
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.053 Z1.2 F30000
G1 X223.514 Y94.188 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.53 Y94.217 E.00108
G2 X227.227 Y94.688 I1.97 J-.717 E.15229
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.729 J-1.186 E.24414
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.435 Y93.864 I1.188 J1.727 E.07947
G1 X223.5 Y94.13 E.00908
M204 S250
G1 X223.903 Y94.081 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.445 Y91.794 I1.604 J-.582 E.0987
G3 X226.355 Y92.018 I.07 J1.673 E.02919
G3 X223.924 Y94.137 I-.848 J1.481 E.19977
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13579
G1 X223.789 Y93.5 E-.11332
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11331
G1 X224.189 Y92.4 E-.11332
G1 X224.297 Y92.293 E-.05762
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z1.2 F30000
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03913
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z1.2 F30000
G1 X32.108 Y94.083 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X32.111 Y94.086 E.00015
G3 X30.445 Y91.794 I-1.604 J-.586 E.227
G3 X31.355 Y92.018 I.07 J1.673 E.02919
G3 X32.189 Y93.798 I-.848 J1.482 E.06433
G1 X32.125 Y94.025 E.00726
; WIPE_START
M204 S10000
G1 X32.111 Y94.086 E-.02389
G1 X31.982 Y94.355 E-.11345
G1 X31.811 Y94.6 E-.11333
G1 X31.6 Y94.811 E-.11334
G1 X31.355 Y94.982 E-.11331
G1 X31.085 Y95.108 E-.11333
G1 X30.797 Y95.185 E-.11331
G1 X30.65 Y95.198 E-.05604
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z1.2 F30000
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.73 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08593
G1 X28.888 Y92.147 E-.1394
G1 X28.773 Y92.312 E-.07624
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14116
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z1.2 F30000
G1 X227.79 Y91.21 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z1.2 F30000
G1 Z.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327687
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281538
G2 X225.841 Y91.514 I-.363 J2.118 E.00363
; LINE_WIDTH: 0.2443
G2 X225.14 Y91.516 I-.336 J5.781 E.0115
; LINE_WIDTH: 0.283928
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327696
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354361
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X221.829 Y91.95 Z1.2 F30000
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.457 Y91.95 E.05401
G1 X155.358 Y160.05 E3.19468
G1 X154.374 Y160.05 E.03265
G1 X110.95 Y116.626 E2.03708
G1 X110.95 Y120.022 E.11264
G1 X139.022 Y91.95 E1.31689
G1 X140.006 Y91.95 E.03265
G1 X208.105 Y160.05 E3.19468
G1 X209.09 Y160.05 E.03265
G1 X227.05 Y142.09 E.84254
G1 X227.05 Y140.614 E.04894
G1 X178.386 Y91.95 E2.28292
G1 X177.402 Y91.95 E.03265
G1 X109.302 Y160.05 E3.19468
G1 X108.318 Y160.05 E.03265
G1 X72.511 Y124.243 E1.67977
G2 X71.493 Y121.1 I-9.768 J1.429 E.11012
G1 X100.642 Y91.95 E1.36746
G1 X101.626 Y91.95 E.03265
G1 X169.726 Y160.05 E3.19468
G1 X170.71 Y160.05 E.03265
G1 X227.05 Y103.71 E2.64302
G1 X227.05 Y102.234 E.04894
G1 X216.766 Y91.95 E.48245
G1 X215.781 Y91.95 E.03265
G1 X147.682 Y160.05 E3.19468
G1 X146.698 Y160.05 E.03265
G1 X110.95 Y124.302 E1.67699
G1 X110.95 Y127.698 E.11264
G1 X146.698 Y91.95 E1.67699
G1 X147.682 Y91.95 E.03265
G1 X215.781 Y160.05 E3.19468
G1 X216.766 Y160.05 E.03265
G1 X227.05 Y149.766 E.48245
G1 X227.05 Y148.29 E.04894
G1 X170.71 Y91.95 E2.64302
G1 X169.726 Y91.95 E.03265
G1 X101.626 Y160.05 E3.19468
G1 X100.642 Y160.05 E.03265
G1 X71.493 Y130.9 E1.36746
G2 X72.511 Y127.757 I-8.749 J-4.572 E.11012
G1 X108.318 Y91.95 E1.67977
G1 X109.302 Y91.95 E.03265
G1 X177.402 Y160.05 E3.19468
G1 X178.386 Y160.05 E.03265
G1 X227.05 Y111.386 E2.28292
G1 X227.05 Y109.91 E.04894
G1 X209.09 Y91.95 E.84254
G1 X208.105 Y91.95 E.03265
G1 X140.006 Y160.05 E3.19468
G1 X139.022 Y160.05 E.03265
G1 X110.95 Y131.978 E1.31689
G1 X110.95 Y135.374 E.11264
G1 X154.374 Y91.95 E2.03708
G1 X155.358 Y91.95 E.03265
G1 X223.457 Y160.05 E3.19468
G1 X224.442 Y160.05 E.03265
G1 X227.05 Y157.442 E.12235
G1 X227.05 Y155.966 E.04894
G1 X163.034 Y91.95 E3.00311
G1 X162.05 Y91.95 E.03265
G1 X93.95 Y160.05 E3.19468
G1 X92.966 Y160.05 E.03265
G1 X67.927 Y135.011 E1.17464
G2 X69.189 Y133.985 I-7.415 J-10.416 E.05398
; WIPE_START
G1 X67.927 Y135.011 E-.61792
G1 X68.191 Y135.275 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y127.655 Z1.2 F30000
G1 X69.189 Y118.015 Z1.2
G1 Z.8
G1 E.8 F1800
G1 F15476.087
G2 X67.927 Y116.989 I-8.677 J9.391 E.05398
G1 X92.966 Y91.95 E1.17464
G1 X93.95 Y91.95 E.03265
G1 X162.05 Y160.05 E3.19468
G1 X163.034 Y160.05 E.03265
G1 X227.05 Y96.034 E3.00311
G1 X227.05 Y95.399 E.02105
G3 X226.173 Y95.85 I-1.606 J-2.042 E.0329
; WIPE_START
G1 X226.727 Y95.625 E-.22718
G1 X227.05 Y95.399 E-.14969
G1 X227.05 Y96.034 E-.24118
G1 X226.786 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y94.531 Z1.2 F30000
G1 Z.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X227.441 Y94.192 E.00873
; LINE_WIDTH: 0.327699
G1 X227.463 Y94.026 E.00389
; LINE_WIDTH: 0.281511
G2 X227.486 Y93.841 I-2.138 J-.366 E.00363
; LINE_WIDTH: 0.244295
G2 X227.484 Y93.14 I-5.792 J-.336 E.0115
; LINE_WIDTH: 0.283908
G1 X227.463 Y92.974 E.00329
; LINE_WIDTH: 0.327676
G1 X227.441 Y92.808 E.00389
; LINE_WIDTH: 0.354364
G1 X227.381 Y92.469 E.00874
; WIPE_START
G1 X227.441 Y92.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X219.897 Y93.968 Z1.2 F30000
G1 X110.95 Y110.718 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.95 Y112.346 E.05401
G1 X131.346 Y91.95 E.9568
G1 X132.33 Y91.95 E.03265
G1 X200.429 Y160.05 E3.19468
G1 X201.414 Y160.05 E.03265
G1 X227.05 Y134.414 E1.20264
G1 X227.05 Y132.938 E.04894
G1 X186.062 Y91.95 E1.92283
G1 X185.078 Y91.95 E.03265
G1 X116.978 Y160.05 E3.19468
G1 X115.994 Y160.05 E.03265
G1 X47.895 Y91.95 E3.19468
G1 X46.91 Y91.95 E.03265
G1 X28.95 Y109.91 E.84254
G1 X28.95 Y111.386 E.04895
G1 X77.614 Y160.05 E2.28292
G1 X78.598 Y160.05 E.03265
G1 X99.05 Y139.598 E.95941
G1 X99.05 Y135.429 E.13829
G1 X55.571 Y91.95 E2.0397
G1 X54.586 Y91.95 E.03265
M73 P37 R32
G1 X28.95 Y117.586 E1.20264
G1 X28.95 Y119.062 E.04894
G1 X69.938 Y160.05 E1.92283
G1 X70.922 Y160.05 E.03265
G1 X99.05 Y131.922 E1.31951
G1 X99.05 Y127.753 E.13829
G1 X63.246 Y91.95 E1.6796
G1 X62.262 Y91.95 E.03265
G1 X28.95 Y125.262 E1.56273
G1 X28.95 Y126.738 E.04895
G1 X62.262 Y160.05 E1.56273
G1 X63.246 Y160.05 E.03265
G1 X99.05 Y124.246 E1.6796
G1 X99.05 Y120.078 E.13829
G1 X70.922 Y91.95 E1.31951
G1 X69.938 Y91.95 E.03265
G1 X28.95 Y132.938 E1.92283
G1 X28.95 Y134.414 E.04895
G1 X54.586 Y160.05 E1.20264
G1 X55.571 Y160.05 E.03265
G1 X99.05 Y116.571 E2.0397
G1 X99.05 Y112.402 E.13829
G1 X78.598 Y91.95 E.95941
G1 X77.614 Y91.95 E.03265
G1 X28.95 Y140.614 E2.28292
G1 X28.95 Y142.09 E.04895
G1 X46.91 Y160.05 E.84254
G1 X47.895 Y160.05 E.03265
G1 X115.994 Y91.95 E3.19468
G1 X116.978 Y91.95 E.03265
G1 X185.078 Y160.05 E3.19468
G1 X186.062 Y160.05 E.03265
G1 X227.05 Y119.062 E1.92283
G1 X227.05 Y117.586 E.04894
G1 X201.414 Y91.95 E1.20264
G1 X200.429 Y91.95 E.03265
G1 X132.33 Y160.05 E3.19468
G1 X131.346 Y160.05 E.03265
G1 X110.95 Y139.654 E.9568
G1 X110.95 Y141.282 E.05401
; WIPE_START
G1 X110.95 Y139.654 E-.61876
G1 X111.213 Y139.917 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X103.669 Y138.76 Z1.2 F30000
G1 X51.874 Y130.813 Z1.2
G1 Z.8
G1 E.8 F1800
G1 F15476.087
G2 X52.705 Y132.212 I14.036 J-7.388 E.05398
G1 X28.95 Y155.966 E1.11436
G1 X28.95 Y157.442 E.04895
G1 X31.558 Y160.05 E.12235
G1 X32.543 Y160.05 E.03265
G1 X56.807 Y135.785 E1.13828
G2 X58.312 Y136.402 I4.129 J-7.931 E.05403
G1 X28.95 Y146.662 F30000
G1 F15476.087
G1 X28.95 Y148.29 E.05401
G1 X50.781 Y126.46 E1.0241
G3 X50.781 Y125.54 I5.034 J-.46 E.03055
G1 X28.95 Y103.71 E1.0241
G1 X28.95 Y102.234 E.04894
G1 X39.234 Y91.95 E.48245
G1 X40.219 Y91.95 E.03265
G1 X63.458 Y115.189 E1.09019
G2 X62.173 Y115.068 I-2.388 J18.392 E.04282
G1 X85.29 Y91.95 E1.08448
G1 X86.274 Y91.95 E.03265
G1 X104.374 Y110.05 E.84908
G1 X105.571 Y110.05 E.0397
G1 X123.67 Y91.95 E.84908
G1 X124.654 Y91.95 E.03265
G1 X192.753 Y160.05 E3.19468
G1 X193.738 Y160.05 E.03265
G1 X227.05 Y126.738 E1.56273
G1 X227.05 Y125.262 E.04895
G1 X193.738 Y91.95 E1.56273
G1 X192.754 Y91.95 E.03265
G1 X124.654 Y160.05 E3.19468
G1 X123.67 Y160.05 E.03265
G1 X105.571 Y141.95 E.84908
G1 X104.374 Y141.95 E.0397
G1 X86.274 Y160.05 E.84908
G1 X85.29 Y160.05 E.03265
G1 X62.173 Y136.932 E1.08448
G2 X63.458 Y136.811 I-1.104 J-18.523 E.04282
G1 X40.219 Y160.05 E1.09019
G1 X39.234 Y160.05 E.03265
G1 X28.95 Y149.766 E.48245
G1 X28.95 Y151.394 E.05401
G1 X29.827 Y95.85 F30000
G1 F15476.087
G3 X28.95 Y95.399 I.729 J-2.492 E.0329
G1 X28.95 Y96.034 E.02105
G1 X52.705 Y119.788 E1.11436
G3 X56.807 Y116.215 I9.083 J6.285 E.18235
G1 X32.543 Y91.95 E1.13828
G1 X34.171 Y91.95 E.05401
; WIPE_START
G1 X32.543 Y91.95 E-.61876
G1 X32.805 Y92.213 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X31.531 Y91.619 Z1.2 F30000
G1 Z.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X31.192 Y91.559 E.00874
; LINE_WIDTH: 0.327687
G1 X31.026 Y91.537 E.00389
; LINE_WIDTH: 0.281538
G2 X30.841 Y91.514 I-.363 J2.118 E.00363
; LINE_WIDTH: 0.2443
G2 X30.14 Y91.516 I-.336 J5.782 E.0115
; LINE_WIDTH: 0.283928
G1 X29.974 Y91.537 E.00329
; LINE_WIDTH: 0.327696
G1 X29.808 Y91.559 E.00389
; LINE_WIDTH: 0.354364
G1 X29.469 Y91.619 E.00873
G1 X28.619 Y92.469 F30000
; LINE_WIDTH: 0.354377
G1 F15000
G1 X28.559 Y92.808 E.00873
; LINE_WIDTH: 0.327704
G1 X28.537 Y92.974 E.00389
; LINE_WIDTH: 0.281527
G2 X28.514 Y93.159 I2.112 J.363 E.00363
; LINE_WIDTH: 0.244295
G2 X28.516 Y93.86 I5.788 J.336 E.0115
; LINE_WIDTH: 0.283928
G1 X28.537 Y94.026 E.00329
; LINE_WIDTH: 0.327696
G1 X28.559 Y94.192 E.00389
; LINE_WIDTH: 0.354364
G1 X28.619 Y94.531 E.00874
; CHANGE_LAYER
; Z_HEIGHT: 1
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X28.559 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 5/25
; update layer progress
M73 L5
M991 S0 P4 ;notify layer change
G17
G3 Z1.2 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.899 Y138.97 Z1.4 F30000
G1 X51.281 Y124.096 Z1.4
G1 Z1
M73 P37 R31
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.288 Y124.081 E.00057
G3 X60.507 Y115.466 I10.423 J1.914 E.44831
G1 X61.47 Y115.4 E.03202
G3 X51.157 Y125.036 I.241 J10.594 E1.69637
G1 X51.273 Y124.156 E.02945
M204 S250
G1 X51.674 Y124.152 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.037 J1.843 E.3999
G1 X61.479 Y115.792 E.02856
G3 X51.663 Y124.211 I.232 J10.202 E1.5399
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37592
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03092
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.053 Z1.4 F30000
G1 X223.514 Y94.188 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.523 Y94.219 E.00108
G2 X227.227 Y94.688 I1.972 J-.715 E.1527
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X29.448 Y95.322 I1.843 J-1.285 E.03094
G1 X29.538 Y95.365 E.00331
G2 X31.688 Y91.773 I.965 J-1.862 E.20998
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.429 Y93.865 I1.184 J1.732 E.0796
G1 X223.499 Y94.13 E.0091
M204 S250
G1 X223.901 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.435 Y91.795 I1.606 J-.58 E.09839
G3 X226.355 Y92.018 I.082 J1.668 E.02951
G3 X223.923 Y94.138 I-.847 J1.483 E.20004
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13581
G1 X223.789 Y93.5 E-.11331
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11333
G1 X224.189 Y92.4 E-.11332
G1 X224.297 Y92.293 E-.05759
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z1.4 F30000
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02175
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.731 J1.192 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24921
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03913
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z1.4 F30000
G1 X32.108 Y94.083 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X32.112 Y94.087 E.00018
G3 X30.435 Y91.795 I-1.605 J-.585 E.22672
G3 X31.355 Y92.018 I.082 J1.668 E.02951
G3 X32.19 Y93.798 I-.847 J1.483 E.06435
G1 X32.125 Y94.025 E.00726
; WIPE_START
M204 S10000
G1 X32.112 Y94.087 E-.02389
G1 X31.982 Y94.355 E-.11352
G1 X31.811 Y94.6 E-.11332
G1 X31.6 Y94.811 E-.11335
G1 X31.355 Y94.982 E-.11329
G1 X31.085 Y95.108 E-.11334
G1 X30.797 Y95.185 E-.11332
G1 X30.65 Y95.198 E-.05599
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z1.4 F30000
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.191 J1.73 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08588
G1 X28.888 Y92.147 E-.13941
G1 X28.773 Y92.312 E-.07628
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14117
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z1.4 F30000
G1 X227.79 Y91.21 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z1.4 F30000
G1 Z1
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327687
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281538
G2 X225.841 Y91.514 I-.363 J2.118 E.00363
; LINE_WIDTH: 0.24429
G2 X225.14 Y91.516 I-.337 J5.785 E.0115
; LINE_WIDTH: 0.283917
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327693
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y92.469 Z1.4 F30000
G1 Z1
G1 E.8 F1800
; LINE_WIDTH: 0.354364
G1 F15000
G1 X227.441 Y92.808 E.00874
; LINE_WIDTH: 0.327676
G1 X227.463 Y92.974 E.00389
; LINE_WIDTH: 0.283908
G1 X227.484 Y93.14 E.00329
; LINE_WIDTH: 0.244295
G3 X227.486 Y93.841 I-5.787 J.364 E.0115
; LINE_WIDTH: 0.281523
G3 X227.463 Y94.026 I-2.137 J-.178 E.00363
; LINE_WIDTH: 0.327686
G1 X227.441 Y94.192 E.00389
; LINE_WIDTH: 0.354373
G1 X227.381 Y94.531 E.00874
; WIPE_START
G1 X227.441 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.173 Y95.85 Z1.4 F30000
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X227.05 Y95.399 I-.729 J-2.493 E.0329
G1 X227.05 Y96.034 E.02105
G1 X163.034 Y160.05 E3.00311
G1 X162.05 Y160.05 E.03265
G1 X93.95 Y91.95 E3.19468
G1 X92.966 Y91.95 E.03265
G1 X67.927 Y116.989 E1.17464
G3 X69.189 Y118.015 I-7.415 J10.416 E.05398
; WIPE_START
G1 X67.927 Y116.989 E-.61792
G1 X68.191 Y116.725 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y124.345 Z1.4 F30000
G1 X69.189 Y133.985 Z1.4
G1 Z1
G1 E.8 F1800
G1 F15476.087
G3 X67.927 Y135.011 I-8.677 J-9.39 E.05398
G1 X92.966 Y160.05 E1.17464
G1 X93.95 Y160.05 E.03265
G1 X162.05 Y91.95 E3.19468
G1 X163.034 Y91.95 E.03265
G1 X227.05 Y155.966 E3.00311
G1 X227.05 Y157.442 E.04894
G1 X224.442 Y160.05 E.12235
G1 X223.457 Y160.05 E.03265
G1 X155.358 Y91.95 E3.19468
G1 X154.374 Y91.95 E.03265
G1 X110.95 Y135.374 E2.03708
G1 X110.95 Y131.978 E.11264
G1 X139.022 Y160.05 E1.31689
G1 X140.006 Y160.05 E.03265
G1 X208.105 Y91.95 E3.19468
G1 X209.09 Y91.95 E.03265
G1 X227.05 Y109.91 E.84254
G1 X227.05 Y111.386 E.04895
G1 X178.386 Y160.05 E2.28292
G1 X177.402 Y160.05 E.03265
G1 X109.302 Y91.95 E3.19468
G1 X108.318 Y91.95 E.03265
G1 X72.511 Y127.757 E1.67977
G3 X71.493 Y130.9 I-9.768 J-1.429 E.11012
G1 X100.642 Y160.05 E1.36746
G1 X101.626 Y160.05 E.03265
G1 X169.726 Y91.95 E3.19468
G1 X170.71 Y91.95 E.03265
G1 X227.05 Y148.29 E2.64302
G1 X227.05 Y149.766 E.04894
G1 X216.766 Y160.05 E.48245
G1 X215.781 Y160.05 E.03265
G1 X147.682 Y91.95 E3.19468
G1 X146.698 Y91.95 E.03265
G1 X110.95 Y127.698 E1.67699
G1 X110.95 Y124.302 E.11264
G1 X146.698 Y160.05 E1.67699
G1 X147.682 Y160.05 E.03265
G1 X215.781 Y91.95 E3.19468
G1 X216.766 Y91.95 E.03265
G1 X227.05 Y102.234 E.48245
G1 X227.05 Y103.71 E.04895
G1 X170.71 Y160.05 E2.64302
G1 X169.726 Y160.05 E.03265
G1 X101.626 Y91.95 E3.19468
G1 X100.642 Y91.95 E.03265
G1 X71.493 Y121.1 E1.36746
G3 X72.511 Y124.243 I-8.749 J4.572 E.11012
G1 X108.318 Y160.05 E1.67977
G1 X109.302 Y160.05 E.03265
G1 X177.402 Y91.95 E3.19468
G1 X178.386 Y91.95 E.03265
G1 X227.05 Y140.614 E2.28292
G1 X227.05 Y142.09 E.04895
G1 X209.09 Y160.05 E.84254
G1 X208.105 Y160.05 E.03265
G1 X140.006 Y91.95 E3.19468
G1 X139.022 Y91.95 E.03265
G1 X110.95 Y120.022 E1.31689
G1 X110.95 Y116.626 E.11264
G1 X154.374 Y160.05 E2.03708
G1 X155.358 Y160.05 E.03265
G1 X223.457 Y91.95 E3.19468
G1 X221.829 Y91.95 E.05401
G1 X227.05 Y123.634 F30000
G1 F15476.087
G1 X227.05 Y125.262 E.05401
G1 X193.738 Y91.95 E1.56273
G1 X192.754 Y91.95 E.03265
G1 X124.654 Y160.05 E3.19468
G1 X123.67 Y160.05 E.03265
G1 X105.571 Y141.95 E.84908
G1 X104.374 Y141.95 E.0397
G1 X86.274 Y160.05 E.84908
G1 X85.29 Y160.05 E.03265
G1 X62.173 Y136.932 E1.08448
G2 X63.458 Y136.811 I-1.104 J-18.523 E.04282
G1 X40.219 Y160.05 E1.09019
G1 X39.234 Y160.05 E.03265
G1 X28.95 Y149.766 E.48245
G1 X28.95 Y148.29 E.04895
G1 X50.781 Y126.46 E1.0241
G3 X50.781 Y125.54 I5.034 J-.46 E.03055
G1 X28.95 Y103.71 E1.0241
G1 X28.95 Y102.234 E.04894
M73 P38 R31
G1 X39.234 Y91.95 E.48245
G1 X40.219 Y91.95 E.03265
G1 X63.458 Y115.189 E1.09019
G2 X62.173 Y115.068 I-2.388 J18.392 E.04282
G1 X85.29 Y91.95 E1.08448
G1 X86.274 Y91.95 E.03265
G1 X104.374 Y110.05 E.84908
G1 X105.571 Y110.05 E.0397
G1 X123.67 Y91.95 E.84908
G1 X124.654 Y91.95 E.03265
G1 X192.753 Y160.05 E3.19468
G1 X193.738 Y160.05 E.03265
G1 X227.05 Y126.738 E1.56273
G1 X227.05 Y128.366 E.05401
G1 X110.95 Y141.282 F30000
G1 F15476.087
G1 X110.95 Y139.654 E.05401
G1 X131.346 Y160.05 E.9568
G1 X132.33 Y160.05 E.03265
G1 X200.429 Y91.95 E3.19468
G1 X201.414 Y91.95 E.03265
G1 X227.05 Y117.586 E1.20264
G1 X227.05 Y119.062 E.04894
G1 X186.062 Y160.05 E1.92283
G1 X185.078 Y160.05 E.03265
G1 X116.978 Y91.95 E3.19468
G1 X115.994 Y91.95 E.03265
G1 X47.895 Y160.05 E3.19468
G1 X46.91 Y160.05 E.03265
G1 X28.95 Y142.09 E.84254
G1 X28.95 Y140.614 E.04895
G1 X77.614 Y91.95 E2.28292
G1 X78.598 Y91.95 E.03265
G1 X99.05 Y112.402 E.95941
G1 X99.05 Y116.571 E.13829
G1 X55.571 Y160.05 E2.0397
G1 X54.586 Y160.05 E.03265
G1 X28.95 Y134.414 E1.20264
G1 X28.95 Y132.938 E.04895
G1 X69.938 Y91.95 E1.92283
G1 X70.922 Y91.95 E.03265
G1 X99.05 Y120.078 E1.31951
G1 X99.05 Y124.246 E.13829
G1 X63.246 Y160.05 E1.6796
G1 X62.262 Y160.05 E.03265
G1 X28.95 Y126.738 E1.56273
G1 X28.95 Y125.262 E.04895
G1 X62.262 Y91.95 E1.56273
G1 X63.246 Y91.95 E.03265
G1 X99.05 Y127.753 E1.6796
G1 X99.05 Y131.922 E.13829
G1 X70.922 Y160.05 E1.31951
G1 X69.938 Y160.05 E.03265
G1 X28.95 Y119.062 E1.92283
G1 X28.95 Y117.586 E.04894
G1 X54.586 Y91.95 E1.20264
G1 X55.571 Y91.95 E.03265
G1 X99.05 Y135.429 E2.0397
G1 X99.05 Y139.598 E.13829
G1 X78.598 Y160.05 E.95941
G1 X77.614 Y160.05 E.03265
G1 X28.95 Y111.386 E2.28292
G1 X28.95 Y109.91 E.04895
G1 X46.91 Y91.95 E.84254
G1 X47.895 Y91.95 E.03265
G1 X115.994 Y160.05 E3.19468
G1 X116.978 Y160.05 E.03265
G1 X185.078 Y91.95 E3.19468
G1 X186.062 Y91.95 E.03265
G1 X227.05 Y132.938 E1.92283
G1 X227.05 Y134.414 E.04894
G1 X201.414 Y160.05 E1.20264
G1 X200.429 Y160.05 E.03265
G1 X132.33 Y91.95 E3.19468
G1 X131.346 Y91.95 E.03265
G1 X110.95 Y112.346 E.9568
G1 X110.95 Y110.718 E.05401
; WIPE_START
G1 X110.95 Y112.346 E-.61876
G1 X111.213 Y112.083 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X104.278 Y115.271 Z1.4 F30000
G1 X58.312 Y136.402 Z1.4
G1 Z1
G1 E.8 F1800
G1 F15476.087
G3 X56.807 Y135.785 I2.624 J-8.548 E.05403
G1 X32.543 Y160.05 E1.13828
G1 X31.558 Y160.05 E.03265
G1 X28.95 Y157.442 E.12235
G1 X28.95 Y155.966 E.04895
G1 X52.705 Y132.212 E1.11436
G3 X51.874 Y130.813 I13.206 J-8.788 E.05398
G1 X34.171 Y91.95 F30000
G1 F15476.087
G1 X32.543 Y91.95 E.05401
G1 X56.807 Y116.215 E1.13828
G2 X52.705 Y119.788 I4.981 J9.859 E.18235
G1 X28.95 Y96.034 E1.11436
G1 X28.95 Y95.399 E.02105
G2 X29.827 Y95.85 I1.605 J-2.041 E.0329
; WIPE_START
G1 X29.273 Y95.625 E-.22717
G1 X28.95 Y95.399 E-.1497
G1 X28.95 Y96.034 E-.24118
G1 X29.214 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
G1 X28.619 Y94.531 Z1.4 F30000
G1 Z1
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354386
G1 F15000
G1 X28.559 Y94.192 E.00874
; LINE_WIDTH: 0.327693
G1 X28.537 Y94.026 E.00389
; LINE_WIDTH: 0.283917
G1 X28.516 Y93.86 E.00329
; LINE_WIDTH: 0.2443
G3 X28.514 Y93.159 I5.787 J-.364 E.0115
; LINE_WIDTH: 0.281525
G3 X28.537 Y92.974 I2.139 J.178 E.00363
; LINE_WIDTH: 0.327686
G1 X28.559 Y92.808 E.00389
; LINE_WIDTH: 0.354377
G1 X28.619 Y92.469 E.00874
G1 X29.469 Y91.619 F30000
; LINE_WIDTH: 0.354384
G1 F15000
G1 X29.808 Y91.559 E.00874
; LINE_WIDTH: 0.327697
G1 X29.974 Y91.537 E.00389
; LINE_WIDTH: 0.283931
G1 X30.14 Y91.516 E.00329
; LINE_WIDTH: 0.244296
G3 X30.841 Y91.514 I.364 J5.785 E.0115
; LINE_WIDTH: 0.281539
G3 X31.026 Y91.537 I-.178 J2.141 E.00363
; LINE_WIDTH: 0.327691
G1 X31.192 Y91.559 E.00389
; LINE_WIDTH: 0.354377
G1 X31.531 Y91.619 E.00874
; CHANGE_LAYER
; Z_HEIGHT: 1.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X31.192 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 6/25
; update layer progress
M73 L6
M991 S0 P5 ;notify layer change
G17
G3 Z1.4 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z1.6 F30000
G1 X51.287 Y124.063 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.502 Y123.14 E.03146
G3 X60.507 Y115.466 I10.209 J2.86 E.41633
G1 X61.47 Y115.4 E.03202
G3 X51.277 Y124.122 I.241 J10.599 E1.72787
M204 S250
G1 X51.67 Y124.151 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.041 J1.848 E.39995
G1 X61.479 Y115.792 E.02856
G3 X51.66 Y124.21 I.232 J10.207 E1.54072
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37597
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03088
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.053 Z1.6 F30000
G1 X223.514 Y94.188 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.53 Y94.217 E.00109
G2 X227.227 Y94.688 I1.97 J-.717 E.15229
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X29.448 Y95.322 I1.842 J-1.285 E.03094
G1 X29.548 Y95.369 E.00366
G2 X31.688 Y91.773 I.951 J-1.869 E.20936
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.435 Y93.864 I1.188 J1.727 E.07947
G1 X223.5 Y94.13 E.00907
M204 S250
G1 X223.9 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.424 Y91.796 I1.606 J-.58 E.09811
G3 X226.6 Y92.189 I.064 J1.76 E.03892
G3 X223.922 Y94.138 I-1.093 J1.312 E.19082
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13583
G1 X223.789 Y93.5 E-.11332
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11333
G1 X224.189 Y92.4 E-.11332
G1 X224.297 Y92.293 E-.05757
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z1.6 F30000
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02175
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.731 J1.192 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24921
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03913
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z1.6 F30000
G1 X32.108 Y94.083 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X32.111 Y94.086 E.00013
G3 X30.424 Y91.796 I-1.604 J-.585 E.22639
G3 X31.6 Y92.189 I.064 J1.76 E.03892
G3 X32.188 Y93.798 I-1.093 J1.312 E.05513
G1 X32.124 Y94.025 E.00726
; WIPE_START
M204 S10000
G1 X32.111 Y94.086 E-.02375
G1 X31.982 Y94.355 E-.11345
G1 X31.811 Y94.6 E-.11332
G1 X31.6 Y94.811 E-.11335
G1 X31.355 Y94.982 E-.11329
G1 X31.085 Y95.108 E-.11334
G1 X30.797 Y95.185 E-.11332
G1 X30.65 Y95.198 E-.05619
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z1.6 F30000
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.191 J1.73 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08588
G1 X28.888 Y92.147 E-.13941
G1 X28.773 Y92.312 E-.07628
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14117
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z1.6 F30000
G1 X227.79 Y91.21 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z1.6 F30000
G1 Z1.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327687
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281538
G2 X225.841 Y91.514 I-.363 J2.118 E.00363
; LINE_WIDTH: 0.244295
G2 X225.14 Y91.516 I-.337 J5.786 E.0115
; LINE_WIDTH: 0.283928
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327696
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354384
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X221.829 Y91.95 Z1.6 F30000
G1 Z1.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.457 Y91.95 E.05401
G1 X155.358 Y160.05 E3.19468
G1 X154.374 Y160.05 E.03265
G1 X110.95 Y116.626 E2.03708
G1 X110.95 Y120.022 E.11264
G1 X139.022 Y91.95 E1.31689
G1 X140.006 Y91.95 E.03265
G1 X208.105 Y160.05 E3.19468
G1 X209.09 Y160.05 E.03265
G1 X227.05 Y142.09 E.84254
G1 X227.05 Y140.614 E.04895
G1 X178.386 Y91.95 E2.28292
G1 X177.402 Y91.95 E.03265
G1 X109.302 Y160.05 E3.19468
G1 X108.318 Y160.05 E.03265
G1 X72.511 Y124.243 E1.67977
G2 X71.493 Y121.1 I-9.768 J1.429 E.11012
G1 X100.642 Y91.95 E1.36746
G1 X101.626 Y91.95 E.03265
G1 X169.726 Y160.05 E3.19468
G1 X170.71 Y160.05 E.03265
G1 X227.05 Y103.71 E2.64302
G1 X227.05 Y102.234 E.04895
G1 X216.766 Y91.95 E.48245
G1 X215.781 Y91.95 E.03265
G1 X147.682 Y160.05 E3.19468
G1 X146.698 Y160.05 E.03265
G1 X110.95 Y124.302 E1.67699
G1 X110.95 Y127.698 E.11264
G1 X146.698 Y91.95 E1.67699
G1 X147.682 Y91.95 E.03265
G1 X215.781 Y160.05 E3.19468
G1 X216.766 Y160.05 E.03265
G1 X227.05 Y149.766 E.48245
G1 X227.05 Y148.29 E.04894
G1 X170.71 Y91.95 E2.64302
G1 X169.726 Y91.95 E.03265
G1 X101.626 Y160.05 E3.19468
G1 X100.642 Y160.05 E.03265
G1 X71.493 Y130.9 E1.36746
G2 X72.511 Y127.757 I-8.749 J-4.572 E.11012
G1 X108.318 Y91.95 E1.67977
G1 X109.302 Y91.95 E.03265
G1 X177.402 Y160.05 E3.19468
G1 X178.386 Y160.05 E.03265
G1 X227.05 Y111.386 E2.28292
G1 X227.05 Y109.91 E.04895
G1 X209.09 Y91.95 E.84254
G1 X208.105 Y91.95 E.03265
G1 X140.006 Y160.05 E3.19468
G1 X139.022 Y160.05 E.03265
G1 X110.95 Y131.978 E1.31689
G1 X110.95 Y135.374 E.11264
G1 X154.374 Y91.95 E2.03708
G1 X155.358 Y91.95 E.03265
G1 X223.457 Y160.05 E3.19468
G1 X224.442 Y160.05 E.03265
G1 X227.05 Y157.442 E.12235
G1 X227.05 Y155.966 E.04894
G1 X163.034 Y91.95 E3.00311
G1 X162.05 Y91.95 E.03265
G1 X93.95 Y160.05 E3.19468
G1 X92.966 Y160.05 E.03265
G1 X67.927 Y135.011 E1.17464
G2 X69.189 Y133.985 I-7.415 J-10.416 E.05398
; WIPE_START
G1 X67.927 Y135.011 E-.61792
G1 X68.191 Y135.275 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y127.655 Z1.6 F30000
G1 X69.189 Y118.015 Z1.6
G1 Z1.2
G1 E.8 F1800
G1 F15476.087
G2 X67.927 Y116.989 I-8.677 J9.391 E.05398
M73 P39 R31
G1 X92.966 Y91.95 E1.17464
G1 X93.95 Y91.95 E.03265
G1 X162.05 Y160.05 E3.19468
G1 X163.034 Y160.05 E.03265
G1 X227.05 Y96.034 E3.00311
G1 X227.05 Y95.399 E.02105
G3 X226.173 Y95.85 I-1.606 J-2.042 E.0329
; WIPE_START
G1 X226.727 Y95.625 E-.22719
G1 X227.05 Y95.399 E-.14969
G1 X227.05 Y96.034 E-.24118
G1 X226.786 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y94.531 Z1.6 F30000
G1 Z1.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354373
G1 F15000
G1 X227.441 Y94.192 E.00874
; LINE_WIDTH: 0.327686
G1 X227.463 Y94.026 E.00389
; LINE_WIDTH: 0.281523
G2 X227.486 Y93.841 I-2.114 J-.363 E.00363
; LINE_WIDTH: 0.244295
G2 X227.484 Y93.14 I-5.788 J-.336 E.0115
; LINE_WIDTH: 0.283908
G1 X227.463 Y92.974 E.00329
; LINE_WIDTH: 0.327676
G1 X227.441 Y92.808 E.00389
; LINE_WIDTH: 0.354364
G1 X227.381 Y92.469 E.00874
; WIPE_START
G1 X227.441 Y92.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.357 Y100.44 Z1.6 F30000
G1 X227.05 Y128.366 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X227.05 Y126.738 E.05401
G1 X193.738 Y160.05 E1.56273
G1 X192.753 Y160.05 E.03265
G1 X124.654 Y91.95 E3.19468
G1 X123.67 Y91.95 E.03265
G1 X105.571 Y110.05 E.84908
G1 X104.374 Y110.05 E.0397
G1 X86.274 Y91.95 E.84908
G1 X85.29 Y91.95 E.03265
G1 X62.173 Y115.068 E1.08448
G3 X63.458 Y115.189 I-1.103 J18.513 E.04282
G1 X40.219 Y91.95 E1.09019
G1 X39.234 Y91.95 E.03265
G1 X28.95 Y102.234 E.48245
G1 X28.95 Y103.71 E.04894
G1 X50.781 Y125.54 E1.0241
G2 X50.781 Y126.46 I5.034 J.46 E.03055
G1 X28.95 Y148.29 E1.0241
G1 X28.95 Y149.766 E.04895
G1 X39.234 Y160.05 E.48245
G1 X40.219 Y160.05 E.03265
G1 X63.458 Y136.811 E1.09019
G3 X62.173 Y136.932 I-2.389 J-18.402 E.04282
G1 X85.29 Y160.05 E1.08448
G1 X86.274 Y160.05 E.03265
G1 X104.374 Y141.95 E.84908
G1 X105.571 Y141.95 E.0397
G1 X123.67 Y160.05 E.84908
G1 X124.654 Y160.05 E.03265
G1 X192.754 Y91.95 E3.19468
G1 X193.738 Y91.95 E.03265
G1 X227.05 Y125.262 E1.56273
G1 X227.05 Y123.634 E.05401
G1 X110.95 Y110.718 F30000
G1 F15476.087
G1 X110.95 Y112.346 E.05401
G1 X131.346 Y91.95 E.9568
G1 X132.33 Y91.95 E.03265
G1 X200.429 Y160.05 E3.19468
G1 X201.414 Y160.05 E.03265
G1 X227.05 Y134.414 E1.20264
G1 X227.05 Y132.938 E.04894
G1 X186.062 Y91.95 E1.92283
G1 X185.078 Y91.95 E.03265
G1 X116.978 Y160.05 E3.19468
G1 X115.994 Y160.05 E.03265
G1 X47.895 Y91.95 E3.19468
G1 X46.91 Y91.95 E.03265
G1 X28.95 Y109.91 E.84254
G1 X28.95 Y111.386 E.04895
G1 X77.614 Y160.05 E2.28292
G1 X78.598 Y160.05 E.03265
G1 X99.05 Y139.598 E.95941
G1 X99.05 Y135.429 E.13829
G1 X55.571 Y91.95 E2.0397
G1 X54.586 Y91.95 E.03265
G1 X28.95 Y117.586 E1.20264
G1 X28.95 Y119.062 E.04894
G1 X69.938 Y160.05 E1.92283
G1 X70.922 Y160.05 E.03265
G1 X99.05 Y131.922 E1.31951
G1 X99.05 Y127.753 E.13829
G1 X63.246 Y91.95 E1.6796
G1 X62.262 Y91.95 E.03265
G1 X28.95 Y125.262 E1.56273
G1 X28.95 Y126.738 E.04895
G1 X62.262 Y160.05 E1.56273
G1 X63.246 Y160.05 E.03265
G1 X99.05 Y124.246 E1.6796
G1 X99.05 Y120.078 E.13829
G1 X70.922 Y91.95 E1.31951
G1 X69.938 Y91.95 E.03265
G1 X28.95 Y132.938 E1.92283
G1 X28.95 Y134.414 E.04895
G1 X54.586 Y160.05 E1.20264
G1 X55.571 Y160.05 E.03265
G1 X99.05 Y116.571 E2.0397
G1 X99.05 Y112.402 E.13829
G1 X78.598 Y91.95 E.95941
G1 X77.614 Y91.95 E.03265
G1 X28.95 Y140.614 E2.28292
G1 X28.95 Y142.09 E.04895
G1 X46.91 Y160.05 E.84254
G1 X47.895 Y160.05 E.03265
G1 X115.994 Y91.95 E3.19468
G1 X116.978 Y91.95 E.03265
G1 X185.078 Y160.05 E3.19468
G1 X186.062 Y160.05 E.03265
G1 X227.05 Y119.062 E1.92283
G1 X227.05 Y117.586 E.04894
G1 X201.414 Y91.95 E1.20264
G1 X200.429 Y91.95 E.03265
G1 X132.33 Y160.05 E3.19468
G1 X131.346 Y160.05 E.03265
G1 X110.95 Y139.654 E.9568
M73 P39 R30
G1 X110.95 Y141.282 E.05401
; WIPE_START
G1 X110.95 Y139.654 E-.61876
G1 X111.213 Y139.917 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X103.669 Y138.76 Z1.6 F30000
G1 X51.874 Y130.813 Z1.6
G1 Z1.2
G1 E.8 F1800
G1 F15476.087
G2 X52.705 Y132.212 I14.036 J-7.388 E.05398
G1 X28.95 Y155.966 E1.11436
G1 X28.95 Y157.442 E.04895
G1 X31.558 Y160.05 E.12235
G1 X32.543 Y160.05 E.03265
G1 X56.807 Y135.785 E1.13828
G2 X58.312 Y136.402 I4.129 J-7.931 E.05403
; WIPE_START
G1 X56.807 Y135.785 E-.61812
G1 X56.543 Y136.049 E-.14188
; WIPE_END
G1 E-.04 F1800
G1 X52.318 Y129.693 Z1.6 F30000
G1 X29.827 Y95.85 Z1.6
G1 Z1.2
G1 E.8 F1800
G1 F15476.087
G3 X28.95 Y95.399 I.729 J-2.493 E.0329
G1 X28.95 Y96.034 E.02105
G1 X52.705 Y119.788 E1.11436
G3 X56.807 Y116.215 I9.083 J6.285 E.18235
G1 X32.543 Y91.95 E1.13828
G1 X34.171 Y91.95 E.05401
; WIPE_START
G1 X32.543 Y91.95 E-.61876
G1 X32.805 Y92.213 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X31.531 Y91.619 Z1.6 F30000
G1 Z1.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X31.192 Y91.559 E.00874
; LINE_WIDTH: 0.327691
G1 X31.026 Y91.537 E.00389
; LINE_WIDTH: 0.281539
G2 X30.841 Y91.514 I-.363 J2.118 E.00363
; LINE_WIDTH: 0.244296
G2 X30.14 Y91.516 I-.337 J5.787 E.0115
; LINE_WIDTH: 0.283931
G1 X29.974 Y91.537 E.00329
; LINE_WIDTH: 0.327697
G1 X29.808 Y91.559 E.00389
; LINE_WIDTH: 0.354384
G1 X29.469 Y91.619 E.00874
G1 X28.619 Y92.469 F30000
; LINE_WIDTH: 0.354377
G1 F15000
G1 X28.559 Y92.808 E.00874
; LINE_WIDTH: 0.327686
G1 X28.537 Y92.974 E.00389
; LINE_WIDTH: 0.281525
G2 X28.514 Y93.159 I2.115 J.363 E.00363
; LINE_WIDTH: 0.2443
G2 X28.516 Y93.86 I5.789 J.336 E.0115
; LINE_WIDTH: 0.283917
G1 X28.537 Y94.026 E.00329
; LINE_WIDTH: 0.327693
G1 X28.559 Y94.192 E.00389
; LINE_WIDTH: 0.354386
G1 X28.619 Y94.531 E.00874
; CHANGE_LAYER
; Z_HEIGHT: 1.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X28.559 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 7/25
; update layer progress
M73 L7
M991 S0 P6 ;notify layer change
G17
G3 Z1.6 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z1.8 F30000
G1 X51.287 Y124.063 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.502 Y123.14 E.03145
G3 X60.507 Y115.466 I10.209 J2.86 E.41634
G1 X61.47 Y115.4 E.03202
G3 X51.277 Y124.122 I.241 J10.599 E1.72789
M204 S250
G1 X51.67 Y124.151 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.041 J1.848 E.39995
G1 X61.479 Y115.792 E.02856
G3 X51.66 Y124.21 I.232 J10.207 E1.54074
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37597
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03088
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.053 Z1.8 F30000
G1 X223.514 Y94.188 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.53 Y94.217 E.0011
G2 X227.227 Y94.688 I1.97 J-.717 E.15229
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.727 J-1.188 E.24389
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.435 Y93.864 I1.188 J1.727 E.07947
G1 X223.5 Y94.13 E.00907
M204 S250
G1 X223.901 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.414 Y91.797 I1.606 J-.58 E.09775
G3 X226.6 Y92.189 I.077 J1.755 E.03924
G3 X223.922 Y94.138 I-1.093 J1.312 E.19082
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13582
G1 X223.789 Y93.5 E-.11332
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11331
G1 X224.189 Y92.4 E-.11333
G1 X224.297 Y92.293 E-.05758
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z1.8 F30000
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03913
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z1.8 F30000
G1 X32.108 Y94.083 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X32.112 Y94.087 E.00015
G3 X30.414 Y91.797 I-1.605 J-.585 E.22608
G3 X31.6 Y92.189 I.077 J1.755 E.03924
G3 X32.189 Y93.798 I-1.093 J1.312 E.05513
G1 X32.124 Y94.025 E.00727
; WIPE_START
M204 S10000
G1 X32.112 Y94.087 E-.02371
G1 X31.982 Y94.355 E-.11347
G1 X31.811 Y94.6 E-.11333
G1 X31.6 Y94.811 E-.11333
G1 X31.355 Y94.982 E-.11332
G1 X31.085 Y95.108 E-.11333
G1 X30.797 Y95.185 E-.11331
G1 X30.65 Y95.198 E-.0562
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z1.8 F30000
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.731 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08592
G1 X28.888 Y92.147 E-.13942
G1 X28.773 Y92.312 E-.07624
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14116
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z1.8 F30000
G1 X227.79 Y91.21 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z1.8 F30000
G1 Z1.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00873
; LINE_WIDTH: 0.327704
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281529
G2 X225.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.24429
G2 X225.14 Y91.516 I-.336 J5.788 E.0115
; LINE_WIDTH: 0.283913
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327691
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354364
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y92.469 Z1.8 F30000
G1 Z1.4
G1 E.8 F1800
G1 F15000
G1 X227.441 Y92.808 E.00874
; LINE_WIDTH: 0.327676
G1 X227.463 Y92.974 E.00389
; LINE_WIDTH: 0.283908
G1 X227.484 Y93.14 E.00329
; LINE_WIDTH: 0.244295
G3 X227.486 Y93.841 I-5.787 J.364 E.0115
; LINE_WIDTH: 0.281523
G3 X227.463 Y94.026 I-2.14 J-.178 E.00363
; LINE_WIDTH: 0.327686
G1 X227.441 Y94.192 E.00389
; LINE_WIDTH: 0.354358
G1 X227.381 Y94.531 E.00873
; WIPE_START
G1 X227.441 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.173 Y95.85 Z1.8 F30000
G1 Z1.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X227.05 Y95.399 I-.729 J-2.493 E.0329
G1 X227.05 Y96.034 E.02105
G1 X163.034 Y160.05 E3.00311
G1 X162.05 Y160.05 E.03265
G1 X93.95 Y91.95 E3.19468
G1 X92.966 Y91.95 E.03265
G1 X67.927 Y116.989 E1.17464
G3 X69.189 Y118.015 I-7.415 J10.416 E.05398
; WIPE_START
G1 X67.927 Y116.989 E-.61792
G1 X68.191 Y116.725 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y124.345 Z1.8 F30000
G1 X69.189 Y133.985 Z1.8
G1 Z1.4
G1 E.8 F1800
G1 F15476.087
G3 X67.927 Y135.011 I-8.677 J-9.39 E.05398
G1 X92.966 Y160.05 E1.17464
G1 X93.95 Y160.05 E.03265
G1 X162.05 Y91.95 E3.19468
G1 X163.034 Y91.95 E.03265
G1 X227.05 Y155.966 E3.00311
G1 X227.05 Y157.442 E.04894
G1 X224.442 Y160.05 E.12235
G1 X223.457 Y160.05 E.03265
G1 X155.358 Y91.95 E3.19468
G1 X154.374 Y91.95 E.03265
G1 X110.95 Y135.374 E2.03708
G1 X110.95 Y131.978 E.11264
G1 X139.022 Y160.05 E1.31689
G1 X140.006 Y160.05 E.03265
G1 X208.105 Y91.95 E3.19468
G1 X209.09 Y91.95 E.03265
G1 X227.05 Y109.91 E.84254
G1 X227.05 Y111.386 E.04894
G1 X178.386 Y160.05 E2.28292
G1 X177.402 Y160.05 E.03265
G1 X109.302 Y91.95 E3.19468
G1 X108.318 Y91.95 E.03265
G1 X72.511 Y127.757 E1.67977
G3 X71.493 Y130.9 I-9.768 J-1.429 E.11012
G1 X100.642 Y160.05 E1.36746
G1 X101.626 Y160.05 E.03265
G1 X169.726 Y91.95 E3.19468
G1 X170.71 Y91.95 E.03265
G1 X227.05 Y148.29 E2.64302
G1 X227.05 Y149.766 E.04894
G1 X216.766 Y160.05 E.48245
G1 X215.781 Y160.05 E.03265
G1 X147.682 Y91.95 E3.19468
G1 X146.698 Y91.95 E.03265
G1 X110.95 Y127.698 E1.67699
M73 P40 R30
G1 X110.95 Y124.302 E.11264
G1 X146.698 Y160.05 E1.67699
G1 X147.682 Y160.05 E.03265
G1 X215.781 Y91.95 E3.19468
G1 X216.766 Y91.95 E.03265
G1 X227.05 Y102.234 E.48245
G1 X227.05 Y103.71 E.04894
G1 X170.71 Y160.05 E2.64302
G1 X169.726 Y160.05 E.03265
G1 X101.626 Y91.95 E3.19468
G1 X100.642 Y91.95 E.03265
G1 X71.493 Y121.1 E1.36746
G3 X72.511 Y124.243 I-8.749 J4.572 E.11012
G1 X108.318 Y160.05 E1.67977
G1 X109.302 Y160.05 E.03265
G1 X177.402 Y91.95 E3.19468
G1 X178.386 Y91.95 E.03265
G1 X227.05 Y140.614 E2.28292
G1 X227.05 Y142.09 E.04894
G1 X209.09 Y160.05 E.84254
G1 X208.105 Y160.05 E.03265
G1 X140.006 Y91.95 E3.19468
G1 X139.022 Y91.95 E.03265
G1 X110.95 Y120.022 E1.31689
G1 X110.95 Y116.626 E.11264
G1 X154.374 Y160.05 E2.03708
G1 X155.358 Y160.05 E.03265
G1 X223.457 Y91.95 E3.19468
G1 X221.829 Y91.95 E.05401
G1 X227.05 Y123.634 F30000
G1 F15476.087
G1 X227.05 Y125.262 E.05401
G1 X193.738 Y91.95 E1.56273
G1 X192.754 Y91.95 E.03265
G1 X124.654 Y160.05 E3.19468
G1 X123.67 Y160.05 E.03265
G1 X105.571 Y141.95 E.84908
G1 X104.374 Y141.95 E.0397
G1 X86.274 Y160.05 E.84908
G1 X85.29 Y160.05 E.03265
G1 X62.173 Y136.932 E1.08448
G2 X63.458 Y136.811 I-1.104 J-18.523 E.04282
G1 X40.219 Y160.05 E1.09019
G1 X39.234 Y160.05 E.03265
G1 X28.95 Y149.766 E.48245
G1 X28.95 Y148.29 E.04895
G1 X50.781 Y126.46 E1.0241
G3 X50.781 Y125.54 I5.034 J-.46 E.03055
G1 X28.95 Y103.71 E1.0241
G1 X28.95 Y102.234 E.04894
G1 X39.234 Y91.95 E.48245
G1 X40.219 Y91.95 E.03265
G1 X63.458 Y115.189 E1.09019
G2 X62.173 Y115.068 I-2.388 J18.392 E.04282
G1 X85.29 Y91.95 E1.08448
G1 X86.274 Y91.95 E.03265
G1 X104.374 Y110.05 E.84908
G1 X105.571 Y110.05 E.0397
G1 X123.67 Y91.95 E.84908
G1 X124.654 Y91.95 E.03265
G1 X192.753 Y160.05 E3.19468
G1 X193.738 Y160.05 E.03265
G1 X227.05 Y126.738 E1.56273
G1 X227.05 Y128.366 E.05401
G1 X110.95 Y141.282 F30000
G1 F15476.087
G1 X110.95 Y139.654 E.05401
G1 X131.346 Y160.05 E.9568
G1 X132.33 Y160.05 E.03265
G1 X200.429 Y91.95 E3.19468
G1 X201.414 Y91.95 E.03265
G1 X227.05 Y117.586 E1.20264
G1 X227.05 Y119.062 E.04894
G1 X186.062 Y160.05 E1.92283
G1 X185.078 Y160.05 E.03265
G1 X116.978 Y91.95 E3.19468
G1 X115.994 Y91.95 E.03265
G1 X47.895 Y160.05 E3.19468
G1 X46.91 Y160.05 E.03265
G1 X28.95 Y142.09 E.84254
G1 X28.95 Y140.614 E.04895
G1 X77.614 Y91.95 E2.28292
G1 X78.598 Y91.95 E.03265
G1 X99.05 Y112.402 E.95941
G1 X99.05 Y116.571 E.13829
G1 X55.571 Y160.05 E2.0397
G1 X54.586 Y160.05 E.03265
G1 X28.95 Y134.414 E1.20264
G1 X28.95 Y132.938 E.04895
G1 X69.938 Y91.95 E1.92283
G1 X70.922 Y91.95 E.03265
G1 X99.05 Y120.078 E1.31951
G1 X99.05 Y124.246 E.13829
G1 X63.246 Y160.05 E1.6796
G1 X62.262 Y160.05 E.03265
G1 X28.95 Y126.738 E1.56273
G1 X28.95 Y125.262 E.04895
G1 X62.262 Y91.95 E1.56273
G1 X63.246 Y91.95 E.03265
G1 X99.05 Y127.753 E1.6796
G1 X99.05 Y131.922 E.13829
G1 X70.922 Y160.05 E1.31951
G1 X69.938 Y160.05 E.03265
G1 X28.95 Y119.062 E1.92283
G1 X28.95 Y117.586 E.04894
G1 X54.586 Y91.95 E1.20264
G1 X55.571 Y91.95 E.03265
G1 X99.05 Y135.429 E2.0397
G1 X99.05 Y139.598 E.13829
G1 X78.598 Y160.05 E.95941
G1 X77.614 Y160.05 E.03265
G1 X28.95 Y111.386 E2.28292
G1 X28.95 Y109.91 E.04895
G1 X46.91 Y91.95 E.84254
G1 X47.895 Y91.95 E.03265
G1 X115.994 Y160.05 E3.19468
G1 X116.978 Y160.05 E.03265
G1 X185.078 Y91.95 E3.19468
G1 X186.062 Y91.95 E.03265
G1 X227.05 Y132.938 E1.92283
G1 X227.05 Y134.414 E.04894
G1 X201.414 Y160.05 E1.20264
G1 X200.429 Y160.05 E.03265
G1 X132.33 Y91.95 E3.19468
G1 X131.346 Y91.95 E.03265
G1 X110.95 Y112.346 E.9568
G1 X110.95 Y110.718 E.05401
; WIPE_START
G1 X110.95 Y112.346 E-.61876
G1 X111.213 Y112.083 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X104.278 Y115.271 Z1.8 F30000
G1 X58.312 Y136.402 Z1.8
G1 Z1.4
G1 E.8 F1800
G1 F15476.087
G3 X56.807 Y135.785 I2.624 J-8.548 E.05403
G1 X32.543 Y160.05 E1.13828
G1 X31.558 Y160.05 E.03265
G1 X28.95 Y157.442 E.12235
G1 X28.95 Y155.966 E.04895
G1 X52.705 Y132.212 E1.11436
G3 X51.874 Y130.813 I13.206 J-8.787 E.05398
G1 X34.171 Y91.95 F30000
G1 F15476.087
G1 X32.543 Y91.95 E.05401
G1 X56.807 Y116.215 E1.13828
G2 X52.705 Y119.788 I4.981 J9.859 E.18235
G1 X28.95 Y96.034 E1.11436
G1 X28.95 Y95.399 E.02105
G2 X29.827 Y95.85 I1.605 J-2.041 E.0329
; WIPE_START
G1 X29.273 Y95.625 E-.22714
G1 X28.95 Y95.399 E-.14973
G1 X28.95 Y96.034 E-.24118
G1 X29.214 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
G1 X28.619 Y94.531 Z1.8 F30000
G1 Z1.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354364
G1 F15000
G1 X28.559 Y94.192 E.00874
; LINE_WIDTH: 0.327696
G1 X28.537 Y94.026 E.00389
; LINE_WIDTH: 0.283928
G1 X28.516 Y93.86 E.00329
; LINE_WIDTH: 0.244295
G3 X28.514 Y93.159 I5.787 J-.364 E.0115
; LINE_WIDTH: 0.281527
G3 X28.537 Y92.974 I2.135 J.177 E.00363
; LINE_WIDTH: 0.327704
G1 X28.559 Y92.808 E.00389
; LINE_WIDTH: 0.354377
G1 X28.619 Y92.469 E.00873
G1 X29.469 Y91.619 F30000
; LINE_WIDTH: 0.354364
G1 F15000
G1 X29.808 Y91.559 E.00874
; LINE_WIDTH: 0.327691
G1 X29.974 Y91.537 E.00389
; LINE_WIDTH: 0.283913
G1 X30.14 Y91.516 E.00329
; LINE_WIDTH: 0.24429
G3 X30.841 Y91.514 I.364 J5.787 E.0115
; LINE_WIDTH: 0.281529
G3 X31.026 Y91.537 I-.178 J2.137 E.00363
; LINE_WIDTH: 0.327704
G1 X31.192 Y91.559 E.00389
; LINE_WIDTH: 0.354377
G1 X31.531 Y91.619 E.00874
; CHANGE_LAYER
; Z_HEIGHT: 1.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X31.192 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 8/25
; update layer progress
M73 L8
M991 S0 P7 ;notify layer change
G17
G3 Z1.8 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.899 Y138.97 Z2 F30000
G1 X51.281 Y124.097 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.284 Y124.08 E.00057
G3 X60.507 Y115.466 I10.427 J1.919 E.44836
G1 X61.47 Y115.4 E.03202
G3 X51.153 Y125.036 I.241 J10.599 E1.69729
G1 X51.273 Y124.156 E.02945
M204 S250
G1 X51.67 Y124.151 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.041 J1.848 E.39995
G1 X61.479 Y115.792 E.02856
G3 X51.66 Y124.21 I.232 J10.207 E1.54074
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37597
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03088
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.053 Z2 F30000
G1 X223.514 Y94.188 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.53 Y94.217 E.0011
G2 X227.227 Y94.688 I1.97 J-.717 E.15229
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17793
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X29.448 Y95.322 I1.843 J-1.285 E.03094
G1 X29.567 Y95.378 E.00435
G2 X31.688 Y91.773 I.933 J-1.878 E.20865
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.435 Y93.864 I1.188 J1.727 E.07947
G1 X223.5 Y94.13 E.00907
M204 S250
G1 X223.901 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.404 Y91.798 I1.606 J-.58 E.0974
G3 X226.6 Y92.189 I.089 J1.75 E.03956
G3 X223.923 Y94.138 I-1.092 J1.313 E.19082
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13582
G1 X223.789 Y93.5 E-.11331
G1 X223.815 Y93.203 E-.11331
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11331
G1 X224.189 Y92.4 E-.11333
G1 X224.297 Y92.293 E-.05759
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z2 F30000
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03913
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z2 F30000
G1 X32.108 Y94.083 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X32.112 Y94.087 E.00015
G3 X30.404 Y91.798 I-1.604 J-.585 E.22572
G3 X31.6 Y92.189 I.089 J1.75 E.03956
G3 X32.189 Y93.798 I-1.092 J1.313 E.05514
G1 X32.124 Y94.026 E.00728
; WIPE_START
M204 S10000
G1 X32.112 Y94.087 E-.02366
G1 X31.982 Y94.355 E-.11348
G1 X31.811 Y94.6 E-.11333
G1 X31.6 Y94.811 E-.11335
G1 X31.355 Y94.982 E-.11329
G1 X31.085 Y95.108 E-.11334
G1 X30.797 Y95.185 E-.11331
G1 X30.65 Y95.198 E-.05625
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z2 F30000
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.191 J1.73 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08588
G1 X28.888 Y92.147 E-.13945
G1 X28.773 Y92.312 E-.07624
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14116
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z2 F30000
G1 X227.79 Y91.21 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z2 F30000
G1 Z1.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00873
; LINE_WIDTH: 0.327704
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281529
G2 X225.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.244296
G2 X225.14 Y91.516 I-.336 J5.783 E.0115
; LINE_WIDTH: 0.283928
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327696
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354361
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X221.829 Y91.95 Z2 F30000
G1 Z1.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.457 Y91.95 E.05401
G1 X155.358 Y160.05 E3.19468
G1 X154.374 Y160.05 E.03265
G1 X110.95 Y116.626 E2.03708
G1 X110.95 Y120.022 E.11264
G1 X139.022 Y91.95 E1.31689
G1 X140.006 Y91.95 E.03265
G1 X208.105 Y160.05 E3.19468
G1 X209.09 Y160.05 E.03265
G1 X227.05 Y142.09 E.84254
G1 X227.05 Y140.614 E.04895
G1 X178.386 Y91.95 E2.28292
G1 X177.402 Y91.95 E.03265
G1 X109.302 Y160.05 E3.19468
G1 X108.318 Y160.05 E.03265
G1 X72.511 Y124.243 E1.67977
G2 X71.493 Y121.1 I-9.768 J1.429 E.11012
G1 X100.642 Y91.95 E1.36746
G1 X101.626 Y91.95 E.03265
G1 X169.726 Y160.05 E3.19468
G1 X170.71 Y160.05 E.03265
G1 X227.05 Y103.71 E2.64302
G1 X227.05 Y102.234 E.04895
G1 X216.766 Y91.95 E.48245
G1 X215.781 Y91.95 E.03265
G1 X147.682 Y160.05 E3.19468
G1 X146.698 Y160.05 E.03265
G1 X110.95 Y124.302 E1.67699
M73 P41 R30
G1 X110.95 Y127.698 E.11264
G1 X146.698 Y91.95 E1.67699
G1 X147.682 Y91.95 E.03265
G1 X215.781 Y160.05 E3.19468
G1 X216.766 Y160.05 E.03265
G1 X227.05 Y149.766 E.48245
G1 X227.05 Y148.29 E.04894
G1 X170.71 Y91.95 E2.64302
G1 X169.726 Y91.95 E.03265
G1 X101.626 Y160.05 E3.19468
G1 X100.642 Y160.05 E.03265
G1 X71.493 Y130.9 E1.36746
G2 X72.511 Y127.757 I-8.749 J-4.572 E.11012
G1 X108.318 Y91.95 E1.67977
G1 X109.302 Y91.95 E.03265
G1 X177.402 Y160.05 E3.19468
G1 X178.386 Y160.05 E.03265
G1 X227.05 Y111.386 E2.28292
G1 X227.05 Y109.91 E.04895
G1 X209.09 Y91.95 E.84254
G1 X208.105 Y91.95 E.03265
G1 X140.006 Y160.05 E3.19468
G1 X139.022 Y160.05 E.03265
G1 X110.95 Y131.978 E1.31689
G1 X110.95 Y135.374 E.11264
G1 X154.374 Y91.95 E2.03708
G1 X155.358 Y91.95 E.03265
G1 X223.457 Y160.05 E3.19468
G1 X224.442 Y160.05 E.03265
G1 X227.05 Y157.442 E.12235
G1 X227.05 Y155.966 E.04894
G1 X163.034 Y91.95 E3.00311
G1 X162.05 Y91.95 E.03265
G1 X93.95 Y160.05 E3.19468
G1 X92.966 Y160.05 E.03265
G1 X67.927 Y135.011 E1.17464
G2 X69.189 Y133.985 I-7.415 J-10.416 E.05398
; WIPE_START
G1 X67.927 Y135.011 E-.61792
G1 X68.191 Y135.275 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y127.655 Z2 F30000
G1 X69.189 Y118.015 Z2
G1 Z1.6
G1 E.8 F1800
G1 F15476.087
G2 X67.927 Y116.989 I-8.677 J9.391 E.05398
G1 X92.966 Y91.95 E1.17464
G1 X93.95 Y91.95 E.03265
G1 X162.05 Y160.05 E3.19468
G1 X163.034 Y160.05 E.03265
G1 X227.05 Y96.034 E3.00311
G1 X227.05 Y95.399 E.02105
G3 X226.173 Y95.85 I-1.606 J-2.042 E.0329
; WIPE_START
G1 X226.727 Y95.625 E-.22718
G1 X227.05 Y95.399 E-.1497
G1 X227.05 Y96.034 E-.24118
G1 X226.786 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y94.531 Z2 F30000
G1 Z1.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354373
G1 F15000
G1 X227.441 Y94.192 E.00873
; LINE_WIDTH: 0.3277
G1 X227.463 Y94.026 E.00389
; LINE_WIDTH: 0.281527
G2 X227.486 Y93.841 I-2.114 J-.363 E.00363
; LINE_WIDTH: 0.244295
G2 X227.484 Y93.14 I-5.788 J-.336 E.0115
; LINE_WIDTH: 0.283908
G1 X227.463 Y92.974 E.00329
; LINE_WIDTH: 0.327676
G1 X227.441 Y92.808 E.00389
; LINE_WIDTH: 0.354361
G1 X227.381 Y92.469 E.00874
; WIPE_START
G1 X227.441 Y92.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.357 Y100.44 Z2 F30000
G1 X227.05 Y128.366 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X227.05 Y126.738 E.05401
G1 X193.738 Y160.05 E1.56273
M73 P41 R29
G1 X192.753 Y160.05 E.03265
G1 X124.654 Y91.95 E3.19468
G1 X123.67 Y91.95 E.03265
G1 X105.571 Y110.05 E.84908
G1 X104.374 Y110.05 E.0397
G1 X86.274 Y91.95 E.84908
G1 X85.29 Y91.95 E.03265
G1 X62.173 Y115.068 E1.08448
G3 X63.458 Y115.189 I-1.103 J18.514 E.04282
G1 X40.219 Y91.95 E1.09019
G1 X39.234 Y91.95 E.03265
G1 X28.95 Y102.234 E.48245
G1 X28.95 Y103.71 E.04894
G1 X50.781 Y125.54 E1.0241
G2 X50.781 Y126.46 I5.034 J.46 E.03055
G1 X28.95 Y148.29 E1.0241
G1 X28.95 Y149.766 E.04895
G1 X39.234 Y160.05 E.48245
G1 X40.219 Y160.05 E.03265
G1 X63.458 Y136.811 E1.09019
G3 X62.173 Y136.932 I-2.389 J-18.402 E.04282
G1 X85.29 Y160.05 E1.08448
G1 X86.274 Y160.05 E.03265
G1 X104.374 Y141.95 E.84908
G1 X105.571 Y141.95 E.0397
G1 X123.67 Y160.05 E.84908
G1 X124.654 Y160.05 E.03265
G1 X192.754 Y91.95 E3.19468
G1 X193.738 Y91.95 E.03265
G1 X227.05 Y125.262 E1.56273
G1 X227.05 Y123.634 E.05401
G1 X110.95 Y110.718 F30000
G1 F15476.087
G1 X110.95 Y112.346 E.05401
G1 X131.346 Y91.95 E.9568
G1 X132.33 Y91.95 E.03265
G1 X200.429 Y160.05 E3.19468
G1 X201.414 Y160.05 E.03265
G1 X227.05 Y134.414 E1.20264
G1 X227.05 Y132.938 E.04894
G1 X186.062 Y91.95 E1.92283
G1 X185.078 Y91.95 E.03265
G1 X116.978 Y160.05 E3.19468
G1 X115.994 Y160.05 E.03265
G1 X47.895 Y91.95 E3.19468
G1 X46.91 Y91.95 E.03265
G1 X28.95 Y109.91 E.84254
G1 X28.95 Y111.386 E.04895
G1 X77.614 Y160.05 E2.28292
G1 X78.598 Y160.05 E.03265
G1 X99.05 Y139.598 E.95941
G1 X99.05 Y135.429 E.13829
G1 X55.571 Y91.95 E2.0397
G1 X54.586 Y91.95 E.03265
G1 X28.95 Y117.586 E1.20264
G1 X28.95 Y119.062 E.04894
G1 X69.938 Y160.05 E1.92283
G1 X70.922 Y160.05 E.03265
G1 X99.05 Y131.922 E1.31951
G1 X99.05 Y127.753 E.13829
G1 X63.246 Y91.95 E1.6796
G1 X62.262 Y91.95 E.03265
G1 X28.95 Y125.262 E1.56273
G1 X28.95 Y126.738 E.04895
G1 X62.262 Y160.05 E1.56273
G1 X63.246 Y160.05 E.03265
G1 X99.05 Y124.246 E1.6796
G1 X99.05 Y120.078 E.13829
G1 X70.922 Y91.95 E1.31951
G1 X69.938 Y91.95 E.03265
G1 X28.95 Y132.938 E1.92283
G1 X28.95 Y134.414 E.04895
G1 X54.586 Y160.05 E1.20264
G1 X55.571 Y160.05 E.03265
G1 X99.05 Y116.571 E2.0397
G1 X99.05 Y112.402 E.13829
G1 X78.598 Y91.95 E.95941
G1 X77.614 Y91.95 E.03265
G1 X28.95 Y140.614 E2.28292
G1 X28.95 Y142.09 E.04895
G1 X46.91 Y160.05 E.84254
G1 X47.895 Y160.05 E.03265
G1 X115.994 Y91.95 E3.19468
G1 X116.978 Y91.95 E.03265
G1 X185.078 Y160.05 E3.19468
G1 X186.062 Y160.05 E.03265
G1 X227.05 Y119.062 E1.92283
G1 X227.05 Y117.586 E.04894
G1 X201.414 Y91.95 E1.20264
G1 X200.429 Y91.95 E.03265
G1 X132.33 Y160.05 E3.19468
G1 X131.346 Y160.05 E.03265
G1 X110.95 Y139.654 E.9568
G1 X110.95 Y141.282 E.05401
; WIPE_START
G1 X110.95 Y139.654 E-.61876
G1 X111.213 Y139.917 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X103.669 Y138.76 Z2 F30000
G1 X51.874 Y130.813 Z2
G1 Z1.6
G1 E.8 F1800
G1 F15476.087
G2 X52.705 Y132.212 I14.036 J-7.388 E.05398
G1 X28.95 Y155.966 E1.11436
G1 X28.95 Y157.442 E.04895
G1 X31.558 Y160.05 E.12235
G1 X32.543 Y160.05 E.03265
G1 X56.807 Y135.785 E1.13828
G2 X58.312 Y136.402 I4.129 J-7.931 E.05403
; WIPE_START
G1 X56.807 Y135.785 E-.61812
G1 X56.543 Y136.049 E-.14188
; WIPE_END
G1 E-.04 F1800
G1 X52.318 Y129.693 Z2 F30000
G1 X29.827 Y95.85 Z2
G1 Z1.6
G1 E.8 F1800
G1 F15476.087
G3 X28.95 Y95.399 I.729 J-2.493 E.0329
G1 X28.95 Y96.034 E.02105
G1 X52.705 Y119.788 E1.11436
G3 X56.807 Y116.215 I9.083 J6.285 E.18235
G1 X32.543 Y91.95 E1.13828
G1 X34.171 Y91.95 E.05401
; WIPE_START
G1 X32.543 Y91.95 E-.61876
G1 X32.805 Y92.213 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X31.531 Y91.619 Z2 F30000
G1 Z1.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354373
G1 F15000
G1 X31.192 Y91.559 E.00873
; LINE_WIDTH: 0.327704
G1 X31.026 Y91.537 E.00389
; LINE_WIDTH: 0.281529
G2 X30.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.244296
G2 X30.14 Y91.516 I-.336 J5.783 E.0115
; LINE_WIDTH: 0.283928
G1 X29.974 Y91.537 E.00329
; LINE_WIDTH: 0.327696
G1 X29.808 Y91.559 E.00389
; LINE_WIDTH: 0.354361
G1 X29.469 Y91.619 E.00874
G1 X28.619 Y92.469 F30000
; LINE_WIDTH: 0.354377
G1 F15000
G1 X28.559 Y92.808 E.00873
; LINE_WIDTH: 0.327704
G1 X28.537 Y92.974 E.00389
; LINE_WIDTH: 0.281527
G2 X28.514 Y93.159 I2.112 J.363 E.00363
; LINE_WIDTH: 0.244295
G2 X28.516 Y93.86 I5.788 J.336 E.0115
; LINE_WIDTH: 0.283928
G1 X28.537 Y94.026 E.00329
; LINE_WIDTH: 0.327696
G1 X28.559 Y94.192 E.00389
; LINE_WIDTH: 0.354364
G1 X28.619 Y94.531 E.00874
; CHANGE_LAYER
; Z_HEIGHT: 1.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X28.559 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 9/25
; update layer progress
M73 L9
M991 S0 P8 ;notify layer change
G17
G3 Z2 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.899 Y138.97 Z2.2 F30000
G1 X51.281 Y124.097 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.288 Y124.081 E.00058
G3 X60.507 Y115.466 I10.423 J1.914 E.44831
G1 X61.47 Y115.4 E.03202
G3 X51.157 Y125.036 I.241 J10.594 E1.69637
G1 X51.273 Y124.156 E.02944
M204 S250
G1 X51.674 Y124.152 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.037 J1.843 E.3999
G1 X61.479 Y115.792 E.02856
G3 X51.663 Y124.211 I.232 J10.202 E1.5399
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37592
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03092
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.055 Z2.2 F30000
G1 X223.537 Y94.25 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.678 Y94.552 E.01107
G2 X227.227 Y94.688 I1.818 J-1.047 E.14052
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X29.448 Y95.322 I1.843 J-1.285 E.03094
G1 X29.576 Y95.382 E.0047
G2 X31.688 Y91.773 I.931 J-1.878 E.20881
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.514 Y94.194 I1.183 J1.732 E.09089
M204 S250
G1 X223.902 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.393 Y91.799 I1.606 J-.58 E.09705
G3 X226.6 Y92.189 I.101 J1.747 E.03988
G3 X223.923 Y94.138 I-1.092 J1.313 E.19081
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13581
G1 X223.789 Y93.5 E-.11332
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11332
G1 X224.189 Y92.4 E-.11333
G1 X224.297 Y92.293 E-.05759
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z2.2 F30000
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03912
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z2.2 F30000
G1 X32.108 Y94.084 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X32.112 Y94.087 E.00016
G3 X30.393 Y91.799 I-1.604 J-.585 E.22537
G3 X31.6 Y92.189 I.101 J1.747 E.03988
G3 X32.189 Y93.798 I-1.092 J1.313 E.05514
G1 X32.124 Y94.026 E.00728
; WIPE_START
M204 S10000
G1 X32.112 Y94.087 E-.0236
G1 X31.982 Y94.355 E-.11349
G1 X31.811 Y94.6 E-.11333
M73 P42 R29
G1 X31.6 Y94.811 E-.11335
G1 X31.355 Y94.982 E-.11329
G1 X31.085 Y95.108 E-.11334
G1 X30.797 Y95.185 E-.11332
G1 X30.649 Y95.198 E-.0563
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z2.2 F30000
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.191 J1.73 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08588
G1 X28.888 Y92.147 E-.13945
G1 X28.773 Y92.312 E-.07624
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14116
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z2.2 F30000
G1 X227.79 Y91.21 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z2.2 F30000
G1 Z1.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00873
; LINE_WIDTH: 0.327704
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281529
G2 X225.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.244296
G2 X225.14 Y91.516 I-.336 J5.783 E.0115
; LINE_WIDTH: 0.283928
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327696
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354361
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y92.469 Z2.2 F30000
G1 Z1.8
G1 E.8 F1800
; LINE_WIDTH: 0.354364
G1 F15000
G1 X227.441 Y92.808 E.00873
; LINE_WIDTH: 0.327676
G1 X227.463 Y92.974 E.00389
; LINE_WIDTH: 0.283908
G1 X227.484 Y93.14 E.00329
; LINE_WIDTH: 0.244295
G3 X227.486 Y93.841 I-5.79 J.364 E.0115
; LINE_WIDTH: 0.281511
G3 X227.463 Y94.026 I-2.162 J-.181 E.00363
; LINE_WIDTH: 0.327699
G1 X227.441 Y94.192 E.00389
; LINE_WIDTH: 0.354377
G1 X227.381 Y94.531 E.00873
; WIPE_START
G1 X227.441 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.173 Y95.85 Z2.2 F30000
G1 Z1.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X227.05 Y95.399 I-.729 J-2.493 E.0329
G1 X227.05 Y96.034 E.02105
G1 X163.034 Y160.05 E3.00311
G1 X162.05 Y160.05 E.03265
G1 X93.95 Y91.95 E3.19468
G1 X92.966 Y91.95 E.03265
G1 X67.927 Y116.989 E1.17464
G3 X69.189 Y118.015 I-7.415 J10.416 E.05398
; WIPE_START
G1 X67.927 Y116.989 E-.61792
G1 X68.191 Y116.725 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y124.345 Z2.2 F30000
G1 X69.189 Y133.985 Z2.2
G1 Z1.8
G1 E.8 F1800
G1 F15476.087
G3 X67.927 Y135.011 I-8.678 J-9.391 E.05398
G1 X92.966 Y160.05 E1.17464
G1 X93.95 Y160.05 E.03265
G1 X162.05 Y91.95 E3.19468
G1 X163.034 Y91.95 E.03265
G1 X227.05 Y155.966 E3.00311
G1 X227.05 Y157.442 E.04894
G1 X224.442 Y160.05 E.12235
G1 X223.457 Y160.05 E.03265
G1 X155.358 Y91.95 E3.19468
G1 X154.374 Y91.95 E.03265
G1 X110.95 Y135.374 E2.03708
G1 X110.95 Y131.978 E.11264
G1 X139.022 Y160.05 E1.31689
G1 X140.006 Y160.05 E.03265
G1 X208.105 Y91.95 E3.19468
G1 X209.09 Y91.95 E.03265
G1 X227.05 Y109.91 E.84254
G1 X227.05 Y111.386 E.04894
G1 X178.386 Y160.05 E2.28292
G1 X177.402 Y160.05 E.03265
G1 X109.302 Y91.95 E3.19468
G1 X108.318 Y91.95 E.03265
G1 X72.511 Y127.757 E1.67977
G3 X71.493 Y130.9 I-9.768 J-1.429 E.11012
G1 X100.642 Y160.05 E1.36746
G1 X101.626 Y160.05 E.03265
G1 X169.726 Y91.95 E3.19468
G1 X170.71 Y91.95 E.03265
G1 X227.05 Y148.29 E2.64302
G1 X227.05 Y149.766 E.04894
G1 X216.766 Y160.05 E.48245
G1 X215.781 Y160.05 E.03265
G1 X147.682 Y91.95 E3.19468
G1 X146.698 Y91.95 E.03265
G1 X110.95 Y127.698 E1.67699
G1 X110.95 Y124.302 E.11264
G1 X146.698 Y160.05 E1.67699
G1 X147.682 Y160.05 E.03265
G1 X215.781 Y91.95 E3.19468
G1 X216.766 Y91.95 E.03265
G1 X227.05 Y102.234 E.48245
G1 X227.05 Y103.71 E.04894
G1 X170.71 Y160.05 E2.64302
G1 X169.726 Y160.05 E.03265
G1 X101.626 Y91.95 E3.19468
G1 X100.642 Y91.95 E.03265
G1 X71.493 Y121.1 E1.36746
G3 X72.511 Y124.243 I-8.749 J4.572 E.11012
G1 X108.318 Y160.05 E1.67977
G1 X109.302 Y160.05 E.03265
G1 X177.402 Y91.95 E3.19468
G1 X178.386 Y91.95 E.03265
G1 X227.05 Y140.614 E2.28292
G1 X227.05 Y142.09 E.04894
G1 X209.09 Y160.05 E.84254
G1 X208.105 Y160.05 E.03265
G1 X140.006 Y91.95 E3.19468
G1 X139.022 Y91.95 E.03265
G1 X110.95 Y120.022 E1.31689
G1 X110.95 Y116.626 E.11264
G1 X154.374 Y160.05 E2.03708
G1 X155.358 Y160.05 E.03265
G1 X223.457 Y91.95 E3.19468
G1 X221.829 Y91.95 E.05401
G1 X110.95 Y141.282 F30000
G1 F15476.087
G1 X110.95 Y139.654 E.05401
G1 X131.346 Y160.05 E.9568
G1 X132.33 Y160.05 E.03265
G1 X200.429 Y91.95 E3.19468
G1 X201.414 Y91.95 E.03265
G1 X227.05 Y117.586 E1.20264
G1 X227.05 Y119.062 E.04894
G1 X186.062 Y160.05 E1.92283
G1 X185.078 Y160.05 E.03265
G1 X116.978 Y91.95 E3.19468
G1 X115.994 Y91.95 E.03265
G1 X47.895 Y160.05 E3.19468
G1 X46.91 Y160.05 E.03265
G1 X28.95 Y142.09 E.84254
G1 X28.95 Y140.614 E.04895
G1 X77.614 Y91.95 E2.28292
G1 X78.598 Y91.95 E.03265
G1 X99.05 Y112.402 E.95941
G1 X99.05 Y116.571 E.13829
G1 X55.571 Y160.05 E2.0397
G1 X54.586 Y160.05 E.03265
G1 X28.95 Y134.414 E1.20264
G1 X28.95 Y132.938 E.04895
G1 X69.938 Y91.95 E1.92283
G1 X70.922 Y91.95 E.03265
G1 X99.05 Y120.078 E1.31951
G1 X99.05 Y124.246 E.13829
G1 X63.246 Y160.05 E1.6796
G1 X62.262 Y160.05 E.03265
G1 X28.95 Y126.738 E1.56273
G1 X28.95 Y125.262 E.04895
G1 X62.262 Y91.95 E1.56273
G1 X63.246 Y91.95 E.03265
G1 X99.05 Y127.753 E1.6796
G1 X99.05 Y131.922 E.13829
G1 X70.922 Y160.05 E1.31951
G1 X69.938 Y160.05 E.03265
G1 X28.95 Y119.062 E1.92283
G1 X28.95 Y117.586 E.04894
G1 X54.586 Y91.95 E1.20264
G1 X55.571 Y91.95 E.03265
G1 X99.05 Y135.429 E2.0397
G1 X99.05 Y139.598 E.13829
G1 X78.598 Y160.05 E.95941
G1 X77.614 Y160.05 E.03265
G1 X28.95 Y111.386 E2.28292
G1 X28.95 Y109.91 E.04895
G1 X46.91 Y91.95 E.84254
G1 X47.895 Y91.95 E.03265
G1 X115.994 Y160.05 E3.19468
G1 X116.978 Y160.05 E.03265
G1 X185.078 Y91.95 E3.19468
G1 X186.062 Y91.95 E.03265
G1 X227.05 Y132.938 E1.92283
G1 X227.05 Y134.414 E.04894
G1 X201.414 Y160.05 E1.20264
G1 X200.429 Y160.05 E.03265
G1 X132.33 Y91.95 E3.19468
G1 X131.346 Y91.95 E.03265
G1 X110.95 Y112.346 E.9568
G1 X110.95 Y110.718 E.05401
; WIPE_START
G1 X110.95 Y112.346 E-.61876
G1 X111.213 Y112.083 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X104.278 Y115.271 Z2.2 F30000
G1 X58.312 Y136.402 Z2.2
G1 Z1.8
G1 E.8 F1800
G1 F15476.087
G3 X56.807 Y135.785 I2.624 J-8.548 E.05403
G1 X32.543 Y160.05 E1.13828
G1 X31.558 Y160.05 E.03265
G1 X28.95 Y157.442 E.12235
G1 X28.95 Y155.966 E.04895
G1 X52.705 Y132.212 E1.11436
G3 X51.874 Y130.813 I13.206 J-8.787 E.05398
G1 X28.95 Y151.394 F30000
G1 F15476.087
G1 X28.95 Y149.766 E.05401
G1 X39.234 Y160.05 E.48245
G1 X40.219 Y160.05 E.03265
G1 X63.458 Y136.811 E1.09019
G3 X62.173 Y136.932 I-2.388 J-18.391 E.04282
G1 X85.29 Y160.05 E1.08448
G1 X86.274 Y160.05 E.03265
G1 X104.374 Y141.95 E.84908
G1 X105.571 Y141.95 E.0397
G1 X123.67 Y160.05 E.84908
G1 X124.654 Y160.05 E.03265
G1 X192.754 Y91.95 E3.19468
G1 X193.738 Y91.95 E.03265
G1 X227.05 Y125.262 E1.56273
G1 X227.05 Y126.738 E.04895
G1 X193.738 Y160.05 E1.56273
G1 X192.753 Y160.05 E.03265
G1 X124.654 Y91.95 E3.19468
G1 X123.67 Y91.95 E.03265
G1 X105.571 Y110.05 E.84908
G1 X104.374 Y110.05 E.0397
G1 X86.274 Y91.95 E.84908
G1 X85.29 Y91.95 E.03265
G1 X62.173 Y115.068 E1.08448
G3 X63.458 Y115.189 I-1.103 J18.513 E.04282
G1 X40.219 Y91.95 E1.09019
G1 X39.234 Y91.95 E.03265
G1 X28.95 Y102.234 E.48245
G1 X28.95 Y103.71 E.04894
G1 X50.781 Y125.54 E1.0241
G2 X50.781 Y126.46 I5.034 J.46 E.03055
G1 X28.95 Y148.29 E1.0241
G1 X28.95 Y146.662 E.05401
; WIPE_START
G1 X28.95 Y148.29 E-.61876
G1 X29.213 Y148.027 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X29.128 Y140.395 Z2.2 F30000
G1 X28.619 Y94.531 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354364
G1 F15000
G1 X28.559 Y94.192 E.00874
; LINE_WIDTH: 0.327696
G1 X28.537 Y94.026 E.00389
; LINE_WIDTH: 0.283928
G1 X28.516 Y93.86 E.00329
; LINE_WIDTH: 0.244295
G3 X28.514 Y93.159 I5.786 J-.364 E.0115
; LINE_WIDTH: 0.281527
G3 X28.537 Y92.974 I2.135 J.177 E.00363
; LINE_WIDTH: 0.327704
G1 X28.559 Y92.808 E.00389
; LINE_WIDTH: 0.354377
G1 X28.619 Y92.469 E.00873
G1 X29.469 Y91.619 F30000
; LINE_WIDTH: 0.354361
G1 F15000
G1 X29.808 Y91.559 E.00874
; LINE_WIDTH: 0.327696
G1 X29.974 Y91.537 E.00389
; LINE_WIDTH: 0.283928
G1 X30.14 Y91.516 E.00329
; LINE_WIDTH: 0.244296
G3 X30.841 Y91.514 I.364 J5.782 E.0115
; LINE_WIDTH: 0.281529
G3 X31.026 Y91.537 I-.178 J2.137 E.00363
; LINE_WIDTH: 0.327704
G1 X31.192 Y91.559 E.00389
; LINE_WIDTH: 0.354373
G1 X31.531 Y91.619 E.00873
; WIPE_START
G1 X31.192 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X34.171 Y91.95 Z2.2 F30000
G1 Z1.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X32.543 Y91.95 E.05401
G1 X56.807 Y116.215 E1.13828
G2 X52.705 Y119.788 I4.981 J9.859 E.18235
G1 X28.95 Y96.034 E1.11436
G1 X28.95 Y95.399 E.02105
G2 X29.827 Y95.85 I1.606 J-2.042 E.0329
; CHANGE_LAYER
; Z_HEIGHT: 2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X29.273 Y95.625 E-.22718
G1 X28.95 Y95.399 E-.1497
G1 X28.95 Y96.034 E-.24118
G1 X29.214 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 10/25
; update layer progress
M73 L10
M991 S0 P9 ;notify layer change
G17
G3 Z2.2 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z2.4 F30000
G1 X51.287 Y124.063 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.505 Y123.14 E.03144
G3 X60.507 Y115.466 I10.206 J2.854 E.41629
G1 X61.47 Y115.4 E.03202
G3 X51.28 Y124.122 I.241 J10.594 E1.72697
M204 S250
G1 X51.674 Y124.152 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.037 J1.843 E.3999
G1 X61.479 Y115.792 E.02856
G3 X51.663 Y124.211 I.232 J10.202 E1.5399
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37592
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03092
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.053 Z2.4 F30000
G1 X223.514 Y94.188 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.53 Y94.217 E.00111
G2 X227.227 Y94.688 I1.97 J-.717 E.15229
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.732 J-1.184 E.24448
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.435 Y93.864 I1.188 J1.727 E.07947
G1 X223.5 Y94.129 E.00906
M204 S250
G1 X223.902 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.383 Y91.799 I1.606 J-.579 E.09672
G3 X226.6 Y92.189 I.112 J1.744 E.0402
G3 X223.923 Y94.138 I-1.092 J1.313 E.19081
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13581
G1 X223.789 Y93.5 E-.11331
G1 X223.815 Y93.203 E-.11331
G1 X223.892 Y92.915 E-.11332
M73 P43 R29
G1 X224.018 Y92.645 E-.11331
G1 X224.189 Y92.4 E-.11333
G1 X224.297 Y92.293 E-.0576
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z2.4 F30000
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03913
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z2.4 F30000
G1 X32.108 Y94.084 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X32.112 Y94.087 E.00016
G3 X30.383 Y91.799 I-1.604 J-.585 E.22503
G3 X31.6 Y92.189 I.112 J1.744 E.0402
G3 X32.19 Y93.798 I-1.092 J1.313 E.05515
G1 X32.124 Y94.026 E.00729
; WIPE_START
M204 S10000
G1 X32.112 Y94.087 E-.02354
G1 X31.982 Y94.355 E-.11349
G1 X31.811 Y94.6 E-.11333
G1 X31.6 Y94.811 E-.11333
G1 X31.355 Y94.982 E-.11332
G1 X31.085 Y95.108 E-.11332
G1 X30.797 Y95.185 E-.11332
G1 X30.649 Y95.198 E-.05635
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z2.4 F30000
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.73 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08593
G1 X28.888 Y92.147 E-.13936
G1 X28.773 Y92.312 E-.07628
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14117
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z2.4 F30000
G1 X227.79 Y91.21 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z2.4 F30000
G1 Z2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00873
; LINE_WIDTH: 0.327704
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281529
G2 X225.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.244286
G2 X225.14 Y91.516 I-.337 J5.786 E.0115
; LINE_WIDTH: 0.283917
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327693
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X221.829 Y91.95 Z2.4 F30000
G1 Z2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.457 Y91.95 E.05401
G1 X155.358 Y160.05 E3.19468
G1 X154.374 Y160.05 E.03265
G1 X110.95 Y116.626 E2.03708
G1 X110.95 Y120.022 E.11264
G1 X139.022 Y91.95 E1.31689
G1 X140.006 Y91.95 E.03265
G1 X208.105 Y160.05 E3.19468
G1 X209.09 Y160.05 E.03265
G1 X227.05 Y142.09 E.84254
G1 X227.05 Y140.614 E.04894
G1 X178.386 Y91.95 E2.28292
G1 X177.402 Y91.95 E.03265
G1 X109.302 Y160.05 E3.19468
G1 X108.318 Y160.05 E.03265
G1 X72.511 Y124.243 E1.67977
G2 X71.493 Y121.1 I-9.768 J1.429 E.11012
G1 X100.642 Y91.95 E1.36746
G1 X101.626 Y91.95 E.03265
G1 X169.726 Y160.05 E3.19468
G1 X170.71 Y160.05 E.03265
G1 X227.05 Y103.71 E2.64302
G1 X227.05 Y102.234 E.04894
G1 X216.766 Y91.95 E.48245
G1 X215.781 Y91.95 E.03265
G1 X147.682 Y160.05 E3.19468
G1 X146.698 Y160.05 E.03265
G1 X110.95 Y124.302 E1.67699
G1 X110.95 Y127.698 E.11264
G1 X146.698 Y91.95 E1.67699
G1 X147.682 Y91.95 E.03265
G1 X215.781 Y160.05 E3.19468
G1 X216.766 Y160.05 E.03265
G1 X227.05 Y149.766 E.48245
G1 X227.05 Y148.29 E.04894
G1 X170.71 Y91.95 E2.64302
G1 X169.726 Y91.95 E.03265
G1 X101.626 Y160.05 E3.19468
G1 X100.642 Y160.05 E.03265
G1 X71.493 Y130.9 E1.36746
G2 X72.511 Y127.757 I-8.749 J-4.572 E.11012
G1 X108.318 Y91.95 E1.67977
G1 X109.302 Y91.95 E.03265
G1 X177.402 Y160.05 E3.19468
G1 X178.386 Y160.05 E.03265
G1 X227.05 Y111.386 E2.28292
G1 X227.05 Y109.91 E.04894
G1 X209.09 Y91.95 E.84254
G1 X208.105 Y91.95 E.03265
G1 X140.006 Y160.05 E3.19468
G1 X139.022 Y160.05 E.03265
G1 X110.95 Y131.978 E1.31689
M73 P43 R28
G1 X110.95 Y135.374 E.11264
G1 X154.374 Y91.95 E2.03708
G1 X155.358 Y91.95 E.03265
G1 X223.457 Y160.05 E3.19468
G1 X224.442 Y160.05 E.03265
G1 X227.05 Y157.442 E.12235
G1 X227.05 Y155.966 E.04894
G1 X163.034 Y91.95 E3.00311
G1 X162.05 Y91.95 E.03265
G1 X93.95 Y160.05 E3.19468
G1 X92.966 Y160.05 E.03265
G1 X67.927 Y135.011 E1.17464
G2 X69.189 Y133.985 I-7.415 J-10.416 E.05398
; WIPE_START
G1 X67.927 Y135.011 E-.61792
G1 X68.191 Y135.275 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y127.655 Z2.4 F30000
G1 X69.189 Y118.015 Z2.4
G1 Z2
G1 E.8 F1800
G1 F15476.087
G2 X67.927 Y116.989 I-8.677 J9.391 E.05398
G1 X92.966 Y91.95 E1.17464
G1 X93.95 Y91.95 E.03265
G1 X162.05 Y160.05 E3.19468
G1 X163.034 Y160.05 E.03265
G1 X227.05 Y96.034 E3.00311
G1 X227.05 Y95.399 E.02105
G3 X226.173 Y95.85 I-1.606 J-2.042 E.0329
; WIPE_START
G1 X226.727 Y95.625 E-.22718
G1 X227.05 Y95.399 E-.1497
G1 X227.05 Y96.034 E-.24118
G1 X226.786 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y94.531 Z2.4 F30000
G1 Z2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X227.441 Y94.192 E.00873
; LINE_WIDTH: 0.327699
G1 X227.463 Y94.026 E.00389
; LINE_WIDTH: 0.281511
G2 X227.486 Y93.841 I-2.138 J-.366 E.00363
; LINE_WIDTH: 0.244295
G2 X227.484 Y93.14 I-5.791 J-.336 E.0115
; LINE_WIDTH: 0.283908
G1 X227.463 Y92.974 E.00329
; LINE_WIDTH: 0.327676
G1 X227.441 Y92.808 E.00389
; LINE_WIDTH: 0.354361
G1 X227.381 Y92.469 E.00873
; WIPE_START
G1 X227.441 Y92.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X219.897 Y93.968 Z2.4 F30000
G1 X110.95 Y110.718 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.95 Y112.346 E.05401
G1 X131.346 Y91.95 E.9568
G1 X132.33 Y91.95 E.03265
G1 X200.429 Y160.05 E3.19468
G1 X201.414 Y160.05 E.03265
G1 X227.05 Y134.414 E1.20264
G1 X227.05 Y132.938 E.04894
G1 X186.062 Y91.95 E1.92283
G1 X185.078 Y91.95 E.03265
G1 X116.978 Y160.05 E3.19468
G1 X115.994 Y160.05 E.03265
G1 X47.895 Y91.95 E3.19468
G1 X46.91 Y91.95 E.03265
G1 X28.95 Y109.91 E.84254
G1 X28.95 Y111.386 E.04895
G1 X77.614 Y160.05 E2.28292
G1 X78.598 Y160.05 E.03265
G1 X99.05 Y139.598 E.95941
G1 X99.05 Y135.429 E.13829
G1 X55.571 Y91.95 E2.0397
G1 X54.586 Y91.95 E.03265
G1 X28.95 Y117.586 E1.20264
G1 X28.95 Y119.062 E.04894
G1 X69.938 Y160.05 E1.92283
G1 X70.922 Y160.05 E.03265
G1 X99.05 Y131.922 E1.31951
G1 X99.05 Y127.753 E.13829
G1 X63.246 Y91.95 E1.6796
G1 X62.262 Y91.95 E.03265
G1 X28.95 Y125.262 E1.56273
G1 X28.95 Y126.738 E.04895
G1 X62.262 Y160.05 E1.56273
G1 X63.246 Y160.05 E.03265
G1 X99.05 Y124.246 E1.6796
G1 X99.05 Y120.078 E.13829
G1 X70.922 Y91.95 E1.31951
G1 X69.938 Y91.95 E.03265
G1 X28.95 Y132.938 E1.92283
G1 X28.95 Y134.414 E.04895
G1 X54.586 Y160.05 E1.20264
G1 X55.571 Y160.05 E.03265
G1 X99.05 Y116.571 E2.0397
G1 X99.05 Y112.402 E.13829
G1 X78.598 Y91.95 E.95941
G1 X77.614 Y91.95 E.03265
G1 X28.95 Y140.614 E2.28292
G1 X28.95 Y142.09 E.04895
G1 X46.91 Y160.05 E.84254
G1 X47.895 Y160.05 E.03265
G1 X115.994 Y91.95 E3.19468
G1 X116.978 Y91.95 E.03265
G1 X185.078 Y160.05 E3.19468
G1 X186.062 Y160.05 E.03265
G1 X227.05 Y119.062 E1.92283
G1 X227.05 Y117.586 E.04894
G1 X201.414 Y91.95 E1.20264
G1 X200.429 Y91.95 E.03265
G1 X132.33 Y160.05 E3.19468
G1 X131.346 Y160.05 E.03265
G1 X110.95 Y139.654 E.9568
G1 X110.95 Y141.282 E.05401
; WIPE_START
G1 X110.95 Y139.654 E-.61876
G1 X111.213 Y139.917 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X103.669 Y138.76 Z2.4 F30000
G1 X51.874 Y130.813 Z2.4
G1 Z2
G1 E.8 F1800
G1 F15476.087
G2 X52.705 Y132.212 I14.036 J-7.388 E.05398
G1 X28.95 Y155.966 E1.11436
G1 X28.95 Y157.442 E.04895
G1 X31.558 Y160.05 E.12235
G1 X32.543 Y160.05 E.03265
G1 X56.807 Y135.785 E1.13828
G2 X58.312 Y136.402 I4.129 J-7.931 E.05403
G1 X28.95 Y146.662 F30000
G1 F15476.087
G1 X28.95 Y148.29 E.05401
G1 X50.781 Y126.46 E1.0241
G3 X50.781 Y125.54 I5.034 J-.46 E.03055
G1 X28.95 Y103.71 E1.0241
G1 X28.95 Y102.234 E.04894
G1 X39.234 Y91.95 E.48245
G1 X40.219 Y91.95 E.03265
G1 X63.458 Y115.189 E1.09019
G2 X62.173 Y115.068 I-2.388 J18.392 E.04282
G1 X85.29 Y91.95 E1.08448
G1 X86.274 Y91.95 E.03265
G1 X104.374 Y110.05 E.84908
G1 X105.571 Y110.05 E.0397
G1 X123.67 Y91.95 E.84908
G1 X124.654 Y91.95 E.03265
G1 X192.753 Y160.05 E3.19468
G1 X193.738 Y160.05 E.03265
G1 X227.05 Y126.738 E1.56273
G1 X227.05 Y125.262 E.04895
G1 X193.738 Y91.95 E1.56273
G1 X192.754 Y91.95 E.03265
G1 X124.654 Y160.05 E3.19468
G1 X123.67 Y160.05 E.03265
G1 X105.571 Y141.95 E.84908
G1 X104.374 Y141.95 E.0397
G1 X86.274 Y160.05 E.84908
G1 X85.29 Y160.05 E.03265
G1 X62.173 Y136.932 E1.08448
G2 X63.458 Y136.811 I-1.104 J-18.523 E.04282
G1 X40.219 Y160.05 E1.09019
G1 X39.234 Y160.05 E.03265
G1 X28.95 Y149.766 E.48245
G1 X28.95 Y151.394 E.05401
G1 X29.827 Y95.85 F30000
G1 F15476.087
G3 X28.95 Y95.399 I.729 J-2.492 E.0329
G1 X28.95 Y96.034 E.02105
G1 X52.705 Y119.788 E1.11436
G3 X56.807 Y116.215 I9.083 J6.285 E.18235
G1 X32.543 Y91.95 E1.13828
G1 X34.171 Y91.95 E.05401
; WIPE_START
G1 X32.543 Y91.95 E-.61876
G1 X32.805 Y92.213 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X31.531 Y91.619 Z2.4 F30000
G1 Z2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X31.192 Y91.559 E.00874
; LINE_WIDTH: 0.327704
G1 X31.026 Y91.537 E.00389
; LINE_WIDTH: 0.281529
G2 X30.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.244286
G2 X30.14 Y91.516 I-.337 J5.787 E.0115
; LINE_WIDTH: 0.283917
G1 X29.974 Y91.537 E.00329
; LINE_WIDTH: 0.327693
G1 X29.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X29.469 Y91.619 E.00873
G1 X28.619 Y92.469 F30000
; LINE_WIDTH: 0.354377
G1 F15000
G1 X28.559 Y92.808 E.00873
; LINE_WIDTH: 0.327704
G1 X28.537 Y92.974 E.00389
; LINE_WIDTH: 0.281527
G2 X28.514 Y93.159 I2.112 J.363 E.00363
; LINE_WIDTH: 0.244295
G2 X28.516 Y93.86 I5.788 J.336 E.0115
; LINE_WIDTH: 0.283928
G1 X28.537 Y94.026 E.00329
; LINE_WIDTH: 0.327696
G1 X28.559 Y94.192 E.00389
; LINE_WIDTH: 0.354364
G1 X28.619 Y94.531 E.00874
; CHANGE_LAYER
; Z_HEIGHT: 2.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X28.559 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 11/25
; update layer progress
M73 L11
M991 S0 P10 ;notify layer change
G17
G3 Z2.4 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
M73 P44 R28
G1 X110.602 Y141.21
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z2.6 F30000
G1 X51.287 Y124.063 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.505 Y123.14 E.03144
G3 X60.507 Y115.466 I10.206 J2.854 E.41629
G1 X61.47 Y115.4 E.03202
G3 X51.28 Y124.122 I.241 J10.594 E1.72697
M204 S250
G1 X51.674 Y124.152 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.037 J1.843 E.3999
G1 X61.479 Y115.792 E.02856
G3 X51.663 Y124.211 I.232 J10.202 E1.5399
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37592
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03092
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.053 Z2.6 F30000
G1 X223.514 Y94.187 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.523 Y94.219 E.00111
G2 X227.227 Y94.688 I1.972 J-.715 E.1527
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.727 J-1.188 E.24389
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.429 Y93.865 I1.183 J1.732 E.0796
G1 X223.499 Y94.129 E.00907
M204 S250
G1 X223.902 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.372 Y91.8 I1.606 J-.579 E.09638
G3 X226.6 Y92.189 I.123 J1.741 E.04052
G3 X223.924 Y94.138 I-1.091 J1.313 E.19081
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13581
G1 X223.789 Y93.5 E-.11332
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11331
G1 X224.189 Y92.4 E-.11333
G1 X224.297 Y92.293 E-.0576
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z2.6 F30000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03912
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z2.6 F30000
G1 X32.108 Y94.084 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X32.112 Y94.087 E.00016
G3 X30.372 Y91.8 I-1.604 J-.585 E.22469
G3 X31.6 Y92.189 I.123 J1.741 E.04052
G3 X32.19 Y93.798 I-1.091 J1.313 E.05515
G1 X32.124 Y94.026 E.0073
; WIPE_START
M204 S10000
G1 X32.112 Y94.087 E-.02348
G1 X31.982 Y94.355 E-.11349
G1 X31.811 Y94.6 E-.11333
G1 X31.6 Y94.811 E-.11333
G1 X31.355 Y94.982 E-.11332
G1 X31.085 Y95.108 E-.11332
G1 X30.797 Y95.185 E-.11332
G1 X30.649 Y95.198 E-.05642
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z2.6 F30000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.731 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08592
G1 X28.888 Y92.147 E-.13942
G1 X28.773 Y92.312 E-.07624
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14116
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z2.6 F30000
G1 X227.79 Y91.21 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z2.6 F30000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327687
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281538
G2 X225.841 Y91.514 I-.363 J2.118 E.00363
; LINE_WIDTH: 0.24429
G2 X225.14 Y91.516 I-.337 J5.785 E.0115
; LINE_WIDTH: 0.283917
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327693
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y92.469 Z2.6 F30000
G1 Z2.2
G1 E.8 F1800
; LINE_WIDTH: 0.354361
G1 F15000
G1 X227.441 Y92.808 E.00873
; LINE_WIDTH: 0.327676
G1 X227.463 Y92.974 E.00389
; LINE_WIDTH: 0.283908
G1 X227.484 Y93.14 E.00329
; LINE_WIDTH: 0.244295
G3 X227.486 Y93.841 I-5.786 J.364 E.0115
; LINE_WIDTH: 0.281528
G3 X227.463 Y94.026 I-2.136 J-.177 E.00363
; LINE_WIDTH: 0.327704
G1 X227.441 Y94.192 E.00389
; LINE_WIDTH: 0.354377
G1 X227.381 Y94.531 E.00873
; WIPE_START
G1 X227.441 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.173 Y95.85 Z2.6 F30000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X227.05 Y95.399 I-.729 J-2.493 E.0329
G1 X227.05 Y96.034 E.02105
G1 X163.034 Y160.05 E3.00311
G1 X162.05 Y160.05 E.03265
G1 X93.95 Y91.95 E3.19468
G1 X92.966 Y91.95 E.03265
G1 X67.927 Y116.989 E1.17464
G3 X69.189 Y118.015 I-7.415 J10.416 E.05398
; WIPE_START
G1 X67.927 Y116.989 E-.61792
G1 X68.191 Y116.725 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y124.345 Z2.6 F30000
G1 X69.189 Y133.985 Z2.6
G1 Z2.2
G1 E.8 F1800
G1 F15476.087
G3 X67.927 Y135.011 I-8.678 J-9.391 E.05398
G1 X92.966 Y160.05 E1.17464
G1 X93.95 Y160.05 E.03265
G1 X162.05 Y91.95 E3.19468
G1 X163.034 Y91.95 E.03265
G1 X227.05 Y155.966 E3.00311
G1 X227.05 Y157.442 E.04894
G1 X224.442 Y160.05 E.12235
G1 X223.457 Y160.05 E.03265
G1 X155.358 Y91.95 E3.19468
G1 X154.374 Y91.95 E.03265
G1 X110.95 Y135.374 E2.03708
G1 X110.95 Y131.978 E.11264
G1 X139.022 Y160.05 E1.31689
G1 X140.006 Y160.05 E.03265
G1 X208.105 Y91.95 E3.19468
G1 X209.09 Y91.95 E.03265
G1 X227.05 Y109.91 E.84254
G1 X227.05 Y111.386 E.04894
G1 X178.386 Y160.05 E2.28292
G1 X177.402 Y160.05 E.03265
G1 X109.302 Y91.95 E3.19468
G1 X108.318 Y91.95 E.03265
G1 X72.511 Y127.757 E1.67977
G3 X71.493 Y130.9 I-9.768 J-1.429 E.11012
G1 X100.642 Y160.05 E1.36746
G1 X101.626 Y160.05 E.03265
G1 X169.726 Y91.95 E3.19468
G1 X170.71 Y91.95 E.03265
G1 X227.05 Y148.29 E2.64302
G1 X227.05 Y149.766 E.04894
G1 X216.766 Y160.05 E.48245
G1 X215.781 Y160.05 E.03265
G1 X147.682 Y91.95 E3.19468
G1 X146.698 Y91.95 E.03265
G1 X110.95 Y127.698 E1.67699
G1 X110.95 Y124.302 E.11264
G1 X146.698 Y160.05 E1.67699
G1 X147.682 Y160.05 E.03265
G1 X215.781 Y91.95 E3.19468
G1 X216.766 Y91.95 E.03265
G1 X227.05 Y102.234 E.48245
G1 X227.05 Y103.71 E.04894
G1 X170.71 Y160.05 E2.64302
G1 X169.726 Y160.05 E.03265
G1 X101.626 Y91.95 E3.19468
G1 X100.642 Y91.95 E.03265
G1 X71.493 Y121.1 E1.36746
G3 X72.511 Y124.243 I-8.749 J4.572 E.11012
G1 X108.318 Y160.05 E1.67977
G1 X109.302 Y160.05 E.03265
G1 X177.402 Y91.95 E3.19468
G1 X178.386 Y91.95 E.03265
G1 X227.05 Y140.614 E2.28292
G1 X227.05 Y142.09 E.04894
G1 X209.09 Y160.05 E.84254
G1 X208.105 Y160.05 E.03265
G1 X140.006 Y91.95 E3.19468
G1 X139.022 Y91.95 E.03265
G1 X110.95 Y120.022 E1.31689
G1 X110.95 Y116.626 E.11264
G1 X154.374 Y160.05 E2.03708
G1 X155.358 Y160.05 E.03265
G1 X223.457 Y91.95 E3.19468
G1 X221.829 Y91.95 E.05401
G1 X110.95 Y141.282 F30000
G1 F15476.087
G1 X110.95 Y139.654 E.05401
G1 X131.346 Y160.05 E.9568
G1 X132.33 Y160.05 E.03265
G1 X200.429 Y91.95 E3.19468
G1 X201.414 Y91.95 E.03265
G1 X227.05 Y117.586 E1.20264
G1 X227.05 Y119.062 E.04894
G1 X186.062 Y160.05 E1.92283
G1 X185.078 Y160.05 E.03265
G1 X116.978 Y91.95 E3.19468
G1 X115.994 Y91.95 E.03265
G1 X47.895 Y160.05 E3.19468
G1 X46.91 Y160.05 E.03265
G1 X28.95 Y142.09 E.84254
G1 X28.95 Y140.614 E.04895
G1 X77.614 Y91.95 E2.28292
G1 X78.598 Y91.95 E.03265
G1 X99.05 Y112.402 E.95941
G1 X99.05 Y116.571 E.13829
G1 X55.571 Y160.05 E2.0397
G1 X54.586 Y160.05 E.03265
G1 X28.95 Y134.414 E1.20264
G1 X28.95 Y132.938 E.04895
G1 X69.938 Y91.95 E1.92283
G1 X70.922 Y91.95 E.03265
G1 X99.05 Y120.078 E1.31951
G1 X99.05 Y124.246 E.13829
G1 X63.246 Y160.05 E1.6796
G1 X62.262 Y160.05 E.03265
G1 X28.95 Y126.738 E1.56273
G1 X28.95 Y125.262 E.04895
G1 X62.262 Y91.95 E1.56273
G1 X63.246 Y91.95 E.03265
G1 X99.05 Y127.753 E1.6796
G1 X99.05 Y131.922 E.13829
G1 X70.922 Y160.05 E1.31951
G1 X69.938 Y160.05 E.03265
G1 X28.95 Y119.062 E1.92283
G1 X28.95 Y117.586 E.04894
G1 X54.586 Y91.95 E1.20264
G1 X55.571 Y91.95 E.03265
G1 X99.05 Y135.429 E2.0397
G1 X99.05 Y139.598 E.13829
G1 X78.598 Y160.05 E.95941
G1 X77.614 Y160.05 E.03265
G1 X28.95 Y111.386 E2.28292
G1 X28.95 Y109.91 E.04895
G1 X46.91 Y91.95 E.84254
G1 X47.895 Y91.95 E.03265
G1 X115.994 Y160.05 E3.19468
G1 X116.978 Y160.05 E.03265
G1 X185.078 Y91.95 E3.19468
G1 X186.062 Y91.95 E.03265
G1 X227.05 Y132.938 E1.92283
G1 X227.05 Y134.414 E.04894
G1 X201.414 Y160.05 E1.20264
G1 X200.429 Y160.05 E.03265
G1 X132.33 Y91.95 E3.19468
G1 X131.346 Y91.95 E.03265
G1 X110.95 Y112.346 E.9568
G1 X110.95 Y110.718 E.05401
; WIPE_START
G1 X110.95 Y112.346 E-.61876
G1 X111.213 Y112.083 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X104.278 Y115.271 Z2.6 F30000
G1 X58.312 Y136.402 Z2.6
G1 Z2.2
G1 E.8 F1800
G1 F15476.087
G3 X56.807 Y135.785 I2.624 J-8.548 E.05403
G1 X32.543 Y160.05 E1.13828
G1 X31.558 Y160.05 E.03265
G1 X28.95 Y157.442 E.12235
G1 X28.95 Y155.966 E.04895
G1 X52.705 Y132.212 E1.11436
G3 X51.874 Y130.813 I13.206 J-8.787 E.05398
G1 X28.95 Y151.394 F30000
G1 F15476.087
G1 X28.95 Y149.766 E.05401
G1 X39.234 Y160.05 E.48245
G1 X40.219 Y160.05 E.03265
G1 X63.458 Y136.811 E1.09019
G3 X62.173 Y136.932 I-2.388 J-18.391 E.04282
G1 X85.29 Y160.05 E1.08448
G1 X86.274 Y160.05 E.03265
G1 X104.374 Y141.95 E.84908
G1 X105.571 Y141.95 E.0397
G1 X123.67 Y160.05 E.84908
G1 X124.654 Y160.05 E.03265
G1 X192.754 Y91.95 E3.19468
G1 X193.738 Y91.95 E.03265
G1 X227.05 Y125.262 E1.56273
G1 X227.05 Y126.738 E.04895
G1 X193.738 Y160.05 E1.56273
G1 X192.753 Y160.05 E.03265
G1 X124.654 Y91.95 E3.19468
G1 X123.67 Y91.95 E.03265
G1 X105.571 Y110.05 E.84908
G1 X104.374 Y110.05 E.0397
G1 X86.274 Y91.95 E.84908
G1 X85.29 Y91.95 E.03265
G1 X62.173 Y115.068 E1.08448
G3 X63.458 Y115.189 I-1.103 J18.513 E.04282
G1 X40.219 Y91.95 E1.09019
G1 X39.234 Y91.95 E.03265
G1 X28.95 Y102.234 E.48245
M73 P45 R28
G1 X28.95 Y103.71 E.04894
G1 X50.781 Y125.54 E1.0241
G2 X50.781 Y126.46 I5.034 J.46 E.03055
G1 X28.95 Y148.29 E1.0241
G1 X28.95 Y146.662 E.05401
; WIPE_START
G1 X28.95 Y148.29 E-.61876
G1 X29.213 Y148.027 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X29.128 Y140.395 Z2.6 F30000
G1 X28.619 Y94.531 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354386
G1 F15000
G1 X28.559 Y94.192 E.00874
; LINE_WIDTH: 0.327693
G1 X28.537 Y94.026 E.00389
; LINE_WIDTH: 0.283917
G1 X28.516 Y93.86 E.00329
; LINE_WIDTH: 0.2443
G3 X28.514 Y93.159 I5.787 J-.364 E.0115
; LINE_WIDTH: 0.281525
G3 X28.537 Y92.974 I2.139 J.178 E.00363
; LINE_WIDTH: 0.327686
G1 X28.559 Y92.808 E.00389
; LINE_WIDTH: 0.354377
G1 X28.619 Y92.469 E.00874
G1 X29.469 Y91.619 F30000
; LINE_WIDTH: 0.354386
G1 F15000
G1 X29.808 Y91.559 E.00873
; LINE_WIDTH: 0.327693
G1 X29.974 Y91.537 E.00389
; LINE_WIDTH: 0.283917
G1 X30.14 Y91.516 E.00329
; LINE_WIDTH: 0.24429
G3 X30.841 Y91.514 I.364 J5.784 E.0115
; LINE_WIDTH: 0.281539
G3 X31.026 Y91.537 I-.178 J2.142 E.00363
; LINE_WIDTH: 0.327691
G1 X31.192 Y91.559 E.00389
; LINE_WIDTH: 0.354377
G1 X31.531 Y91.619 E.00874
; WIPE_START
G1 X31.192 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X34.171 Y91.95 Z2.6 F30000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X32.543 Y91.95 E.05401
G1 X56.807 Y116.215 E1.13828
G2 X52.705 Y119.788 I4.981 J9.859 E.18235
G1 X28.95 Y96.034 E1.11436
G1 X28.95 Y95.399 E.02105
G2 X29.827 Y95.85 I1.605 J-2.041 E.0329
; CHANGE_LAYER
; Z_HEIGHT: 2.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X29.273 Y95.625 E-.22714
G1 X28.95 Y95.399 E-.14973
G1 X28.95 Y96.034 E-.24118
G1 X29.214 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 12/25
; update layer progress
M73 L12
M991 S0 P11 ;notify layer change
G17
G3 Z2.6 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z2.8 F30000
G1 X51.288 Y124.063 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.502 Y123.14 E.03144
G3 X60.507 Y115.466 I10.209 J2.86 E.41633
G1 X61.47 Y115.4 E.03202
G3 X51.277 Y124.122 I.241 J10.599 E1.7279
M204 S250
G1 X51.67 Y124.151 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.041 J1.848 E.39995
G1 X61.479 Y115.792 E.02856
G3 X51.66 Y124.21 I.232 J10.207 E1.54073
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37597
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03088
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.053 Z2.8 F30000
G1 X223.514 Y94.187 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.523 Y94.219 E.00111
G2 X227.227 Y94.688 I1.972 J-.715 E.1527
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.727 J-1.188 E.24389
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.429 Y93.865 I1.183 J1.732 E.0796
G1 X223.499 Y94.129 E.00906
M204 S250
G1 X223.901 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.362 Y91.801 I1.606 J-.58 E.09612
G3 X226.811 Y92.4 I.151 J1.686 E.05008
G3 X223.922 Y94.138 I-1.304 J1.102 E.1816
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13583
G1 X223.789 Y93.5 E-.11332
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11331
G1 X224.189 Y92.4 E-.11333
G1 X224.297 Y92.293 E-.05758
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z2.8 F30000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.731 J1.192 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06804
G1 X227.112 Y92.147 E-.07626
G1 X227.039 Y92.075 E-.03914
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z2.8 F30000
G1 X32.108 Y94.084 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
M73 P45 R27
G1 X32.11 Y94.086 E.0001
G3 X30.362 Y91.801 I-1.603 J-.584 E.22433
G3 X31.811 Y92.4 I.151 J1.686 E.05008
G3 X32.153 Y93.954 I-1.304 J1.101 E.05084
G1 X32.127 Y94.027 E.00239
; WIPE_START
M204 S10000
G1 X32.11 Y94.086 E-.02324
G1 X31.982 Y94.355 E-.11342
G1 X31.811 Y94.6 E-.11333
G1 X31.6 Y94.811 E-.11335
G1 X31.355 Y94.982 E-.11329
G1 X31.085 Y95.108 E-.11334
G1 X30.797 Y95.185 E-.11332
G1 X30.648 Y95.198 E-.05672
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z2.8 F30000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.731 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08589
G1 X28.888 Y92.147 E-.13944
G1 X28.773 Y92.312 E-.07625
G1 X28.602 Y92.258 E-.06804
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14117
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z2.8 F30000
G1 X227.79 Y91.21 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z2.8 F30000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327691
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281539
G2 X225.841 Y91.514 I-.363 J2.118 E.00363
; LINE_WIDTH: 0.24429
G2 X225.14 Y91.516 I-.337 J5.785 E.0115
; LINE_WIDTH: 0.283917
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327693
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X221.829 Y91.95 Z2.8 F30000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.457 Y91.95 E.05401
G1 X155.358 Y160.05 E3.19468
G1 X154.374 Y160.05 E.03265
G1 X110.95 Y116.626 E2.03708
G1 X110.95 Y120.022 E.11264
G1 X139.022 Y91.95 E1.31689
G1 X140.006 Y91.95 E.03265
G1 X208.105 Y160.05 E3.19468
G1 X209.09 Y160.05 E.03265
G1 X227.05 Y142.09 E.84254
G1 X227.05 Y140.614 E.04894
G1 X178.386 Y91.95 E2.28292
G1 X177.402 Y91.95 E.03265
G1 X109.302 Y160.05 E3.19468
G1 X108.318 Y160.05 E.03265
G1 X72.511 Y124.243 E1.67977
G2 X71.493 Y121.1 I-9.768 J1.429 E.11012
G1 X100.642 Y91.95 E1.36746
G1 X101.626 Y91.95 E.03265
G1 X169.726 Y160.05 E3.19468
G1 X170.71 Y160.05 E.03265
G1 X227.05 Y103.71 E2.64302
G1 X227.05 Y102.234 E.04894
G1 X216.766 Y91.95 E.48245
G1 X215.781 Y91.95 E.03265
G1 X147.682 Y160.05 E3.19468
G1 X146.698 Y160.05 E.03265
G1 X110.95 Y124.302 E1.67699
G1 X110.95 Y127.698 E.11264
G1 X146.698 Y91.95 E1.67699
G1 X147.682 Y91.95 E.03265
G1 X215.781 Y160.05 E3.19468
G1 X216.766 Y160.05 E.03265
G1 X227.05 Y149.766 E.48245
G1 X227.05 Y148.29 E.04894
G1 X170.71 Y91.95 E2.64302
G1 X169.726 Y91.95 E.03265
G1 X101.626 Y160.05 E3.19468
G1 X100.642 Y160.05 E.03265
G1 X71.493 Y130.9 E1.36746
G2 X72.511 Y127.757 I-8.749 J-4.572 E.11012
G1 X108.318 Y91.95 E1.67977
G1 X109.302 Y91.95 E.03265
G1 X177.402 Y160.05 E3.19468
G1 X178.386 Y160.05 E.03265
G1 X227.05 Y111.386 E2.28292
G1 X227.05 Y109.91 E.04894
G1 X209.09 Y91.95 E.84254
G1 X208.105 Y91.95 E.03265
G1 X140.006 Y160.05 E3.19468
G1 X139.022 Y160.05 E.03265
G1 X110.95 Y131.978 E1.31689
G1 X110.95 Y135.374 E.11264
G1 X154.374 Y91.95 E2.03708
G1 X155.358 Y91.95 E.03265
G1 X223.457 Y160.05 E3.19468
G1 X224.442 Y160.05 E.03265
G1 X227.05 Y157.442 E.12235
G1 X227.05 Y155.966 E.04894
G1 X163.034 Y91.95 E3.00311
G1 X162.05 Y91.95 E.03265
G1 X93.95 Y160.05 E3.19468
G1 X92.966 Y160.05 E.03265
G1 X67.927 Y135.011 E1.17464
G2 X69.189 Y133.985 I-7.416 J-10.417 E.05398
; WIPE_START
G1 X67.927 Y135.011 E-.61792
G1 X68.191 Y135.275 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y127.655 Z2.8 F30000
G1 X69.189 Y118.015 Z2.8
G1 Z2.4
G1 E.8 F1800
G1 F15476.087
G2 X67.927 Y116.989 I-8.677 J9.391 E.05398
G1 X92.966 Y91.95 E1.17464
G1 X93.95 Y91.95 E.03265
G1 X162.05 Y160.05 E3.19468
G1 X163.034 Y160.05 E.03265
G1 X227.05 Y96.034 E3.00311
G1 X227.05 Y95.399 E.02105
G3 X226.173 Y95.85 I-1.606 J-2.042 E.0329
; WIPE_START
G1 X226.727 Y95.625 E-.22718
G1 X227.05 Y95.399 E-.1497
G1 X227.05 Y96.034 E-.24118
G1 X226.786 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y94.531 Z2.8 F30000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X227.441 Y94.192 E.00873
; LINE_WIDTH: 0.327704
G1 X227.463 Y94.026 E.00389
; LINE_WIDTH: 0.281528
G2 X227.486 Y93.841 I-2.112 J-.363 E.00363
; LINE_WIDTH: 0.244295
G2 X227.484 Y93.14 I-5.788 J-.336 E.0115
; LINE_WIDTH: 0.283908
G1 X227.463 Y92.974 E.00329
; LINE_WIDTH: 0.327676
G1 X227.441 Y92.808 E.00389
; LINE_WIDTH: 0.354361
G1 X227.381 Y92.469 E.00874
; WIPE_START
G1 X227.441 Y92.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X219.897 Y93.968 Z2.8 F30000
G1 X110.95 Y110.718 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.95 Y112.346 E.05401
G1 X131.346 Y91.95 E.9568
G1 X132.33 Y91.95 E.03265
G1 X200.429 Y160.05 E3.19468
G1 X201.414 Y160.05 E.03265
G1 X227.05 Y134.414 E1.20264
G1 X227.05 Y132.938 E.04894
G1 X186.062 Y91.95 E1.92283
G1 X185.078 Y91.95 E.03265
G1 X116.978 Y160.05 E3.19468
G1 X115.994 Y160.05 E.03265
G1 X47.895 Y91.95 E3.19468
G1 X46.91 Y91.95 E.03265
G1 X28.95 Y109.91 E.84254
G1 X28.95 Y111.386 E.04894
G1 X77.614 Y160.05 E2.28292
G1 X78.598 Y160.05 E.03265
G1 X99.05 Y139.598 E.95941
G1 X99.05 Y135.429 E.13829
G1 X55.571 Y91.95 E2.0397
G1 X54.586 Y91.95 E.03265
G1 X28.95 Y117.586 E1.20264
G1 X28.95 Y119.062 E.04894
G1 X69.938 Y160.05 E1.92283
G1 X70.922 Y160.05 E.03265
G1 X99.05 Y131.922 E1.31951
G1 X99.05 Y127.753 E.13829
G1 X63.246 Y91.95 E1.6796
G1 X62.262 Y91.95 E.03265
G1 X28.95 Y125.262 E1.56273
G1 X28.95 Y126.738 E.04894
G1 X62.262 Y160.05 E1.56273
G1 X63.246 Y160.05 E.03265
G1 X99.05 Y124.246 E1.6796
G1 X99.05 Y120.078 E.13829
G1 X70.922 Y91.95 E1.31951
G1 X69.938 Y91.95 E.03265
G1 X28.95 Y132.938 E1.92283
G1 X28.95 Y134.414 E.04894
G1 X54.586 Y160.05 E1.20264
G1 X55.571 Y160.05 E.03265
G1 X99.05 Y116.571 E2.0397
G1 X99.05 Y112.402 E.13829
G1 X78.598 Y91.95 E.95941
G1 X77.614 Y91.95 E.03265
G1 X28.95 Y140.614 E2.28292
G1 X28.95 Y142.09 E.04894
G1 X46.91 Y160.05 E.84254
G1 X47.895 Y160.05 E.03265
G1 X115.994 Y91.95 E3.19468
G1 X116.978 Y91.95 E.03265
G1 X185.078 Y160.05 E3.19468
G1 X186.062 Y160.05 E.03265
G1 X227.05 Y119.062 E1.92283
G1 X227.05 Y117.586 E.04894
G1 X201.414 Y91.95 E1.20264
G1 X200.429 Y91.95 E.03265
G1 X132.33 Y160.05 E3.19468
G1 X131.346 Y160.05 E.03265
G1 X110.95 Y139.654 E.9568
G1 X110.95 Y141.282 E.05401
; WIPE_START
G1 X110.95 Y139.654 E-.61876
G1 X111.213 Y139.917 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X103.669 Y138.76 Z2.8 F30000
G1 X51.874 Y130.813 Z2.8
G1 Z2.4
G1 E.8 F1800
G1 F15476.087
G2 X52.705 Y132.212 I14.036 J-7.388 E.05398
G1 X28.95 Y155.966 E1.11436
G1 X28.95 Y157.442 E.04895
G1 X31.558 Y160.05 E.12235
G1 X32.543 Y160.05 E.03265
G1 X56.807 Y135.785 E1.13828
G2 X58.312 Y136.402 I4.129 J-7.931 E.05403
G1 X28.95 Y146.662 F30000
G1 F15476.087
G1 X28.95 Y148.29 E.05401
G1 X50.781 Y126.46 E1.0241
M73 P46 R27
G3 X50.781 Y125.54 I5.034 J-.46 E.03055
G1 X28.95 Y103.71 E1.0241
G1 X28.95 Y102.234 E.04894
G1 X39.234 Y91.95 E.48245
G1 X40.219 Y91.95 E.03265
G1 X63.458 Y115.189 E1.09019
G2 X62.173 Y115.068 I-2.388 J18.392 E.04282
G1 X85.29 Y91.95 E1.08448
G1 X86.274 Y91.95 E.03265
G1 X104.374 Y110.05 E.84908
G1 X105.571 Y110.05 E.0397
G1 X123.67 Y91.95 E.84908
G1 X124.654 Y91.95 E.03265
G1 X192.753 Y160.05 E3.19468
G1 X193.738 Y160.05 E.03265
G1 X227.05 Y126.738 E1.56273
G1 X227.05 Y125.262 E.04895
G1 X193.738 Y91.95 E1.56273
G1 X192.754 Y91.95 E.03265
G1 X124.654 Y160.05 E3.19468
G1 X123.67 Y160.05 E.03265
G1 X105.571 Y141.95 E.84908
G1 X104.374 Y141.95 E.0397
G1 X86.274 Y160.05 E.84908
G1 X85.29 Y160.05 E.03265
G1 X62.173 Y136.932 E1.08448
G2 X63.458 Y136.811 I-1.104 J-18.523 E.04282
G1 X40.219 Y160.05 E1.09019
G1 X39.234 Y160.05 E.03265
G1 X28.95 Y149.766 E.48245
G1 X28.95 Y151.394 E.05401
G1 X29.827 Y95.85 F30000
G1 F15476.087
G3 X28.95 Y95.399 I.729 J-2.493 E.0329
G1 X28.95 Y96.034 E.02105
G1 X52.705 Y119.788 E1.11436
G3 X56.807 Y116.215 I9.083 J6.285 E.18235
G1 X32.543 Y91.95 E1.13828
G1 X34.171 Y91.95 E.05401
; WIPE_START
G1 X32.543 Y91.95 E-.61876
G1 X32.805 Y92.213 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X31.531 Y91.619 Z2.8 F30000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X31.192 Y91.559 E.00874
; LINE_WIDTH: 0.327691
G1 X31.026 Y91.537 E.00389
; LINE_WIDTH: 0.281539
G2 X30.841 Y91.514 I-.363 J2.118 E.00363
; LINE_WIDTH: 0.24429
G2 X30.14 Y91.516 I-.337 J5.785 E.0115
; LINE_WIDTH: 0.283922
G1 X29.974 Y91.537 E.00329
; LINE_WIDTH: 0.327708
G1 X29.808 Y91.559 E.00389
; LINE_WIDTH: 0.354389
G1 X29.469 Y91.619 E.00874
G1 X28.619 Y92.469 F30000
; LINE_WIDTH: 0.354373
G1 F15000
G1 X28.559 Y92.808 E.00874
; LINE_WIDTH: 0.327686
G1 X28.537 Y92.974 E.00389
; LINE_WIDTH: 0.281525
G2 X28.514 Y93.159 I2.116 J.363 E.00363
; LINE_WIDTH: 0.2443
G2 X28.516 Y93.86 I5.788 J.336 E.0115
; LINE_WIDTH: 0.283917
G1 X28.537 Y94.026 E.00329
; LINE_WIDTH: 0.327693
G1 X28.559 Y94.192 E.00389
; LINE_WIDTH: 0.354386
G1 X28.619 Y94.531 E.00874
; CHANGE_LAYER
; Z_HEIGHT: 2.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X28.559 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 13/25
; update layer progress
M73 L13
M991 S0 P12 ;notify layer change
G17
G3 Z2.8 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.899 Y138.97 Z3 F30000
G1 X51.281 Y124.097 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.288 Y124.081 E.00059
G3 X60.507 Y115.466 I10.423 J1.914 E.44831
G1 X61.47 Y115.4 E.03202
G3 X51.157 Y125.036 I.241 J10.594 E1.69637
G1 X51.273 Y124.157 E.02943
M204 S250
G1 X51.674 Y124.152 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.037 J1.843 E.3999
G1 X61.479 Y115.792 E.02856
G3 X51.663 Y124.211 I.232 J10.202 E1.5399
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37592
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03092
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.053 Z3 F30000
G1 X223.514 Y94.187 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.53 Y94.217 E.00113
G2 X227.227 Y94.688 I1.97 J-.717 E.15229
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.727 J-1.188 E.24389
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.435 Y93.864 I1.188 J1.727 E.07946
G1 X223.5 Y94.129 E.00904
M204 S250
G1 X223.901 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.351 Y91.802 I1.606 J-.58 E.0958
G3 X226.811 Y92.4 I.162 J1.685 E.0504
G3 X223.922 Y94.138 I-1.304 J1.102 E.1816
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13583
G1 X223.789 Y93.5 E-.11331
G1 X223.815 Y93.203 E-.11331
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11332
G1 X224.189 Y92.4 E-.11333
G1 X224.297 Y92.293 E-.05758
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z3 F30000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03912
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z3 F30000
G1 X32.108 Y94.084 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X32.111 Y94.086 E.00011
G3 X30.351 Y91.802 I-1.604 J-.584 E.22413
G3 X31.811 Y92.4 I.162 J1.685 E.0504
G3 X32.156 Y93.944 I-1.304 J1.102 E.05053
G1 X32.127 Y94.028 E.00272
; WIPE_START
M204 S10000
G1 X32.111 Y94.086 E-.02319
G1 X31.982 Y94.355 E-.11345
G1 X31.811 Y94.6 E-.11332
G1 X31.6 Y94.811 E-.11335
G1 X31.355 Y94.982 E-.11329
G1 X31.085 Y95.108 E-.11334
G1 X30.797 Y95.185 E-.11332
G1 X30.648 Y95.198 E-.05675
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z3 F30000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.731 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08589
G1 X28.888 Y92.147 E-.13942
G1 X28.773 Y92.312 E-.07627
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14117
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z3 F30000
G1 X227.79 Y91.21 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z3 F30000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327687
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281538
G2 X225.841 Y91.514 I-.363 J2.118 E.00363
; LINE_WIDTH: 0.244295
G2 X225.14 Y91.516 I-.336 J5.786 E.0115
; LINE_WIDTH: 0.283913
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327691
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354364
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y92.469 Z3 F30000
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.354361
G1 F15000
G1 X227.441 Y92.808 E.00873
; LINE_WIDTH: 0.327676
G1 X227.463 Y92.974 E.00389
; LINE_WIDTH: 0.283908
G1 X227.484 Y93.14 E.00329
; LINE_WIDTH: 0.244295
G3 X227.486 Y93.841 I-5.787 J.364 E.0115
; LINE_WIDTH: 0.281523
G3 X227.463 Y94.026 I-2.14 J-.178 E.00363
; LINE_WIDTH: 0.327686
G1 X227.441 Y94.192 E.00389
; LINE_WIDTH: 0.354358
G1 X227.381 Y94.531 E.00873
; WIPE_START
G1 X227.441 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.173 Y95.85 Z3 F30000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X227.05 Y95.399 I-.729 J-2.493 E.0329
G1 X227.05 Y96.034 E.02105
G1 X163.034 Y160.05 E3.00311
G1 X162.05 Y160.05 E.03265
G1 X93.95 Y91.95 E3.19468
G1 X92.966 Y91.95 E.03265
G1 X67.927 Y116.989 E1.17464
G3 X69.189 Y118.015 I-7.415 J10.416 E.05398
; WIPE_START
G1 X67.927 Y116.989 E-.61792
G1 X68.191 Y116.725 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y124.345 Z3 F30000
G1 X69.189 Y133.985 Z3
G1 Z2.6
G1 E.8 F1800
G1 F15476.087
G3 X67.927 Y135.011 I-8.678 J-9.391 E.05398
G1 X92.966 Y160.05 E1.17464
G1 X93.95 Y160.05 E.03265
G1 X162.05 Y91.95 E3.19468
G1 X163.034 Y91.95 E.03265
G1 X227.05 Y155.966 E3.00311
G1 X227.05 Y157.442 E.04894
G1 X224.442 Y160.05 E.12235
G1 X223.457 Y160.05 E.03265
G1 X155.358 Y91.95 E3.19468
G1 X154.374 Y91.95 E.03265
G1 X110.95 Y135.374 E2.03708
G1 X110.95 Y131.978 E.11264
G1 X139.022 Y160.05 E1.31689
G1 X140.006 Y160.05 E.03265
G1 X208.105 Y91.95 E3.19468
G1 X209.09 Y91.95 E.03265
G1 X227.05 Y109.91 E.84254
G1 X227.05 Y111.386 E.04895
G1 X178.386 Y160.05 E2.28292
G1 X177.402 Y160.05 E.03265
G1 X109.302 Y91.95 E3.19468
G1 X108.318 Y91.95 E.03265
G1 X72.511 Y127.757 E1.67977
G3 X71.493 Y130.9 I-9.768 J-1.429 E.11012
G1 X100.642 Y160.05 E1.36746
G1 X101.626 Y160.05 E.03265
G1 X169.726 Y91.95 E3.19468
G1 X170.71 Y91.95 E.03265
G1 X227.05 Y148.29 E2.64302
G1 X227.05 Y149.766 E.04894
G1 X216.766 Y160.05 E.48245
G1 X215.781 Y160.05 E.03265
G1 X147.682 Y91.95 E3.19468
G1 X146.698 Y91.95 E.03265
G1 X110.95 Y127.698 E1.67699
G1 X110.95 Y124.302 E.11264
G1 X146.698 Y160.05 E1.67699
G1 X147.682 Y160.05 E.03265
G1 X215.781 Y91.95 E3.19468
G1 X216.766 Y91.95 E.03265
G1 X227.05 Y102.234 E.48245
G1 X227.05 Y103.71 E.04895
G1 X170.71 Y160.05 E2.64302
G1 X169.726 Y160.05 E.03265
G1 X101.626 Y91.95 E3.19468
G1 X100.642 Y91.95 E.03265
G1 X71.493 Y121.1 E1.36746
G3 X72.511 Y124.243 I-8.751 J4.573 E.11012
G1 X108.318 Y160.05 E1.67977
G1 X109.302 Y160.05 E.03265
G1 X177.402 Y91.95 E3.19468
G1 X178.386 Y91.95 E.03265
G1 X227.05 Y140.614 E2.28292
G1 X227.05 Y142.09 E.04895
G1 X209.09 Y160.05 E.84254
G1 X208.105 Y160.05 E.03265
G1 X140.006 Y91.95 E3.19468
G1 X139.022 Y91.95 E.03265
G1 X110.95 Y120.022 E1.31689
G1 X110.95 Y116.626 E.11264
G1 X154.374 Y160.05 E2.03708
G1 X155.358 Y160.05 E.03265
G1 X223.457 Y91.95 E3.19468
G1 X221.829 Y91.95 E.05401
G1 X110.95 Y141.282 F30000
G1 F15476.087
G1 X110.95 Y139.654 E.05401
G1 X131.346 Y160.05 E.9568
G1 X132.33 Y160.05 E.03265
G1 X200.429 Y91.95 E3.19468
G1 X201.414 Y91.95 E.03265
G1 X227.05 Y117.586 E1.20264
G1 X227.05 Y119.062 E.04894
G1 X186.062 Y160.05 E1.92283
G1 X185.078 Y160.05 E.03265
G1 X116.978 Y91.95 E3.19468
G1 X115.994 Y91.95 E.03265
G1 X47.895 Y160.05 E3.19468
G1 X46.91 Y160.05 E.03265
G1 X28.95 Y142.09 E.84254
G1 X28.95 Y140.614 E.04894
G1 X77.614 Y91.95 E2.28292
G1 X78.598 Y91.95 E.03265
G1 X99.05 Y112.402 E.95941
G1 X99.05 Y116.571 E.13829
G1 X55.571 Y160.05 E2.0397
G1 X54.586 Y160.05 E.03265
G1 X28.95 Y134.414 E1.20264
G1 X28.95 Y132.938 E.04894
G1 X69.938 Y91.95 E1.92283
G1 X70.922 Y91.95 E.03265
G1 X99.05 Y120.078 E1.31951
G1 X99.05 Y124.246 E.13829
G1 X63.246 Y160.05 E1.6796
G1 X62.262 Y160.05 E.03265
G1 X28.95 Y126.738 E1.56273
G1 X28.95 Y125.262 E.04894
G1 X62.262 Y91.95 E1.56273
G1 X63.246 Y91.95 E.03265
G1 X99.05 Y127.753 E1.6796
G1 X99.05 Y131.922 E.13829
G1 X70.922 Y160.05 E1.31951
G1 X69.938 Y160.05 E.03265
G1 X28.95 Y119.062 E1.92283
G1 X28.95 Y117.586 E.04894
G1 X54.586 Y91.95 E1.20264
G1 X55.571 Y91.95 E.03265
G1 X99.05 Y135.429 E2.0397
G1 X99.05 Y139.598 E.13829
G1 X78.598 Y160.05 E.95941
G1 X77.614 Y160.05 E.03265
G1 X28.95 Y111.386 E2.28292
G1 X28.95 Y109.91 E.04894
G1 X46.91 Y91.95 E.84254
G1 X47.895 Y91.95 E.03265
G1 X115.994 Y160.05 E3.19468
G1 X116.978 Y160.05 E.03265
G1 X185.078 Y91.95 E3.19468
G1 X186.062 Y91.95 E.03265
G1 X227.05 Y132.938 E1.92283
G1 X227.05 Y134.414 E.04894
G1 X201.414 Y160.05 E1.20264
G1 X200.429 Y160.05 E.03265
M73 P47 R27
G1 X132.33 Y91.95 E3.19468
G1 X131.346 Y91.95 E.03265
G1 X110.95 Y112.346 E.9568
G1 X110.95 Y110.718 E.05401
; WIPE_START
G1 X110.95 Y112.346 E-.61876
G1 X111.213 Y112.083 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X104.278 Y115.271 Z3 F30000
G1 X58.312 Y136.402 Z3
G1 Z2.6
G1 E.8 F1800
G1 F15476.087
G3 X56.807 Y135.785 I2.624 J-8.548 E.05403
G1 X32.543 Y160.05 E1.13828
G1 X31.558 Y160.05 E.03265
G1 X28.95 Y157.442 E.12235
G1 X28.95 Y155.966 E.04895
G1 X52.705 Y132.212 E1.11436
G3 X51.874 Y130.813 I13.206 J-8.787 E.05398
G1 X28.95 Y151.394 F30000
G1 F15476.087
G1 X28.95 Y149.766 E.05401
G1 X39.234 Y160.05 E.48245
G1 X40.219 Y160.05 E.03265
G1 X63.458 Y136.811 E1.09019
G3 X62.173 Y136.932 I-2.388 J-18.382 E.04282
G1 X85.29 Y160.05 E1.08448
G1 X86.274 Y160.05 E.03265
G1 X104.374 Y141.95 E.84908
G1 X105.571 Y141.95 E.0397
G1 X123.67 Y160.05 E.84908
G1 X124.654 Y160.05 E.03265
G1 X192.754 Y91.95 E3.19468
G1 X193.738 Y91.95 E.03265
G1 X227.05 Y125.262 E1.56273
G1 X227.05 Y126.738 E.04895
G1 X193.738 Y160.05 E1.56273
G1 X192.753 Y160.05 E.03265
G1 X124.654 Y91.95 E3.19468
G1 X123.67 Y91.95 E.03265
G1 X105.571 Y110.05 E.84908
G1 X104.374 Y110.05 E.0397
G1 X86.274 Y91.95 E.84908
G1 X85.29 Y91.95 E.03265
G1 X62.173 Y115.068 E1.08448
G3 X63.458 Y115.189 I-1.103 J18.514 E.04282
G1 X40.219 Y91.95 E1.09019
G1 X39.234 Y91.95 E.03265
G1 X28.95 Y102.234 E.48245
G1 X28.95 Y103.71 E.04894
G1 X50.781 Y125.54 E1.0241
M73 P47 R26
G2 X50.781 Y126.46 I5.034 J.46 E.03055
G1 X28.95 Y148.29 E1.0241
G1 X28.95 Y146.662 E.05401
; WIPE_START
G1 X28.95 Y148.29 E-.61876
G1 X29.213 Y148.027 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X29.128 Y140.395 Z3 F30000
G1 X28.619 Y94.531 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354361
G1 F15000
G1 X28.559 Y94.192 E.00874
; LINE_WIDTH: 0.327696
G1 X28.537 Y94.026 E.00389
; LINE_WIDTH: 0.283928
G1 X28.516 Y93.86 E.00329
; LINE_WIDTH: 0.2443
G3 X28.514 Y93.159 I5.78 J-.364 E.0115
; LINE_WIDTH: 0.281538
G3 X28.537 Y92.974 I2.142 J.178 E.00363
; LINE_WIDTH: 0.327687
G1 X28.559 Y92.808 E.00389
; LINE_WIDTH: 0.354377
G1 X28.619 Y92.469 E.00874
G1 X29.469 Y91.619 F30000
; LINE_WIDTH: 0.354364
G1 F15000
G1 X29.808 Y91.559 E.00874
; LINE_WIDTH: 0.327691
G1 X29.974 Y91.537 E.00389
; LINE_WIDTH: 0.283913
G1 X30.14 Y91.516 E.00329
; LINE_WIDTH: 0.244295
G3 X30.841 Y91.514 I.364 J5.785 E.0115
; LINE_WIDTH: 0.281538
G3 X31.026 Y91.537 I-.178 J2.142 E.00363
; LINE_WIDTH: 0.327687
G1 X31.192 Y91.559 E.00389
; LINE_WIDTH: 0.354377
G1 X31.531 Y91.619 E.00874
; WIPE_START
G1 X31.192 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X34.171 Y91.95 Z3 F30000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X32.543 Y91.95 E.05401
G1 X56.807 Y116.215 E1.13828
G2 X52.705 Y119.788 I4.981 J9.859 E.18235
G1 X28.95 Y96.034 E1.11436
G1 X28.95 Y95.399 E.02105
G2 X29.827 Y95.85 I1.605 J-2.041 E.0329
; CHANGE_LAYER
; Z_HEIGHT: 2.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X29.273 Y95.625 E-.22715
G1 X28.95 Y95.399 E-.14973
G1 X28.95 Y96.034 E-.24117
G1 X29.214 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 14/25
; update layer progress
M73 L14
M991 S0 P13 ;notify layer change
G17
G3 Z3 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z3.2 F30000
G1 X51.288 Y124.063 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.502 Y123.14 E.03144
G3 X60.507 Y115.466 I10.209 J2.86 E.41634
G1 X61.47 Y115.4 E.03202
G3 X51.277 Y124.122 I.241 J10.599 E1.72792
M204 S250
G1 X51.67 Y124.151 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.041 J1.848 E.39995
G1 X61.479 Y115.792 E.02856
G3 X51.659 Y124.21 I.232 J10.207 E1.54075
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37597
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03088
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.053 Z3.2 F30000
G1 X223.514 Y94.187 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.53 Y94.217 E.00113
G2 X227.227 Y94.688 I1.97 J-.717 E.15229
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.732 J-1.184 E.24448
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.435 Y93.864 I1.188 J1.727 E.07947
G1 X223.5 Y94.129 E.00904
M204 S250
G1 X223.902 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.341 Y91.803 I1.606 J-.579 E.09542
G3 X226.6 Y92.189 I.155 J1.737 E.04148
G3 X223.924 Y94.138 I-1.092 J1.313 E.19081
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13581
G1 X223.789 Y93.5 E-.11331
G1 X223.815 Y93.203 E-.11331
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11333
G1 X224.189 Y92.4 E-.1133
G1 X224.297 Y92.293 E-.05761
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02175
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.731 J1.192 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24921
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06804
G1 X227.112 Y92.147 E-.07626
G1 X227.039 Y92.075 E-.03914
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z3.2 F30000
G1 X32.108 Y94.084 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X32.112 Y94.087 E.00015
G3 X30.341 Y91.803 I-1.604 J-.585 E.22373
G3 X31.6 Y92.189 I.156 J1.737 E.04148
G3 X32.19 Y93.798 I-1.092 J1.313 E.05515
G1 X32.124 Y94.027 E.00731
; WIPE_START
M204 S10000
G1 X32.112 Y94.087 E-.02326
G1 X31.982 Y94.355 E-.1135
G1 X31.811 Y94.6 E-.11332
G1 X31.6 Y94.811 E-.11335
G1 X31.355 Y94.982 E-.11329
G1 X31.085 Y95.108 E-.11334
G1 X30.797 Y95.185 E-.11331
G1 X30.649 Y95.198 E-.05664
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.731 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08589
G1 X28.888 Y92.147 E-.13945
G1 X28.773 Y92.312 E-.07624
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14116
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z3.2 F30000
G1 X227.79 Y91.21 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327704
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281529
G2 X225.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.24429
G2 X225.14 Y91.516 I-.336 J5.788 E.0115
; LINE_WIDTH: 0.283913
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327691
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354364
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X221.829 Y91.95 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.457 Y91.95 E.05401
G1 X155.358 Y160.05 E3.19468
G1 X154.374 Y160.05 E.03265
G1 X110.95 Y116.626 E2.03708
G1 X110.95 Y120.022 E.11264
G1 X139.022 Y91.95 E1.31689
G1 X140.006 Y91.95 E.03265
G1 X208.105 Y160.05 E3.19468
G1 X209.09 Y160.05 E.03265
G1 X227.05 Y142.09 E.84254
G1 X227.05 Y140.614 E.04895
G1 X178.386 Y91.95 E2.28292
G1 X177.402 Y91.95 E.03265
G1 X109.302 Y160.05 E3.19468
G1 X108.318 Y160.05 E.03265
G1 X72.511 Y124.243 E1.67977
G2 X71.493 Y121.1 I-9.768 J1.429 E.11012
G1 X100.642 Y91.95 E1.36746
G1 X101.626 Y91.95 E.03265
G1 X169.726 Y160.05 E3.19468
G1 X170.71 Y160.05 E.03265
G1 X227.05 Y103.71 E2.64302
G1 X227.05 Y102.234 E.04895
G1 X216.766 Y91.95 E.48245
G1 X215.781 Y91.95 E.03265
G1 X147.682 Y160.05 E3.19468
G1 X146.698 Y160.05 E.03265
G1 X110.95 Y124.302 E1.67699
G1 X110.95 Y127.698 E.11264
G1 X146.698 Y91.95 E1.67699
G1 X147.682 Y91.95 E.03265
G1 X215.781 Y160.05 E3.19468
G1 X216.766 Y160.05 E.03265
G1 X227.05 Y149.766 E.48245
G1 X227.05 Y148.29 E.04894
G1 X170.71 Y91.95 E2.64302
G1 X169.726 Y91.95 E.03265
G1 X101.626 Y160.05 E3.19468
G1 X100.642 Y160.05 E.03265
G1 X71.493 Y130.9 E1.36746
G2 X72.511 Y127.757 I-8.749 J-4.572 E.11012
G1 X108.318 Y91.95 E1.67977
G1 X109.302 Y91.95 E.03265
G1 X177.402 Y160.05 E3.19468
G1 X178.386 Y160.05 E.03265
G1 X227.05 Y111.386 E2.28292
G1 X227.05 Y109.91 E.04895
G1 X209.09 Y91.95 E.84254
G1 X208.105 Y91.95 E.03265
G1 X140.006 Y160.05 E3.19468
G1 X139.022 Y160.05 E.03265
G1 X110.95 Y131.978 E1.31689
G1 X110.95 Y135.374 E.11264
G1 X154.374 Y91.95 E2.03708
G1 X155.358 Y91.95 E.03265
G1 X223.457 Y160.05 E3.19468
G1 X224.442 Y160.05 E.03265
G1 X227.05 Y157.442 E.12235
G1 X227.05 Y155.966 E.04894
G1 X163.034 Y91.95 E3.00311
G1 X162.05 Y91.95 E.03265
G1 X93.95 Y160.05 E3.19468
G1 X92.966 Y160.05 E.03265
G1 X67.927 Y135.011 E1.17464
G2 X69.189 Y133.985 I-7.415 J-10.416 E.05398
; WIPE_START
G1 X67.927 Y135.011 E-.61792
G1 X68.191 Y135.275 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y127.655 Z3.2 F30000
G1 X69.189 Y118.015 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F15476.087
G2 X67.927 Y116.989 I-8.676 J9.39 E.05398
G1 X92.966 Y91.95 E1.17464
G1 X93.95 Y91.95 E.03265
G1 X162.05 Y160.05 E3.19468
G1 X163.034 Y160.05 E.03265
G1 X227.05 Y96.034 E3.00311
G1 X227.05 Y95.399 E.02105
G3 X226.173 Y95.85 I-1.606 J-2.042 E.0329
; WIPE_START
G1 X226.727 Y95.625 E-.22718
G1 X227.05 Y95.399 E-.14969
G1 X227.05 Y96.034 E-.24118
G1 X226.786 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y94.531 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354358
G1 F15000
G1 X227.441 Y94.192 E.00873
; LINE_WIDTH: 0.327682
G1 X227.463 Y94.026 E.00389
; LINE_WIDTH: 0.281522
G2 X227.486 Y93.841 I-2.117 J-.363 E.00363
; LINE_WIDTH: 0.244295
G2 X227.484 Y93.14 I-5.788 J-.336 E.0115
; LINE_WIDTH: 0.283908
G1 X227.463 Y92.974 E.00329
; LINE_WIDTH: 0.327676
G1 X227.441 Y92.808 E.00389
; LINE_WIDTH: 0.354361
G1 X227.381 Y92.469 E.00873
; WIPE_START
G1 X227.441 Y92.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.357 Y100.44 Z3.2 F30000
G1 X227.05 Y128.366 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X227.05 Y126.738 E.05401
G1 X193.738 Y160.05 E1.56273
G1 X192.753 Y160.05 E.03265
G1 X124.654 Y91.95 E3.19468
G1 X123.67 Y91.95 E.03265
G1 X105.571 Y110.05 E.84908
M73 P48 R26
G1 X104.374 Y110.05 E.0397
G1 X86.274 Y91.95 E.84908
G1 X85.29 Y91.95 E.03265
G1 X62.173 Y115.068 E1.08448
G3 X63.458 Y115.189 I-1.103 J18.514 E.04282
G1 X40.219 Y91.95 E1.09019
G1 X39.234 Y91.95 E.03265
G1 X28.95 Y102.234 E.48245
G1 X28.95 Y103.71 E.04894
G1 X50.781 Y125.54 E1.0241
G2 X50.781 Y126.46 I5.034 J.46 E.03055
G1 X28.95 Y148.29 E1.0241
G1 X28.95 Y149.766 E.04895
G1 X39.234 Y160.05 E.48245
G1 X40.219 Y160.05 E.03265
G1 X63.458 Y136.811 E1.09019
G3 X62.173 Y136.932 I-2.389 J-18.402 E.04282
G1 X85.29 Y160.05 E1.08448
G1 X86.274 Y160.05 E.03265
G1 X104.374 Y141.95 E.84908
G1 X105.571 Y141.95 E.0397
G1 X123.67 Y160.05 E.84908
G1 X124.654 Y160.05 E.03265
G1 X192.754 Y91.95 E3.19468
G1 X193.738 Y91.95 E.03265
G1 X227.05 Y125.262 E1.56273
G1 X227.05 Y123.634 E.05401
G1 X110.95 Y110.718 F30000
G1 F15476.087
G1 X110.95 Y112.346 E.05401
G1 X131.346 Y91.95 E.9568
G1 X132.33 Y91.95 E.03265
G1 X200.429 Y160.05 E3.19468
G1 X201.414 Y160.05 E.03265
G1 X227.05 Y134.414 E1.20264
G1 X227.05 Y132.938 E.04894
G1 X186.062 Y91.95 E1.92283
G1 X185.078 Y91.95 E.03265
G1 X116.978 Y160.05 E3.19468
G1 X115.994 Y160.05 E.03265
G1 X47.895 Y91.95 E3.19468
G1 X46.91 Y91.95 E.03265
G1 X28.95 Y109.91 E.84254
G1 X28.95 Y111.386 E.04895
G1 X77.614 Y160.05 E2.28292
G1 X78.598 Y160.05 E.03265
G1 X99.05 Y139.598 E.95941
G1 X99.05 Y135.429 E.13829
G1 X55.571 Y91.95 E2.0397
G1 X54.586 Y91.95 E.03265
G1 X28.95 Y117.586 E1.20264
G1 X28.95 Y119.062 E.04894
G1 X69.938 Y160.05 E1.92283
G1 X70.922 Y160.05 E.03265
G1 X99.05 Y131.922 E1.31951
G1 X99.05 Y127.753 E.13829
G1 X63.246 Y91.95 E1.6796
G1 X62.262 Y91.95 E.03265
G1 X28.95 Y125.262 E1.56273
G1 X28.95 Y126.738 E.04895
G1 X62.262 Y160.05 E1.56273
G1 X63.246 Y160.05 E.03265
G1 X99.05 Y124.246 E1.6796
G1 X99.05 Y120.078 E.13829
G1 X70.922 Y91.95 E1.31951
G1 X69.938 Y91.95 E.03265
G1 X28.95 Y132.938 E1.92283
G1 X28.95 Y134.414 E.04895
G1 X54.586 Y160.05 E1.20264
G1 X55.571 Y160.05 E.03265
G1 X99.05 Y116.571 E2.0397
G1 X99.05 Y112.402 E.13829
G1 X78.598 Y91.95 E.95941
G1 X77.614 Y91.95 E.03265
G1 X28.95 Y140.614 E2.28292
G1 X28.95 Y142.09 E.04895
G1 X46.91 Y160.05 E.84254
G1 X47.895 Y160.05 E.03265
G1 X115.994 Y91.95 E3.19468
G1 X116.978 Y91.95 E.03265
G1 X185.078 Y160.05 E3.19468
G1 X186.062 Y160.05 E.03265
G1 X227.05 Y119.062 E1.92283
G1 X227.05 Y117.586 E.04894
G1 X201.414 Y91.95 E1.20264
G1 X200.429 Y91.95 E.03265
G1 X132.33 Y160.05 E3.19468
G1 X131.346 Y160.05 E.03265
G1 X110.95 Y139.654 E.9568
G1 X110.95 Y141.282 E.05401
; WIPE_START
G1 X110.95 Y139.654 E-.61876
G1 X111.213 Y139.917 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X103.669 Y138.76 Z3.2 F30000
G1 X51.874 Y130.813 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F15476.087
G2 X52.705 Y132.212 I14.036 J-7.388 E.05398
G1 X28.95 Y155.966 E1.11436
G1 X28.95 Y157.442 E.04895
G1 X31.558 Y160.05 E.12235
G1 X32.543 Y160.05 E.03265
G1 X56.807 Y135.785 E1.13828
G2 X58.312 Y136.402 I4.129 J-7.931 E.05403
; WIPE_START
G1 X56.807 Y135.785 E-.61812
G1 X56.543 Y136.049 E-.14188
; WIPE_END
G1 E-.04 F1800
G1 X52.318 Y129.693 Z3.2 F30000
G1 X29.827 Y95.85 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F15476.087
G3 X28.95 Y95.399 I.729 J-2.492 E.0329
G1 X28.95 Y96.034 E.02105
G1 X52.705 Y119.788 E1.11436
G3 X56.807 Y116.215 I9.083 J6.285 E.18235
G1 X32.543 Y91.95 E1.13828
G1 X34.171 Y91.95 E.05401
; WIPE_START
G1 X32.543 Y91.95 E-.61876
G1 X32.805 Y92.213 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X31.531 Y91.619 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X31.192 Y91.559 E.00874
; LINE_WIDTH: 0.327704
G1 X31.026 Y91.537 E.00389
; LINE_WIDTH: 0.281529
G2 X30.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.244291
G2 X30.14 Y91.516 I-.336 J5.789 E.0115
; LINE_WIDTH: 0.283917
G1 X29.974 Y91.537 E.00329
; LINE_WIDTH: 0.327693
G1 X29.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X29.469 Y91.619 E.00874
G1 X28.619 Y92.469 F30000
; LINE_WIDTH: 0.354377
G1 F15000
G1 X28.559 Y92.808 E.00874
; LINE_WIDTH: 0.327686
G1 X28.537 Y92.974 E.00389
; LINE_WIDTH: 0.281523
G2 X28.514 Y93.159 I2.114 J.363 E.00363
; LINE_WIDTH: 0.244295
G2 X28.516 Y93.86 I5.788 J.336 E.0115
; LINE_WIDTH: 0.283928
G1 X28.537 Y94.026 E.00329
; LINE_WIDTH: 0.327696
G1 X28.559 Y94.192 E.00389
; LINE_WIDTH: 0.354364
G1 X28.619 Y94.531 E.00874
; CHANGE_LAYER
; Z_HEIGHT: 3
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X28.559 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 15/25
; update layer progress
M73 L15
M991 S0 P14 ;notify layer change
G17
G3 Z3.2 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z3.4 F30000
G1 X51.288 Y124.063 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.502 Y123.14 E.03143
G3 X60.507 Y115.466 I10.209 J2.86 E.41633
G1 X61.47 Y115.4 E.03202
G3 X51.277 Y124.122 I.241 J10.599 E1.72788
M204 S250
G1 X51.67 Y124.151 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.041 J1.848 E.39995
G1 X61.479 Y115.792 E.02856
G3 X51.66 Y124.21 I.232 J10.207 E1.54073
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37597
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03088
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.056 Z3.4 F30000
G1 X223.537 Y94.25 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.684 Y94.548 E.01102
G2 X227.227 Y94.688 I1.816 J-1.048 E.14015
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.732 J-1.184 E.24448
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.521 Y94.193 I1.188 J1.727 E.09075
M204 S250
G1 X223.902 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.331 Y91.804 I1.606 J-.58 E.09512
G3 X226.6 Y92.189 I.166 J1.736 E.0418
G3 X223.923 Y94.138 I-1.092 J1.313 E.19081
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13581
G1 X223.789 Y93.5 E-.11332
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11332
G1 X224.189 Y92.4 E-.11333
G1 X224.297 Y92.293 E-.05759
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03913
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z3.4 F30000
G1 X32.108 Y94.085 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X32.112 Y94.087 E.00015
G3 X30.331 Y91.804 I-1.604 J-.585 E.22343
G3 X31.6 Y92.189 I.166 J1.736 E.0418
G3 X32.189 Y93.798 I-1.092 J1.313 E.05514
G1 X32.124 Y94.027 E.00732
; WIPE_START
M204 S10000
G1 X32.112 Y94.087 E-.02318
G1 X31.982 Y94.355 E-.1135
G1 X31.811 Y94.6 E-.11332
G1 X31.6 Y94.811 E-.11335
G1 X31.355 Y94.982 E-.11329
G1 X31.085 Y95.108 E-.11334
G1 X30.797 Y95.185 E-.11332
G1 X30.648 Y95.198 E-.05672
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.731 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02175
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.0859
G1 X28.888 Y92.147 E-.1394
G1 X28.773 Y92.312 E-.07627
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14117
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z3.4 F30000
G1 X227.79 Y91.21 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354373
G1 F15000
G1 X226.192 Y91.559 E.00873
; LINE_WIDTH: 0.327704
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281529
G2 X225.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.244296
G2 X225.14 Y91.516 I-.336 J5.783 E.0115
; LINE_WIDTH: 0.283928
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327696
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354361
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y92.469 Z3.4 F30000
G1 Z3
G1 E.8 F1800
G1 F15000
G1 X227.441 Y92.808 E.00873
; LINE_WIDTH: 0.327676
G1 X227.463 Y92.974 E.00389
; LINE_WIDTH: 0.283908
G1 X227.484 Y93.14 E.00329
; LINE_WIDTH: 0.244295
G3 X227.486 Y93.841 I-5.786 J.364 E.0115
; LINE_WIDTH: 0.281523
G3 X227.463 Y94.026 I-2.137 J-.178 E.00363
; LINE_WIDTH: 0.327686
G1 X227.441 Y94.192 E.00389
; LINE_WIDTH: 0.354377
G1 X227.381 Y94.531 E.00874
; WIPE_START
G1 X227.441 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.173 Y95.85 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X227.05 Y95.399 I-.729 J-2.494 E.0329
G1 X227.05 Y96.034 E.02105
G1 X163.034 Y160.05 E3.00311
G1 X162.05 Y160.05 E.03265
G1 X93.95 Y91.95 E3.19468
G1 X92.966 Y91.95 E.03265
G1 X67.927 Y116.989 E1.17464
G3 X69.189 Y118.015 I-7.415 J10.416 E.05398
; WIPE_START
G1 X67.927 Y116.989 E-.61792
G1 X68.191 Y116.725 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y124.345 Z3.4 F30000
G1 X69.189 Y133.985 Z3.4
G1 Z3
G1 E.8 F1800
G1 F15476.087
G3 X67.927 Y135.011 I-8.678 J-9.391 E.05398
G1 X92.966 Y160.05 E1.17464
G1 X93.95 Y160.05 E.03265
G1 X162.05 Y91.95 E3.19468
G1 X163.034 Y91.95 E.03265
G1 X227.05 Y155.966 E3.00311
G1 X227.05 Y157.442 E.04894
G1 X224.442 Y160.05 E.12235
G1 X223.457 Y160.05 E.03265
G1 X155.358 Y91.95 E3.19468
G1 X154.374 Y91.95 E.03265
G1 X110.95 Y135.374 E2.03708
G1 X110.95 Y131.978 E.11264
G1 X139.022 Y160.05 E1.31689
G1 X140.006 Y160.05 E.03265
G1 X208.105 Y91.95 E3.19468
G1 X209.09 Y91.95 E.03265
G1 X227.05 Y109.91 E.84254
G1 X227.05 Y111.386 E.04895
G1 X178.386 Y160.05 E2.28292
G1 X177.402 Y160.05 E.03265
G1 X109.302 Y91.95 E3.19468
G1 X108.318 Y91.95 E.03265
G1 X72.511 Y127.757 E1.67977
G3 X71.493 Y130.9 I-9.769 J-1.43 E.11012
G1 X100.642 Y160.05 E1.36746
G1 X101.626 Y160.05 E.03265
G1 X169.726 Y91.95 E3.19468
G1 X170.71 Y91.95 E.03265
G1 X227.05 Y148.29 E2.64302
G1 X227.05 Y149.766 E.04894
G1 X216.766 Y160.05 E.48245
G1 X215.781 Y160.05 E.03265
G1 X147.682 Y91.95 E3.19468
G1 X146.698 Y91.95 E.03265
G1 X110.95 Y127.698 E1.67699
G1 X110.95 Y124.302 E.11264
G1 X146.698 Y160.05 E1.67699
G1 X147.682 Y160.05 E.03265
G1 X215.781 Y91.95 E3.19468
G1 X216.766 Y91.95 E.03265
G1 X227.05 Y102.234 E.48245
G1 X227.05 Y103.71 E.04895
G1 X170.71 Y160.05 E2.64302
G1 X169.726 Y160.05 E.03265
G1 X101.626 Y91.95 E3.19468
G1 X100.642 Y91.95 E.03265
G1 X71.493 Y121.1 E1.36746
G3 X72.511 Y124.243 I-8.75 J4.573 E.11012
G1 X108.318 Y160.05 E1.67977
G1 X109.302 Y160.05 E.03265
G1 X177.402 Y91.95 E3.19468
G1 X178.386 Y91.95 E.03265
G1 X227.05 Y140.614 E2.28292
G1 X227.05 Y142.09 E.04895
G1 X209.09 Y160.05 E.84254
G1 X208.105 Y160.05 E.03265
G1 X140.006 Y91.95 E3.19468
G1 X139.022 Y91.95 E.03265
G1 X110.95 Y120.022 E1.31689
G1 X110.95 Y116.626 E.11264
G1 X154.374 Y160.05 E2.03708
G1 X155.358 Y160.05 E.03265
G1 X223.457 Y91.95 E3.19468
G1 X221.829 Y91.95 E.05401
G1 X227.05 Y123.634 F30000
G1 F15476.087
G1 X227.05 Y125.262 E.05401
G1 X193.738 Y91.95 E1.56273
G1 X192.754 Y91.95 E.03265
G1 X124.654 Y160.05 E3.19468
G1 X123.67 Y160.05 E.03265
G1 X105.571 Y141.95 E.84908
G1 X104.374 Y141.95 E.0397
G1 X86.274 Y160.05 E.84908
G1 X85.29 Y160.05 E.03265
G1 X62.173 Y136.932 E1.08448
G2 X63.458 Y136.811 I-1.103 J-18.513 E.04282
M73 P49 R26
G1 X40.219 Y160.05 E1.09019
G1 X39.234 Y160.05 E.03265
G1 X28.95 Y149.766 E.48245
G1 X28.95 Y148.29 E.04895
G1 X50.781 Y126.46 E1.0241
G3 X50.781 Y125.54 I5.034 J-.46 E.03055
G1 X28.95 Y103.71 E1.0241
G1 X28.95 Y102.234 E.04894
G1 X39.234 Y91.95 E.48245
G1 X40.219 Y91.95 E.03265
G1 X63.458 Y115.189 E1.09019
G2 X62.173 Y115.068 I-2.388 J18.394 E.04282
G1 X85.29 Y91.95 E1.08448
G1 X86.274 Y91.95 E.03265
G1 X104.374 Y110.05 E.84908
G1 X105.571 Y110.05 E.0397
G1 X123.67 Y91.95 E.84908
G1 X124.654 Y91.95 E.03265
G1 X192.753 Y160.05 E3.19468
G1 X193.738 Y160.05 E.03265
G1 X227.05 Y126.738 E1.56273
G1 X227.05 Y128.366 E.05401
G1 X110.95 Y141.282 F30000
G1 F15476.087
G1 X110.95 Y139.654 E.05401
G1 X131.346 Y160.05 E.9568
G1 X132.33 Y160.05 E.03265
G1 X200.429 Y91.95 E3.19468
G1 X201.414 Y91.95 E.03265
G1 X227.05 Y117.586 E1.20264
G1 X227.05 Y119.062 E.04894
G1 X186.062 Y160.05 E1.92283
G1 X185.078 Y160.05 E.03265
G1 X116.978 Y91.95 E3.19468
G1 X115.994 Y91.95 E.03265
G1 X47.895 Y160.05 E3.19468
M73 P49 R25
G1 X46.91 Y160.05 E.03265
G1 X28.95 Y142.09 E.84254
G1 X28.95 Y140.614 E.04895
G1 X77.614 Y91.95 E2.28292
G1 X78.598 Y91.95 E.03265
G1 X99.05 Y112.402 E.95941
G1 X99.05 Y116.571 E.13829
G1 X55.571 Y160.05 E2.0397
G1 X54.586 Y160.05 E.03265
G1 X28.95 Y134.414 E1.20264
G1 X28.95 Y132.938 E.04895
G1 X69.938 Y91.95 E1.92283
G1 X70.922 Y91.95 E.03265
G1 X99.05 Y120.078 E1.31951
G1 X99.05 Y124.246 E.13829
G1 X63.246 Y160.05 E1.6796
G1 X62.262 Y160.05 E.03265
G1 X28.95 Y126.738 E1.56273
G1 X28.95 Y125.262 E.04895
G1 X62.262 Y91.95 E1.56273
G1 X63.246 Y91.95 E.03265
G1 X99.05 Y127.753 E1.6796
G1 X99.05 Y131.922 E.13829
G1 X70.922 Y160.05 E1.31951
G1 X69.938 Y160.05 E.03265
G1 X28.95 Y119.062 E1.92283
G1 X28.95 Y117.586 E.04894
G1 X54.586 Y91.95 E1.20264
G1 X55.571 Y91.95 E.03265
G1 X99.05 Y135.429 E2.0397
G1 X99.05 Y139.598 E.13829
G1 X78.598 Y160.05 E.95941
G1 X77.614 Y160.05 E.03265
G1 X28.95 Y111.386 E2.28292
G1 X28.95 Y109.91 E.04895
G1 X46.91 Y91.95 E.84254
G1 X47.895 Y91.95 E.03265
G1 X115.994 Y160.05 E3.19468
G1 X116.978 Y160.05 E.03265
G1 X185.078 Y91.95 E3.19468
G1 X186.062 Y91.95 E.03265
G1 X227.05 Y132.938 E1.92283
G1 X227.05 Y134.414 E.04894
G1 X201.414 Y160.05 E1.20264
G1 X200.429 Y160.05 E.03265
G1 X132.33 Y91.95 E3.19468
G1 X131.346 Y91.95 E.03265
G1 X110.95 Y112.346 E.9568
G1 X110.95 Y110.718 E.05401
; WIPE_START
G1 X110.95 Y112.346 E-.61876
G1 X111.213 Y112.083 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X104.278 Y115.271 Z3.4 F30000
G1 X58.312 Y136.402 Z3.4
G1 Z3
G1 E.8 F1800
G1 F15476.087
G3 X56.807 Y135.785 I2.624 J-8.548 E.05403
G1 X32.543 Y160.05 E1.13828
G1 X31.558 Y160.05 E.03265
G1 X28.95 Y157.442 E.12235
G1 X28.95 Y155.966 E.04895
G1 X52.705 Y132.212 E1.11436
G3 X51.874 Y130.813 I13.206 J-8.787 E.05398
G1 X34.171 Y91.95 F30000
G1 F15476.087
G1 X32.543 Y91.95 E.05401
G1 X56.807 Y116.215 E1.13828
G2 X52.705 Y119.788 I4.981 J9.859 E.18235
G1 X28.95 Y96.034 E1.11436
G1 X28.95 Y95.399 E.02105
G2 X29.827 Y95.85 I1.605 J-2.041 E.0329
; WIPE_START
G1 X29.273 Y95.625 E-.22714
G1 X28.95 Y95.399 E-.14973
G1 X28.95 Y96.034 E-.24118
G1 X29.214 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
G1 X28.619 Y94.531 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354364
G1 F15000
G1 X28.559 Y94.192 E.00874
; LINE_WIDTH: 0.327696
G1 X28.537 Y94.026 E.00389
; LINE_WIDTH: 0.283928
G1 X28.516 Y93.86 E.00329
; LINE_WIDTH: 0.244295
G3 X28.514 Y93.159 I5.786 J-.364 E.0115
; LINE_WIDTH: 0.281527
G3 X28.537 Y92.974 I2.135 J.177 E.00363
; LINE_WIDTH: 0.327704
G1 X28.559 Y92.808 E.00389
; LINE_WIDTH: 0.354377
G1 X28.619 Y92.469 E.00873
G1 X29.469 Y91.619 F30000
; LINE_WIDTH: 0.354361
G1 F15000
G1 X29.808 Y91.559 E.00874
; LINE_WIDTH: 0.327696
G1 X29.974 Y91.537 E.00389
; LINE_WIDTH: 0.283928
G1 X30.14 Y91.516 E.00329
; LINE_WIDTH: 0.244296
G3 X30.841 Y91.514 I.364 J5.782 E.0115
; LINE_WIDTH: 0.281529
G3 X31.026 Y91.537 I-.178 J2.137 E.00363
; LINE_WIDTH: 0.327704
G1 X31.192 Y91.559 E.00389
; LINE_WIDTH: 0.354377
G1 X31.531 Y91.619 E.00874
; CHANGE_LAYER
; Z_HEIGHT: 3.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X31.192 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 16/25
; update layer progress
M73 L16
M991 S0 P15 ;notify layer change
G17
G3 Z3.4 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z3.6 F30000
G1 X51.288 Y124.062 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.505 Y123.14 E.03142
G3 X60.507 Y115.466 I10.206 J2.854 E.41629
G1 X61.47 Y115.4 E.03202
G3 X51.28 Y124.122 I.241 J10.594 E1.72699
M204 S250
G1 X51.674 Y124.152 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.037 J1.843 E.3999
G1 X61.479 Y115.792 E.02856
G3 X51.663 Y124.211 I.232 J10.202 E1.5399
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37592
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03092
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.055 Z3.6 F30000
G1 X223.537 Y94.251 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.678 Y94.552 E.01104
G2 X227.227 Y94.688 I1.817 J-1.047 E.14051
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.732 J-1.184 E.24448
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.514 Y94.195 I1.184 J1.732 E.09092
M204 S250
G1 X223.902 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.32 Y91.805 I1.606 J-.58 E.09481
G3 X226.6 Y92.189 I.176 J1.736 E.04213
G3 X223.923 Y94.138 I-1.092 J1.313 E.19081
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13581
G1 X223.789 Y93.5 E-.11331
G1 X223.815 Y93.203 E-.11331
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11332
G1 X224.189 Y92.4 E-.11333
G1 X224.297 Y92.293 E-.05759
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03913
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z3.6 F30000
G1 X32.108 Y94.085 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X32.112 Y94.087 E.00014
G3 X30.32 Y91.805 I-1.604 J-.585 E.22313
G3 X31.6 Y92.189 I.176 J1.736 E.04213
G3 X32.189 Y93.798 I-1.092 J1.313 E.05514
G1 X32.124 Y94.027 E.00732
; WIPE_START
M204 S10000
G1 X32.112 Y94.087 E-.0231
G1 X31.982 Y94.355 E-.1135
G1 X31.811 Y94.6 E-.11332
G1 X31.6 Y94.811 E-.11333
G1 X31.355 Y94.982 E-.11332
G1 X31.085 Y95.108 E-.11332
G1 X30.797 Y95.185 E-.11332
G1 X30.648 Y95.198 E-.0568
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.73 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08593
G1 X28.888 Y92.147 E-.13936
G1 X28.773 Y92.312 E-.07628
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14117
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z3.6 F30000
G1 X227.79 Y91.21 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354373
G1 F15000
G1 X226.192 Y91.559 E.00873
; LINE_WIDTH: 0.327704
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281529
G2 X225.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.244286
G2 X225.14 Y91.516 I-.336 J5.786 E.0115
; LINE_WIDTH: 0.283917
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327693
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X221.829 Y91.95 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.457 Y91.95 E.05401
G1 X155.358 Y160.05 E3.19468
G1 X154.374 Y160.05 E.03265
G1 X110.95 Y116.626 E2.03708
G1 X110.95 Y120.022 E.11264
G1 X139.022 Y91.95 E1.31689
G1 X140.006 Y91.95 E.03265
G1 X208.105 Y160.05 E3.19468
G1 X209.09 Y160.05 E.03265
G1 X227.05 Y142.09 E.84254
G1 X227.05 Y140.614 E.04894
G1 X178.386 Y91.95 E2.28292
G1 X177.402 Y91.95 E.03265
G1 X109.302 Y160.05 E3.19468
G1 X108.318 Y160.05 E.03265
G1 X72.511 Y124.243 E1.67977
G2 X71.493 Y121.1 I-9.768 J1.429 E.11012
G1 X100.642 Y91.95 E1.36746
G1 X101.626 Y91.95 E.03265
G1 X169.726 Y160.05 E3.19468
G1 X170.71 Y160.05 E.03265
G1 X227.05 Y103.71 E2.64302
G1 X227.05 Y102.234 E.04894
G1 X216.766 Y91.95 E.48245
G1 X215.781 Y91.95 E.03265
G1 X147.682 Y160.05 E3.19468
G1 X146.698 Y160.05 E.03265
G1 X110.95 Y124.302 E1.67699
G1 X110.95 Y127.698 E.11264
G1 X146.698 Y91.95 E1.67699
G1 X147.682 Y91.95 E.03265
G1 X215.781 Y160.05 E3.19468
G1 X216.766 Y160.05 E.03265
G1 X227.05 Y149.766 E.48245
G1 X227.05 Y148.29 E.04894
G1 X170.71 Y91.95 E2.64302
G1 X169.726 Y91.95 E.03265
G1 X101.626 Y160.05 E3.19468
G1 X100.642 Y160.05 E.03265
G1 X71.493 Y130.9 E1.36746
G2 X72.511 Y127.757 I-8.749 J-4.572 E.11012
G1 X108.318 Y91.95 E1.67977
G1 X109.302 Y91.95 E.03265
G1 X177.402 Y160.05 E3.19468
G1 X178.386 Y160.05 E.03265
G1 X227.05 Y111.386 E2.28292
G1 X227.05 Y109.91 E.04894
G1 X209.09 Y91.95 E.84254
G1 X208.105 Y91.95 E.03265
G1 X140.006 Y160.05 E3.19468
G1 X139.022 Y160.05 E.03265
G1 X110.95 Y131.978 E1.31689
G1 X110.95 Y135.374 E.11264
G1 X154.374 Y91.95 E2.03708
G1 X155.358 Y91.95 E.03265
G1 X223.457 Y160.05 E3.19468
G1 X224.442 Y160.05 E.03265
G1 X227.05 Y157.442 E.12235
G1 X227.05 Y155.966 E.04894
G1 X163.034 Y91.95 E3.00311
G1 X162.05 Y91.95 E.03265
G1 X93.95 Y160.05 E3.19468
G1 X92.966 Y160.05 E.03265
G1 X67.927 Y135.011 E1.17464
G2 X69.189 Y133.985 I-7.416 J-10.417 E.05398
; WIPE_START
G1 X67.927 Y135.011 E-.61792
M73 P50 R25
G1 X68.191 Y135.275 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y127.655 Z3.6 F30000
G1 X69.189 Y118.015 Z3.6
G1 Z3.2
G1 E.8 F1800
G1 F15476.087
G2 X67.927 Y116.989 I-8.677 J9.391 E.05398
G1 X92.966 Y91.95 E1.17464
G1 X93.95 Y91.95 E.03265
G1 X162.05 Y160.05 E3.19468
G1 X163.034 Y160.05 E.03265
G1 X227.05 Y96.034 E3.00311
G1 X227.05 Y95.399 E.02105
G3 X226.173 Y95.85 I-1.605 J-2.042 E.0329
; WIPE_START
G1 X226.727 Y95.625 E-.22716
G1 X227.05 Y95.399 E-.14972
G1 X227.05 Y96.034 E-.24118
G1 X226.786 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y94.531 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X227.441 Y94.192 E.00874
; LINE_WIDTH: 0.327686
G1 X227.463 Y94.026 E.00389
; LINE_WIDTH: 0.281523
G2 X227.486 Y93.841 I-2.114 J-.363 E.00363
; LINE_WIDTH: 0.244285
G2 X227.484 Y93.14 I-5.786 J-.336 E.0115
; LINE_WIDTH: 0.283902
G1 X227.463 Y92.974 E.00329
; LINE_WIDTH: 0.327688
G1 X227.441 Y92.808 E.00389
; LINE_WIDTH: 0.354386
G1 X227.381 Y92.469 E.00873
; WIPE_START
G1 X227.441 Y92.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X219.897 Y93.968 Z3.6 F30000
G1 X110.95 Y110.718 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.95 Y112.346 E.05401
G1 X131.346 Y91.95 E.9568
G1 X132.33 Y91.95 E.03265
G1 X200.429 Y160.05 E3.19468
G1 X201.414 Y160.05 E.03265
G1 X227.05 Y134.414 E1.20264
G1 X227.05 Y132.938 E.04894
G1 X186.062 Y91.95 E1.92283
G1 X185.078 Y91.95 E.03265
G1 X116.978 Y160.05 E3.19468
G1 X115.994 Y160.05 E.03265
G1 X47.895 Y91.95 E3.19468
G1 X46.91 Y91.95 E.03265
G1 X28.95 Y109.91 E.84254
G1 X28.95 Y111.386 E.04895
G1 X77.614 Y160.05 E2.28292
G1 X78.598 Y160.05 E.03265
G1 X99.05 Y139.598 E.95941
G1 X99.05 Y135.429 E.13829
G1 X55.571 Y91.95 E2.0397
G1 X54.586 Y91.95 E.03265
G1 X28.95 Y117.586 E1.20264
G1 X28.95 Y119.062 E.04894
G1 X69.938 Y160.05 E1.92283
G1 X70.922 Y160.05 E.03265
G1 X99.05 Y131.922 E1.31951
G1 X99.05 Y127.753 E.13829
G1 X63.246 Y91.95 E1.6796
G1 X62.262 Y91.95 E.03265
G1 X28.95 Y125.262 E1.56273
G1 X28.95 Y126.738 E.04895
G1 X62.262 Y160.05 E1.56273
G1 X63.246 Y160.05 E.03265
G1 X99.05 Y124.246 E1.6796
G1 X99.05 Y120.078 E.13829
G1 X70.922 Y91.95 E1.31951
G1 X69.938 Y91.95 E.03265
G1 X28.95 Y132.938 E1.92283
G1 X28.95 Y134.414 E.04895
G1 X54.586 Y160.05 E1.20264
G1 X55.571 Y160.05 E.03265
G1 X99.05 Y116.571 E2.0397
G1 X99.05 Y112.402 E.13829
G1 X78.598 Y91.95 E.95941
G1 X77.614 Y91.95 E.03265
G1 X28.95 Y140.614 E2.28292
G1 X28.95 Y142.09 E.04895
G1 X46.91 Y160.05 E.84254
G1 X47.895 Y160.05 E.03265
G1 X115.994 Y91.95 E3.19468
G1 X116.978 Y91.95 E.03265
G1 X185.078 Y160.05 E3.19468
G1 X186.062 Y160.05 E.03265
G1 X227.05 Y119.062 E1.92283
G1 X227.05 Y117.586 E.04894
G1 X201.414 Y91.95 E1.20264
G1 X200.429 Y91.95 E.03265
G1 X132.33 Y160.05 E3.19468
G1 X131.346 Y160.05 E.03265
G1 X110.95 Y139.654 E.9568
G1 X110.95 Y141.282 E.05401
; WIPE_START
G1 X110.95 Y139.654 E-.61876
G1 X111.213 Y139.917 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X103.669 Y138.76 Z3.6 F30000
G1 X51.874 Y130.813 Z3.6
G1 Z3.2
G1 E.8 F1800
G1 F15476.087
G2 X52.705 Y132.212 I14.036 J-7.388 E.05398
G1 X28.95 Y155.966 E1.11436
G1 X28.95 Y157.442 E.04895
G1 X31.558 Y160.05 E.12235
G1 X32.543 Y160.05 E.03265
G1 X56.807 Y135.785 E1.13828
G2 X58.312 Y136.402 I4.129 J-7.931 E.05403
G1 X28.95 Y146.662 F30000
G1 F15476.087
G1 X28.95 Y148.29 E.05401
G1 X50.781 Y126.46 E1.0241
G3 X50.781 Y125.54 I5.034 J-.46 E.03055
G1 X28.95 Y103.71 E1.0241
G1 X28.95 Y102.234 E.04894
G1 X39.234 Y91.95 E.48245
G1 X40.219 Y91.95 E.03265
G1 X63.458 Y115.189 E1.09019
G2 X62.173 Y115.068 I-2.388 J18.392 E.04282
G1 X85.29 Y91.95 E1.08448
G1 X86.274 Y91.95 E.03265
G1 X104.374 Y110.05 E.84908
G1 X105.571 Y110.05 E.0397
G1 X123.67 Y91.95 E.84908
G1 X124.654 Y91.95 E.03265
G1 X192.753 Y160.05 E3.19468
G1 X193.738 Y160.05 E.03265
G1 X227.05 Y126.738 E1.56273
G1 X227.05 Y125.262 E.04895
G1 X193.738 Y91.95 E1.56273
G1 X192.754 Y91.95 E.03265
G1 X124.654 Y160.05 E3.19468
G1 X123.67 Y160.05 E.03265
G1 X105.571 Y141.95 E.84908
G1 X104.374 Y141.95 E.0397
G1 X86.274 Y160.05 E.84908
G1 X85.29 Y160.05 E.03265
G1 X62.173 Y136.932 E1.08448
G2 X63.458 Y136.811 I-1.103 J-18.513 E.04282
G1 X40.219 Y160.05 E1.09019
G1 X39.234 Y160.05 E.03265
G1 X28.95 Y149.766 E.48245
G1 X28.95 Y151.394 E.05401
G1 X29.827 Y95.85 F30000
G1 F15476.087
G3 X28.95 Y95.399 I.729 J-2.492 E.0329
G1 X28.95 Y96.034 E.02105
G1 X52.705 Y119.788 E1.11436
G3 X56.807 Y116.215 I9.083 J6.285 E.18235
G1 X32.543 Y91.95 E1.13828
G1 X34.171 Y91.95 E.05401
; WIPE_START
G1 X32.543 Y91.95 E-.61876
G1 X32.805 Y92.213 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X31.531 Y91.619 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X31.192 Y91.559 E.00874
; LINE_WIDTH: 0.327704
G1 X31.026 Y91.537 E.00389
; LINE_WIDTH: 0.281529
G2 X30.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.244286
G2 X30.14 Y91.516 I-.337 J5.787 E.0115
; LINE_WIDTH: 0.283917
G1 X29.974 Y91.537 E.00329
; LINE_WIDTH: 0.327693
G1 X29.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X29.469 Y91.619 E.00873
G1 X28.619 Y92.469 F30000
; LINE_WIDTH: 0.354396
G1 F15000
G1 X28.559 Y92.808 E.00874
; LINE_WIDTH: 0.327704
G1 X28.537 Y92.974 E.00389
; LINE_WIDTH: 0.281529
G2 X28.514 Y93.159 I2.114 J.363 E.00363
; LINE_WIDTH: 0.2443
G2 X28.516 Y93.86 I5.789 J.336 E.0115
; LINE_WIDTH: 0.283917
G1 X28.537 Y94.026 E.00329
; LINE_WIDTH: 0.327693
G1 X28.559 Y94.192 E.00389
; LINE_WIDTH: 0.354386
G1 X28.619 Y94.531 E.00874
; CHANGE_LAYER
; Z_HEIGHT: 3.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X28.559 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 17/25
; update layer progress
M73 L17
M991 S0 P16 ;notify layer change
G17
G3 Z3.6 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z3.8 F30000
G1 X51.288 Y124.062 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.505 Y123.14 E.03142
G3 X60.507 Y115.466 I10.206 J2.854 E.41629
G1 X61.47 Y115.4 E.03202
G3 X51.28 Y124.122 I.241 J10.594 E1.72699
M204 S250
G1 X51.674 Y124.152 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.037 J1.843 E.3999
G1 X61.479 Y115.792 E.02856
G3 X51.663 Y124.211 I.232 J10.202 E1.5399
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37592
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03092
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.055 Z3.8 F30000
G1 X223.537 Y94.251 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.684 Y94.548 E.01101
G2 X227.227 Y94.688 I1.816 J-1.048 E.14015
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.727 J-1.188 E.24389
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.521 Y94.193 I1.188 J1.727 E.09076
M204 S250
G1 X223.901 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.31 Y91.806 I1.606 J-.58 E.09452
G3 X226.6 Y92.189 I.186 J1.736 E.04245
G3 X223.923 Y94.138 I-1.092 J1.313 E.19081
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13582
G1 X223.789 Y93.5 E-.11332
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11332
G1 X224.189 Y92.4 E-.11333
G1 X224.297 Y92.293 E-.05759
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03913
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z3.8 F30000
G1 X32.112 Y94.087 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X30.31 Y91.806 I-1.604 J-.585 E.22284
G3 X31.6 Y92.189 I.186 J1.736 E.04245
G3 X32.131 Y94.03 I-1.092 J1.313 E.0625
; WIPE_START
M204 S10000
G1 X31.982 Y94.355 E-.1361
G1 X31.811 Y94.6 E-.11332
G1 X31.6 Y94.811 E-.11333
G1 X31.355 Y94.982 E-.11332
G1 X31.085 Y95.108 E-.11332
G1 X30.797 Y95.185 E-.11332
G1 X30.647 Y95.198 E-.05729
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.73 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08593
G1 X28.888 Y92.147 E-.13936
G1 X28.773 Y92.312 E-.07628
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14117
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z3.8 F30000
G1 X227.79 Y91.21 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354373
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327687
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281538
G2 X225.841 Y91.514 I-.363 J2.118 E.00363
; LINE_WIDTH: 0.24429
G2 X225.14 Y91.516 I-.337 J5.785 E.0115
; LINE_WIDTH: 0.283917
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327693
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y92.469 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
G1 F15000
G1 X227.441 Y92.808 E.00873
; LINE_WIDTH: 0.327688
G1 X227.463 Y92.974 E.00389
; LINE_WIDTH: 0.283902
G1 X227.484 Y93.14 E.00329
; LINE_WIDTH: 0.244285
G3 X227.486 Y93.841 I-5.785 J.364 E.0115
; LINE_WIDTH: 0.281523
G3 X227.463 Y94.026 I-2.137 J-.178 E.00363
; LINE_WIDTH: 0.327686
G1 X227.441 Y94.192 E.00389
; LINE_WIDTH: 0.354377
G1 X227.381 Y94.531 E.00874
; WIPE_START
G1 X227.441 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.173 Y95.85 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X227.05 Y95.399 I-.729 J-2.493 E.0329
G1 X227.05 Y96.034 E.02105
G1 X163.034 Y160.05 E3.00311
G1 X162.05 Y160.05 E.03265
G1 X93.95 Y91.95 E3.19468
G1 X92.966 Y91.95 E.03265
G1 X67.927 Y116.989 E1.17464
G3 X69.189 Y118.015 I-7.415 J10.416 E.05398
; WIPE_START
G1 X67.927 Y116.989 E-.61792
G1 X68.191 Y116.725 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y124.345 Z3.8 F30000
G1 X69.189 Y133.985 Z3.8
G1 Z3.4
G1 E.8 F1800
G1 F15476.087
G3 X67.927 Y135.011 I-8.677 J-9.39 E.05398
G1 X92.966 Y160.05 E1.17464
M73 P51 R25
G1 X93.95 Y160.05 E.03265
G1 X162.05 Y91.95 E3.19468
G1 X163.034 Y91.95 E.03265
G1 X227.05 Y155.966 E3.00311
G1 X227.05 Y157.442 E.04894
G1 X224.442 Y160.05 E.12235
G1 X223.457 Y160.05 E.03265
G1 X155.358 Y91.95 E3.19468
G1 X154.374 Y91.95 E.03265
G1 X110.95 Y135.374 E2.03708
G1 X110.95 Y131.978 E.11264
G1 X139.022 Y160.05 E1.31689
G1 X140.006 Y160.05 E.03265
G1 X208.105 Y91.95 E3.19468
G1 X209.09 Y91.95 E.03265
G1 X227.05 Y109.91 E.84254
G1 X227.05 Y111.386 E.04894
G1 X178.386 Y160.05 E2.28292
G1 X177.402 Y160.05 E.03265
G1 X109.302 Y91.95 E3.19468
G1 X108.318 Y91.95 E.03265
G1 X72.511 Y127.757 E1.67977
G3 X71.493 Y130.9 I-9.768 J-1.429 E.11012
G1 X100.642 Y160.05 E1.36746
G1 X101.626 Y160.05 E.03265
G1 X169.726 Y91.95 E3.19468
G1 X170.71 Y91.95 E.03265
G1 X227.05 Y148.29 E2.64302
G1 X227.05 Y149.766 E.04894
G1 X216.766 Y160.05 E.48245
G1 X215.781 Y160.05 E.03265
G1 X147.682 Y91.95 E3.19468
G1 X146.698 Y91.95 E.03265
G1 X110.95 Y127.698 E1.67699
G1 X110.95 Y124.302 E.11264
G1 X146.698 Y160.05 E1.67699
G1 X147.682 Y160.05 E.03265
G1 X215.781 Y91.95 E3.19468
G1 X216.766 Y91.95 E.03265
G1 X227.05 Y102.234 E.48245
G1 X227.05 Y103.71 E.04894
G1 X170.71 Y160.05 E2.64302
G1 X169.726 Y160.05 E.03265
G1 X101.626 Y91.95 E3.19468
G1 X100.642 Y91.95 E.03265
G1 X71.493 Y121.1 E1.36746
G3 X72.511 Y124.243 I-8.75 J4.573 E.11012
G1 X108.318 Y160.05 E1.67977
G1 X109.302 Y160.05 E.03265
G1 X177.402 Y91.95 E3.19468
G1 X178.386 Y91.95 E.03265
G1 X227.05 Y140.614 E2.28292
G1 X227.05 Y142.09 E.04894
G1 X209.09 Y160.05 E.84254
G1 X208.105 Y160.05 E.03265
G1 X140.006 Y91.95 E3.19468
G1 X139.022 Y91.95 E.03265
G1 X110.95 Y120.022 E1.31689
G1 X110.95 Y116.626 E.11264
G1 X154.374 Y160.05 E2.03708
G1 X155.358 Y160.05 E.03265
M73 P51 R24
G1 X223.457 Y91.95 E3.19468
G1 X221.829 Y91.95 E.05401
G1 X110.95 Y141.282 F30000
G1 F15476.087
G1 X110.95 Y139.654 E.05401
G1 X131.346 Y160.05 E.9568
G1 X132.33 Y160.05 E.03265
G1 X200.429 Y91.95 E3.19468
G1 X201.414 Y91.95 E.03265
G1 X227.05 Y117.586 E1.20264
G1 X227.05 Y119.062 E.04894
G1 X186.062 Y160.05 E1.92283
G1 X185.078 Y160.05 E.03265
G1 X116.978 Y91.95 E3.19468
G1 X115.994 Y91.95 E.03265
G1 X47.895 Y160.05 E3.19468
G1 X46.91 Y160.05 E.03265
G1 X28.95 Y142.09 E.84254
G1 X28.95 Y140.614 E.04895
G1 X77.614 Y91.95 E2.28292
G1 X78.598 Y91.95 E.03265
G1 X99.05 Y112.402 E.95941
G1 X99.05 Y116.571 E.13829
G1 X55.571 Y160.05 E2.0397
G1 X54.586 Y160.05 E.03265
G1 X28.95 Y134.414 E1.20264
G1 X28.95 Y132.938 E.04895
G1 X69.938 Y91.95 E1.92283
G1 X70.922 Y91.95 E.03265
G1 X99.05 Y120.078 E1.31951
G1 X99.05 Y124.246 E.13829
G1 X63.246 Y160.05 E1.6796
G1 X62.262 Y160.05 E.03265
G1 X28.95 Y126.738 E1.56273
G1 X28.95 Y125.262 E.04895
G1 X62.262 Y91.95 E1.56273
G1 X63.246 Y91.95 E.03265
G1 X99.05 Y127.753 E1.6796
G1 X99.05 Y131.922 E.13829
G1 X70.922 Y160.05 E1.31951
G1 X69.938 Y160.05 E.03265
G1 X28.95 Y119.062 E1.92283
G1 X28.95 Y117.586 E.04894
G1 X54.586 Y91.95 E1.20264
G1 X55.571 Y91.95 E.03265
G1 X99.05 Y135.429 E2.0397
G1 X99.05 Y139.598 E.13829
G1 X78.598 Y160.05 E.95941
G1 X77.614 Y160.05 E.03265
G1 X28.95 Y111.386 E2.28292
G1 X28.95 Y109.91 E.04895
G1 X46.91 Y91.95 E.84254
G1 X47.895 Y91.95 E.03265
G1 X115.994 Y160.05 E3.19468
G1 X116.978 Y160.05 E.03265
G1 X185.078 Y91.95 E3.19468
G1 X186.062 Y91.95 E.03265
G1 X227.05 Y132.938 E1.92283
G1 X227.05 Y134.414 E.04894
G1 X201.414 Y160.05 E1.20264
G1 X200.429 Y160.05 E.03265
G1 X132.33 Y91.95 E3.19468
G1 X131.346 Y91.95 E.03265
G1 X110.95 Y112.346 E.9568
G1 X110.95 Y110.718 E.05401
; WIPE_START
G1 X110.95 Y112.346 E-.61876
G1 X111.213 Y112.083 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X104.278 Y115.271 Z3.8 F30000
G1 X58.312 Y136.402 Z3.8
G1 Z3.4
G1 E.8 F1800
G1 F15476.087
G3 X56.807 Y135.785 I2.624 J-8.548 E.05403
G1 X32.543 Y160.05 E1.13828
G1 X31.558 Y160.05 E.03265
G1 X28.95 Y157.442 E.12235
G1 X28.95 Y155.966 E.04895
G1 X52.705 Y132.212 E1.11436
G3 X51.874 Y130.813 I13.206 J-8.787 E.05398
G1 X28.95 Y151.394 F30000
G1 F15476.087
G1 X28.95 Y149.766 E.05401
G1 X39.234 Y160.05 E.48245
G1 X40.219 Y160.05 E.03265
G1 X63.458 Y136.811 E1.09019
G3 X62.173 Y136.932 I-2.388 J-18.384 E.04282
G1 X85.29 Y160.05 E1.08448
G1 X86.274 Y160.05 E.03265
G1 X104.374 Y141.95 E.84908
G1 X105.571 Y141.95 E.0397
G1 X123.67 Y160.05 E.84908
G1 X124.654 Y160.05 E.03265
G1 X192.754 Y91.95 E3.19468
G1 X193.738 Y91.95 E.03265
G1 X227.05 Y125.262 E1.56273
G1 X227.05 Y126.738 E.04895
G1 X193.738 Y160.05 E1.56273
G1 X192.753 Y160.05 E.03265
G1 X124.654 Y91.95 E3.19468
G1 X123.67 Y91.95 E.03265
G1 X105.571 Y110.05 E.84908
G1 X104.374 Y110.05 E.0397
G1 X86.274 Y91.95 E.84908
G1 X85.29 Y91.95 E.03265
G1 X62.173 Y115.068 E1.08448
G3 X63.458 Y115.189 I-1.103 J18.513 E.04282
G1 X40.219 Y91.95 E1.09019
G1 X39.234 Y91.95 E.03265
G1 X28.95 Y102.234 E.48245
G1 X28.95 Y103.71 E.04894
G1 X50.781 Y125.54 E1.0241
G2 X50.781 Y126.46 I5.034 J.46 E.03055
G1 X28.95 Y148.29 E1.0241
G1 X28.95 Y146.662 E.05401
; WIPE_START
G1 X28.95 Y148.29 E-.61876
G1 X29.213 Y148.027 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X29.128 Y140.395 Z3.8 F30000
G1 X28.619 Y94.531 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354386
G1 F15000
G1 X28.559 Y94.192 E.00874
; LINE_WIDTH: 0.327693
G1 X28.537 Y94.026 E.00389
; LINE_WIDTH: 0.283917
G1 X28.516 Y93.86 E.00329
; LINE_WIDTH: 0.2443
G3 X28.514 Y93.159 I5.787 J-.364 E.0115
; LINE_WIDTH: 0.281525
G3 X28.537 Y92.974 I2.139 J.178 E.00363
; LINE_WIDTH: 0.327686
G1 X28.559 Y92.808 E.00389
; LINE_WIDTH: 0.354377
G1 X28.619 Y92.469 E.00874
G1 X29.469 Y91.619 F30000
; LINE_WIDTH: 0.354386
G1 F15000
G1 X29.808 Y91.559 E.00873
; LINE_WIDTH: 0.327693
G1 X29.974 Y91.537 E.00389
; LINE_WIDTH: 0.283917
G1 X30.14 Y91.516 E.00329
; LINE_WIDTH: 0.24429
G3 X30.841 Y91.514 I.364 J5.783 E.0115
; LINE_WIDTH: 0.281539
G3 X31.026 Y91.537 I-.178 J2.142 E.00363
; LINE_WIDTH: 0.327691
G1 X31.192 Y91.559 E.00389
; LINE_WIDTH: 0.354377
G1 X31.531 Y91.619 E.00874
; WIPE_START
G1 X31.192 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X34.171 Y91.95 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X32.543 Y91.95 E.05401
G1 X56.807 Y116.215 E1.13828
G2 X52.705 Y119.788 I4.981 J9.859 E.18235
G1 X28.95 Y96.034 E1.11436
G1 X28.95 Y95.399 E.02105
G2 X29.827 Y95.85 I1.605 J-2.041 E.0329
; CHANGE_LAYER
; Z_HEIGHT: 3.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X29.273 Y95.625 E-.22714
G1 X28.95 Y95.399 E-.14974
G1 X28.95 Y96.034 E-.24118
G1 X29.214 Y96.298 E-.14195
; WIPE_END
G1 E-.03999 F1800
; layer num/total_layer_count: 18/25
; update layer progress
M73 L18
M991 S0 P17 ;notify layer change
G17
G3 Z3.8 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z4 F30000
G1 X51.288 Y124.062 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.505 Y123.14 E.03142
G3 X60.507 Y115.466 I10.206 J2.854 E.41629
G1 X61.47 Y115.4 E.03202
G3 X51.28 Y124.122 I.241 J10.594 E1.72699
M204 S250
G1 X51.674 Y124.152 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X60.551 Y115.856 I10.037 J1.843 E.3999
G1 X61.479 Y115.792 E.02856
G3 X51.663 Y124.211 I.232 J10.202 E1.5399
; WIPE_START
M204 S10000
G1 X51.879 Y123.245 E-.37592
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03092
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.053 Z4 F30000
G1 X223.514 Y94.186 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.53 Y94.217 E.00115
G2 X227.227 Y94.688 I1.97 J-.717 E.15229
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.732 J-1.184 E.24448
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.435 Y93.864 I1.188 J1.727 E.07947
G1 X223.499 Y94.128 E.00902
M204 S250
G1 X223.901 Y94.082 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X225.299 Y91.807 I1.606 J-.58 E.09422
G3 X226.6 Y92.189 I.195 J1.737 E.04277
G3 X223.922 Y94.138 I-1.093 J1.312 E.19082
; WIPE_START
M204 S10000
G1 X223.815 Y93.797 E-.13583
G1 X223.789 Y93.5 E-.11331
G1 X223.815 Y93.203 E-.11331
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11333
G1 X224.189 Y92.4 E-.1133
G1 X224.297 Y92.293 E-.05759
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24923
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03912
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z4 F30000
G1 X32.112 Y94.087 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X30.299 Y91.807 I-1.605 J-.585 E.22255
G3 X31.6 Y92.189 I.195 J1.737 E.04277
G3 X32.131 Y94.03 I-1.093 J1.312 E.06249
; WIPE_START
M204 S10000
G1 X31.982 Y94.355 E-.1361
G1 X31.811 Y94.6 E-.11332
G1 X31.6 Y94.811 E-.11333
G1 X31.355 Y94.982 E-.11333
G1 X31.085 Y95.108 E-.11331
G1 X30.797 Y95.185 E-.11332
G1 X30.647 Y95.198 E-.05729
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.191 J1.73 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08591
G1 X28.888 Y92.147 E-.13943
G1 X28.773 Y92.312 E-.07624
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14115
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z4 F30000
G1 X227.79 Y91.21 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327686
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281525
G2 X225.841 Y91.514 I-.363 J2.116 E.00363
; LINE_WIDTH: 0.244295
G2 X225.14 Y91.516 I-.336 J5.793 E.0115
; LINE_WIDTH: 0.283902
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327688
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
M73 P52 R24
G1 X221.829 Y91.95 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.457 Y91.95 E.05401
G1 X155.358 Y160.05 E3.19468
G1 X154.374 Y160.05 E.03265
G1 X110.95 Y116.626 E2.03708
G1 X110.95 Y120.022 E.11264
G1 X139.022 Y91.95 E1.31689
G1 X140.006 Y91.95 E.03265
G1 X208.105 Y160.05 E3.19468
G1 X209.09 Y160.05 E.03265
G1 X227.05 Y142.09 E.84254
G1 X227.05 Y140.614 E.04895
G1 X178.386 Y91.95 E2.28292
G1 X177.402 Y91.95 E.03265
G1 X109.302 Y160.05 E3.19468
G1 X108.318 Y160.05 E.03265
G1 X72.511 Y124.243 E1.67977
G2 X71.493 Y121.1 I-9.768 J1.429 E.11012
G1 X100.642 Y91.95 E1.36746
G1 X101.626 Y91.95 E.03265
G1 X169.726 Y160.05 E3.19468
G1 X170.71 Y160.05 E.03265
G1 X227.05 Y103.71 E2.64302
G1 X227.05 Y102.234 E.04895
G1 X216.766 Y91.95 E.48245
G1 X215.781 Y91.95 E.03265
G1 X147.682 Y160.05 E3.19468
G1 X146.698 Y160.05 E.03265
G1 X110.95 Y124.302 E1.67699
G1 X110.95 Y127.698 E.11264
G1 X146.698 Y91.95 E1.67699
G1 X147.682 Y91.95 E.03265
G1 X215.781 Y160.05 E3.19468
G1 X216.766 Y160.05 E.03265
G1 X227.05 Y149.766 E.48245
G1 X227.05 Y148.29 E.04894
G1 X170.71 Y91.95 E2.64302
G1 X169.726 Y91.95 E.03265
G1 X101.626 Y160.05 E3.19468
G1 X100.642 Y160.05 E.03265
G1 X71.493 Y130.9 E1.36746
G2 X72.511 Y127.757 I-8.749 J-4.572 E.11012
G1 X108.318 Y91.95 E1.67977
G1 X109.302 Y91.95 E.03265
G1 X177.402 Y160.05 E3.19468
G1 X178.386 Y160.05 E.03265
G1 X227.05 Y111.386 E2.28292
G1 X227.05 Y109.91 E.04895
G1 X209.09 Y91.95 E.84254
G1 X208.105 Y91.95 E.03265
G1 X140.006 Y160.05 E3.19468
G1 X139.022 Y160.05 E.03265
G1 X110.95 Y131.978 E1.31689
G1 X110.95 Y135.374 E.11264
G1 X154.374 Y91.95 E2.03708
G1 X155.358 Y91.95 E.03265
G1 X223.457 Y160.05 E3.19468
G1 X224.442 Y160.05 E.03265
G1 X227.05 Y157.442 E.12235
G1 X227.05 Y155.966 E.04894
G1 X163.034 Y91.95 E3.00311
G1 X162.05 Y91.95 E.03265
G1 X93.95 Y160.05 E3.19468
G1 X92.966 Y160.05 E.03265
G1 X67.927 Y135.011 E1.17464
G2 X69.189 Y133.985 I-7.415 J-10.416 E.05398
; WIPE_START
G1 X67.927 Y135.011 E-.61792
G1 X68.191 Y135.275 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y127.655 Z4 F30000
G1 X69.189 Y118.015 Z4
G1 Z3.6
G1 E.8 F1800
G1 F15476.087
G2 X67.927 Y116.989 I-8.677 J9.391 E.05398
G1 X92.966 Y91.95 E1.17464
G1 X93.95 Y91.95 E.03265
G1 X162.05 Y160.05 E3.19468
G1 X163.034 Y160.05 E.03265
G1 X227.05 Y96.034 E3.00311
G1 X227.05 Y95.399 E.02105
G3 X226.173 Y95.85 I-1.605 J-2.042 E.0329
; WIPE_START
G1 X226.727 Y95.625 E-.22719
G1 X227.05 Y95.399 E-.14969
G1 X227.05 Y96.034 E-.24118
G1 X226.786 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y94.531 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354358
G1 F15000
G1 X227.441 Y94.192 E.00873
; LINE_WIDTH: 0.327682
G1 X227.463 Y94.026 E.00389
; LINE_WIDTH: 0.281522
G2 X227.486 Y93.841 I-2.117 J-.363 E.00363
; LINE_WIDTH: 0.244295
G2 X227.484 Y93.14 I-5.788 J-.336 E.0115
; LINE_WIDTH: 0.283913
G1 X227.463 Y92.974 E.00329
; LINE_WIDTH: 0.327691
G1 X227.441 Y92.808 E.00389
; LINE_WIDTH: 0.354364
G1 X227.381 Y92.469 E.00873
; WIPE_START
G1 X227.441 Y92.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.357 Y100.44 Z4 F30000
G1 X227.05 Y128.366 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X227.05 Y126.738 E.05401
G1 X193.738 Y160.05 E1.56273
G1 X192.753 Y160.05 E.03265
G1 X124.654 Y91.95 E3.19468
G1 X123.67 Y91.95 E.03265
G1 X105.571 Y110.05 E.84908
G1 X104.374 Y110.05 E.0397
G1 X86.274 Y91.95 E.84908
G1 X85.29 Y91.95 E.03265
G1 X62.173 Y115.068 E1.08448
G3 X63.458 Y115.189 I-1.103 J18.513 E.04282
G1 X40.219 Y91.95 E1.09019
G1 X39.234 Y91.95 E.03265
G1 X28.95 Y102.234 E.48245
G1 X28.95 Y103.71 E.04894
G1 X50.781 Y125.54 E1.0241
G2 X50.781 Y126.46 I5.034 J.46 E.03055
G1 X28.95 Y148.29 E1.0241
G1 X28.95 Y149.766 E.04895
G1 X39.234 Y160.05 E.48245
G1 X40.219 Y160.05 E.03265
G1 X63.458 Y136.811 E1.09019
G3 X62.173 Y136.932 I-2.388 J-18.391 E.04282
G1 X85.29 Y160.05 E1.08448
G1 X86.274 Y160.05 E.03265
G1 X104.374 Y141.95 E.84908
G1 X105.571 Y141.95 E.0397
G1 X123.67 Y160.05 E.84908
G1 X124.654 Y160.05 E.03265
G1 X192.754 Y91.95 E3.19468
G1 X193.738 Y91.95 E.03265
G1 X227.05 Y125.262 E1.56273
G1 X227.05 Y123.634 E.05401
G1 X110.95 Y110.718 F30000
G1 F15476.087
G1 X110.95 Y112.346 E.05401
G1 X131.346 Y91.95 E.9568
G1 X132.33 Y91.95 E.03265
G1 X200.429 Y160.05 E3.19468
G1 X201.414 Y160.05 E.03265
G1 X227.05 Y134.414 E1.20264
G1 X227.05 Y132.938 E.04894
G1 X186.062 Y91.95 E1.92283
G1 X185.078 Y91.95 E.03265
G1 X116.978 Y160.05 E3.19468
G1 X115.994 Y160.05 E.03265
G1 X47.895 Y91.95 E3.19468
G1 X46.91 Y91.95 E.03265
G1 X28.95 Y109.91 E.84254
G1 X28.95 Y111.386 E.04895
G1 X77.614 Y160.05 E2.28292
G1 X78.598 Y160.05 E.03265
G1 X99.05 Y139.598 E.95941
G1 X99.05 Y135.429 E.13829
G1 X55.571 Y91.95 E2.0397
G1 X54.586 Y91.95 E.03265
G1 X28.95 Y117.586 E1.20264
G1 X28.95 Y119.062 E.04894
G1 X69.938 Y160.05 E1.92283
G1 X70.922 Y160.05 E.03265
G1 X99.05 Y131.922 E1.31951
G1 X99.05 Y127.753 E.13829
G1 X63.246 Y91.95 E1.6796
G1 X62.262 Y91.95 E.03265
G1 X28.95 Y125.262 E1.56273
G1 X28.95 Y126.738 E.04895
G1 X62.262 Y160.05 E1.56273
G1 X63.246 Y160.05 E.03265
G1 X99.05 Y124.246 E1.6796
G1 X99.05 Y120.078 E.13829
G1 X70.922 Y91.95 E1.31951
G1 X69.938 Y91.95 E.03265
G1 X28.95 Y132.938 E1.92283
G1 X28.95 Y134.414 E.04895
G1 X54.586 Y160.05 E1.20264
G1 X55.571 Y160.05 E.03265
G1 X99.05 Y116.571 E2.0397
G1 X99.05 Y112.402 E.13829
G1 X78.598 Y91.95 E.95941
G1 X77.614 Y91.95 E.03265
G1 X28.95 Y140.614 E2.28292
G1 X28.95 Y142.09 E.04895
G1 X46.91 Y160.05 E.84254
G1 X47.895 Y160.05 E.03265
G1 X115.994 Y91.95 E3.19468
G1 X116.978 Y91.95 E.03265
G1 X185.078 Y160.05 E3.19468
G1 X186.062 Y160.05 E.03265
G1 X227.05 Y119.062 E1.92283
G1 X227.05 Y117.586 E.04894
G1 X201.414 Y91.95 E1.20264
G1 X200.429 Y91.95 E.03265
G1 X132.33 Y160.05 E3.19468
G1 X131.346 Y160.05 E.03265
G1 X110.95 Y139.654 E.9568
G1 X110.95 Y141.282 E.05401
; WIPE_START
G1 X110.95 Y139.654 E-.61876
G1 X111.213 Y139.917 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X103.669 Y138.76 Z4 F30000
G1 X51.874 Y130.813 Z4
G1 Z3.6
G1 E.8 F1800
G1 F15476.087
G2 X52.705 Y132.212 I14.036 J-7.388 E.05398
G1 X28.95 Y155.966 E1.11436
G1 X28.95 Y157.442 E.04895
G1 X31.558 Y160.05 E.12235
G1 X32.543 Y160.05 E.03265
G1 X56.807 Y135.785 E1.13828
G2 X58.312 Y136.402 I4.129 J-7.931 E.05403
; WIPE_START
G1 X56.807 Y135.785 E-.61812
G1 X56.543 Y136.049 E-.14188
; WIPE_END
G1 E-.04 F1800
G1 X52.318 Y129.693 Z4 F30000
G1 X29.827 Y95.85 Z4
G1 Z3.6
G1 E.8 F1800
G1 F15476.087
G3 X28.95 Y95.399 I.729 J-2.492 E.0329
G1 X28.95 Y96.034 E.02105
G1 X52.705 Y119.788 E1.11436
G3 X56.807 Y116.215 I9.083 J6.285 E.18235
G1 X32.543 Y91.95 E1.13828
G1 X34.171 Y91.95 E.05401
; WIPE_START
G1 X32.543 Y91.95 E-.61876
G1 X32.805 Y92.213 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X31.531 Y91.619 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X31.192 Y91.559 E.00874
; LINE_WIDTH: 0.327686
G1 X31.026 Y91.537 E.00389
; LINE_WIDTH: 0.281525
G2 X30.841 Y91.514 I-.363 J2.115 E.00363
; LINE_WIDTH: 0.244291
G2 X30.14 Y91.516 I-.337 J5.787 E.0115
; LINE_WIDTH: 0.283902
G1 X29.974 Y91.537 E.00329
; LINE_WIDTH: 0.327688
G1 X29.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X29.469 Y91.619 E.00873
G1 X28.619 Y92.469 F30000
; LINE_WIDTH: 0.354377
G1 F15000
G1 X28.559 Y92.808 E.00873
; LINE_WIDTH: 0.3277
G1 X28.537 Y92.974 E.00389
; LINE_WIDTH: 0.281529
G2 X28.514 Y93.159 I2.116 J.363 E.00363
; LINE_WIDTH: 0.2443
G2 X28.516 Y93.86 I5.788 J.336 E.0115
; LINE_WIDTH: 0.283917
G1 X28.537 Y94.026 E.00329
; LINE_WIDTH: 0.327693
G1 X28.559 Y94.192 E.00389
; LINE_WIDTH: 0.354386
G1 X28.619 Y94.531 E.00874
; CHANGE_LAYER
; Z_HEIGHT: 3.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X28.559 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 19/25
; update layer progress
M73 L19
M991 S0 P18 ;notify layer change
G17
G3 Z4 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.899 Y138.97 Z4.2 F30000
G1 X51.281 Y124.098 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.288 Y124.081 E.00061
G3 X60.507 Y115.466 I10.423 J1.914 E.44831
G1 X61.47 Y115.4 E.03202
G3 X51.157 Y125.036 I.241 J10.594 E1.69637
G1 X51.273 Y124.157 E.02942
M204 S250
G1 X51.67 Y124.151 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X51.674 Y124.152 E.00013
G3 X60.551 Y115.856 I10.037 J1.843 E.3999
G1 X61.479 Y115.792 E.02856
G3 X51.548 Y125.072 I.232 J10.202 E1.51319
G1 X51.662 Y124.21 E.0267
; WIPE_START
M204 S10000
G1 X51.674 Y124.152 E-.02283
G1 X51.879 Y123.245 E-.35315
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03086
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.056 Z4.2 F30000
G1 X223.537 Y94.251 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.684 Y94.548 E.011
G2 X227.227 Y94.688 I1.816 J-1.048 E.14015
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.732 J-1.184 E.24448
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.522 Y94.193 I1.188 J1.727 E.09077
M204 S250
G1 X223.892 Y94.085 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X223.903 Y94.081 E.00034
G3 X225.289 Y91.808 I1.605 J-.581 E.09384
G3 X226.355 Y92.018 I.226 J1.66 E.03402
G3 X224.028 Y94.35 I-.847 J1.482 E.19265
G1 X223.92 Y94.139 E.00729
; WIPE_START
M204 S10000
G1 X223.903 Y94.081 E-.02277
G1 X223.815 Y93.797 E-.11304
G1 X223.789 Y93.5 E-.11331
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11331
G1 X224.018 Y92.645 E-.11333
G1 X224.189 Y92.4 E-.1133
G1 X224.297 Y92.293 E-.05762
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.731 J1.192 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03913
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z4.2 F30000
G1 X32.107 Y94.086 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X31.985 Y94.357 E.00915
G3 X30.289 Y91.808 I-1.477 J-.857 E.21286
M73 P53 R24
G3 X31.355 Y92.018 I.226 J1.661 E.03402
G3 X32.13 Y94.035 I-.847 J1.482 E.07185
; WIPE_START
M204 S10000
G1 X31.985 Y94.357 E-.13449
G1 X31.811 Y94.6 E-.11343
G1 X31.6 Y94.811 E-.11336
G1 X31.355 Y94.982 E-.11329
G1 X31.085 Y95.108 E-.11334
G1 X30.797 Y95.185 E-.11332
G1 X30.643 Y95.198 E-.05877
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.731 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08591
G1 X28.888 Y92.147 E-.13942
G1 X28.773 Y92.312 E-.07624
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14115
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z4.2 F30000
G1 X227.79 Y91.21 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
M73 P53 R23
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327686
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281525
G2 X225.841 Y91.514 I-.363 J2.116 E.00363
; LINE_WIDTH: 0.244295
G2 X225.14 Y91.516 I-.336 J5.793 E.0115
; LINE_WIDTH: 0.283917
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327693
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354386
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y92.469 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.354364
G1 F15000
G1 X227.441 Y92.808 E.00874
; LINE_WIDTH: 0.327691
G1 X227.463 Y92.974 E.00389
; LINE_WIDTH: 0.283913
G1 X227.484 Y93.14 E.00329
; LINE_WIDTH: 0.244295
G3 X227.486 Y93.841 I-5.787 J.364 E.0115
; LINE_WIDTH: 0.281523
G3 X227.463 Y94.026 I-2.137 J-.178 E.00363
; LINE_WIDTH: 0.327686
G1 X227.441 Y94.192 E.00389
; LINE_WIDTH: 0.354377
G1 X227.381 Y94.531 E.00874
; WIPE_START
G1 X227.441 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.173 Y95.85 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X227.05 Y95.399 I-.729 J-2.493 E.0329
G1 X227.05 Y96.034 E.02105
G1 X163.034 Y160.05 E3.00311
G1 X162.05 Y160.05 E.03265
G1 X93.95 Y91.95 E3.19468
G1 X92.966 Y91.95 E.03265
G1 X67.927 Y116.989 E1.17464
G3 X69.189 Y118.015 I-7.415 J10.416 E.05398
; WIPE_START
G1 X67.927 Y116.989 E-.61792
G1 X68.191 Y116.725 E-.14208
; WIPE_END
G1 E-.04 F1800
G1 X68.632 Y124.345 Z4.2 F30000
G1 X69.189 Y133.985 Z4.2
G1 Z3.8
G1 E.8 F1800
G1 F15476.087
G3 X67.927 Y135.01 I-8.674 J-9.387 E.05398
G1 X92.966 Y160.05 E1.17464
G1 X93.95 Y160.05 E.03265
G1 X162.05 Y91.95 E3.19468
G1 X163.034 Y91.95 E.03265
G1 X227.05 Y155.966 E3.00311
G1 X227.05 Y157.442 E.04894
G1 X224.442 Y160.05 E.12235
G1 X223.457 Y160.05 E.03265
G1 X155.358 Y91.95 E3.19468
G1 X154.374 Y91.95 E.03265
G1 X110.95 Y135.374 E2.03708
G1 X110.95 Y131.978 E.11264
G1 X139.022 Y160.05 E1.31689
G1 X140.006 Y160.05 E.03265
G1 X208.105 Y91.95 E3.19468
G1 X209.09 Y91.95 E.03265
G1 X227.05 Y109.91 E.84254
G1 X227.05 Y111.386 E.04894
G1 X178.386 Y160.05 E2.28292
G1 X177.402 Y160.05 E.03265
G1 X109.302 Y91.95 E3.19468
G1 X108.318 Y91.95 E.03265
G1 X72.511 Y127.757 E1.67977
G3 X71.493 Y130.9 I-9.768 J-1.429 E.11012
G1 X100.642 Y160.05 E1.36746
G1 X101.626 Y160.05 E.03265
G1 X169.726 Y91.95 E3.19468
G1 X170.71 Y91.95 E.03265
G1 X227.05 Y148.29 E2.64302
G1 X227.05 Y149.766 E.04894
G1 X216.766 Y160.05 E.48245
G1 X215.781 Y160.05 E.03265
G1 X147.682 Y91.95 E3.19468
G1 X146.698 Y91.95 E.03265
G1 X110.95 Y127.698 E1.67699
G1 X110.95 Y124.302 E.11264
G1 X146.698 Y160.05 E1.67699
G1 X147.682 Y160.05 E.03265
G1 X215.781 Y91.95 E3.19468
G1 X216.766 Y91.95 E.03265
G1 X227.05 Y102.234 E.48245
G1 X227.05 Y103.71 E.04894
G1 X170.71 Y160.05 E2.64302
G1 X169.726 Y160.05 E.03265
G1 X101.626 Y91.95 E3.19468
G1 X100.642 Y91.95 E.03265
G1 X71.493 Y121.1 E1.36746
G3 X72.511 Y124.243 I-8.751 J4.573 E.11012
G1 X108.318 Y160.05 E1.67977
G1 X109.302 Y160.05 E.03265
G1 X177.402 Y91.95 E3.19468
G1 X178.386 Y91.95 E.03265
G1 X227.05 Y140.614 E2.28292
G1 X227.05 Y142.09 E.04894
G1 X209.09 Y160.05 E.84254
G1 X208.105 Y160.05 E.03265
G1 X140.006 Y91.95 E3.19468
G1 X139.022 Y91.95 E.03265
G1 X110.95 Y120.022 E1.31689
G1 X110.95 Y116.626 E.11264
G1 X154.374 Y160.05 E2.03708
G1 X155.358 Y160.05 E.03265
G1 X223.457 Y91.95 E3.19468
G1 X221.829 Y91.95 E.05401
G1 X110.95 Y141.282 F30000
G1 F15476.087
G1 X110.95 Y139.654 E.05401
G1 X131.346 Y160.05 E.9568
G1 X132.33 Y160.05 E.03265
G1 X200.429 Y91.95 E3.19468
G1 X201.414 Y91.95 E.03265
G1 X227.05 Y117.586 E1.20264
G1 X227.05 Y119.062 E.04894
G1 X186.062 Y160.05 E1.92283
G1 X185.078 Y160.05 E.03265
G1 X116.978 Y91.95 E3.19468
G1 X115.994 Y91.95 E.03265
G1 X47.895 Y160.05 E3.19468
G1 X46.91 Y160.05 E.03265
G1 X28.95 Y142.09 E.84254
G1 X28.95 Y140.614 E.04895
G1 X77.614 Y91.95 E2.28292
G1 X78.598 Y91.95 E.03265
G1 X99.05 Y112.402 E.95941
G1 X99.05 Y116.571 E.13829
G1 X55.571 Y160.05 E2.0397
G1 X54.586 Y160.05 E.03265
G1 X28.95 Y134.414 E1.20264
G1 X28.95 Y132.938 E.04895
G1 X69.938 Y91.95 E1.92283
G1 X70.922 Y91.95 E.03265
G1 X99.05 Y120.078 E1.31951
G1 X99.05 Y124.246 E.13829
G1 X63.246 Y160.05 E1.6796
G1 X62.262 Y160.05 E.03265
G1 X28.95 Y126.738 E1.56273
G1 X28.95 Y125.262 E.04895
G1 X62.262 Y91.95 E1.56273
G1 X63.246 Y91.95 E.03265
G1 X99.05 Y127.753 E1.6796
G1 X99.05 Y131.922 E.13829
G1 X70.922 Y160.05 E1.31951
G1 X69.938 Y160.05 E.03265
G1 X28.95 Y119.062 E1.92283
G1 X28.95 Y117.586 E.04894
G1 X54.586 Y91.95 E1.20264
G1 X55.571 Y91.95 E.03265
G1 X99.05 Y135.429 E2.0397
G1 X99.05 Y139.598 E.13829
G1 X78.598 Y160.05 E.95941
G1 X77.614 Y160.05 E.03265
G1 X28.95 Y111.386 E2.28292
G1 X28.95 Y109.91 E.04895
G1 X46.91 Y91.95 E.84254
G1 X47.895 Y91.95 E.03265
G1 X115.994 Y160.05 E3.19468
G1 X116.978 Y160.05 E.03265
G1 X185.078 Y91.95 E3.19468
G1 X186.062 Y91.95 E.03265
G1 X227.05 Y132.938 E1.92283
G1 X227.05 Y134.414 E.04894
G1 X201.414 Y160.05 E1.20264
G1 X200.429 Y160.05 E.03265
G1 X132.33 Y91.95 E3.19468
G1 X131.346 Y91.95 E.03265
G1 X110.95 Y112.346 E.9568
G1 X110.95 Y110.718 E.05401
; WIPE_START
G1 X110.95 Y112.346 E-.61876
G1 X111.213 Y112.083 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X104.278 Y115.271 Z4.2 F30000
G1 X58.312 Y136.402 Z4.2
G1 Z3.8
G1 E.8 F1800
G1 F15476.087
G3 X56.807 Y135.785 I2.624 J-8.548 E.05403
G1 X32.543 Y160.05 E1.13828
G1 X31.558 Y160.05 E.03265
G1 X28.95 Y157.442 E.12235
G1 X28.95 Y155.966 E.04895
G1 X52.705 Y132.212 E1.11436
G3 X51.874 Y130.813 I13.206 J-8.787 E.05398
G1 X28.95 Y151.394 F30000
G1 F15476.087
G1 X28.95 Y149.766 E.05401
G1 X39.234 Y160.05 E.48245
G1 X40.219 Y160.05 E.03265
G1 X63.458 Y136.811 E1.09019
G3 X62.173 Y136.932 I-2.388 J-18.382 E.04282
G1 X85.29 Y160.05 E1.08448
G1 X86.274 Y160.05 E.03265
G1 X104.374 Y141.95 E.84908
G1 X105.571 Y141.95 E.0397
G1 X123.67 Y160.05 E.84908
G1 X124.654 Y160.05 E.03265
G1 X192.754 Y91.95 E3.19468
G1 X193.738 Y91.95 E.03265
G1 X227.05 Y125.262 E1.56273
G1 X227.05 Y126.738 E.04895
G1 X193.738 Y160.05 E1.56273
G1 X192.753 Y160.05 E.03265
G1 X124.654 Y91.95 E3.19468
G1 X123.67 Y91.95 E.03265
G1 X105.571 Y110.05 E.84908
G1 X104.374 Y110.05 E.0397
G1 X86.274 Y91.95 E.84908
G1 X85.29 Y91.95 E.03265
G1 X62.173 Y115.068 E1.08448
G3 X63.458 Y115.189 I-1.104 J18.515 E.04282
G1 X40.219 Y91.95 E1.09019
G1 X39.234 Y91.95 E.03265
G1 X28.95 Y102.234 E.48245
G1 X28.95 Y103.71 E.04894
G1 X50.781 Y125.54 E1.0241
G2 X50.781 Y126.46 I5.034 J.46 E.03055
G1 X28.95 Y148.29 E1.0241
G1 X28.95 Y146.662 E.05401
; WIPE_START
G1 X28.95 Y148.29 E-.61876
G1 X29.213 Y148.027 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X29.128 Y140.395 Z4.2 F30000
G1 X28.619 Y94.531 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354386
G1 F15000
G1 X28.559 Y94.192 E.00873
; LINE_WIDTH: 0.327693
G1 X28.537 Y94.026 E.00389
; LINE_WIDTH: 0.283917
G1 X28.516 Y93.86 E.00329
; LINE_WIDTH: 0.2443
G3 X28.514 Y93.159 I5.787 J-.364 E.0115
; LINE_WIDTH: 0.281529
G3 X28.537 Y92.974 I2.14 J.178 E.00363
; LINE_WIDTH: 0.3277
G1 X28.559 Y92.808 E.00389
; LINE_WIDTH: 0.354377
G1 X28.619 Y92.469 E.00873
G1 X29.469 Y91.619 F30000
; LINE_WIDTH: 0.354386
G1 F15000
G1 X29.808 Y91.559 E.00873
; LINE_WIDTH: 0.327708
G1 X29.974 Y91.537 E.00389
; LINE_WIDTH: 0.283922
G1 X30.14 Y91.516 E.00329
; LINE_WIDTH: 0.244295
G3 X30.841 Y91.514 I.364 J5.792 E.0115
; LINE_WIDTH: 0.281528
G3 X31.026 Y91.537 I-.178 J2.137 E.00363
; LINE_WIDTH: 0.3277
G1 X31.192 Y91.559 E.00389
; LINE_WIDTH: 0.354377
G1 X31.531 Y91.619 E.00874
; WIPE_START
G1 X31.192 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X34.171 Y91.95 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X32.543 Y91.95 E.05401
G1 X56.807 Y116.215 E1.13828
G2 X52.705 Y119.788 I4.981 J9.859 E.18235
G1 X28.95 Y96.034 E1.11436
G1 X28.95 Y95.399 E.02105
G2 X29.827 Y95.85 I1.605 J-2.041 E.0329
; CHANGE_LAYER
; Z_HEIGHT: 4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X29.273 Y95.625 E-.22718
G1 X28.95 Y95.399 E-.1497
G1 X28.95 Y96.034 E-.24118
G1 X29.214 Y96.298 E-.14195
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 20/25
; update layer progress
M73 L20
M991 S0 P19 ;notify layer change
G17
G3 Z4.2 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.899 Y138.97 Z4.4 F30000
G1 X51.281 Y124.098 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.284 Y124.08 E.0006
G3 X60.507 Y115.466 I10.427 J1.919 E.44836
G1 X61.47 Y115.4 E.03202
G3 X51.153 Y125.036 I.241 J10.599 E1.69728
G1 X51.273 Y124.157 E.02942
M204 S250
G1 X51.67 Y124.151 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X51.67 Y124.151 E.00002
G3 X60.551 Y115.856 I10.041 J1.848 E.39995
G1 X61.479 Y115.792 E.02856
G3 X51.544 Y125.071 I.232 J10.207 E1.51402
G1 X51.661 Y124.21 E.0267
; WIPE_START
M204 S10000
G1 X51.67 Y124.151 E-.02287
G1 X51.879 Y123.245 E-.35321
G1 X52.171 Y122.363 E-.35315
G1 X52.203 Y122.288 E-.03077
; WIPE_END
G1 E-.04 F1800
M73 P54 R23
G1 X59.735 Y121.053 Z4.4 F30000
G1 X223.514 Y94.186 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.53 Y94.217 E.00116
G2 X227.227 Y94.688 I1.97 J-.717 E.15229
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17793
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.732 J-1.184 E.24448
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.435 Y93.864 I1.188 J1.727 E.07947
G1 X223.499 Y94.128 E.00901
M204 S250
G1 X223.893 Y94.085 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X223.902 Y94.082 E.00032
G3 X225.279 Y91.809 I1.606 J-.581 E.09357
G3 X226.355 Y92.018 I.235 J1.663 E.03434
G3 X224.027 Y94.351 I-.848 J1.482 E.19266
G1 X223.92 Y94.139 E.00729
; WIPE_START
M204 S10000
G1 X223.902 Y94.082 E-.02281
G1 X223.815 Y93.797 E-.11304
G1 X223.789 Y93.5 E-.11332
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11331
G1 X224.018 Y92.645 E-.11332
G1 X224.189 Y92.4 E-.11333
G1 X224.297 Y92.293 E-.05754
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07628
G1 X227.039 Y92.075 E-.03911
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z4.4 F30000
G1 X32.107 Y94.086 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X31.985 Y94.357 E.00914
G3 X30.279 Y91.809 I-1.477 J-.857 E.21261
G3 X31.355 Y92.018 I.235 J1.663 E.03434
G3 X32.13 Y94.034 I-.848 J1.482 E.07183
; WIPE_START
M204 S10000
G1 X31.985 Y94.357 E-.13455
G1 X31.811 Y94.6 E-.11346
G1 X31.6 Y94.811 E-.11331
G1 X31.355 Y94.982 E-.1133
G1 X31.085 Y95.108 E-.11335
G1 X30.797 Y95.185 E-.11331
G1 X30.643 Y95.198 E-.05872
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.731 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08591
G1 X28.888 Y92.147 E-.13944
G1 X28.773 Y92.312 E-.07623
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14116
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z4.4 F30000
G1 X227.79 Y91.21 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00873
; LINE_WIDTH: 0.327704
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281529
G2 X225.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.24429
G2 X225.14 Y91.516 I-.336 J5.788 E.0115
; LINE_WIDTH: 0.283913
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327691
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354384
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y92.469 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; LINE_WIDTH: 0.354364
G1 F15000
G1 X227.441 Y92.808 E.00873
; LINE_WIDTH: 0.327691
G1 X227.463 Y92.974 E.00389
; LINE_WIDTH: 0.283913
G1 X227.484 Y93.14 E.00329
; LINE_WIDTH: 0.244295
G3 X227.486 Y93.841 I-5.787 J.364 E.0115
; LINE_WIDTH: 0.281522
G3 X227.463 Y94.026 I-2.141 J-.178 E.00363
; LINE_WIDTH: 0.327682
G1 X227.441 Y94.192 E.00389
; LINE_WIDTH: 0.354358
G1 X227.381 Y94.531 E.00873
; WIPE_START
G1 X227.441 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X225.429 Y96.326 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X226.673 Y96.067 I.169 J-2.298 E.04271
G1 X226.673 Y96.411 E.01142
G1 X163.411 Y159.673 E2.96772
G1 X161.673 Y159.673 E.05767
G1 X94.327 Y92.327 E3.15929
G1 X92.589 Y92.327 E.05767
G1 X68.2 Y116.716 E1.14414
G3 X71.774 Y120.818 I-6.658 J9.411 E.18219
G1 X100.265 Y92.327 E1.33654
G1 X102.003 Y92.327 E.05767
G1 X169.348 Y159.673 E3.15929
G1 X171.087 Y159.673 E.05767
G1 X226.673 Y104.087 E2.60763
G1 X226.673 Y101.857 E.07397
G1 X217.143 Y92.327 E.44706
G1 X215.404 Y92.327 E.05767
G1 X148.059 Y159.673 E3.15929
G1 X146.321 Y159.673 E.05767
G1 X111.327 Y124.679 E1.6416
G1 X111.327 Y127.321 E.08761
G1 X146.321 Y92.327 E1.6416
G1 X148.059 Y92.327 E.05767
G1 X215.404 Y159.673 E3.15929
G1 X217.143 Y159.672 E.05767
G1 X226.673 Y150.143 E.44706
G1 X226.673 Y147.913 E.07397
G1 X171.087 Y92.327 E2.60763
G1 X169.348 Y92.327 E.05767
G1 X102.003 Y159.673 E3.15929
G1 X100.265 Y159.673 E.05767
G1 X71.774 Y131.182 E1.33654
G3 X68.2 Y135.284 I-10.232 J-5.309 E.18219
G1 X92.589 Y159.673 E1.14414
G1 X94.327 Y159.673 E.05767
G1 X161.673 Y92.327 E3.15929
G1 X163.411 Y92.327 E.05767
G1 X226.673 Y155.589 E2.96772
G1 X226.673 Y157.819 E.07397
G1 X224.819 Y159.672 E.08696
G1 X223.08 Y159.673 E.05767
G1 X155.735 Y92.327 E3.15929
G1 X153.997 Y92.327 E.05767
G1 X111.327 Y134.997 E2.00169
G1 X111.327 Y132.355 E.08761
G1 X138.645 Y159.673 E1.2815
G1 X140.383 Y159.673 E.05767
G1 X207.728 Y92.327 E3.15929
G1 X209.467 Y92.327 E.05767
G1 X226.673 Y109.533 E.80715
G1 X226.672 Y111.763 E.07397
G1 X178.763 Y159.672 E2.24753
G1 X177.024 Y159.673 E.05767
G1 X109.679 Y92.327 E3.15929
G1 X107.941 Y92.327 E.05767
G1 X72.955 Y127.313 E1.64125
G2 X72.955 Y124.687 I-11.802 J-1.313 E.08729
G1 X107.941 Y159.673 E1.64125
G1 X109.679 Y159.673 E.05767
G1 X177.024 Y92.327 E3.15929
G1 X178.763 Y92.327 E.05767
G1 X226.673 Y140.237 E2.24753
G1 X226.673 Y142.467 E.07397
G1 X209.467 Y159.673 E.80715
G1 X207.728 Y159.673 E.05767
G1 X140.383 Y92.327 E3.15929
G1 X138.645 Y92.327 E.05767
G1 X111.327 Y119.645 E1.2815
G1 X111.327 Y117.003 E.08761
G1 X153.997 Y159.673 E2.00169
G1 X155.735 Y159.673 E.05767
G1 X222.824 Y92.583 E3.14729
G3 X222.933 Y92.327 I.78 J.181 E.00927
G1 X221.584 Y92.327 E.04477
G1 X226.673 Y128.743 F30000
G1 F15476.087
G1 X226.673 Y127.115 E.05401
G1 X194.115 Y159.673 E1.52734
G1 X192.376 Y159.673 E.05767
G1 X125.031 Y92.327 E3.15929
G1 X123.293 Y92.327 E.05767
G1 X105.948 Y109.672 E.81369
G1 X103.997 Y109.672 E.06472
G1 X86.652 Y92.327 E.81369
G1 X84.913 Y92.327 E.05767
G1 X62.537 Y114.704 E1.04971
G1 X63.028 Y114.76 E.0164
G1 X40.596 Y92.327 E1.05234
G1 X38.857 Y92.327 E.05767
G1 X29.327 Y101.857 E.44706
G1 X29.327 Y104.087 E.07397
G1 X50.419 Y125.179 E.98947
G2 X50.419 Y126.821 I8.991 J.821 E.05454
G1 X29.327 Y147.913 E.98947
G1 X29.327 Y150.143 E.07397
G1 X38.857 Y159.673 E.44706
G1 X40.596 Y159.673 E.05767
G1 X63.028 Y137.24 E1.05234
G1 X62.537 Y137.296 E.0164
G1 X84.913 Y159.673 E1.04971
G1 X86.652 Y159.673 E.05767
G1 X103.997 Y142.327 E.81369
G1 X105.948 Y142.327 E.06472
G1 X123.293 Y159.673 E.81369
G1 X125.031 Y159.673 E.05767
G1 X192.376 Y92.327 E3.15929
G1 X194.115 Y92.327 E.05767
G1 X226.673 Y124.885 E1.52734
G1 X226.673 Y123.257 E.05401
G1 X111.327 Y113.597 F30000
G1 F15476.087
G1 X111.327 Y111.969 E.05401
G1 X130.969 Y92.327 E.92141
G1 X132.707 Y92.327 E.05767
G1 X200.052 Y159.673 E3.15929
G1 X201.791 Y159.673 E.05767
G1 X226.673 Y134.791 E1.16725
G1 X226.673 Y132.561 E.07397
G1 X186.439 Y92.327 E1.88744
G1 X184.7 Y92.327 E.05767
G1 X117.355 Y159.673 E3.15929
G1 X115.617 Y159.673 E.05767
G1 X48.272 Y92.327 E3.15929
G1 X46.533 Y92.327 E.05767
G1 X29.327 Y109.533 E.80715
G1 X29.327 Y111.763 E.07397
G1 X77.237 Y159.673 E2.24753
G1 X78.976 Y159.673 E.05767
G1 X98.672 Y139.976 E.92402
G1 X98.672 Y135.052 E.16332
G1 X55.948 Y92.327 E2.00431
G1 X54.209 Y92.327 E.05767
G1 X29.327 Y117.209 E1.16725
G1 X29.327 Y119.439 E.07397
G1 X69.561 Y159.673 E1.88744
G1 X71.3 Y159.673 E.05767
G1 X98.672 Y132.3 E1.28412
G1 X98.672 Y127.376 E.16331
G1 X63.624 Y92.327 E1.64421
G1 X61.885 Y92.327 E.05767
G1 X29.327 Y124.885 E1.52734
G1 X29.327 Y127.115 E.07397
G1 X61.885 Y159.673 E1.52734
G1 X63.624 Y159.673 E.05767
G1 X98.672 Y124.624 E1.64421
G1 X98.672 Y119.7 E.16332
G1 X71.3 Y92.327 E1.28412
G1 X69.561 Y92.327 E.05767
G1 X29.327 Y132.561 E1.88744
G1 X29.327 Y134.791 E.07397
G1 X54.209 Y159.673 E1.16725
G1 X55.948 Y159.673 E.05767
G1 X98.672 Y116.948 E2.00431
G1 X98.672 Y112.024 E.16332
G1 X78.976 Y92.327 E.92402
G1 X77.237 Y92.327 E.05767
G1 X29.327 Y140.237 E2.24753
G1 X29.327 Y142.467 E.07397
G1 X46.533 Y159.673 E.80715
G1 X48.272 Y159.673 E.05767
G1 X115.617 Y92.327 E3.15929
G1 X117.355 Y92.327 E.05767
G1 X184.7 Y159.673 E3.15929
G1 X186.439 Y159.673 E.05767
G1 X226.673 Y119.439 E1.88744
G1 X226.673 Y117.209 E.07397
G1 X201.791 Y92.327 E1.16725
G1 X200.052 Y92.327 E.05767
G1 X132.707 Y159.673 E3.15929
G1 X130.969 Y159.673 E.05767
G1 X111.327 Y140.031 E.92141
G1 X111.327 Y138.403 E.05401
G1 X110.937 Y110.062 F30000
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.399394
G1 F3000;_EXTRUDE_SET_SPEED
G1 X110.965 Y110.194 E.00391
G1 X110.965 Y141.806 E.91824
G1 X110.937 Y141.938 E.00391
G1 X110.806 Y141.965 E.00391
G1 X99.194 Y141.965 E.33728
G1 X99.062 Y141.938 E.00391
G1 X99.035 Y141.806 E.00391
G1 X99.035 Y110.194 E.91824
G1 X99.062 Y110.062 E.00391
G1 X99.194 Y110.035 E.00391
G1 X110.806 Y110.035 E.33728
G1 X110.879 Y110.05 E.00217
; Slow Down End
; WIPE_START
G1 X110.806 Y110.035 E-.02839
G1 X108.88 Y110.035 E-.73161
; WIPE_END
G1 E-.04 F1800
G1 X101.861 Y113.033 Z4.4 F30000
G1 X72.665 Y125.501 Z4.4
G1 Z4
G1 E.8 F1800
; Slow Down Start
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X72.665 Y125.508 E.0002
G3 X72.575 Y124.514 I-10.954 J.492 E1.88108
G1 X72.66 Y125.441 E.02579
; Slow Down End
; WIPE_START
G1 X72.575 Y124.514 E-.35375
G1 X72.395 Y123.532 E-.37931
G1 X72.376 Y123.464 E-.02694
; WIPE_END
G1 E-.04 F1800
G1 X65.211 Y126.093 Z4.4 F30000
G1 X51.595 Y131.089 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X52.433 Y132.484 I8.054 J-3.891 E.05403
G1 X29.327 Y155.589 E1.08392
G1 X29.327 Y157.819 E.07397
G1 X31.181 Y159.673 E.08696
G1 X32.92 Y159.673 E.05767
M73 P55 R23
G1 X56.523 Y136.07 E1.10726
G2 X58.022 Y136.7 I4.199 J-7.897 E.05404
; WIPE_START
G1 X56.523 Y136.07 E-.61816
G1 X56.259 Y136.334 E-.14184
; WIPE_END
G1 E-.04 F1800
G1 X51.868 Y130.09 Z4.4 F30000
G1 X29.327 Y98.039 Z4.4
G1 Z4
M73 P55 R22
G1 E.8 F1800
G1 F15476.087
G1 X29.327 Y96.411 E.05401
G1 X52.433 Y119.516 E1.08392
G3 X56.523 Y115.93 I9.44 J6.64 E.18215
G1 X33.176 Y92.583 E1.09525
G3 X33.237 Y94.186 I-2.507 J.899 E.05404
G1 X32.54 Y92.023 F30000
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.45471
G1 F3000;_EXTRUDE_SET_SPEED
G1 X32.636 Y91.994 E.00339
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.430778
;_EXTRUDE_SET_SPEED
G1 X32.733 Y91.965 E.00319
G1 X223.267 Y91.965 E6.02191
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.405406
;_EXTRUDE_SET_SPEED
G1 X223.46 Y92.023 E.00597
G1 X223.41 Y92.195 E.00528
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.38292
;_EXTRUDE_SET_SPEED
G1 X223.187 Y92.643 E.01387
G2 X225.915 Y95.932 I2.313 J.857 E.14316
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.40685
;_EXTRUDE_SET_SPEED
G1 X226.136 Y95.873 E.00679
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.436822
;_EXTRUDE_SET_SPEED
G1 X226.357 Y95.813 E.00735
G1 X226.977 Y95.54 E.02175
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.45471
;_EXTRUDE_SET_SPEED
G1 X227.006 Y95.636 E.00339
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.399451
;_EXTRUDE_SET_SPEED
G1 X227.035 Y95.733 E.00293
G1 X227.035 Y159.876 E1.86353
G1 X227.008 Y160.008 E.00391
G1 X226.876 Y160.035 E.00391
G1 X29.124 Y160.035 E5.74523
G1 X28.992 Y160.008 E.00391
G1 X28.965 Y159.876 E.00391
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.40685
;_EXTRUDE_SET_SPEED
G1 X28.965 Y127.804 E.9511
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.454132
;_EXTRUDE_SET_SPEED
G1 X28.965 Y95.733 E1.07467
G1 X29.023 Y95.54 E.00677
G1 X29.195 Y95.59 E.00599
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.38292
;_EXTRUDE_SET_SPEED
G1 X29.643 Y95.813 E.01387
G2 X32.932 Y93.085 I.857 J-2.313 E.14316
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.40685
;_EXTRUDE_SET_SPEED
G1 X32.873 Y92.864 E.00679
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.43725
;_EXTRUDE_SET_SPEED
G1 X32.813 Y92.643 E.00735
G1 X32.564 Y92.078 E.01984
; Slow Down End
; WIPE_START
G1 X32.813 Y92.643 E-.55451
G1 X32.873 Y92.864 E-.20549
; WIPE_END
G1 E-.04 F1800
G1 X31.531 Y91.619 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X31.192 Y91.559 E.00873
; LINE_WIDTH: 0.327704
G1 X31.026 Y91.537 E.00389
; LINE_WIDTH: 0.281529
G2 X30.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.24429
G2 X30.14 Y91.516 I-.336 J5.788 E.0115
; LINE_WIDTH: 0.283913
G1 X29.974 Y91.537 E.00329
; LINE_WIDTH: 0.327691
G1 X29.808 Y91.559 E.00389
; LINE_WIDTH: 0.354384
G1 X29.469 Y91.619 E.00873
G1 X28.619 Y92.469 F30000
; LINE_WIDTH: 0.354377
G1 F15000
G1 X28.559 Y92.808 E.00874
; LINE_WIDTH: 0.327686
G1 X28.537 Y92.974 E.00389
; LINE_WIDTH: 0.281523
G2 X28.514 Y93.159 I2.114 J.363 E.00363
; LINE_WIDTH: 0.244295
G2 X28.516 Y93.86 I5.789 J.336 E.0115
; LINE_WIDTH: 0.283931
G1 X28.537 Y94.026 E.00329
; LINE_WIDTH: 0.327697
G1 X28.559 Y94.192 E.00389
; LINE_WIDTH: 0.354384
G1 X28.619 Y94.531 E.00874
; CHANGE_LAYER
; Z_HEIGHT: 4.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X28.559 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 21/25
; update layer progress
M73 L21
M991 S0 P20 ;notify layer change
G17
G3 Z4.4 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z4.6 F30000
G1 X51.288 Y124.062 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.502 Y123.14 E.03142
G3 X60.507 Y115.466 I10.209 J2.86 E.41633
G1 X61.47 Y115.4 E.03202
G3 X51.277 Y124.121 I.241 J10.599 E1.72791
M204 S250
G1 X51.67 Y124.151 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X51.88 Y123.245 E.02855
G3 X60.551 Y115.856 I9.831 J2.754 E.37138
G1 X61.479 Y115.792 E.02856
G3 X51.66 Y124.209 I.232 J10.207 E1.54072
; WIPE_START
M204 S10000
G1 X51.88 Y123.245 E-.37566
G1 X52.171 Y122.363 E-.35312
G1 X52.203 Y122.287 E-.03122
; WIPE_END
G1 E-.04 F1800
G1 X59.735 Y121.052 Z4.6 F30000
G1 X223.514 Y94.186 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.53 Y94.217 E.00116
G2 X227.227 Y94.688 I1.97 J-.717 E.15229
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.732 J-1.184 E.24448
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.435 Y93.864 I1.188 J1.727 E.07947
G1 X223.499 Y94.128 E.009
M204 S250
G1 X223.893 Y94.086 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X223.903 Y94.081 E.00034
G3 X225.268 Y91.809 I1.604 J-.582 E.09326
G3 X226.355 Y92.018 I.244 J1.665 E.03467
G3 X224.028 Y94.35 I-.848 J1.481 E.19249
G1 X223.92 Y94.139 E.00728
; WIPE_START
M204 S10000
G1 X223.903 Y94.081 E-.02286
G1 X223.815 Y93.797 E-.11303
G1 X223.789 Y93.5 E-.11332
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11332
G1 X224.189 Y92.4 E-.11332
G1 X224.296 Y92.293 E-.05751
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02175
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.731 J1.192 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24921
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03914
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z4.6 F30000
G1 X32.107 Y94.087 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X31.983 Y94.356 E.00912
G3 X30.268 Y91.809 I-1.476 J-.857 E.21218
G3 X31.355 Y92.018 I.244 J1.665 E.03467
G3 X32.129 Y94.032 I-.848 J1.481 E.07175
; WIPE_START
M204 S10000
G1 X31.983 Y94.356 E-.13499
G1 X31.811 Y94.6 E-.11338
G1 X31.6 Y94.811 E-.11335
G1 X31.355 Y94.982 E-.11329
G1 X31.085 Y95.108 E-.11334
G1 X30.797 Y95.185 E-.11331
G1 X30.644 Y95.198 E-.05834
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.731 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02175
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08591
G1 X28.888 Y92.147 E-.13943
G1 X28.773 Y92.312 E-.07623
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14117
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z4.6 F30000
G1 X227.79 Y91.21 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354373
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327686
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281523
G2 X225.841 Y91.514 I-.363 J2.114 E.00363
; LINE_WIDTH: 0.244295
G2 X225.14 Y91.516 I-.336 J5.787 E.0115
; LINE_WIDTH: 0.283913
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327691
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354364
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y92.469 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.354361
G1 F15000
G1 X227.441 Y92.808 E.00873
; LINE_WIDTH: 0.327676
G1 X227.463 Y92.974 E.00389
; LINE_WIDTH: 0.283908
G1 X227.484 Y93.14 E.00329
; LINE_WIDTH: 0.244295
G3 X227.486 Y93.841 I-5.786 J.364 E.0115
; LINE_WIDTH: 0.281523
G3 X227.463 Y94.026 I-2.14 J-.178 E.00363
; LINE_WIDTH: 0.327686
G1 X227.441 Y94.192 E.00389
; LINE_WIDTH: 0.354354
G1 X227.381 Y94.531 E.00874
; WIPE_START
G1 X227.441 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.311 Y101.823 Z4.6 F30000
G1 X226.321 Y160.231 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40023
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X227.028 Y159.523 E.0513
G1 X227.028 Y158.886 E.03264
G1 X225.886 Y160.028 E.08277
G1 X225.25 Y160.028 E.03264
G1 X227.028 Y158.25 E.12893
G1 X227.028 Y157.613 E.03264
G1 X224.613 Y160.028 E.17509
G1 X223.976 Y160.028 E.03264
G1 X227.028 Y156.976 E.22124
G1 X227.028 Y156.339 E.03264
G1 X223.339 Y160.028 E.2674
G1 X222.703 Y160.028 E.03264
G1 X227.028 Y155.703 E.31356
G1 X227.028 Y155.066 E.03264
G1 X222.066 Y160.028 E.35971
G1 X221.429 Y160.028 E.03264
G1 X227.028 Y154.429 E.40587
G1 X227.028 Y153.793 E.03264
G1 X220.793 Y160.028 E.45203
G1 X220.156 Y160.028 E.03264
G1 X227.028 Y153.156 E.49818
G1 X227.028 Y152.519 E.03264
G1 X219.519 Y160.028 E.54434
G1 X218.882 Y160.028 E.03264
G1 X227.028 Y151.882 E.5905
G1 X227.028 Y151.246 E.03264
G1 X218.246 Y160.028 E.63665
G1 X217.609 Y160.028 E.03264
G1 X227.028 Y150.609 E.68281
G1 X227.028 Y149.972 E.03264
G1 X216.972 Y160.028 E.72897
G1 X216.336 Y160.028 E.03264
G1 X227.028 Y149.336 E.77512
G1 X227.028 Y148.699 E.03264
G1 X215.699 Y160.028 E.82128
G1 X215.062 Y160.028 E.03264
G1 X227.028 Y148.062 E.86744
G1 X227.028 Y147.425 E.03264
G1 X214.425 Y160.028 E.91359
G1 X213.789 Y160.028 E.03264
G1 X227.028 Y146.789 E.95975
G1 X227.028 Y146.152 E.03264
G1 X213.152 Y160.028 E1.00591
G1 X212.515 Y160.028 E.03264
G1 X227.028 Y145.515 E1.05206
G1 X227.028 Y144.878 E.03264
G1 X211.878 Y160.028 E1.09822
G1 X211.242 Y160.028 E.03264
G1 X227.028 Y144.242 E1.14438
G1 X227.028 Y143.605 E.03264
G1 X210.605 Y160.028 E1.19053
G1 X209.968 Y160.028 E.03264
G1 X227.028 Y142.968 E1.23669
G1 X227.028 Y142.332 E.03264
G1 X209.332 Y160.028 E1.28285
G1 X208.695 Y160.028 E.03264
G1 X227.028 Y141.695 E1.329
G1 X227.028 Y141.058 E.03264
G1 X208.058 Y160.028 E1.37516
G1 X207.421 Y160.028 E.03264
G1 X227.028 Y140.421 E1.42132
G1 X227.028 Y139.785 E.03264
G1 X206.785 Y160.028 E1.46747
G1 X206.148 Y160.028 E.03264
G1 X227.028 Y139.148 E1.51363
G1 X227.028 Y138.511 E.03264
G1 X205.511 Y160.028 E1.55979
G1 X204.875 Y160.028 E.03264
G1 X227.028 Y137.875 E1.60594
G1 X227.028 Y137.238 E.03264
G1 X204.238 Y160.028 E1.6521
G1 X203.601 Y160.028 E.03264
G1 X227.028 Y136.601 E1.69826
G1 X227.028 Y135.964 E.03264
G1 X202.964 Y160.028 E1.74441
G1 X202.328 Y160.028 E.03264
G1 X227.028 Y135.328 E1.79057
G1 X227.028 Y134.691 E.03264
G1 X201.691 Y160.028 E1.83672
G1 X201.054 Y160.028 E.03264
G1 X227.028 Y134.054 E1.88288
G1 X227.028 Y133.417 E.03264
G1 X200.417 Y160.028 E1.92904
M73 P56 R22
G1 X199.781 Y160.028 E.03264
G1 X227.028 Y132.781 E1.97519
G1 X227.028 Y132.144 E.03264
G1 X199.144 Y160.028 E2.02135
G1 X198.507 Y160.028 E.03264
G1 X227.028 Y131.507 E2.06751
G1 X227.028 Y130.871 E.03264
G1 X197.871 Y160.028 E2.11366
G1 X197.234 Y160.028 E.03264
G1 X227.028 Y130.234 E2.15982
G1 X227.028 Y129.597 E.03264
G1 X196.597 Y160.028 E2.20598
G1 X195.96 Y160.028 E.03264
G1 X227.028 Y128.96 E2.25213
G1 X227.028 Y128.324 E.03264
G1 X195.324 Y160.028 E2.29829
G1 X194.687 Y160.028 E.03264
G1 X227.028 Y127.687 E2.34445
G1 X227.028 Y127.05 E.03264
G1 X194.05 Y160.028 E2.3906
G1 X193.414 Y160.028 E.03264
G1 X227.028 Y126.414 E2.43676
G1 X227.028 Y125.777 E.03264
G1 X192.777 Y160.028 E2.48292
G1 X192.14 Y160.028 E.03264
G1 X227.028 Y125.14 E2.52907
G1 X227.028 Y124.503 E.03264
G1 X191.503 Y160.028 E2.57523
G1 X190.867 Y160.028 E.03264
G1 X227.028 Y123.867 E2.62139
G1 X227.028 Y123.23 E.03264
G1 X190.23 Y160.028 E2.66754
G1 X189.593 Y160.028 E.03264
G1 X227.028 Y122.593 E2.7137
G1 X227.028 Y121.957 E.03264
G1 X188.956 Y160.028 E2.75986
G1 X188.32 Y160.028 E.03264
G1 X227.028 Y121.32 E2.80601
G1 X227.028 Y120.683 E.03264
G1 X187.683 Y160.028 E2.85217
G1 X187.046 Y160.028 E.03264
G1 X227.028 Y120.046 E2.89833
G1 X227.028 Y119.41 E.03264
G1 X186.41 Y160.028 E2.94448
G1 X185.773 Y160.028 E.03264
G1 X227.028 Y118.773 E2.99064
G1 X227.028 Y118.136 E.03264
G1 X185.136 Y160.028 E3.0368
G1 X184.499 Y160.028 E.03264
G1 X227.028 Y117.499 E3.08295
G1 X227.028 Y116.863 E.03264
G1 X183.863 Y160.028 E3.12911
G1 X183.226 Y160.028 E.03264
G1 X227.028 Y116.226 E3.17527
G1 X227.028 Y115.589 E.03264
G1 X182.589 Y160.028 E3.22142
G1 X181.953 Y160.028 E.03264
G1 X227.028 Y114.953 E3.26758
G1 X227.028 Y114.316 E.03264
G1 X181.316 Y160.028 E3.31374
G1 X180.679 Y160.028 E.03264
G1 X227.028 Y113.679 E3.35989
G1 X227.028 Y113.042 E.03264
G1 X180.042 Y160.028 E3.40605
G1 X179.406 Y160.028 E.03264
G1 X227.028 Y112.406 E3.45221
G1 X227.028 Y111.769 E.03264
G1 X178.769 Y160.028 E3.49836
G1 X178.132 Y160.028 E.03264
G1 X227.028 Y111.132 E3.54452
G1 X227.028 Y110.496 E.03264
G1 X177.496 Y160.028 E3.59068
G1 X176.859 Y160.028 E.03264
G1 X227.028 Y109.859 E3.63683
G1 X227.028 Y109.222 E.03264
G1 X176.222 Y160.028 E3.68299
G1 X175.585 Y160.028 E.03264
G1 X227.028 Y108.585 E3.72914
G1 X227.028 Y107.949 E.03264
G1 X174.949 Y160.028 E3.7753
G1 X174.312 Y160.028 E.03264
G1 X227.028 Y107.312 E3.82146
G1 X227.028 Y106.675 E.03264
G1 X173.675 Y160.028 E3.86761
G1 X173.038 Y160.028 E.03264
G1 X227.028 Y106.038 E3.91377
M73 P57 R21
G1 X227.028 Y105.402 E.03264
G1 X172.402 Y160.028 E3.95993
G1 X171.765 Y160.028 E.03264
G1 X227.028 Y104.765 E4.00608
G1 X227.028 Y104.128 E.03264
G1 X171.128 Y160.028 E4.05224
G1 X170.492 Y160.028 E.03264
G1 X227.028 Y103.492 E4.0984
G1 X227.028 Y102.855 E.03264
G1 X169.855 Y160.028 E4.14455
G1 X169.218 Y160.028 E.03264
G1 X227.028 Y102.218 E4.19071
G1 X227.028 Y101.581 E.03264
G1 X168.581 Y160.028 E4.23687
G1 X167.945 Y160.028 E.03264
G1 X227.028 Y100.945 E4.28302
G1 X227.028 Y100.308 E.03264
G1 X167.308 Y160.028 E4.32918
G1 X166.671 Y160.028 E.03264
G1 X227.028 Y99.671 E4.37534
G1 X227.028 Y99.035 E.03264
G1 X166.035 Y160.028 E4.42149
G1 X165.398 Y160.028 E.03264
G1 X227.028 Y98.398 E4.46765
G1 X227.028 Y97.761 E.03264
G1 X164.761 Y160.028 E4.51381
G1 X164.124 Y160.028 E.03264
G1 X227.028 Y97.124 E4.55996
G1 X227.028 Y96.488 E.03264
G1 X163.488 Y160.028 E4.60612
G1 X162.851 Y160.028 E.03264
G1 X227.028 Y95.851 E4.65228
G1 X227.028 Y95.508 E.01756
G1 X226.477 Y95.765 E.03118
G1 X162.214 Y160.028 E4.65847
G1 X161.577 Y160.028 E.03264
G1 X225.643 Y95.963 E4.64415
G1 X225.5 Y95.976 E.00734
G1 X225.039 Y95.93 E.02373
G1 X160.941 Y160.028 E4.64657
G1 X160.304 Y160.028 E.03264
G1 X224.553 Y95.779 E4.65746
G3 X224.138 Y95.557 I.571 J-1.562 E.02419
G1 X159.667 Y160.028 E4.67357
G1 X159.031 Y160.028 E.03264
G1 X223.786 Y95.273 E4.69416
G3 X223.491 Y94.931 I.824 J-1.006 E.02326
G1 X158.394 Y160.028 E4.71898
M73 P58 R21
G1 X157.757 Y160.028 E.03264
G1 X223.258 Y94.527 E4.74822
G3 X223.095 Y94.053 I1.263 J-.699 E.02582
G1 X157.12 Y160.028 E4.78258
G1 X156.484 Y160.028 E.03264
G1 X223.026 Y93.486 E4.82369
G3 X223.156 Y92.719 I2.243 J-.013 E.0401
G1 X155.847 Y160.028 E4.87931
G1 X155.21 Y160.028 E.03264
G1 X223.267 Y91.972 E4.93348
G1 X222.63 Y91.972 E.03264
G1 X154.574 Y160.028 E4.93348
G1 X153.937 Y160.028 E.03264
G1 X221.993 Y91.972 E4.93348
G1 X221.357 Y91.972 E.03264
G1 X153.3 Y160.028 E4.93348
G1 X152.663 Y160.028 E.03264
G1 X220.72 Y91.972 E4.93348
G1 X220.083 Y91.972 E.03264
G1 X152.027 Y160.028 E4.93348
G1 X151.39 Y160.028 E.03264
G1 X219.446 Y91.972 E4.93348
G1 X218.81 Y91.972 E.03264
G1 X150.753 Y160.028 E4.93348
G1 X150.116 Y160.028 E.03264
G1 X218.173 Y91.972 E4.93348
G1 X217.536 Y91.972 E.03264
G1 X149.48 Y160.028 E4.93348
G1 X148.843 Y160.028 E.03264
G1 X216.899 Y91.972 E4.93348
G1 X216.263 Y91.972 E.03264
G1 X148.206 Y160.028 E4.93348
G1 X147.57 Y160.028 E.03264
G1 X215.626 Y91.972 E4.93348
M73 P58 R20
G1 X214.989 Y91.972 E.03264
G1 X146.933 Y160.028 E4.93348
G1 X146.296 Y160.028 E.03264
M73 P59 R20
G1 X214.353 Y91.972 E4.93348
G1 X213.716 Y91.972 E.03264
G1 X145.659 Y160.028 E4.93348
G1 X145.023 Y160.028 E.03264
G1 X213.079 Y91.972 E4.93348
G1 X212.442 Y91.972 E.03264
G1 X144.386 Y160.028 E4.93348
G1 X143.749 Y160.028 E.03264
G1 X211.806 Y91.972 E4.93348
G1 X211.169 Y91.972 E.03264
G1 X143.113 Y160.028 E4.93348
G1 X142.476 Y160.028 E.03264
G1 X210.532 Y91.972 E4.93348
G1 X209.896 Y91.972 E.03264
G1 X141.839 Y160.028 E4.93348
G1 X141.202 Y160.028 E.03264
G1 X209.259 Y91.972 E4.93348
G1 X208.622 Y91.972 E.03264
G1 X140.566 Y160.028 E4.93348
G1 X139.929 Y160.028 E.03264
G1 X207.985 Y91.972 E4.93348
G1 X207.349 Y91.972 E.03264
G1 X139.292 Y160.028 E4.93348
G1 X138.656 Y160.028 E.03264
G1 X206.712 Y91.972 E4.93348
G1 X206.075 Y91.972 E.03264
G1 X138.019 Y160.028 E4.93348
G1 X137.382 Y160.028 E.03264
G1 X205.439 Y91.972 E4.93348
G1 X204.802 Y91.972 E.03264
G1 X136.745 Y160.028 E4.93348
G1 X136.109 Y160.028 E.03264
G1 X204.165 Y91.972 E4.93348
M73 P60 R20
G1 X203.528 Y91.972 E.03264
G1 X135.472 Y160.028 E4.93348
G1 X134.835 Y160.028 E.03264
G1 X202.892 Y91.972 E4.93348
G1 X202.255 Y91.972 E.03264
G1 X134.198 Y160.028 E4.93348
G1 X133.562 Y160.028 E.03264
G1 X201.618 Y91.972 E4.93348
G1 X200.981 Y91.972 E.03264
G1 X132.925 Y160.028 E4.93348
G1 X132.288 Y160.028 E.03264
G1 X200.345 Y91.972 E4.93348
G1 X199.708 Y91.972 E.03264
G1 X131.652 Y160.028 E4.93348
G1 X131.015 Y160.028 E.03264
G1 X199.071 Y91.972 E4.93348
G1 X198.435 Y91.972 E.03264
G1 X130.378 Y160.028 E4.93348
G1 X129.741 Y160.028 E.03264
G1 X197.798 Y91.972 E4.93348
G1 X197.161 Y91.972 E.03264
G1 X129.105 Y160.028 E4.93348
G1 X128.468 Y160.028 E.03264
G1 X196.524 Y91.972 E4.93348
G1 X195.888 Y91.972 E.03264
G1 X127.831 Y160.028 E4.93348
G1 X127.195 Y160.028 E.03264
G1 X195.251 Y91.972 E4.93348
M73 P60 R19
G1 X194.614 Y91.972 E.03264
G1 X126.558 Y160.028 E4.93348
G1 X125.921 Y160.028 E.03264
G1 X193.978 Y91.972 E4.93348
M73 P61 R19
G1 X193.341 Y91.972 E.03264
G1 X125.284 Y160.028 E4.93348
G1 X124.648 Y160.028 E.03264
G1 X192.704 Y91.972 E4.93348
G1 X192.067 Y91.972 E.03264
G1 X124.011 Y160.028 E4.93348
G1 X123.374 Y160.028 E.03264
G1 X191.431 Y91.972 E4.93348
G1 X190.794 Y91.972 E.03264
G1 X122.737 Y160.028 E4.93348
G1 X122.101 Y160.028 E.03264
G1 X190.157 Y91.972 E4.93348
G1 X189.52 Y91.972 E.03264
G1 X121.464 Y160.028 E4.93348
G1 X120.827 Y160.028 E.03264
G1 X188.884 Y91.972 E4.93348
G1 X188.247 Y91.972 E.03264
G1 X120.191 Y160.028 E4.93348
G1 X119.554 Y160.028 E.03264
G1 X187.61 Y91.972 E4.93348
G1 X186.974 Y91.972 E.03264
G1 X118.917 Y160.028 E4.93348
G1 X118.28 Y160.028 E.03264
G1 X186.337 Y91.972 E4.93348
G1 X185.7 Y91.972 E.03264
G1 X117.644 Y160.028 E4.93348
G1 X117.007 Y160.028 E.03264
G1 X185.063 Y91.972 E4.93348
G1 X184.427 Y91.972 E.03264
G1 X116.37 Y160.028 E4.93348
G1 X115.734 Y160.028 E.03264
G1 X183.79 Y91.972 E4.93348
M73 P62 R19
G1 X183.153 Y91.972 E.03264
G1 X115.097 Y160.028 E4.93348
G1 X114.46 Y160.028 E.03264
G1 X182.517 Y91.972 E4.93348
G1 X181.88 Y91.972 E.03264
G1 X113.823 Y160.028 E4.93348
G1 X113.187 Y160.028 E.03264
G1 X181.243 Y91.972 E4.93348
G1 X180.606 Y91.972 E.03264
G1 X112.55 Y160.028 E4.93348
G1 X111.913 Y160.028 E.03264
G1 X179.97 Y91.972 E4.93348
G1 X179.333 Y91.972 E.03264
G1 X111.276 Y160.028 E4.93348
G1 X110.64 Y160.028 E.03264
G1 X178.696 Y91.972 E4.93348
G1 X178.059 Y91.972 E.03264
G1 X110.003 Y160.028 E4.93348
G1 X109.366 Y160.028 E.03264
G1 X177.423 Y91.972 E4.93348
G1 X176.786 Y91.972 E.03264
G1 X108.73 Y160.028 E4.93348
G1 X108.093 Y160.028 E.03264
G1 X176.149 Y91.972 E4.93348
G1 X175.513 Y91.972 E.03264
G1 X107.456 Y160.028 E4.93348
M73 P62 R18
G1 X106.819 Y160.028 E.03264
G1 X174.876 Y91.972 E4.93348
G1 X174.239 Y91.972 E.03264
G1 X106.183 Y160.028 E4.93348
M73 P63 R18
G1 X105.546 Y160.028 E.03264
G1 X173.602 Y91.972 E4.93348
G1 X172.966 Y91.972 E.03264
G1 X104.909 Y160.028 E4.93348
G1 X104.273 Y160.028 E.03264
G1 X172.329 Y91.972 E4.93348
G1 X171.692 Y91.972 E.03264
G1 X103.636 Y160.028 E4.93348
G1 X102.999 Y160.028 E.03264
G1 X171.056 Y91.972 E4.93348
G1 X170.419 Y91.972 E.03264
G1 X102.362 Y160.028 E4.93348
G1 X101.726 Y160.028 E.03264
G1 X169.782 Y91.972 E4.93348
G1 X169.145 Y91.972 E.03264
G1 X101.089 Y160.028 E4.93348
G1 X100.452 Y160.028 E.03264
G1 X168.509 Y91.972 E4.93348
G1 X167.872 Y91.972 E.03264
G1 X99.815 Y160.028 E4.93348
G1 X99.179 Y160.028 E.03264
G1 X167.235 Y91.972 E4.93348
G1 X166.598 Y91.972 E.03264
G1 X98.542 Y160.028 E4.93348
G1 X97.905 Y160.028 E.03264
G1 X165.962 Y91.972 E4.93348
G1 X165.325 Y91.972 E.03264
G1 X97.269 Y160.028 E4.93348
G1 X96.632 Y160.028 E.03264
G1 X164.688 Y91.972 E4.93348
G1 X164.052 Y91.972 E.03264
G1 X95.995 Y160.028 E4.93348
M73 P64 R18
G1 X95.358 Y160.028 E.03264
G1 X163.415 Y91.972 E4.93348
G1 X162.778 Y91.972 E.03264
G1 X94.722 Y160.028 E4.93348
G1 X94.085 Y160.028 E.03264
G1 X162.141 Y91.972 E4.93348
G1 X161.505 Y91.972 E.03264
G1 X93.448 Y160.028 E4.93348
G1 X92.812 Y160.028 E.03264
G1 X160.868 Y91.972 E4.93348
G1 X160.231 Y91.972 E.03264
G1 X110.972 Y141.231 E3.57087
G1 X110.972 Y140.595 E.03264
G1 X159.595 Y91.972 E3.52471
G1 X158.958 Y91.972 E.03264
G1 X110.972 Y139.958 E3.47856
G1 X110.972 Y139.321 E.03264
G1 X158.321 Y91.972 E3.4324
G1 X157.684 Y91.972 E.03264
G1 X110.972 Y138.684 E3.38624
G1 X110.972 Y138.048 E.03264
G1 X157.048 Y91.972 E3.34009
G1 X156.411 Y91.972 E.03264
G1 X110.972 Y137.411 E3.29393
G1 X110.972 Y136.774 E.03264
G1 X155.774 Y91.972 E3.24777
M73 P64 R17
G1 X155.138 Y91.972 E.03264
G1 X110.972 Y136.137 E3.20162
G1 X110.972 Y135.501 E.03264
G1 X154.501 Y91.972 E3.15546
G1 X153.864 Y91.972 E.03264
G1 X110.972 Y134.864 E3.1093
M73 P65 R17
G1 X110.972 Y134.227 E.03264
G1 X153.227 Y91.972 E3.06315
G1 X152.591 Y91.972 E.03264
G1 X110.972 Y133.591 E3.01699
G1 X110.972 Y132.954 E.03264
G1 X151.954 Y91.972 E2.97083
G1 X151.317 Y91.972 E.03264
G1 X110.972 Y132.317 E2.92468
G1 X110.972 Y131.68 E.03264
G1 X150.68 Y91.972 E2.87852
G1 X150.044 Y91.972 E.03264
G1 X110.972 Y131.044 E2.83236
G1 X110.972 Y130.407 E.03264
G1 X149.407 Y91.972 E2.78621
G1 X148.77 Y91.972 E.03264
G1 X110.972 Y129.77 E2.74005
G1 X110.972 Y129.134 E.03264
G1 X148.134 Y91.972 E2.69389
G1 X147.497 Y91.972 E.03264
G1 X110.972 Y128.497 E2.64774
G1 X110.972 Y127.86 E.03264
G1 X146.86 Y91.972 E2.60158
G1 X146.223 Y91.972 E.03264
G1 X110.972 Y127.223 E2.55543
G1 X110.972 Y126.587 E.03264
G1 X145.587 Y91.972 E2.50927
G1 X144.95 Y91.972 E.03264
G1 X110.972 Y125.95 E2.46311
G1 X110.972 Y125.313 E.03264
G1 X144.313 Y91.972 E2.41696
G1 X143.677 Y91.972 E.03264
G1 X110.972 Y124.677 E2.3708
M73 P66 R17
G1 X110.972 Y124.04 E.03264
G1 X143.04 Y91.972 E2.32464
G1 X142.403 Y91.972 E.03264
G1 X110.972 Y123.403 E2.27849
G1 X110.972 Y122.766 E.03264
G1 X141.766 Y91.972 E2.23233
G1 X141.13 Y91.972 E.03264
G1 X110.972 Y122.13 E2.18617
G1 X110.972 Y121.493 E.03264
G1 X140.493 Y91.972 E2.14002
G1 X139.856 Y91.972 E.03264
G1 X110.972 Y120.856 E2.09386
G1 X110.972 Y120.219 E.03264
G1 X139.219 Y91.972 E2.0477
G1 X138.583 Y91.972 E.03264
G1 X110.972 Y119.583 E2.00155
G1 X110.972 Y118.946 E.03264
G1 X137.946 Y91.972 E1.95539
G1 X137.309 Y91.972 E.03264
G1 X110.972 Y118.309 E1.90923
G1 X110.972 Y117.673 E.03264
G1 X136.673 Y91.972 E1.86308
G1 X136.036 Y91.972 E.03264
G1 X110.972 Y117.036 E1.81692
G1 X110.972 Y116.399 E.03264
G1 X135.399 Y91.972 E1.77076
G1 X134.762 Y91.972 E.03264
G1 X110.972 Y115.762 E1.72461
G1 X110.972 Y115.126 E.03264
G1 X134.126 Y91.972 E1.67845
G1 X133.489 Y91.972 E.03264
G1 X110.972 Y114.489 E1.63229
G1 X110.972 Y113.852 E.03264
G1 X132.852 Y91.972 E1.58614
G1 X132.216 Y91.972 E.03264
G1 X110.972 Y113.216 E1.53998
G1 X110.972 Y112.579 E.03264
G1 X131.579 Y91.972 E1.49382
G1 X130.942 Y91.972 E.03264
G1 X110.972 Y111.942 E1.44767
M73 P66 R16
G1 X110.972 Y111.305 E.03264
G1 X130.305 Y91.972 E1.40151
G1 X129.669 Y91.972 E.03264
G1 X110.972 Y110.669 E1.35535
G1 X110.972 Y110.032 E.03264
G1 X129.032 Y91.972 E1.3092
G1 X128.395 Y91.972 E.03264
G1 X110.339 Y110.028 E1.30893
G1 X109.702 Y110.028 E.03264
G1 X127.758 Y91.972 E1.30893
G1 X127.122 Y91.972 E.03264
G1 X109.065 Y110.028 E1.30893
G1 X108.429 Y110.028 E.03264
G1 X126.485 Y91.972 E1.30893
M73 P67 R16
G1 X125.848 Y91.972 E.03264
G1 X107.792 Y110.028 E1.30893
G1 X107.155 Y110.028 E.03264
G1 X125.212 Y91.972 E1.30893
G1 X124.575 Y91.972 E.03264
G1 X106.518 Y110.028 E1.30893
G1 X105.882 Y110.028 E.03264
G1 X123.938 Y91.972 E1.30893
G1 X123.301 Y91.972 E.03264
G1 X105.245 Y110.028 E1.30893
G1 X104.608 Y110.028 E.03264
G1 X122.665 Y91.972 E1.30893
G1 X122.028 Y91.972 E.03264
G1 X103.972 Y110.028 E1.30893
G1 X103.335 Y110.028 E.03264
G1 X121.391 Y91.972 E1.30893
G1 X120.755 Y91.972 E.03264
G1 X102.698 Y110.028 E1.30893
G1 X102.061 Y110.028 E.03264
G1 X120.118 Y91.972 E1.30893
G1 X119.481 Y91.972 E.03264
G1 X101.425 Y110.028 E1.30893
G1 X100.788 Y110.028 E.03264
G1 X118.844 Y91.972 E1.30893
G1 X118.208 Y91.972 E.03264
G1 X100.151 Y110.028 E1.30893
G1 X99.515 Y110.028 E.03264
G1 X117.571 Y91.972 E1.30893
G1 X116.934 Y91.972 E.03264
G1 X48.878 Y160.028 E4.93348
G1 X49.514 Y160.028 E.03264
G1 X99.028 Y110.515 E3.5893
G1 X99.028 Y111.151 E.03264
G1 X50.151 Y160.028 E3.54314
G1 X50.788 Y160.028 E.03264
G1 X99.028 Y111.788 E3.49699
G1 X99.028 Y112.425 E.03264
G1 X51.425 Y160.028 E3.45083
G1 X52.061 Y160.028 E.03264
G1 X99.028 Y113.061 E3.40467
G1 X99.028 Y113.698 E.03264
G1 X52.698 Y160.028 E3.35852
G1 X53.335 Y160.028 E.03264
G1 X99.028 Y114.335 E3.31236
G1 X99.028 Y114.972 E.03264
G1 X53.972 Y160.028 E3.2662
G1 X54.608 Y160.028 E.03264
G1 X99.028 Y115.608 E3.22005
G1 X99.028 Y116.245 E.03264
G1 X55.245 Y160.028 E3.17389
G1 X55.882 Y160.028 E.03264
G1 X99.028 Y116.882 E3.12773
G1 X99.028 Y117.518 E.03264
G1 X56.518 Y160.028 E3.08158
G1 X57.155 Y160.028 E.03264
G1 X99.028 Y118.155 E3.03542
G1 X99.028 Y118.792 E.03264
G1 X57.792 Y160.028 E2.98926
G1 X58.429 Y160.028 E.03264
G1 X99.028 Y119.429 E2.94311
G1 X99.028 Y120.065 E.03264
G1 X59.065 Y160.028 E2.89695
G1 X59.702 Y160.028 E.03264
G1 X99.028 Y120.702 E2.85079
G1 X99.028 Y121.339 E.03264
G1 X60.339 Y160.028 E2.80464
G1 X60.975 Y160.028 E.03264
G1 X99.028 Y121.975 E2.75848
G1 X99.028 Y122.612 E.03264
G1 X61.612 Y160.028 E2.71232
G1 X62.249 Y160.028 E.03264
G1 X99.028 Y123.249 E2.66617
G1 X99.028 Y123.886 E.03264
G1 X62.886 Y160.028 E2.62001
G1 X63.522 Y160.028 E.03264
G1 X99.028 Y124.522 E2.57385
G1 X99.028 Y125.159 E.03264
G1 X64.159 Y160.028 E2.5277
G1 X64.796 Y160.028 E.03264
G1 X99.028 Y125.796 E2.48154
G1 X99.028 Y126.433 E.03264
G1 X65.433 Y160.028 E2.43538
G1 X66.069 Y160.028 E.03264
G1 X99.028 Y127.069 E2.38923
G1 X99.028 Y127.706 E.03264
G1 X66.706 Y160.028 E2.34307
M73 P68 R16
G1 X67.343 Y160.028 E.03264
G1 X99.028 Y128.343 E2.29691
G1 X99.028 Y128.979 E.03264
G1 X67.979 Y160.028 E2.25076
G1 X68.616 Y160.028 E.03264
G1 X99.028 Y129.616 E2.2046
G1 X99.028 Y130.253 E.03264
G1 X69.253 Y160.028 E2.15844
G1 X69.89 Y160.028 E.03264
G1 X99.028 Y130.89 E2.11229
G1 X99.028 Y131.526 E.03264
G1 X70.526 Y160.028 E2.06613
G1 X71.163 Y160.028 E.03264
G1 X99.028 Y132.163 E2.01997
G1 X99.028 Y132.8 E.03264
G1 X71.8 Y160.028 E1.97382
G1 X72.436 Y160.028 E.03264
G1 X99.028 Y133.436 E1.92766
G1 X99.028 Y134.073 E.03264
G1 X73.073 Y160.028 E1.8815
G1 X73.71 Y160.028 E.03264
G1 X99.028 Y134.71 E1.83535
G1 X99.028 Y135.347 E.03264
G1 X74.347 Y160.028 E1.78919
G1 X74.983 Y160.028 E.03264
G1 X99.028 Y135.983 E1.74304
G1 X99.028 Y136.62 E.03264
G1 X75.62 Y160.028 E1.69688
G1 X76.257 Y160.028 E.03264
G1 X99.028 Y137.257 E1.65072
G1 X99.028 Y137.894 E.03264
G1 X76.894 Y160.028 E1.60457
G1 X77.53 Y160.028 E.03264
G1 X99.028 Y138.53 E1.55841
G1 X99.028 Y139.167 E.03264
G1 X78.167 Y160.028 E1.51225
G1 X78.804 Y160.028 E.03264
G1 X99.028 Y139.804 E1.4661
M73 P68 R15
G1 X99.028 Y140.44 E.03264
G1 X79.44 Y160.028 E1.41994
G1 X80.077 Y160.028 E.03264
G1 X99.028 Y141.077 E1.37378
G1 X99.028 Y141.714 E.03264
G1 X80.714 Y160.028 E1.32763
G1 X81.351 Y160.028 E.03264
G1 X99.407 Y141.972 E1.30893
G1 X100.044 Y141.972 E.03264
G1 X81.987 Y160.028 E1.30893
G1 X82.624 Y160.028 E.03264
G1 X100.68 Y141.972 E1.30893
G1 X101.317 Y141.972 E.03264
G1 X83.261 Y160.028 E1.30893
G1 X83.897 Y160.028 E.03264
G1 X101.954 Y141.972 E1.30893
M73 P69 R15
G1 X102.591 Y141.972 E.03264
G1 X84.534 Y160.028 E1.30893
G1 X85.171 Y160.028 E.03264
G1 X103.227 Y141.972 E1.30893
G1 X103.864 Y141.972 E.03264
G1 X85.808 Y160.028 E1.30893
G1 X86.444 Y160.028 E.03264
G1 X104.501 Y141.972 E1.30893
G1 X105.137 Y141.972 E.03264
G1 X87.081 Y160.028 E1.30893
G1 X87.718 Y160.028 E.03264
G1 X105.774 Y141.972 E1.30893
G1 X106.411 Y141.972 E.03264
G1 X88.354 Y160.028 E1.30893
G1 X88.991 Y160.028 E.03264
G1 X107.048 Y141.972 E1.30893
G1 X107.684 Y141.972 E.03264
G1 X89.628 Y160.028 E1.30893
G1 X90.265 Y160.028 E.03264
G1 X108.321 Y141.972 E1.30893
G1 X108.958 Y141.972 E.03264
G1 X90.901 Y160.028 E1.30893
G1 X91.538 Y160.028 E.03264
G1 X109.595 Y141.972 E1.30893
G1 X110.231 Y141.972 E.03264
G1 X91.972 Y160.231 E1.32361
G1 X48.039 Y160.231 F30000
G1 F3000
G1 X116.297 Y91.972 E4.94816
G1 X115.661 Y91.972 E.03264
G1 X47.604 Y160.028 E4.93348
G1 X46.968 Y160.028 E.03264
G1 X115.024 Y91.972 E4.93348
G1 X114.387 Y91.972 E.03264
G1 X46.331 Y160.028 E4.93348
G1 X45.694 Y160.028 E.03264
G1 X113.751 Y91.972 E4.93348
G1 X113.114 Y91.972 E.03264
G1 X45.057 Y160.028 E4.93348
G1 X44.421 Y160.028 E.03264
G1 X112.477 Y91.972 E4.93348
G1 X111.84 Y91.972 E.03264
G1 X43.784 Y160.028 E4.93348
G1 X43.147 Y160.028 E.03264
G1 X111.204 Y91.972 E4.93348
G1 X110.567 Y91.972 E.03264
G1 X71.399 Y131.139 E2.8393
G1 X71.775 Y130.372 E.04382
G1 X71.926 Y129.976 E.02171
G1 X109.93 Y91.972 E2.75496
G1 X109.294 Y91.972 E.03264
G1 X72.25 Y129.016 E2.68536
G2 X72.457 Y128.172 I-4.516 J-1.556 E.04461
G1 X108.657 Y91.972 E2.62418
G1 X108.02 Y91.972 E.03264
G1 X72.59 Y127.402 E2.56837
G1 X72.654 Y126.701 E.03607
G1 X107.383 Y91.972 E2.51757
G1 X106.747 Y91.972 E.03264
G1 X72.672 Y126.046 E2.47008
G2 X72.665 Y125.417 I-3.448 J-.273 E.03229
G1 X106.11 Y91.972 E2.42448
G1 X105.473 Y91.972 E.03264
G1 X72.611 Y124.834 E2.38218
G2 X72.538 Y124.27 I-3.904 J.222 E.02915
G1 X104.837 Y91.972 E2.34134
G1 X104.2 Y91.972 E.03264
G1 X72.439 Y123.732 E2.30236
G2 X72.315 Y123.219 I-2.868 J.42 E.02709
G1 X103.563 Y91.972 E2.26517
G1 X102.926 Y91.972 E.03264
G1 X72.176 Y122.722 E2.22912
G2 X72.012 Y122.249 I-3.288 J.876 E.02567
G1 X102.29 Y91.972 E2.19485
G1 X101.653 Y91.972 E.03264
G1 X71.836 Y121.788 E2.16144
G2 X71.639 Y121.349 I-2.505 J.863 E.02472
G1 X101.016 Y91.972 E2.12961
G1 X100.379 Y91.972 E.03264
G1 X71.429 Y120.922 E2.09862
G2 X71.203 Y120.512 I-2.356 J1.035 E.02405
G1 X99.743 Y91.972 E2.0689
G1 X99.106 Y91.972 E.03264
G1 X70.962 Y120.116 E2.0402
G2 X70.709 Y119.732 I-2.23 J1.193 E.0236
M73 P70 R15
G1 X98.469 Y91.972 E2.01237
G1 X97.833 Y91.972 E.03264
G1 X70.438 Y119.366 E1.98585
G2 X70.161 Y119.006 I-2.109 J1.336 E.02331
G1 X97.196 Y91.972 E1.95976
G1 X96.559 Y91.972 E.03264
G1 X69.861 Y118.67 E1.93537
G1 X69.561 Y118.333 E.02312
G1 X95.922 Y91.972 E1.91098
G1 X95.286 Y91.972 E.03264
G1 X69.232 Y118.026 E1.88867
G1 X68.903 Y117.718 E.02309
G1 X94.649 Y91.972 E1.86638
G1 X94.012 Y91.972 E.03264
G1 X68.551 Y117.433 E1.84572
G1 X68.192 Y117.155 E.02326
G1 X93.376 Y91.972 E1.82555
G1 X92.739 Y91.972 E.03264
G1 X67.817 Y116.894 E1.80661
G1 X67.429 Y116.645 E.02363
G1 X92.102 Y91.972 E1.7886
G1 X91.465 Y91.972 E.03264
G1 X67.028 Y116.409 E1.77151
G1 X66.608 Y116.192 E.02421
G1 X90.829 Y91.972 E1.75575
G1 X90.192 Y91.972 E.03264
G1 X66.179 Y115.984 E1.74069
G1 X65.727 Y115.8 E.02504
G1 X89.555 Y91.972 E1.72733
G1 X88.918 Y91.972 E.03264
G1 X65.266 Y115.624 E1.7146
M73 P70 R14
G1 X64.778 Y115.476 E.02615
G1 X88.282 Y91.972 E1.70381
G1 X87.645 Y91.972 E.03264
G1 X64.279 Y115.338 E1.69384
G1 X63.752 Y115.228 E.0276
G1 X87.008 Y91.972 E1.6859
G1 X86.372 Y91.972 E.03264
G1 X63.205 Y115.138 E1.67934
G1 X62.634 Y115.073 E.02948
G1 X85.735 Y91.972 E1.67461
G1 X85.098 Y91.972 E.03264
G1 X62.027 Y115.043 E1.67245
G2 X61.399 Y115.034 I-.361 J3.439 E.03224
G1 X84.461 Y91.972 E1.67183
G1 X83.825 Y91.972 E.03264
G1 X60.715 Y115.081 E1.67521
G2 X59.984 Y115.175 I.151 J4.053 E.03783
G1 X83.188 Y91.972 E1.68205
G1 X82.551 Y91.972 E.03264
G1 X59.193 Y115.33 E1.69323
G1 X58.511 Y115.504 E.03612
G1 X58.311 Y115.575 E.01086
G1 X81.915 Y91.972 E1.71103
G1 X81.278 Y91.972 E.03264
M73 P71 R14
G1 X57.275 Y115.975 E1.74
G2 X55.936 Y116.677 I3.884 J9.034 E.07759
G1 X80.641 Y91.972 E1.79092
G1 X80.004 Y91.972 E.03264
G1 X28.972 Y143.004 E3.6994
G1 X28.972 Y143.641 E.03264
G1 X52.379 Y120.233 E1.69684
G1 X51.856 Y121.175 E.05521
G1 X51.688 Y121.562 E.02162
G1 X28.972 Y144.278 E1.64672
G1 X28.972 Y144.915 E.03264
G1 X51.292 Y122.594 E1.61801
G2 X51.043 Y123.48 I4.728 J1.807 E.04722
G1 X28.972 Y145.551 E1.59996
G1 X28.972 Y146.188 E.03264
G1 X50.883 Y124.276 E1.58839
G1 X50.849 Y124.526 E.01291
G2 X50.783 Y125.013 I2.638 J.605 E.02525
G1 X28.972 Y146.825 E1.58112
G1 X28.972 Y147.461 E.03264
G1 X50.753 Y125.681 E1.57892
G2 X50.753 Y126.317 I3.483 J.319 E.03269
G1 X28.972 Y148.098 E1.57891
G1 X28.972 Y148.735 E.03264
G1 X50.78 Y126.926 E1.58092
G2 X50.851 Y127.492 I11.861 J-1.205 E.02922
G1 X28.972 Y149.372 E1.58608
G1 X28.972 Y150.008 E.03264
G1 X50.933 Y128.047 E1.59201
G1 X51.053 Y128.564 E.0272
G1 X28.972 Y150.645 E1.6007
G1 X28.972 Y151.282 E.03264
G1 X51.182 Y129.072 E1.61002
G1 X51.34 Y129.551 E.02584
G1 X28.972 Y151.918 E1.62147
G1 X28.972 Y152.555 E.03264
G1 X51.506 Y130.021 E1.63356
G1 X51.699 Y130.464 E.02481
G1 X28.972 Y153.192 E1.64754
G1 X28.972 Y153.829 E.03264
G1 X51.898 Y130.902 E1.66195
G1 X52.123 Y131.314 E.02404
G1 X28.972 Y154.465 E1.67828
G1 X28.972 Y155.102 E.03264
G1 X52.35 Y131.723 E1.69474
G1 X52.606 Y132.104 E.02352
G1 X28.972 Y155.739 E1.7133
G1 X28.972 Y156.375 E.03264
G1 X52.862 Y132.485 E1.73185
G2 X53.144 Y132.84 I2.08 J-1.365 E.02326
G1 X28.972 Y157.012 E1.7523
G1 X28.972 Y157.649 E.03264
G1 X53.43 Y133.191 E1.77301
G2 X53.735 Y133.522 I1.967 J-1.505 E.02313
G1 X28.972 Y158.286 E1.79514
G1 X28.972 Y158.922 E.03264
G1 X54.05 Y133.844 E1.81795
G2 X54.378 Y134.153 I1.855 J-1.642 E.02312
G1 X28.972 Y159.559 E1.84173
G1 X28.972 Y160.028 E.02405
G1 X29.139 Y160.028 E.00859
G1 X54.722 Y134.446 E1.8545
G2 X55.073 Y134.731 I1.742 J-1.781 E.02323
G1 X29.776 Y160.028 E1.83378
G1 X30.413 Y160.028 E.03264
G1 X55.446 Y134.995 E1.81468
G2 X55.821 Y135.257 I1.615 J-1.915 E.02347
G1 X31.05 Y160.028 E1.79571
G1 X31.686 Y160.028 E.03264
G1 X56.225 Y135.49 E1.77882
G1 X56.628 Y135.723 E.02389
G1 X32.323 Y160.028 E1.76192
G1 X32.96 Y160.028 E.03264
G1 X57.061 Y135.927 E1.74715
G1 X57.497 Y136.128 E.02459
G1 X33.596 Y160.028 E1.73257
G1 X34.233 Y160.028 E.03264
G1 X57.961 Y136.3 E1.72005
G1 X58.431 Y136.467 E.02556
G1 X34.87 Y160.028 E1.70795
G1 X35.507 Y160.028 E.03264
G1 X58.931 Y136.603 E1.69809
G1 X59.438 Y136.733 E.02683
G1 X36.143 Y160.028 E1.68869
G1 X36.78 Y160.028 E.03264
G1 X59.984 Y136.825 E1.68206
G2 X60.538 Y136.907 I.729 J-3 E.02877
G1 X37.417 Y160.028 E1.6761
G1 X38.054 Y160.028 E.03264
M73 P72 R14
G1 X61.134 Y136.948 E1.67314
G2 X61.755 Y136.963 I.396 J-3.392 E.03189
G1 X38.69 Y160.028 E1.672
G1 X39.327 Y160.028 E.03264
G1 X62.407 Y136.948 E1.67308
G2 X63.12 Y136.872 I-2.142 J-23.273 E.03678
G1 X39.964 Y160.028 E1.67864
G1 X40.6 Y160.028 E.03264
G1 X63.885 Y136.744 E1.6879
G2 X64.725 Y136.541 I-.692 J-4.699 E.04435
G1 X41.237 Y160.028 E1.70263
G1 X41.874 Y160.028 E.03264
G1 X65.685 Y136.217 E1.72608
G2 X66.863 Y135.676 I-3.426 J-9.011 E.06649
G1 X42.308 Y160.231 E1.77998
G1 X28.769 Y142.57 F30000
G1 F3000
G1 X79.368 Y91.972 E3.66793
G1 X78.731 Y91.972 E.03264
G1 X28.972 Y141.731 E3.60709
G1 X28.972 Y141.094 E.03264
G1 X78.094 Y91.972 E3.56093
G1 X77.457 Y91.972 E.03264
G1 X28.972 Y140.457 E3.51478
G1 X28.972 Y139.821 E.03264
G1 X76.821 Y91.972 E3.46862
G1 X76.184 Y91.972 E.03264
G1 X28.972 Y139.184 E3.42246
G1 X28.972 Y138.547 E.03264
G1 X75.547 Y91.972 E3.37631
G1 X74.911 Y91.972 E.03264
G1 X28.972 Y137.911 E3.33015
G1 X28.972 Y137.274 E.03264
G1 X74.274 Y91.972 E3.28399
G1 X73.637 Y91.972 E.03264
G1 X28.972 Y136.637 E3.23784
G1 X28.972 Y136 E.03264
G1 X73 Y91.972 E3.19168
G1 X72.364 Y91.972 E.03264
G1 X28.972 Y135.364 E3.14552
G1 X28.972 Y134.727 E.03264
G1 X71.727 Y91.972 E3.09937
G1 X71.09 Y91.972 E.03264
G1 X28.972 Y134.09 E3.05321
G1 X28.972 Y133.454 E.03264
G1 X70.454 Y91.972 E3.00705
G1 X69.817 Y91.972 E.03264
G1 X28.972 Y132.817 E2.9609
G1 X28.972 Y132.18 E.03264
G1 X69.18 Y91.972 E2.91474
G1 X68.543 Y91.972 E.03264
G1 X28.972 Y131.543 E2.86858
G1 X28.972 Y130.907 E.03264
G1 X67.907 Y91.972 E2.82243
G1 X67.27 Y91.972 E.03264
G1 X28.972 Y130.27 E2.77627
G1 X28.972 Y129.633 E.03264
G1 X66.633 Y91.972 E2.73011
G1 X65.996 Y91.972 E.03264
M73 P72 R13
G1 X28.972 Y128.996 E2.68396
G1 X28.972 Y128.36 E.03264
G1 X65.36 Y91.972 E2.6378
G1 X64.723 Y91.972 E.03264
G1 X28.972 Y127.723 E2.59165
G1 X28.972 Y127.086 E.03264
G1 X64.086 Y91.972 E2.54549
G1 X63.45 Y91.972 E.03264
G1 X28.972 Y126.45 E2.49933
G1 X28.972 Y125.813 E.03264
G1 X62.813 Y91.972 E2.45318
G1 X62.176 Y91.972 E.03264
G1 X28.972 Y125.176 E2.40702
G1 X28.972 Y124.539 E.03264
G1 X61.539 Y91.972 E2.36086
G1 X60.903 Y91.972 E.03264
G1 X28.972 Y123.903 E2.31471
G1 X28.972 Y123.266 E.03264
G1 X60.266 Y91.972 E2.26855
M73 P73 R13
G1 X59.629 Y91.972 E.03264
G1 X28.972 Y122.629 E2.22239
G1 X28.972 Y121.993 E.03264
G1 X58.993 Y91.972 E2.17624
G1 X58.356 Y91.972 E.03264
G1 X28.972 Y121.356 E2.13008
G1 X28.972 Y120.719 E.03264
G1 X57.719 Y91.972 E2.08392
G1 X57.082 Y91.972 E.03264
G1 X28.972 Y120.082 E2.03777
G1 X28.972 Y119.446 E.03264
G1 X56.446 Y91.972 E1.99161
G1 X55.809 Y91.972 E.03264
G1 X28.972 Y118.809 E1.94545
G1 X28.972 Y118.172 E.03264
G1 X55.172 Y91.972 E1.8993
G1 X54.536 Y91.972 E.03264
G1 X28.972 Y117.535 E1.85314
G1 X28.972 Y116.899 E.03264
G1 X53.899 Y91.972 E1.80698
G1 X53.262 Y91.972 E.03264
G1 X28.972 Y116.262 E1.76083
G1 X28.972 Y115.625 E.03264
G1 X52.625 Y91.972 E1.71467
G1 X51.989 Y91.972 E.03264
G1 X28.972 Y114.989 E1.66851
G1 X28.972 Y114.352 E.03264
G1 X51.352 Y91.972 E1.62236
G1 X50.715 Y91.972 E.03264
G1 X28.972 Y113.715 E1.5762
G1 X28.972 Y113.078 E.03264
G1 X50.078 Y91.972 E1.53004
G1 X49.442 Y91.972 E.03264
G1 X28.972 Y112.442 E1.48389
G1 X28.972 Y111.805 E.03264
G1 X48.805 Y91.972 E1.43773
G1 X48.168 Y91.972 E.03264
G1 X28.972 Y111.168 E1.39157
G1 X28.972 Y110.532 E.03264
G1 X47.532 Y91.972 E1.34542
G1 X46.895 Y91.972 E.03264
G1 X28.972 Y109.895 E1.29926
G1 X28.972 Y109.258 E.03264
G1 X46.258 Y91.972 E1.2531
G1 X45.621 Y91.972 E.03264
G1 X28.972 Y108.621 E1.20695
G1 X28.972 Y107.985 E.03264
G1 X44.985 Y91.972 E1.16079
G1 X44.348 Y91.972 E.03264
G1 X28.972 Y107.348 E1.11463
G1 X28.972 Y106.711 E.03264
G1 X43.711 Y91.972 E1.06848
G1 X43.075 Y91.972 E.03264
G1 X28.972 Y106.075 E1.02232
G1 X28.972 Y105.438 E.03264
G1 X42.438 Y91.972 E.97616
G1 X41.801 Y91.972 E.03264
M73 P74 R13
G1 X28.972 Y104.801 E.93001
G1 X28.972 Y104.164 E.03264
G1 X41.164 Y91.972 E.88385
G1 X40.528 Y91.972 E.03264
G1 X28.972 Y103.528 E.8377
G1 X28.972 Y102.891 E.03264
G1 X39.891 Y91.972 E.79154
G1 X39.254 Y91.972 E.03264
G1 X28.972 Y102.254 E.74538
G1 X28.972 Y101.617 E.03264
G1 X38.617 Y91.972 E.69923
G1 X37.981 Y91.972 E.03264
G1 X28.972 Y100.981 E.65307
G1 X28.972 Y100.344 E.03264
G1 X37.344 Y91.972 E.60691
G1 X36.707 Y91.972 E.03264
G1 X28.972 Y99.707 E.56076
G1 X28.972 Y99.071 E.03264
G1 X36.071 Y91.972 E.5146
G1 X35.434 Y91.972 E.03264
G1 X28.972 Y98.434 E.46844
G1 X28.972 Y97.797 E.03264
G1 X30.822 Y95.947 E.13409
G3 X30.184 Y95.948 I-.32 J-1.805 E.03283
G1 X28.972 Y97.16 E.0879
G1 X28.972 Y96.524 E.03264
G1 X29.666 Y95.83 E.05032
G3 X29.23 Y95.629 I3.686 J-8.58 E.02461
G1 X28.769 Y96.089 E.03339
; WIPE_START
G1 X29.23 Y95.629 E-.24756
G1 X29.666 Y95.83 E-.18239
G1 X29.052 Y96.444 E-.33005
; WIPE_END
G1 E-.04 F1800
G1 X28.619 Y94.531 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354364
; LAYER_HEIGHT: 0.2
G1 F15000
G1 X28.559 Y94.192 E.00874
; LINE_WIDTH: 0.327696
G1 X28.537 Y94.026 E.00389
; LINE_WIDTH: 0.283928
G1 X28.516 Y93.86 E.00329
; LINE_WIDTH: 0.244295
G3 X28.514 Y93.159 I5.787 J-.364 E.0115
; LINE_WIDTH: 0.281522
G3 X28.537 Y92.974 I2.134 J.177 E.00363
; LINE_WIDTH: 0.327686
G1 X28.559 Y92.808 E.00389
; LINE_WIDTH: 0.354373
G1 X28.619 Y92.469 E.00874
G1 X29.469 Y91.619 F30000
; LINE_WIDTH: 0.354364
G1 F15000
G1 X29.808 Y91.559 E.00874
; LINE_WIDTH: 0.327691
G1 X29.974 Y91.537 E.00389
; LINE_WIDTH: 0.283913
G1 X30.14 Y91.516 E.00329
; LINE_WIDTH: 0.244295
G3 X30.841 Y91.514 I.364 J5.786 E.0115
; LINE_WIDTH: 0.281527
G3 X31.026 Y91.537 I-.177 J2.135 E.00363
; LINE_WIDTH: 0.327704
G1 X31.192 Y91.559 E.00389
; LINE_WIDTH: 0.354373
G1 X31.531 Y91.619 E.00874
; WIPE_START
G1 X31.192 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X32.476 Y92.382 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40023
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X32.887 Y91.972 E.02976
G1 X33.524 Y91.972 E.03264
G1 X32.83 Y92.666 E.05032
G1 X32.938 Y93.07 E.02146
G1 X32.948 Y93.184 E.00587
G1 X34.16 Y91.972 E.0879
G1 X34.797 Y91.972 E.03264
G1 X32.688 Y94.081 E.15292
; CHANGE_LAYER
; Z_HEIGHT: 4.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X34.102 Y92.667 E-.76
; WIPE_END
M73 P74 R12
G1 E-.04 F1800
; layer num/total_layer_count: 22/25
; update layer progress
M73 L22
M991 S0 P21 ;notify layer change
G17
G3 Z4.6 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z4.8 F30000
G1 X51.288 Y124.062 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.504 Y123.14 E.03141
G3 X60.507 Y115.466 I10.207 J2.857 E.41631
G1 X61.47 Y115.4 E.03202
G3 X51.279 Y124.121 I.241 J10.597 E1.72746
M204 S250
G1 X51.67 Y124.15 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X51.881 Y123.246 E.02855
G3 X60.551 Y115.856 I9.83 J2.751 E.37136
G1 X61.479 Y115.792 E.02856
G3 X51.661 Y124.208 I.232 J10.205 E1.54042
; WIPE_START
M204 S10000
G1 X51.881 Y123.246 E-.3751
G1 X52.171 Y122.363 E-.3531
G1 X52.204 Y122.286 E-.03181
; WIPE_END
G1 E-.04 F1800
G1 X59.736 Y121.053 Z4.8 F30000
G1 X223.537 Y94.251 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.684 Y94.548 E.01099
G2 X227.227 Y94.688 I1.816 J-1.048 E.14015
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.727 J-1.188 E.24389
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.522 Y94.194 I1.188 J1.727 E.09078
M204 S250
G1 X223.893 Y94.086 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X223.902 Y94.082 E.00032
G3 X225.258 Y91.81 I1.606 J-.582 E.09295
G3 X226.085 Y91.892 I.234 J1.851 E.02576
G3 X224.027 Y94.351 I-.577 J1.608 E.20188
G1 X223.92 Y94.139 E.00728
; WIPE_START
M204 S10000
G1 X223.902 Y94.082 E-.02291
G1 X223.815 Y93.797 E-.11305
G1 X223.789 Y93.5 E-.11331
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11331
G1 X224.018 Y92.645 E-.11332
G1 X224.189 Y92.4 E-.11333
G1 X224.296 Y92.293 E-.05744
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02175
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.191 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24921
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07626
G1 X227.039 Y92.074 E-.03915
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z4.8 F30000
G1 X32.107 Y94.087 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X31.984 Y94.357 E.00911
G3 X30.258 Y91.81 I-1.476 J-.858 E.21186
G3 X31.085 Y91.892 I.234 J1.851 E.02577
G3 X32.129 Y94.034 I-.577 J1.607 E.08104
; WIPE_START
M204 S10000
G1 X31.984 Y94.357 E-.13452
G1 X31.811 Y94.6 E-.11342
G1 X31.6 Y94.811 E-.11335
G1 X31.355 Y94.982 E-.11331
G1 X31.085 Y95.108 E-.11332
G1 X30.797 Y95.185 E-.11332
G1 X30.643 Y95.198 E-.05877
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.731 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08589
G1 X28.888 Y92.147 E-.13941
G1 X28.773 Y92.312 E-.07628
G1 X28.602 Y92.258 E-.06804
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14116
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z4.8 F30000
G1 X227.79 Y91.21 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354373
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327691
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281539
G2 X225.841 Y91.514 I-.363 J2.118 E.00363
; LINE_WIDTH: 0.244295
G2 X225.14 Y91.516 I-.337 J5.786 E.0115
; LINE_WIDTH: 0.283928
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327696
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354364
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y92.469 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.354366
G1 F15000
G1 X227.441 Y92.808 E.00874
; LINE_WIDTH: 0.327686
G1 X227.463 Y92.974 E.00389
; LINE_WIDTH: 0.283899
G1 X227.484 Y93.14 E.00329
; LINE_WIDTH: 0.244285
G3 X227.486 Y93.841 I-5.785 J.364 E.0115
; LINE_WIDTH: 0.281523
G3 X227.463 Y94.026 I-2.14 J-.178 E.00363
; LINE_WIDTH: 0.327686
G1 X227.441 Y94.192 E.00389
; LINE_WIDTH: 0.354354
G1 X227.381 Y94.531 E.00873
; WIPE_START
G1 X227.441 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.329 Y101.824 Z4.8 F30000
G1 X226.471 Y160.234 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42058
G1 F15000
G1 X227.065 Y159.641 E.02584
G1 X227.065 Y159.106 E.01644
G1 X226.106 Y160.065 E.0417
G1 X225.572 Y160.065 E.01644
G1 X227.065 Y158.572 E.06495
G1 X227.065 Y158.038 E.01644
G1 X225.038 Y160.065 E.08819
G1 X224.504 Y160.065 E.01644
G1 X227.065 Y157.504 E.11144
G1 X227.065 Y156.97 E.01644
G1 X223.97 Y160.065 E.13468
G1 X223.436 Y160.065 E.01644
G1 X227.065 Y156.436 E.15793
G1 X227.065 Y155.902 E.01644
G1 X222.902 Y160.065 E.18117
G1 X222.368 Y160.065 E.01644
G1 X227.065 Y155.368 E.20442
G1 X227.065 Y154.834 E.01644
G1 X221.834 Y160.065 E.22766
G1 X221.3 Y160.065 E.01644
G1 X227.065 Y154.3 E.25091
G1 X227.065 Y153.766 E.01644
G1 X220.766 Y160.065 E.27415
G1 X220.231 Y160.065 E.01644
G1 X227.065 Y153.231 E.2974
G1 X227.065 Y152.697 E.01644
G1 X219.697 Y160.065 E.32064
G1 X219.163 Y160.065 E.01644
G1 X227.065 Y152.163 E.34388
G1 X227.065 Y151.629 E.01644
G1 X218.629 Y160.065 E.36713
G1 X218.095 Y160.065 E.01644
G1 X227.065 Y151.095 E.39037
G1 X227.065 Y150.561 E.01644
G1 X217.561 Y160.065 E.41362
G1 X217.027 Y160.065 E.01644
G1 X227.065 Y150.027 E.43686
G1 X227.065 Y149.493 E.01644
G1 X216.493 Y160.065 E.46011
G1 X215.959 Y160.065 E.01644
G1 X227.065 Y148.959 E.48335
G1 X227.065 Y148.425 E.01644
G1 X215.425 Y160.065 E.5066
G1 X214.891 Y160.065 E.01644
G1 X227.065 Y147.891 E.52984
G1 X227.065 Y147.356 E.01644
G1 X214.356 Y160.065 E.55309
G1 X213.822 Y160.065 E.01644
G1 X227.065 Y146.822 E.57633
G1 X227.065 Y146.288 E.01644
G1 X213.288 Y160.065 E.59957
G1 X212.754 Y160.065 E.01644
G1 X227.065 Y145.754 E.62282
G1 X227.065 Y145.22 E.01644
G1 X212.22 Y160.065 E.64606
G1 X211.686 Y160.065 E.01644
G1 X227.065 Y144.686 E.66931
G1 X227.065 Y144.152 E.01644
G1 X211.152 Y160.065 E.69255
G1 X210.618 Y160.065 E.01644
G1 X227.065 Y143.618 E.7158
G1 X227.065 Y143.084 E.01644
G1 X210.084 Y160.065 E.73904
G1 X209.55 Y160.065 E.01644
G1 X227.065 Y142.55 E.76229
G1 X227.065 Y142.015 E.01644
G1 X209.015 Y160.065 E.78553
G1 X208.481 Y160.065 E.01644
G1 X227.065 Y141.481 E.80878
G1 X227.065 Y140.947 E.01644
G1 X207.947 Y160.065 E.83202
G1 X207.413 Y160.065 E.01644
G1 X227.065 Y140.413 E.85527
G1 X227.065 Y139.879 E.01644
G1 X206.879 Y160.065 E.87851
G1 X206.345 Y160.065 E.01644
G1 X227.065 Y139.345 E.90175
G1 X227.065 Y138.811 E.01644
G1 X205.811 Y160.065 E.925
G1 X205.277 Y160.065 E.01644
M73 P75 R12
G1 X227.065 Y138.277 E.94824
G1 X227.065 Y137.743 E.01644
G1 X204.743 Y160.065 E.97149
G1 X204.209 Y160.065 E.01644
G1 X227.065 Y137.209 E.99473
G1 X227.065 Y136.675 E.01644
G1 X203.675 Y160.065 E1.01798
G1 X203.14 Y160.065 E.01644
G1 X227.065 Y136.14 E1.04122
G1 X227.065 Y135.606 E.01644
G1 X202.606 Y160.065 E1.06447
G1 X202.072 Y160.065 E.01644
G1 X227.065 Y135.072 E1.08771
G1 X227.065 Y134.538 E.01644
G1 X201.538 Y160.065 E1.11096
G1 X201.004 Y160.065 E.01644
G1 X227.065 Y134.004 E1.1342
G1 X227.065 Y133.47 E.01644
G1 X200.47 Y160.065 E1.15745
G1 X199.936 Y160.065 E.01644
G1 X227.065 Y132.936 E1.18069
G1 X227.065 Y132.402 E.01644
G1 X199.402 Y160.065 E1.20393
G1 X198.868 Y160.065 E.01644
G1 X227.065 Y131.868 E1.22718
G1 X227.065 Y131.334 E.01644
G1 X198.334 Y160.065 E1.25042
G1 X197.8 Y160.065 E.01644
G1 X227.065 Y130.8 E1.27367
G1 X227.065 Y130.265 E.01644
G1 X197.265 Y160.065 E1.29691
G1 X196.731 Y160.065 E.01644
G1 X227.065 Y129.731 E1.32016
G1 X227.065 Y129.197 E.01644
G1 X196.197 Y160.065 E1.3434
G1 X195.663 Y160.065 E.01644
G1 X227.065 Y128.663 E1.36665
G1 X227.065 Y128.129 E.01644
G1 X195.129 Y160.065 E1.38989
G1 X194.595 Y160.065 E.01644
G1 X227.065 Y127.595 E1.41314
G1 X227.065 Y127.061 E.01644
G1 X194.061 Y160.065 E1.43638
G1 X193.527 Y160.065 E.01644
G1 X227.065 Y126.527 E1.45962
G1 X227.065 Y125.993 E.01644
G1 X192.993 Y160.065 E1.48287
G1 X192.459 Y160.065 E.01644
G1 X227.065 Y125.459 E1.50611
G1 X227.065 Y124.925 E.01644
G1 X191.925 Y160.065 E1.52936
G1 X191.39 Y160.065 E.01644
G1 X227.065 Y124.39 E1.5526
G1 X227.065 Y123.856 E.01644
G1 X190.856 Y160.065 E1.57585
G1 X190.322 Y160.065 E.01644
G1 X227.065 Y123.322 E1.59909
G1 X227.065 Y122.788 E.01644
G1 X189.788 Y160.065 E1.62234
G1 X189.254 Y160.065 E.01644
G1 X227.065 Y122.254 E1.64558
G1 X227.065 Y121.72 E.01644
G1 X188.72 Y160.065 E1.66883
G1 X188.186 Y160.065 E.01644
G1 X227.065 Y121.186 E1.69207
G1 X227.065 Y120.652 E.01644
G1 X187.652 Y160.065 E1.71532
G1 X187.118 Y160.065 E.01644
G1 X227.065 Y120.118 E1.73856
G1 X227.065 Y119.584 E.01644
G1 X186.584 Y160.065 E1.7618
G1 X186.05 Y160.065 E.01644
G1 X227.065 Y119.05 E1.78505
G1 X227.065 Y118.515 E.01644
G1 X185.515 Y160.065 E1.80829
G1 X184.981 Y160.065 E.01644
G1 X227.065 Y117.981 E1.83154
G1 X227.065 Y117.447 E.01644
G1 X184.447 Y160.065 E1.85478
G1 X183.913 Y160.065 E.01644
G1 X227.065 Y116.913 E1.87803
G1 X227.065 Y116.379 E.01644
G1 X183.379 Y160.065 E1.90127
G1 X182.845 Y160.065 E.01644
G1 X227.065 Y115.845 E1.92452
G1 X227.065 Y115.311 E.01644
G1 X182.311 Y160.065 E1.94776
G1 X181.777 Y160.065 E.01644
G1 X227.065 Y114.777 E1.97101
G1 X227.065 Y114.243 E.01644
G1 X181.243 Y160.065 E1.99425
G1 X180.709 Y160.065 E.01644
G1 X227.065 Y113.709 E2.0175
G1 X227.065 Y113.175 E.01644
G1 X180.175 Y160.065 E2.04074
G1 X179.64 Y160.065 E.01644
G1 X227.065 Y112.64 E2.06398
G1 X227.065 Y112.106 E.01644
G1 X179.106 Y160.065 E2.08723
G1 X178.572 Y160.065 E.01644
G1 X227.065 Y111.572 E2.11047
G1 X227.065 Y111.038 E.01644
G1 X178.038 Y160.065 E2.13372
G1 X177.504 Y160.065 E.01644
G1 X227.065 Y110.504 E2.15696
G1 X227.065 Y109.97 E.01644
G1 X176.97 Y160.065 E2.18021
G1 X176.436 Y160.065 E.01644
G1 X227.065 Y109.436 E2.20345
G1 X227.065 Y108.902 E.01644
G1 X175.902 Y160.065 E2.2267
G1 X175.368 Y160.065 E.01644
G1 X227.065 Y108.368 E2.24994
G1 X227.065 Y107.834 E.01644
G1 X174.834 Y160.065 E2.27319
G1 X174.3 Y160.065 E.01644
G1 X227.065 Y107.3 E2.29643
G1 X227.065 Y106.765 E.01644
G1 X173.765 Y160.065 E2.31967
G1 X173.231 Y160.065 E.01644
G1 X227.065 Y106.231 E2.34292
G1 X227.065 Y105.697 E.01644
G1 X172.697 Y160.065 E2.36616
G1 X172.163 Y160.065 E.01644
G1 X227.065 Y105.163 E2.38941
G1 X227.065 Y104.629 E.01644
G1 X171.629 Y160.065 E2.41265
G1 X171.095 Y160.065 E.01644
G1 X227.065 Y104.095 E2.4359
G1 X227.065 Y103.561 E.01644
G1 X170.561 Y160.065 E2.45914
G1 X170.027 Y160.065 E.01644
G1 X227.065 Y103.027 E2.48239
G1 X227.065 Y102.493 E.01644
G1 X169.493 Y160.065 E2.50563
G1 X168.959 Y160.065 E.01644
G1 X227.065 Y101.959 E2.52888
G1 X227.065 Y101.425 E.01644
G1 X168.425 Y160.065 E2.55212
G1 X167.89 Y160.065 E.01644
G1 X227.065 Y100.89 E2.57537
G1 X227.065 Y100.356 E.01644
G1 X167.356 Y160.065 E2.59861
G1 X166.822 Y160.065 E.01644
G1 X227.065 Y99.822 E2.62185
G1 X227.065 Y99.288 E.01644
G1 X166.288 Y160.065 E2.6451
G1 X165.754 Y160.065 E.01644
G1 X227.065 Y98.754 E2.66834
G1 X227.065 Y98.22 E.01644
G1 X165.22 Y160.065 E2.69159
G1 X164.686 Y160.065 E.01644
G1 X227.065 Y97.686 E2.71483
G1 X227.065 Y97.152 E.01644
G1 X164.152 Y160.065 E2.73808
G1 X163.618 Y160.065 E.01644
G1 X227.065 Y96.618 E2.76132
G1 X227.065 Y96.084 E.01644
G1 X163.084 Y160.065 E2.78457
G1 X162.549 Y160.065 E.01644
G1 X227.065 Y95.55 E2.80781
G1 X227.065 Y95.37 E.00551
G3 X226.272 Y95.809 I-1.782 J-2.289 E.028
G1 X162.015 Y160.065 E2.79654
G1 X161.481 Y160.065 E.01644
G1 X225.617 Y95.929 E2.79131
G1 X225.5 Y95.939 E.00363
G1 X225.107 Y95.905 E.01213
G1 X160.947 Y160.065 E2.79236
G1 X160.413 Y160.065 E.01644
G1 X224.682 Y95.796 E2.79708
G1 X224.315 Y95.628 E.0124
G1 X159.879 Y160.065 E2.80438
G1 X159.345 Y160.065 E.01644
G1 X223.996 Y95.413 E2.81374
G3 X223.72 Y95.156 I.592 J-.913 E.01169
G1 X158.811 Y160.065 E2.82495
G1 X158.277 Y160.065 E.01644
G1 X223.484 Y94.857 E2.83794
G3 X223.292 Y94.515 I.874 J-.715 E.01214
G1 X157.743 Y160.065 E2.85284
G1 X157.209 Y160.065 E.01644
G1 X223.151 Y94.122 E2.86994
G3 X223.075 Y93.664 I1.263 J-.445 E.01437
G1 X156.674 Y160.065 E2.88988
G1 X156.14 Y160.065 E.01644
G1 X223.095 Y93.11 E2.91399
G1 X223.098 Y93.077 E.00103
G3 X223.386 Y92.285 I2.388 J.42 E.02603
G1 X155.606 Y160.065 E2.94987
G1 X155.072 Y160.065 E.01644
G1 X223.202 Y91.935 E2.96511
G1 X222.667 Y91.935 E.01644
G1 X154.538 Y160.065 E2.96511
G1 X154.004 Y160.065 E.01644
G1 X222.133 Y91.935 E2.96511
G1 X221.599 Y91.935 E.01644
G1 X153.47 Y160.065 E2.96511
G1 X152.936 Y160.065 E.01644
G1 X221.065 Y91.935 E2.96511
G1 X220.531 Y91.935 E.01644
G1 X152.402 Y160.065 E2.96511
G1 X151.868 Y160.065 E.01644
G1 X219.997 Y91.935 E2.96511
G1 X219.463 Y91.935 E.01644
G1 X151.334 Y160.065 E2.96511
G1 X150.799 Y160.065 E.01644
G1 X218.929 Y91.935 E2.96511
G1 X218.395 Y91.935 E.01644
G1 X150.265 Y160.065 E2.96511
G1 X149.731 Y160.065 E.01644
G1 X217.861 Y91.935 E2.96511
G1 X217.327 Y91.935 E.01644
G1 X149.197 Y160.065 E2.96511
G1 X148.663 Y160.065 E.01644
G1 X216.792 Y91.935 E2.96511
G1 X216.258 Y91.935 E.01644
G1 X148.129 Y160.065 E2.96511
G1 X147.595 Y160.065 E.01644
G1 X215.724 Y91.935 E2.96511
G1 X215.19 Y91.935 E.01644
G1 X147.061 Y160.065 E2.96511
G1 X146.527 Y160.065 E.01644
G1 X214.656 Y91.935 E2.96511
G1 X214.122 Y91.935 E.01644
G1 X145.993 Y160.065 E2.96511
G1 X145.459 Y160.065 E.01644
G1 X213.588 Y91.935 E2.96511
G1 X213.054 Y91.935 E.01644
G1 X144.924 Y160.065 E2.96511
G1 X144.39 Y160.065 E.01644
G1 X212.52 Y91.935 E2.96511
G1 X211.986 Y91.935 E.01644
G1 X143.856 Y160.065 E2.96511
G1 X143.322 Y160.065 E.01644
G1 X211.452 Y91.935 E2.96511
G1 X210.917 Y91.935 E.01644
G1 X142.788 Y160.065 E2.96511
G1 X142.254 Y160.065 E.01644
G1 X210.383 Y91.935 E2.96511
M73 P76 R12
G1 X209.849 Y91.935 E.01644
G1 X141.72 Y160.065 E2.96511
G1 X141.186 Y160.065 E.01644
G1 X209.315 Y91.935 E2.96511
G1 X208.781 Y91.935 E.01644
G1 X140.652 Y160.065 E2.96511
G1 X140.118 Y160.065 E.01644
G1 X208.247 Y91.935 E2.96511
G1 X207.713 Y91.935 E.01644
G1 X139.584 Y160.065 E2.96511
G1 X139.049 Y160.065 E.01644
G1 X207.179 Y91.935 E2.96511
G1 X206.645 Y91.935 E.01644
G1 X138.515 Y160.065 E2.96511
G1 X137.981 Y160.065 E.01644
G1 X206.111 Y91.935 E2.96511
G1 X205.577 Y91.935 E.01644
G1 X137.447 Y160.065 E2.96511
G1 X136.913 Y160.065 E.01644
G1 X205.042 Y91.935 E2.96511
G1 X204.508 Y91.935 E.01644
G1 X136.379 Y160.065 E2.96511
G1 X135.845 Y160.065 E.01644
G1 X203.974 Y91.935 E2.96511
G1 X203.44 Y91.935 E.01644
G1 X135.311 Y160.065 E2.96511
G1 X134.777 Y160.065 E.01644
G1 X202.906 Y91.935 E2.96511
G1 X202.372 Y91.935 E.01644
G1 X134.243 Y160.065 E2.96511
G1 X133.709 Y160.065 E.01644
G1 X201.838 Y91.935 E2.96511
G1 X201.304 Y91.935 E.01644
G1 X133.174 Y160.065 E2.96511
G1 X132.64 Y160.065 E.01644
G1 X200.77 Y91.935 E2.96511
G1 X200.236 Y91.935 E.01644
G1 X132.106 Y160.065 E2.96511
G1 X131.572 Y160.065 E.01644
G1 X199.702 Y91.935 E2.96511
G1 X199.167 Y91.935 E.01644
G1 X131.038 Y160.065 E2.96511
G1 X130.504 Y160.065 E.01644
G1 X198.633 Y91.935 E2.96511
G1 X198.099 Y91.935 E.01644
G1 X129.97 Y160.065 E2.96511
G1 X129.436 Y160.065 E.01644
G1 X197.565 Y91.935 E2.96511
G1 X197.031 Y91.935 E.01644
G1 X128.902 Y160.065 E2.96511
G1 X128.368 Y160.065 E.01644
G1 X196.497 Y91.935 E2.96511
G1 X195.963 Y91.935 E.01644
G1 X127.834 Y160.065 E2.96511
G1 X127.299 Y160.065 E.01644
G1 X195.429 Y91.935 E2.96511
G1 X194.895 Y91.935 E.01644
G1 X126.765 Y160.065 E2.96511
G1 X126.231 Y160.065 E.01644
G1 X194.361 Y91.935 E2.96511
G1 X193.827 Y91.935 E.01644
G1 X125.697 Y160.065 E2.96511
G1 X125.163 Y160.065 E.01644
G1 X193.292 Y91.935 E2.96511
G1 X192.758 Y91.935 E.01644
G1 X124.629 Y160.065 E2.96511
G1 X124.095 Y160.065 E.01644
G1 X192.224 Y91.935 E2.96511
G1 X191.69 Y91.935 E.01644
G1 X123.561 Y160.065 E2.96511
G1 X123.027 Y160.065 E.01644
G1 X191.156 Y91.935 E2.96511
G1 X190.622 Y91.935 E.01644
G1 X122.493 Y160.065 E2.96511
G1 X121.958 Y160.065 E.01644
G1 X190.088 Y91.935 E2.96511
G1 X189.554 Y91.935 E.01644
G1 X121.424 Y160.065 E2.96511
G1 X120.89 Y160.065 E.01644
G1 X189.02 Y91.935 E2.96511
M73 P76 R11
G1 X188.486 Y91.935 E.01644
G1 X120.356 Y160.065 E2.96511
G1 X119.822 Y160.065 E.01644
G1 X187.952 Y91.935 E2.96511
G1 X187.417 Y91.935 E.01644
G1 X119.288 Y160.065 E2.96511
G1 X118.754 Y160.065 E.01644
G1 X186.883 Y91.935 E2.96511
G1 X186.349 Y91.935 E.01644
G1 X118.22 Y160.065 E2.96511
G1 X117.686 Y160.065 E.01644
G1 X185.815 Y91.935 E2.96511
G1 X185.281 Y91.935 E.01644
G1 X117.152 Y160.065 E2.96511
G1 X116.618 Y160.065 E.01644
G1 X184.747 Y91.935 E2.96511
G1 X184.213 Y91.935 E.01644
G1 X116.083 Y160.065 E2.96511
G1 X115.549 Y160.065 E.01644
G1 X183.679 Y91.935 E2.96511
G1 X183.145 Y91.935 E.01644
G1 X115.015 Y160.065 E2.96511
G1 X114.481 Y160.065 E.01644
G1 X182.611 Y91.935 E2.96511
G1 X182.077 Y91.935 E.01644
G1 X113.947 Y160.065 E2.96511
G1 X113.413 Y160.065 E.01644
G1 X181.542 Y91.935 E2.96511
G1 X181.008 Y91.935 E.01644
G1 X112.879 Y160.065 E2.96511
G1 X112.345 Y160.065 E.01644
G1 X180.474 Y91.935 E2.96511
G1 X179.94 Y91.935 E.01644
G1 X111.811 Y160.065 E2.96511
G1 X111.277 Y160.065 E.01644
G1 X179.406 Y91.935 E2.96511
G1 X178.872 Y91.935 E.01644
G1 X110.743 Y160.065 E2.96511
G1 X110.208 Y160.065 E.01644
G1 X178.338 Y91.935 E2.96511
G1 X177.804 Y91.935 E.01644
G1 X109.674 Y160.065 E2.96511
G1 X109.14 Y160.065 E.01644
G1 X177.27 Y91.935 E2.96511
G1 X176.736 Y91.935 E.01644
G1 X108.606 Y160.065 E2.96511
G1 X108.072 Y160.065 E.01644
G1 X176.201 Y91.935 E2.96511
G1 X175.667 Y91.935 E.01644
G1 X107.538 Y160.065 E2.96511
G1 X107.004 Y160.065 E.01644
G1 X175.133 Y91.935 E2.96511
G1 X174.599 Y91.935 E.01644
G1 X106.47 Y160.065 E2.96511
G1 X105.936 Y160.065 E.01644
G1 X174.065 Y91.935 E2.96511
G1 X173.531 Y91.935 E.01644
G1 X105.402 Y160.065 E2.96511
G1 X104.868 Y160.065 E.01644
G1 X172.997 Y91.935 E2.96511
G1 X172.463 Y91.935 E.01644
G1 X104.333 Y160.065 E2.96511
G1 X103.799 Y160.065 E.01644
G1 X171.929 Y91.935 E2.96511
G1 X171.395 Y91.935 E.01644
G1 X103.265 Y160.065 E2.96511
M73 P77 R11
G1 X102.731 Y160.065 E.01644
G1 X170.861 Y91.935 E2.96511
G1 X170.326 Y91.935 E.01644
G1 X102.197 Y160.065 E2.96511
G1 X101.663 Y160.065 E.01644
G1 X169.792 Y91.935 E2.96511
G1 X169.258 Y91.935 E.01644
G1 X101.129 Y160.065 E2.96511
G1 X100.595 Y160.065 E.01644
G1 X168.724 Y91.935 E2.96511
G1 X168.19 Y91.935 E.01644
G1 X100.061 Y160.065 E2.96511
G1 X99.527 Y160.065 E.01644
G1 X167.656 Y91.935 E2.96511
G1 X167.122 Y91.935 E.01644
G1 X98.993 Y160.065 E2.96511
G1 X98.458 Y160.065 E.01644
G1 X166.588 Y91.935 E2.96511
G1 X166.054 Y91.935 E.01644
G1 X97.924 Y160.065 E2.96511
G1 X97.39 Y160.065 E.01644
G1 X165.52 Y91.935 E2.96511
G1 X164.986 Y91.935 E.01644
G1 X96.856 Y160.065 E2.96511
G1 X96.322 Y160.065 E.01644
G1 X164.451 Y91.935 E2.96511
G1 X163.917 Y91.935 E.01644
G1 X95.788 Y160.065 E2.96511
G1 X95.254 Y160.065 E.01644
G1 X163.383 Y91.935 E2.96511
G1 X162.849 Y91.935 E.01644
G1 X94.72 Y160.065 E2.96511
G1 X94.186 Y160.065 E.01644
G1 X162.315 Y91.935 E2.96511
G1 X161.781 Y91.935 E.01644
G1 X93.652 Y160.065 E2.96511
G1 X93.118 Y160.065 E.01644
G1 X161.247 Y91.935 E2.96511
G1 X160.713 Y91.935 E.01644
G1 X92.583 Y160.065 E2.96511
G1 X92.049 Y160.065 E.01644
G1 X110.179 Y141.935 E.78902
G1 X109.645 Y141.935 E.01644
G1 X91.515 Y160.065 E.78902
G1 X90.981 Y160.065 E.01644
G1 X109.111 Y141.935 E.78902
G1 X108.576 Y141.935 E.01644
G1 X90.447 Y160.065 E.78902
G1 X89.913 Y160.065 E.01644
G1 X108.042 Y141.935 E.78902
G1 X107.508 Y141.935 E.01644
G1 X89.379 Y160.065 E.78902
G1 X88.845 Y160.065 E.01644
G1 X106.974 Y141.935 E.78902
G1 X106.44 Y141.935 E.01644
G1 X88.311 Y160.065 E.78902
G1 X87.777 Y160.065 E.01644
G1 X105.906 Y141.935 E.78902
G1 X105.372 Y141.935 E.01644
G1 X87.243 Y160.065 E.78902
G1 X86.708 Y160.065 E.01644
G1 X104.838 Y141.935 E.78902
G1 X104.304 Y141.935 E.01644
G1 X86.174 Y160.065 E.78902
G1 X85.64 Y160.065 E.01644
G1 X103.77 Y141.935 E.78902
G1 X103.236 Y141.935 E.01644
G1 X85.106 Y160.065 E.78902
G1 X84.572 Y160.065 E.01644
G1 X102.701 Y141.935 E.78902
G1 X102.167 Y141.935 E.01644
G1 X84.038 Y160.065 E.78902
G1 X83.504 Y160.065 E.01644
G1 X101.633 Y141.935 E.78902
G1 X101.099 Y141.935 E.01644
G1 X82.97 Y160.065 E.78902
G1 X82.436 Y160.065 E.01644
G1 X100.565 Y141.935 E.78902
G1 X100.031 Y141.935 E.01644
G1 X81.902 Y160.065 E.78902
G1 X81.368 Y160.065 E.01644
G1 X99.497 Y141.935 E.78902
G1 X99.065 Y141.935 E.0133
G1 X99.065 Y141.833 E.00314
G1 X80.833 Y160.065 E.79346
G1 X80.299 Y160.065 E.01644
G1 X99.065 Y141.299 E.8167
G1 X99.065 Y140.765 E.01644
G1 X79.765 Y160.065 E.83994
G1 X79.231 Y160.065 E.01644
G1 X99.065 Y140.231 E.86319
G1 X99.065 Y139.697 E.01644
G1 X78.697 Y160.065 E.88643
G1 X78.163 Y160.065 E.01644
G1 X99.065 Y139.163 E.90968
G1 X99.065 Y138.629 E.01644
G1 X77.629 Y160.065 E.93292
G1 X77.095 Y160.065 E.01644
G1 X99.065 Y138.095 E.95617
G1 X99.065 Y137.561 E.01644
G1 X76.561 Y160.065 E.97941
G1 X76.027 Y160.065 E.01644
G1 X99.065 Y137.027 E1.00266
G1 X99.065 Y136.493 E.01644
G1 X75.492 Y160.065 E1.0259
G1 X74.958 Y160.065 E.01644
G1 X99.065 Y135.958 E1.04915
G1 X99.065 Y135.424 E.01644
G1 X74.424 Y160.065 E1.07239
G1 X73.89 Y160.065 E.01644
G1 X99.065 Y134.89 E1.09564
G1 X99.065 Y134.356 E.01644
G1 X73.356 Y160.065 E1.11888
G1 X72.822 Y160.065 E.01644
G1 X99.065 Y133.822 E1.14212
G1 X99.065 Y133.288 E.01644
G1 X72.288 Y160.065 E1.16537
G1 X71.754 Y160.065 E.01644
G1 X99.065 Y132.754 E1.18861
G1 X99.065 Y132.22 E.01644
G1 X71.22 Y160.065 E1.21186
G1 X70.686 Y160.065 E.01644
G1 X99.065 Y131.686 E1.2351
G1 X99.065 Y131.152 E.01644
G1 X70.152 Y160.065 E1.25835
G1 X69.617 Y160.065 E.01644
G1 X99.065 Y130.618 E1.28159
G1 X99.065 Y130.083 E.01644
G1 X69.083 Y160.065 E1.30484
G1 X68.549 Y160.065 E.01644
G1 X99.065 Y129.549 E1.32808
G1 X99.065 Y129.015 E.01644
G1 X68.015 Y160.065 E1.35133
G1 X67.481 Y160.065 E.01644
G1 X99.065 Y128.481 E1.37457
G1 X99.065 Y127.947 E.01644
G1 X66.947 Y160.065 E1.39781
G1 X66.413 Y160.065 E.01644
G1 X99.065 Y127.413 E1.42106
G1 X99.065 Y126.879 E.01644
G1 X65.879 Y160.065 E1.4443
G1 X65.345 Y160.065 E.01644
G1 X99.065 Y126.345 E1.46755
G1 X99.065 Y125.811 E.01644
G1 X64.811 Y160.065 E1.49079
G1 X64.277 Y160.065 E.01644
G1 X99.065 Y125.277 E1.51404
G1 X99.065 Y124.742 E.01644
G1 X63.742 Y160.065 E1.53728
G1 X63.208 Y160.065 E.01644
G1 X99.065 Y124.208 E1.56053
G1 X99.065 Y123.674 E.01644
G1 X62.674 Y160.065 E1.58377
G1 X62.14 Y160.065 E.01644
G1 X99.065 Y123.14 E1.60702
G1 X99.065 Y122.606 E.01644
G1 X61.606 Y160.065 E1.63026
G1 X61.072 Y160.065 E.01644
G1 X99.065 Y122.072 E1.65351
G1 X99.065 Y121.538 E.01644
G1 X60.538 Y160.065 E1.67675
G1 X60.004 Y160.065 E.01644
G1 X99.065 Y121.004 E1.69999
G1 X99.065 Y120.47 E.01644
G1 X59.47 Y160.065 E1.72324
G1 X58.936 Y160.065 E.01644
G1 X99.065 Y119.936 E1.74648
G1 X99.065 Y119.402 E.01644
G1 X58.402 Y160.065 E1.76973
G1 X57.867 Y160.065 E.01644
G1 X99.065 Y118.867 E1.79297
G1 X99.065 Y118.333 E.01644
G1 X57.333 Y160.065 E1.81622
G1 X56.799 Y160.065 E.01644
G1 X99.065 Y117.799 E1.83946
G1 X99.065 Y117.265 E.01644
G1 X56.265 Y160.065 E1.86271
G1 X55.731 Y160.065 E.01644
G1 X99.065 Y116.731 E1.88595
G1 X99.065 Y116.197 E.01644
G1 X55.197 Y160.065 E1.9092
G1 X54.663 Y160.065 E.01644
G1 X99.065 Y115.663 E1.93244
G1 X99.065 Y115.129 E.01644
G1 X54.129 Y160.065 E1.95569
G1 X53.595 Y160.065 E.01644
G1 X99.065 Y114.595 E1.97893
G1 X99.065 Y114.061 E.01644
G1 X53.061 Y160.065 E2.00217
G1 X52.527 Y160.065 E.01644
G1 X99.065 Y113.527 E2.02542
G1 X99.065 Y112.992 E.01644
G1 X51.992 Y160.065 E2.04866
G1 X51.458 Y160.065 E.01644
G1 X99.065 Y112.458 E2.07191
G1 X99.065 Y111.924 E.01644
G1 X50.924 Y160.065 E2.09515
G1 X50.39 Y160.065 E.01644
G1 X99.065 Y111.39 E2.1184
G1 X99.065 Y110.856 E.01644
G1 X49.856 Y160.065 E2.14164
G1 X49.322 Y160.065 E.01644
G1 X117.451 Y91.935 E2.96511
G1 X117.985 Y91.935 E.01644
G1 X99.856 Y110.065 E.78902
G1 X100.39 Y110.065 E.01644
G1 X118.52 Y91.935 E.78902
G1 X119.054 Y91.935 E.01644
G1 X100.924 Y110.065 E.78902
G1 X101.458 Y110.065 E.01644
G1 X119.588 Y91.935 E.78902
G1 X120.122 Y91.935 E.01644
G1 X101.992 Y110.065 E.78902
G1 X102.527 Y110.065 E.01644
G1 X120.656 Y91.935 E.78902
G1 X121.19 Y91.935 E.01644
G1 X103.061 Y110.065 E.78902
G1 X103.595 Y110.065 E.01644
G1 X121.724 Y91.935 E.78902
M73 P78 R11
G1 X122.258 Y91.935 E.01644
G1 X104.129 Y110.065 E.78902
G1 X104.663 Y110.065 E.01644
G1 X122.792 Y91.935 E.78902
G1 X123.326 Y91.935 E.01644
G1 X105.197 Y110.065 E.78902
G1 X105.731 Y110.065 E.01644
G1 X123.86 Y91.935 E.78902
G1 X124.395 Y91.935 E.01644
G1 X106.265 Y110.065 E.78902
G1 X106.799 Y110.065 E.01644
G1 X124.929 Y91.935 E.78902
G1 X125.463 Y91.935 E.01644
G1 X107.333 Y110.065 E.78902
G1 X107.867 Y110.065 E.01644
G1 X125.997 Y91.935 E.78902
G1 X126.531 Y91.935 E.01644
G1 X108.402 Y110.065 E.78902
G1 X108.936 Y110.065 E.01644
G1 X127.065 Y91.935 E.78902
G1 X127.599 Y91.935 E.01644
G1 X109.47 Y110.065 E.78902
G1 X110.004 Y110.065 E.01644
G1 X128.133 Y91.935 E.78902
G1 X128.667 Y91.935 E.01644
G1 X110.538 Y110.065 E.78902
G1 X110.935 Y110.065 E.01223
G1 X110.935 Y110.201 E.00421
G1 X129.201 Y91.935 E.79497
G1 X129.735 Y91.935 E.01644
G1 X110.935 Y110.735 E.81822
G1 X110.935 Y111.27 E.01644
G1 X130.27 Y91.935 E.84146
G1 X130.804 Y91.935 E.01644
G1 X110.935 Y111.804 E.86471
G1 X110.935 Y112.338 E.01644
G1 X131.338 Y91.935 E.88795
G1 X131.872 Y91.935 E.01644
G1 X110.935 Y112.872 E.91119
G1 X110.935 Y113.406 E.01644
G1 X132.406 Y91.935 E.93444
G1 X132.94 Y91.935 E.01644
G1 X110.935 Y113.94 E.95768
G1 X110.935 Y114.474 E.01644
G1 X133.474 Y91.935 E.98093
G1 X134.008 Y91.935 E.01644
G1 X110.935 Y115.008 E1.00417
G1 X110.935 Y115.542 E.01644
G1 X134.542 Y91.935 E1.02742
G1 X135.076 Y91.935 E.01644
G1 X110.935 Y116.076 E1.05066
G1 X110.935 Y116.61 E.01644
G1 X135.61 Y91.935 E1.07391
G1 X136.145 Y91.935 E.01644
G1 X110.935 Y117.145 E1.09715
G1 X110.935 Y117.679 E.01644
G1 X136.679 Y91.935 E1.1204
G1 X137.213 Y91.935 E.01644
G1 X110.935 Y118.213 E1.14364
G1 X110.935 Y118.747 E.01644
G1 X137.747 Y91.935 E1.16688
G1 X138.281 Y91.935 E.01644
G1 X110.935 Y119.281 E1.19013
G1 X110.935 Y119.815 E.01644
G1 X138.815 Y91.935 E1.21337
G1 X139.349 Y91.935 E.01644
G1 X110.935 Y120.349 E1.23662
G1 X110.935 Y120.883 E.01644
G1 X139.883 Y91.935 E1.25986
G1 X140.417 Y91.935 E.01644
G1 X110.935 Y121.417 E1.28311
G1 X110.935 Y121.951 E.01644
G1 X140.951 Y91.935 E1.30635
G1 X141.486 Y91.935 E.01644
G1 X110.935 Y122.486 E1.3296
G1 X110.935 Y123.02 E.01644
G1 X142.02 Y91.935 E1.35284
G1 X142.554 Y91.935 E.01644
G1 X110.935 Y123.554 E1.37609
G1 X110.935 Y124.088 E.01644
G1 X143.088 Y91.935 E1.39933
G1 X143.622 Y91.935 E.01644
G1 X110.935 Y124.622 E1.42258
G1 X110.935 Y125.156 E.01644
G1 X144.156 Y91.935 E1.44582
G1 X144.69 Y91.935 E.01644
G1 X110.935 Y125.69 E1.46907
G1 X110.935 Y126.224 E.01644
G1 X145.224 Y91.935 E1.49231
G1 X145.758 Y91.935 E.01644
G1 X110.935 Y126.758 E1.51555
G1 X110.935 Y127.292 E.01644
G1 X146.292 Y91.935 E1.5388
G1 X146.826 Y91.935 E.01644
G1 X110.935 Y127.826 E1.56204
G1 X110.935 Y128.361 E.01644
G1 X147.361 Y91.935 E1.58529
G1 X147.895 Y91.935 E.01644
G1 X110.935 Y128.895 E1.60853
G1 X110.935 Y129.429 E.01644
G1 X148.429 Y91.935 E1.63178
G1 X148.963 Y91.935 E.01644
G1 X110.935 Y129.963 E1.65502
G1 X110.935 Y130.497 E.01644
G1 X149.497 Y91.935 E1.67827
G1 X150.031 Y91.935 E.01644
G1 X110.935 Y131.031 E1.70151
G1 X110.935 Y131.565 E.01644
G1 X150.565 Y91.935 E1.72476
G1 X151.099 Y91.935 E.01644
G1 X110.935 Y132.099 E1.748
G1 X110.935 Y132.633 E.01644
G1 X151.633 Y91.935 E1.77124
G1 X152.167 Y91.935 E.01644
G1 X110.935 Y133.167 E1.79449
G1 X110.935 Y133.701 E.01644
G1 X152.701 Y91.935 E1.81773
G1 X153.236 Y91.935 E.01644
G1 X110.935 Y134.236 E1.84098
G1 X110.935 Y134.77 E.01644
G1 X153.77 Y91.935 E1.86422
G1 X154.304 Y91.935 E.01644
G1 X110.935 Y135.304 E1.88747
G1 X110.935 Y135.838 E.01644
G1 X154.838 Y91.935 E1.91071
G1 X155.372 Y91.935 E.01644
G1 X110.935 Y136.372 E1.93396
G1 X110.935 Y136.906 E.01644
G1 X155.906 Y91.935 E1.9572
G1 X156.44 Y91.935 E.01644
G1 X110.935 Y137.44 E1.98045
G1 X110.935 Y137.974 E.01644
G1 X156.974 Y91.935 E2.00369
G1 X157.508 Y91.935 E.01644
G1 X110.935 Y138.508 E2.02694
G1 X110.935 Y139.042 E.01644
G1 X158.042 Y91.935 E2.05018
G1 X158.576 Y91.935 E.01644
G1 X110.935 Y139.576 E2.07342
G1 X110.935 Y140.111 E.01644
G1 X159.111 Y91.935 E2.09667
G1 X159.645 Y91.935 E.01644
G1 X110.935 Y140.645 E2.11991
G1 X110.935 Y141.179 E.01644
G1 X160.348 Y91.766 E2.15054
G1 X110.678 Y91.766 F30000
G1 F15000
G1 X71.411 Y131.032 E1.70895
G2 X71.859 Y130.051 I-5.152 J-2.941 E.03324
G1 X109.974 Y91.935 E1.65885
G1 X109.44 Y91.935 E.01644
G1 X72.154 Y129.221 E1.62275
G1 X72.362 Y128.479 E.02371
G1 X108.906 Y91.935 E1.59045
M73 P78 R10
G1 X108.372 Y91.935 E.01644
G1 X72.484 Y127.823 E1.56191
G2 X72.572 Y127.201 I-3.363 J-.792 E.01935
G1 X107.838 Y91.935 E1.53484
G1 X107.304 Y91.935 E.01644
G1 X72.625 Y126.614 E1.50926
G2 X72.636 Y126.069 I-2.979 J-.33 E.01679
G1 X106.77 Y91.935 E1.48555
G1 X106.235 Y91.935 E.01644
G1 X72.636 Y125.535 E1.46231
G2 X72.594 Y125.043 I-2.715 J-.016 E.01522
G1 X105.701 Y91.935 E1.44089
G1 X105.167 Y91.935 E.01644
G1 X72.549 Y124.553 E1.41959
G2 X72.47 Y124.099 I-2.529 J.21 E.01422
G1 X104.633 Y91.935 E1.39982
G1 X104.099 Y91.935 E.01644
G1 X72.386 Y123.648 E1.38019
G2 X72.278 Y123.222 I-2.384 J.379 E.01354
G1 X103.565 Y91.935 E1.36165
G1 X103.031 Y91.935 E.01644
G1 X72.161 Y122.805 E1.34349
G2 X72.031 Y122.401 I-2.274 J.512 E.01307
G1 X102.497 Y91.935 E1.32593
G1 X101.963 Y91.935 E.01644
G1 X71.883 Y122.015 E1.3091
G2 X71.735 Y121.629 I-2.206 J.628 E.01273
G1 X101.429 Y91.935 E1.29232
G1 X100.895 Y91.935 E.01644
G1 X71.559 Y121.27 E1.27671
G1 X71.384 Y120.912 E.01229
G1 X100.36 Y91.935 E1.26111
G1 X99.826 Y91.935 E.01644
G1 X71.194 Y120.568 E1.24613
G1 X70.992 Y120.236 E.01196
G1 X99.292 Y91.935 E1.23168
G1 X98.758 Y91.935 E.01644
G1 X70.79 Y119.903 E1.21722
G2 X70.563 Y119.596 I-1.806 J1.096 E.01177
G1 X98.224 Y91.935 E1.20385
G1 X97.69 Y91.935 E.01644
G1 X70.336 Y119.289 E1.1905
G2 X70.099 Y118.992 I-1.749 J1.147 E.01171
G1 X97.156 Y91.935 E1.17755
G1 X96.622 Y91.935 E.01644
G1 X69.848 Y118.71 E1.16526
G1 X69.596 Y118.427 E.01164
G1 X96.088 Y91.935 E1.15298
G1 X95.554 Y91.935 E.01644
G1 X69.326 Y118.163 E1.14148
G1 X69.05 Y117.905 E.01163
G1 X95.02 Y91.935 E1.13026
G1 X94.485 Y91.935 E.01644
G1 X68.771 Y117.65 E1.11915
G1 X68.47 Y117.417 E.01171
G1 X93.951 Y91.935 E1.10899
G1 X93.417 Y91.935 E.01644
G1 X68.169 Y117.183 E1.09883
G2 X67.856 Y116.962 I-1.367 J1.605 E.01181
G1 X92.883 Y91.935 E1.08921
G1 X92.349 Y91.935 E.01644
G1 X67.531 Y116.754 E1.08014
G1 X67.205 Y116.545 E.0119
G1 X91.815 Y91.935 E1.07107
G1 X91.281 Y91.935 E.01644
G1 X66.855 Y116.361 E1.06305
G1 X66.503 Y116.179 E.01219
G1 X90.747 Y91.935 E1.05512
G1 X90.213 Y91.935 E.01644
G1 X66.14 Y116.008 E1.04767
G1 X65.761 Y115.853 E.01261
G1 X89.679 Y91.935 E1.04094
G1 X89.144 Y91.935 E.01644
G1 X65.381 Y115.698 E1.03421
G2 X64.973 Y115.573 I-.895 J2.189 E.01317
G1 X88.61 Y91.935 E1.02875
G1 X88.076 Y91.935 E.01644
G1 X64.563 Y115.448 E1.02332
G2 X64.133 Y115.345 I-.781 J2.307 E.01365
G1 X87.542 Y91.935 E1.01883
G1 X87.008 Y91.935 E.01644
G1 X63.69 Y115.253 E1.01483
G2 X63.232 Y115.178 I-.641 J2.473 E.01433
G1 X86.474 Y91.935 E1.01155
G1 X85.94 Y91.935 E.01644
G1 X62.752 Y115.123 E1.00916
G2 X62.257 Y115.085 I-.458 J2.695 E.01532
G1 X85.406 Y91.935 E1.0075
G1 X84.872 Y91.935 E.01644
G1 X61.734 Y115.073 E1.00698
G2 X61.188 Y115.085 I-.205 J3 E.01685
G1 X84.338 Y91.935 E1.00753
G1 X83.804 Y91.935 E.01644
G1 X60.614 Y115.125 E1.00923
G2 X59.994 Y115.211 I.162 J3.443 E.0193
G1 X83.269 Y91.935 E1.01299
G1 X82.735 Y91.935 E.01644
G1 X59.341 Y115.329 E1.01815
G1 X58.624 Y115.513 E.0228
G1 X82.201 Y91.935 E1.02614
G1 X81.667 Y91.935 E.01644
G1 X57.811 Y115.792 E1.03827
G1 X57.583 Y115.873 E.00743
G1 X56.864 Y116.205 E.0244
G1 X81.133 Y91.935 E1.05625
G1 X80.599 Y91.935 E.01644
G1 X55.577 Y116.957 E1.08899
G2 X52.922 Y119.492 I5.959 J8.9 E.11352
G1 X52.675 Y119.86 E.01365
G1 X28.935 Y143.599 E1.03318
G1 X28.935 Y144.133 E.01644
G1 X51.902 Y121.166 E.99956
G1 X51.489 Y122.114 E.03181
G1 X28.935 Y144.667 E.98157
G1 X28.935 Y145.201 E.01644
G1 X51.226 Y122.911 E.97013
G2 X51.047 Y123.624 I3.816 J1.336 E.02265
G1 X28.935 Y145.735 E.96235
G1 X28.935 Y146.269 E.01644
G1 X50.919 Y124.286 E.95676
G1 X50.834 Y124.905 E.01923
G1 X28.935 Y146.804 E.95306
G1 X28.935 Y147.338 E.01644
G1 X50.799 Y125.474 E.95153
G2 X50.776 Y126.031 I3.04 J.402 E.01717
G1 X28.935 Y147.872 E.95054
G1 X28.935 Y148.406 E.01644
G1 X50.799 Y126.542 E.95156
G2 X50.827 Y127.048 I2.788 J.1 E.01562
G1 X28.935 Y148.94 E.95278
G1 X28.935 Y149.474 E.01644
G1 X50.892 Y127.518 E.95558
G2 X50.957 Y127.987 I2.629 J-.125 E.01459
G1 X28.935 Y150.008 E.95841
M73 P79 R10
G1 X28.935 Y150.542 E.01644
G1 X51.057 Y128.42 E.96279
G1 X51.158 Y128.854 E.0137
G1 X28.935 Y151.076 E.96716
G1 X28.935 Y151.61 E.01644
G1 X51.283 Y129.263 E.97261
G1 X51.416 Y129.664 E.01301
G1 X28.935 Y152.144 E.97838
G1 X28.935 Y152.679 E.01644
G1 X51.56 Y130.053 E.98469
G1 X51.722 Y130.426 E.01249
G1 X28.935 Y153.213 E.99173
G1 X28.935 Y153.747 E.01644
G1 X51.884 Y130.798 E.99876
G2 X52.072 Y131.144 I1.986 J-.856 E.01214
G1 X28.935 Y154.281 E1.00695
G1 X28.935 Y154.815 E.01644
G1 X52.261 Y131.489 E1.01518
G2 X52.461 Y131.823 I1.927 J-.929 E.012
G1 X28.935 Y155.349 E1.02389
G1 X28.935 Y155.883 E.01644
G1 X52.676 Y132.142 E1.03324
G1 X52.891 Y132.462 E.01184
G1 X28.935 Y156.417 E1.04258
G1 X28.935 Y156.951 E.01644
G1 X53.127 Y132.76 E1.05285
G1 X53.366 Y133.054 E.01168
G1 X28.935 Y157.485 E1.06328
G1 X28.935 Y158.019 E.01644
G1 X53.612 Y133.343 E1.07395
G1 X53.876 Y133.613 E.01162
G1 X28.935 Y158.554 E1.08544
G1 X28.935 Y159.088 E.01644
G1 X54.14 Y133.883 E1.09693
G2 X54.418 Y134.139 I1.537 J-1.396 E.01165
G1 X28.935 Y159.622 E1.10905
G1 X28.935 Y160.065 E.01363
G1 X29.026 Y160.065 E.00281
G1 X54.706 Y134.385 E1.11764
G1 X54.995 Y134.63 E.01166
G1 X29.561 Y160.065 E1.10694
G1 X30.095 Y160.065 E.01644
G1 X55.307 Y134.852 E1.09729
G1 X55.62 Y135.073 E.01179
G1 X30.629 Y160.065 E1.08767
G1 X31.163 Y160.065 E.01644
G1 X55.943 Y135.285 E1.07846
G1 X56.281 Y135.48 E.01203
G1 X31.697 Y160.065 E1.06995
G1 X32.231 Y160.065 E.01644
G1 X56.62 Y135.676 E1.06145
G2 X56.981 Y135.849 I1.13 J-1.888 E.01233
G1 X32.765 Y160.065 E1.0539
G1 X33.299 Y160.065 E.01644
G1 X57.346 Y136.018 E1.04656
G2 X57.721 Y136.177 I1.057 J-1.977 E.01256
G1 X33.833 Y160.065 E1.03965
G1 X34.367 Y160.065 E.01644
G1 X58.115 Y136.317 E1.03356
G1 X58.51 Y136.457 E.01287
G1 X34.902 Y160.065 E1.02746
G1 X35.436 Y160.065 E.01644
G1 X58.934 Y136.566 E1.02269
G1 X59.359 Y136.675 E.01351
G1 X35.97 Y160.065 E1.01795
G1 X36.504 Y160.065 E.01644
G1 X59.809 Y136.759 E1.01428
G1 X60.269 Y136.833 E.01434
G1 X37.038 Y160.065 E1.01106
G1 X37.572 Y160.065 E.01644
G1 X60.752 Y136.885 E1.00883
G1 X61.252 Y136.919 E.01542
G1 X38.106 Y160.065 E1.00734
G1 X38.64 Y160.065 E.01644
G1 X61.779 Y136.926 E1.00702
G1 X62.325 Y136.914 E.01682
G1 X39.174 Y160.065 E1.00757
G1 X39.708 Y160.065 E.01644
G1 X62.914 Y136.859 E1.00997
G2 X63.526 Y136.781 I-.118 J-3.384 E.01899
G1 X40.242 Y160.065 E1.01334
G1 X40.777 Y160.065 E.01644
G1 X64.2 Y136.641 E1.01944
G2 X64.938 Y136.438 I-.746 J-4.142 E.02358
G1 X41.311 Y160.065 E1.02829
G1 X41.845 Y160.065 E.01644
G1 X65.764 Y136.146 E1.04099
G2 X66.75 Y135.693 I-1.983 J-5.627 E.03344
G1 X42.379 Y160.065 E1.06068
G1 X42.913 Y160.065 E.01644
G1 X111.042 Y91.935 E2.96511
G1 X111.576 Y91.935 E.01644
G1 X43.447 Y160.065 E2.96511
G1 X43.981 Y160.065 E.01644
G1 X112.11 Y91.935 E2.96511
G1 X112.645 Y91.935 E.01644
G1 X44.515 Y160.065 E2.96511
G1 X45.049 Y160.065 E.01644
G1 X113.179 Y91.935 E2.96511
G1 X113.713 Y91.935 E.01644
G1 X45.583 Y160.065 E2.96511
G1 X46.117 Y160.065 E.01644
G1 X114.247 Y91.935 E2.96511
G1 X114.781 Y91.935 E.01644
G1 X46.652 Y160.065 E2.96511
G1 X47.186 Y160.065 E.01644
G1 X115.315 Y91.935 E2.96511
G1 X115.849 Y91.935 E.01644
G1 X47.72 Y160.065 E2.96511
G1 X48.254 Y160.065 E.01644
G1 X116.383 Y91.935 E2.96511
G1 X116.917 Y91.935 E.01644
G1 X48.618 Y160.234 E2.97249
G1 X28.766 Y143.235 F30000
G1 F15000
G1 X80.065 Y91.935 E2.23263
G1 X79.531 Y91.935 E.01644
G1 X28.935 Y142.531 E2.202
G1 X28.935 Y141.997 E.01644
G1 X78.997 Y91.935 E2.17876
G1 X78.463 Y91.935 E.01644
G1 X28.935 Y141.463 E2.15552
G1 X28.935 Y140.929 E.01644
G1 X77.929 Y91.935 E2.13227
G1 X77.394 Y91.935 E.01644
G1 X28.935 Y140.394 E2.10903
G1 X28.935 Y139.86 E.01644
G1 X76.86 Y91.935 E2.08578
G1 X76.326 Y91.935 E.01644
G1 X28.935 Y139.326 E2.06254
G1 X28.935 Y138.792 E.01644
G1 X75.792 Y91.935 E2.03929
G1 X75.258 Y91.935 E.01644
G1 X28.935 Y138.258 E2.01605
G1 X28.935 Y137.724 E.01644
G1 X74.724 Y91.935 E1.9928
G1 X74.19 Y91.935 E.01644
G1 X28.935 Y137.19 E1.96956
G1 X28.935 Y136.656 E.01644
G1 X73.656 Y91.935 E1.94631
G1 X73.122 Y91.935 E.01644
G1 X28.935 Y136.122 E1.92307
G1 X28.935 Y135.588 E.01644
G1 X72.588 Y91.935 E1.89982
G1 X72.054 Y91.935 E.01644
G1 X28.935 Y135.054 E1.87658
G1 X28.935 Y134.519 E.01644
G1 X71.519 Y91.935 E1.85334
G1 X70.985 Y91.935 E.01644
G1 X28.935 Y133.985 E1.83009
G1 X28.935 Y133.451 E.01644
G1 X70.451 Y91.935 E1.80685
G1 X69.917 Y91.935 E.01644
G1 X28.935 Y132.917 E1.7836
G1 X28.935 Y132.383 E.01644
G1 X69.383 Y91.935 E1.76036
G1 X68.849 Y91.935 E.01644
G1 X28.935 Y131.849 E1.73711
G1 X28.935 Y131.315 E.01644
G1 X68.315 Y91.935 E1.71387
G1 X67.781 Y91.935 E.01644
G1 X28.935 Y130.781 E1.69062
G1 X28.935 Y130.247 E.01644
G1 X67.247 Y91.935 E1.66738
G1 X66.713 Y91.935 E.01644
G1 X28.935 Y129.713 E1.64413
G1 X28.935 Y129.179 E.01644
G1 X66.179 Y91.935 E1.62089
G1 X65.644 Y91.935 E.01644
G1 X28.935 Y128.644 E1.59764
G1 X28.935 Y128.11 E.01644
G1 X65.11 Y91.935 E1.5744
G1 X64.576 Y91.935 E.01644
G1 X28.935 Y127.576 E1.55116
G1 X28.935 Y127.042 E.01644
G1 X64.042 Y91.935 E1.52791
G1 X63.508 Y91.935 E.01644
G1 X28.935 Y126.508 E1.50467
G1 X28.935 Y125.974 E.01644
G1 X62.974 Y91.935 E1.48142
G1 X62.44 Y91.935 E.01644
G1 X28.935 Y125.44 E1.45818
G1 X28.935 Y124.906 E.01644
G1 X61.906 Y91.935 E1.43493
G1 X61.372 Y91.935 E.01644
G1 X28.935 Y124.372 E1.41169
G1 X28.935 Y123.838 E.01644
G1 X60.838 Y91.935 E1.38844
G1 X60.304 Y91.935 E.01644
G1 X28.935 Y123.304 E1.3652
G1 X28.935 Y122.769 E.01644
G1 X59.769 Y91.935 E1.34195
G1 X59.235 Y91.935 E.01644
G1 X28.935 Y122.235 E1.31871
G1 X28.935 Y121.701 E.01644
G1 X58.701 Y91.935 E1.29546
G1 X58.167 Y91.935 E.01644
G1 X28.935 Y121.167 E1.27222
G1 X28.935 Y120.633 E.01644
G1 X57.633 Y91.935 E1.24898
G1 X57.099 Y91.935 E.01644
G1 X28.935 Y120.099 E1.22573
G1 X28.935 Y119.565 E.01644
G1 X56.565 Y91.935 E1.20249
G1 X56.031 Y91.935 E.01644
G1 X28.935 Y119.031 E1.17924
G1 X28.935 Y118.497 E.01644
G1 X55.497 Y91.935 E1.156
G1 X54.963 Y91.935 E.01644
G1 X28.935 Y117.963 E1.13275
G1 X28.935 Y117.429 E.01644
G1 X54.429 Y91.935 E1.10951
G1 X53.894 Y91.935 E.01644
G1 X28.935 Y116.894 E1.08626
G1 X28.935 Y116.36 E.01644
G1 X53.36 Y91.935 E1.06302
G1 X52.826 Y91.935 E.01644
G1 X28.935 Y115.826 E1.03977
G1 X28.935 Y115.292 E.01644
G1 X52.292 Y91.935 E1.01653
G1 X51.758 Y91.935 E.01644
G1 X28.935 Y114.758 E.99328
G1 X28.935 Y114.224 E.01644
G1 X51.224 Y91.935 E.97004
G1 X50.69 Y91.935 E.01644
G1 X28.935 Y113.69 E.9468
G1 X28.935 Y113.156 E.01644
G1 X50.156 Y91.935 E.92355
G1 X49.622 Y91.935 E.01644
G1 X28.935 Y112.622 E.90031
G1 X28.935 Y112.088 E.01644
G1 X49.088 Y91.935 E.87706
G1 X48.554 Y91.935 E.01644
G1 X28.935 Y111.553 E.85382
G1 X28.935 Y111.019 E.01644
G1 X48.019 Y91.935 E.83057
G1 X47.485 Y91.935 E.01644
G1 X28.935 Y110.485 E.80733
G1 X28.935 Y109.951 E.01644
G1 X46.951 Y91.935 E.78408
G1 X46.417 Y91.935 E.01644
G1 X28.935 Y109.417 E.76084
G1 X28.935 Y108.883 E.01644
G1 X45.883 Y91.935 E.73759
G1 X45.349 Y91.935 E.01644
G1 X28.935 Y108.349 E.71435
G1 X28.935 Y107.815 E.01644
G1 X44.815 Y91.935 E.69111
G1 X44.281 Y91.935 E.01644
G1 X28.935 Y107.281 E.66786
G1 X28.935 Y106.747 E.01644
G1 X43.747 Y91.935 E.64462
G1 X43.213 Y91.935 E.01644
G1 X28.935 Y106.213 E.62137
G1 X28.935 Y105.678 E.01644
G1 X42.678 Y91.935 E.59813
G1 X42.144 Y91.935 E.01644
G1 X28.935 Y105.144 E.57488
G1 X28.935 Y104.61 E.01644
G1 X41.61 Y91.935 E.55164
G1 X41.076 Y91.935 E.01644
G1 X28.935 Y104.076 E.52839
G1 X28.935 Y103.542 E.01644
G1 X40.542 Y91.935 E.50515
G1 X40.008 Y91.935 E.01644
G1 X28.935 Y103.008 E.4819
G1 X28.935 Y102.474 E.01644
G1 X39.474 Y91.935 E.45866
G1 X38.94 Y91.935 E.01644
G1 X28.935 Y101.94 E.43541
G1 X28.935 Y101.406 E.01644
G1 X38.406 Y91.935 E.41217
G1 X37.872 Y91.935 E.01644
G1 X28.935 Y100.872 E.38893
G1 X28.935 Y100.338 E.01644
G1 X37.338 Y91.935 E.36568
G1 X36.803 Y91.935 E.01644
G1 X28.935 Y99.803 E.34244
G1 X28.935 Y99.269 E.01644
G1 X36.269 Y91.935 E.31919
G1 X35.735 Y91.935 E.01644
G1 X28.935 Y98.735 E.29595
G1 X28.935 Y98.201 E.01644
G1 X31.354 Y95.783 E.10526
M73 P80 R10
G1 X31.334 Y95.792 E.00067
G3 X30.679 Y95.923 I-.7 J-1.793 E.02066
G1 X28.935 Y97.667 E.0759
G1 X28.935 Y97.133 E.01644
G1 X30.159 Y95.909 E.05327
G1 X29.726 Y95.808 E.01368
G1 X28.935 Y96.599 E.03442
G1 X28.935 Y96.065 E.01644
G1 X29.354 Y95.646 E.01821
G3 X29.03 Y95.436 I.432 J-1.023 E.01195
G1 X28.766 Y95.7 E.01149
; WIPE_START
G1 X29.03 Y95.436 E-.14186
G1 X29.354 Y95.646 E-.14676
G1 X28.935 Y96.065 E-.22491
G1 X28.935 Y96.599 E-.20296
G1 X29.016 Y96.518 E-.04351
; WIPE_END
G1 E-.04 F1800
G1 X28.619 Y94.531 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354386
G1 F15000
G1 X28.559 Y94.192 E.00874
; LINE_WIDTH: 0.327693
G1 X28.537 Y94.026 E.00389
; LINE_WIDTH: 0.283917
G1 X28.516 Y93.86 E.00329
; LINE_WIDTH: 0.244295
G3 X28.514 Y93.159 I5.787 J-.364 E.0115
; LINE_WIDTH: 0.281527
G3 X28.537 Y92.974 I2.135 J.177 E.00363
; LINE_WIDTH: 0.327704
G1 X28.559 Y92.808 E.00389
; LINE_WIDTH: 0.354373
G1 X28.619 Y92.469 E.00873
G1 X29.469 Y91.619 F30000
; LINE_WIDTH: 0.354364
G1 F15000
G1 X29.808 Y91.559 E.00874
; LINE_WIDTH: 0.327696
G1 X29.974 Y91.537 E.00389
; LINE_WIDTH: 0.283928
G1 X30.14 Y91.516 E.00329
; LINE_WIDTH: 0.244295
G3 X30.841 Y91.514 I.364 J5.785 E.0115
; LINE_WIDTH: 0.281539
G3 X31.026 Y91.537 I-.178 J2.141 E.00363
; LINE_WIDTH: 0.327691
G1 X31.192 Y91.559 E.00389
; LINE_WIDTH: 0.354373
G1 X31.531 Y91.619 E.00874
G1 X32.315 Y92.151 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42058
G1 F15000
G1 X32.531 Y91.935 E.00941
G1 X33.065 Y91.935 E.01644
G1 X32.646 Y92.354 E.01821
G1 X32.808 Y92.726 E.01249
G1 X33.599 Y91.935 E.03442
G1 X34.133 Y91.935 E.01644
G1 X32.909 Y93.159 E.05327
G3 X32.923 Y93.679 I-1.466 J.3 E.01609
G1 X34.667 Y91.935 E.0759
G1 X35.201 Y91.935 E.01644
G1 X32.377 Y94.76 E.12292
; CHANGE_LAYER
; Z_HEIGHT: 4.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X33.791 Y93.345 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 23/25
; update layer progress
M73 L23
M991 S0 P22 ;notify layer change
G17
G3 Z4.8 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z5 F30000
G1 X51.288 Y124.062 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.502 Y123.139 E.03141
G3 X60.507 Y115.466 I10.209 J2.86 E.41633
G1 X61.47 Y115.4 E.03202
G3 X51.277 Y124.121 I.241 J10.599 E1.72793
M204 S250
G1 X51.67 Y124.15 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X51.883 Y123.246 E.02855
G3 X60.551 Y115.856 I9.828 J2.748 E.37134
G1 X61.479 Y115.792 E.02856
G3 X51.664 Y124.207 I.232 J10.202 E1.54002
; WIPE_START
M204 S10000
G1 X51.883 Y123.246 E-.37433
G1 X52.171 Y122.363 E-.35307
G1 X52.205 Y122.284 E-.0326
; WIPE_END
G1 E-.04 F1800
G1 X59.737 Y121.049 Z5 F30000
G1 X223.513 Y94.186 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.53 Y94.217 E.00117
G2 X227.227 Y94.688 I1.97 J-.717 E.15229
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.727 J-1.188 E.24389
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.435 Y93.864 I1.188 J1.727 E.07947
G1 X223.499 Y94.128 E.009
M204 S250
G1 X223.893 Y94.086 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X223.901 Y94.082 E.00029
G3 X225.247 Y91.811 I1.606 J-.582 E.09269
G3 X226.085 Y91.892 I.243 J1.859 E.02609
G3 X224.026 Y94.351 I-.578 J1.607 E.20179
G1 X223.92 Y94.139 E.00728
; WIPE_START
M204 S10000
G1 X223.901 Y94.082 E-.02295
G1 X223.815 Y93.797 E-.11307
G1 X223.789 Y93.5 E-.11332
G1 X223.815 Y93.203 E-.11332
G1 X223.892 Y92.915 E-.11332
G1 X224.018 Y92.645 E-.11332
G1 X224.189 Y92.4 E-.11332
G1 X224.296 Y92.294 E-.05739
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.731 J1.192 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07625
G1 X227.039 Y92.075 E-.03915
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z5 F30000
G1 X32.107 Y94.087 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X31.984 Y94.357 E.0091
G3 X30.247 Y91.811 I-1.477 J-.857 E.2117
G3 X31.085 Y91.892 I.243 J1.859 E.02609
G3 X32.129 Y94.034 I-.578 J1.607 E.081
; WIPE_START
M204 S10000
G1 X31.984 Y94.357 E-.13457
G1 X31.811 Y94.6 E-.11341
G1 X31.6 Y94.811 E-.11334
G1 X31.355 Y94.982 E-.11331
G1 X31.085 Y95.108 E-.11333
G1 X30.797 Y95.185 E-.11331
G1 X30.643 Y95.198 E-.05872
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.731 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08591
G1 X28.888 Y92.147 E-.1394
G1 X28.773 Y92.312 E-.07626
G1 X28.602 Y92.258 E-.06804
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14116
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z5 F30000
G1 X227.79 Y91.21 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354377
G1 F15000
G1 X226.192 Y91.559 E.00873
; LINE_WIDTH: 0.327704
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281527
G2 X225.841 Y91.514 I-.363 J2.112 E.00363
; LINE_WIDTH: 0.24429
G2 X225.14 Y91.516 I-.336 J5.792 E.0115
; LINE_WIDTH: 0.283908
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327676
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354342
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X223.301 Y91.766 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42058
G1 F15000
G1 X223.564 Y92.028 E.01144
G2 X223.354 Y92.353 I.813 J.757 E.01194
G1 X222.937 Y91.935 E.01816
G1 X222.403 Y91.935 E.01644
G1 X223.192 Y92.725 E.03436
G1 X223.091 Y93.158 E.01368
G1 X221.869 Y91.935 E.05319
G1 X221.335 Y91.935 E.01644
G1 X223.077 Y93.677 E.07581
G2 X223.208 Y94.334 I1.931 J-.045 E.02073
G1 X223.216 Y94.35 E.00055
G1 X220.801 Y91.935 E.10511
G1 X220.267 Y91.935 E.01644
G1 X227.065 Y98.733 E.29586
G1 X227.065 Y98.199 E.01644
G1 X224.65 Y95.784 E.10511
G2 X225.323 Y95.923 I.983 J-3.059 E.0212
G1 X227.065 Y97.665 E.07581
G1 X227.065 Y97.131 E.01644
G1 X225.842 Y95.909 E.05319
G1 X226.275 Y95.808 E.01368
G1 X227.065 Y96.597 E.03436
G1 X227.065 Y96.063 E.01644
G1 X226.647 Y95.646 E.01816
G2 X226.972 Y95.436 I-.434 J-1.024 E.01194
G1 X227.234 Y95.699 E.01144
; WIPE_START
G1 X226.972 Y95.436 E-.14125
G1 X226.647 Y95.646 E-.14674
G1 X227.065 Y96.063 E-.2242
G1 X227.065 Y96.597 E-.20295
G1 X226.981 Y96.514 E-.04485
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y94.531 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354358
G1 F15000
G1 X227.441 Y94.192 E.00874
; LINE_WIDTH: 0.327682
G1 X227.463 Y94.026 E.00389
; LINE_WIDTH: 0.281522
G2 X227.486 Y93.841 I-2.117 J-.363 E.00363
; LINE_WIDTH: 0.244285
G2 X227.484 Y93.14 I-5.786 J-.336 E.0115
; LINE_WIDTH: 0.283902
G1 X227.463 Y92.974 E.00329
; LINE_WIDTH: 0.327688
G1 X227.441 Y92.808 E.00389
; LINE_WIDTH: 0.354386
G1 X227.381 Y92.469 E.00873
; WIPE_START
G1 X227.441 Y92.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.234 Y99.437 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42058
G1 F15000
G1 X219.733 Y91.935 E.32649
G1 X219.198 Y91.935 E.01644
G1 X227.065 Y99.802 E.34235
G1 X227.065 Y100.336 E.01644
G1 X218.664 Y91.935 E.3656
G1 X218.13 Y91.935 E.01644
G1 X227.065 Y100.87 E.38884
G1 X227.065 Y101.404 E.01644
G1 X217.596 Y91.935 E.41209
G1 X217.062 Y91.935 E.01644
G1 X227.065 Y101.938 E.43533
G1 X227.065 Y102.472 E.01644
G1 X216.528 Y91.935 E.45858
G1 X215.994 Y91.935 E.01644
G1 X227.065 Y103.006 E.48182
G1 X227.065 Y103.54 E.01644
G1 X215.46 Y91.935 E.50507
G1 X214.926 Y91.935 E.01644
G1 X227.065 Y104.074 E.52831
G1 X227.065 Y104.608 E.01644
G1 X214.392 Y91.935 E.55155
G1 X213.858 Y91.935 E.01644
G1 X227.065 Y105.142 E.5748
G1 X227.065 Y105.677 E.01644
G1 X213.323 Y91.935 E.59804
G1 X212.789 Y91.935 E.01644
G1 X227.065 Y106.211 E.62129
G1 X227.065 Y106.745 E.01644
G1 X212.255 Y91.935 E.64453
G1 X211.721 Y91.935 E.01644
G1 X227.065 Y107.279 E.66778
G1 X227.065 Y107.813 E.01644
G1 X211.187 Y91.935 E.69102
G1 X210.653 Y91.935 E.01644
G1 X227.065 Y108.347 E.71427
G1 X227.065 Y108.881 E.01644
G1 X210.119 Y91.935 E.73751
G1 X209.585 Y91.935 E.01644
G1 X227.065 Y109.415 E.76076
G1 X227.065 Y109.949 E.01644
G1 X209.051 Y91.935 E.784
G1 X208.517 Y91.935 E.01644
G1 X227.065 Y110.483 E.80724
G1 X227.065 Y111.017 E.01644
M73 P80 R9
G1 X207.982 Y91.935 E.83049
G1 X207.448 Y91.935 E.01644
G1 X227.065 Y111.552 E.85373
G1 X227.065 Y112.086 E.01644
G1 X206.914 Y91.935 E.87698
G1 X206.38 Y91.935 E.01644
G1 X227.065 Y112.62 E.90022
G1 X227.065 Y113.154 E.01644
G1 X205.846 Y91.935 E.92347
G1 X205.312 Y91.935 E.01644
G1 X227.065 Y113.688 E.94671
G1 X227.065 Y114.222 E.01644
G1 X204.778 Y91.935 E.96996
G1 X204.244 Y91.935 E.01644
G1 X227.065 Y114.756 E.9932
G1 X227.065 Y115.29 E.01644
G1 X203.71 Y91.935 E1.01645
G1 X203.176 Y91.935 E.01644
G1 X227.065 Y115.824 E1.03969
G1 X227.065 Y116.358 E.01644
G1 X202.642 Y91.935 E1.06294
G1 X202.107 Y91.935 E.01644
G1 X227.065 Y116.893 E1.08618
G1 X227.065 Y117.427 E.01644
G1 X201.573 Y91.935 E1.10942
G1 X201.039 Y91.935 E.01644
G1 X227.065 Y117.961 E1.13267
G1 X227.065 Y118.495 E.01644
G1 X200.505 Y91.935 E1.15591
G1 X199.971 Y91.935 E.01644
G1 X227.065 Y119.029 E1.17916
G1 X227.065 Y119.563 E.01644
G1 X199.437 Y91.935 E1.2024
G1 X198.903 Y91.935 E.01644
G1 X227.065 Y120.097 E1.22565
G1 X227.065 Y120.631 E.01644
G1 X198.369 Y91.935 E1.24889
G1 X197.835 Y91.935 E.01644
G1 X227.065 Y121.165 E1.27214
G1 X227.065 Y121.699 E.01644
G1 X197.301 Y91.935 E1.29538
G1 X196.767 Y91.935 E.01644
G1 X227.065 Y122.233 E1.31863
G1 X227.065 Y122.768 E.01644
G1 X196.232 Y91.935 E1.34187
G1 X195.698 Y91.935 E.01644
G1 X227.065 Y123.302 E1.36512
G1 X227.065 Y123.836 E.01644
G1 X195.164 Y91.935 E1.38836
G1 X194.63 Y91.935 E.01644
G1 X227.065 Y124.37 E1.4116
G1 X227.065 Y124.904 E.01644
G1 X194.096 Y91.935 E1.43485
G1 X193.562 Y91.935 E.01644
G1 X227.065 Y125.438 E1.45809
G1 X227.065 Y125.972 E.01644
G1 X193.028 Y91.935 E1.48134
G1 X192.494 Y91.935 E.01644
G1 X227.065 Y126.506 E1.50458
G1 X227.065 Y127.04 E.01644
G1 X191.96 Y91.935 E1.52783
G1 X191.426 Y91.935 E.01644
G1 X227.065 Y127.574 E1.55107
G1 X227.065 Y128.108 E.01644
G1 X190.892 Y91.935 E1.57432
G1 X190.357 Y91.935 E.01644
G1 X227.065 Y128.643 E1.59756
G1 X227.065 Y129.177 E.01644
G1 X189.823 Y91.935 E1.62081
G1 X189.289 Y91.935 E.01644
G1 X227.065 Y129.711 E1.64405
G1 X227.065 Y130.245 E.01644
G1 X188.755 Y91.935 E1.6673
G1 X188.221 Y91.935 E.01644
G1 X227.065 Y130.779 E1.69054
G1 X227.065 Y131.313 E.01644
G1 X187.687 Y91.935 E1.71378
G1 X187.153 Y91.935 E.01644
G1 X227.065 Y131.847 E1.73703
G1 X227.065 Y132.381 E.01644
G1 X186.619 Y91.935 E1.76027
G1 X186.085 Y91.935 E.01644
G1 X227.065 Y132.915 E1.78352
G1 X227.065 Y133.449 E.01644
G1 X185.551 Y91.935 E1.80676
G1 X185.017 Y91.935 E.01644
G1 X227.065 Y133.983 E1.83001
G1 X227.065 Y134.518 E.01644
G1 X184.482 Y91.935 E1.85325
G1 X183.948 Y91.935 E.01644
G1 X227.065 Y135.052 E1.8765
G1 X227.065 Y135.586 E.01644
G1 X183.414 Y91.935 E1.89974
G1 X182.88 Y91.935 E.01644
G1 X227.065 Y136.12 E1.92299
G1 X227.065 Y136.654 E.01644
G1 X182.346 Y91.935 E1.94623
G1 X181.812 Y91.935 E.01644
G1 X227.065 Y137.188 E1.96948
G1 X227.065 Y137.722 E.01644
G1 X181.278 Y91.935 E1.99272
G1 X180.744 Y91.935 E.01644
G1 X227.065 Y138.256 E2.01596
G1 X227.065 Y138.79 E.01644
G1 X180.21 Y91.935 E2.03921
G1 X179.676 Y91.935 E.01644
G1 X227.065 Y139.324 E2.06245
G1 X227.065 Y139.858 E.01644
G1 X179.142 Y91.935 E2.0857
G1 X178.607 Y91.935 E.01644
G1 X227.065 Y140.393 E2.10894
G1 X227.065 Y140.927 E.01644
G1 X178.073 Y91.935 E2.13219
G1 X177.539 Y91.935 E.01644
G1 X227.065 Y141.461 E2.15543
G1 X227.065 Y141.995 E.01644
G1 X177.005 Y91.935 E2.17868
G1 X176.471 Y91.935 E.01644
G1 X227.065 Y142.529 E2.20192
G1 X227.065 Y143.063 E.01644
G1 X175.937 Y91.935 E2.22517
G1 X175.403 Y91.935 E.01644
G1 X227.065 Y143.597 E2.24841
G1 X227.065 Y144.131 E.01644
G1 X174.869 Y91.935 E2.27165
G1 X174.335 Y91.935 E.01644
G1 X227.065 Y144.665 E2.2949
G1 X227.065 Y145.199 E.01644
G1 X173.801 Y91.935 E2.31814
G1 X173.267 Y91.935 E.01644
G1 X227.065 Y145.733 E2.34139
G1 X227.065 Y146.268 E.01644
G1 X172.732 Y91.935 E2.36463
G1 X172.198 Y91.935 E.01644
G1 X227.065 Y146.802 E2.38788
G1 X227.065 Y147.336 E.01644
G1 X171.664 Y91.935 E2.41112
G1 X171.13 Y91.935 E.01644
G1 X227.065 Y147.87 E2.43437
G1 X227.065 Y148.404 E.01644
G1 X170.596 Y91.935 E2.45761
G1 X170.062 Y91.935 E.01644
G1 X227.065 Y148.938 E2.48086
G1 X227.065 Y149.472 E.01644
G1 X169.528 Y91.935 E2.5041
G1 X168.994 Y91.935 E.01644
G1 X227.065 Y150.006 E2.52735
G1 X227.065 Y150.54 E.01644
G1 X168.46 Y91.935 E2.55059
G1 X167.926 Y91.935 E.01644
G1 X227.065 Y151.074 E2.57383
G1 X227.065 Y151.608 E.01644
G1 X167.392 Y91.935 E2.59708
G1 X166.857 Y91.935 E.01644
G1 X227.065 Y152.143 E2.62032
G1 X227.065 Y152.677 E.01644
G1 X166.323 Y91.935 E2.64357
G1 X165.789 Y91.935 E.01644
G1 X227.065 Y153.211 E2.66681
G1 X227.065 Y153.745 E.01644
G1 X165.255 Y91.935 E2.69006
G1 X164.721 Y91.935 E.01644
G1 X227.065 Y154.279 E2.7133
G1 X227.065 Y154.813 E.01644
G1 X164.187 Y91.935 E2.73655
G1 X163.653 Y91.935 E.01644
G1 X227.065 Y155.347 E2.75979
G1 X227.065 Y155.881 E.01644
G1 X163.119 Y91.935 E2.78304
G1 X162.585 Y91.935 E.01644
G1 X227.065 Y156.415 E2.80628
M73 P81 R9
G1 X227.065 Y156.949 E.01644
G1 X162.051 Y91.935 E2.82953
G1 X161.516 Y91.935 E.01644
G1 X227.065 Y157.483 E2.85277
G1 X227.065 Y158.018 E.01644
G1 X160.982 Y91.935 E2.87601
G1 X160.448 Y91.935 E.01644
G1 X227.065 Y158.552 E2.89926
G1 X227.065 Y159.086 E.01644
G1 X159.914 Y91.935 E2.9225
G1 X159.38 Y91.935 E.01644
G1 X227.065 Y159.62 E2.94575
G1 X227.065 Y160.065 E.01369
G1 X226.975 Y160.065 E.00275
G1 X158.846 Y91.935 E2.96511
G1 X158.312 Y91.935 E.01644
G1 X226.441 Y160.065 E2.96511
G1 X225.907 Y160.065 E.01644
G1 X157.778 Y91.935 E2.96511
G1 X157.244 Y91.935 E.01644
G1 X225.373 Y160.065 E2.96511
G1 X224.839 Y160.065 E.01644
G1 X156.71 Y91.935 E2.96511
G1 X156.176 Y91.935 E.01644
G1 X224.305 Y160.065 E2.96511
G1 X223.771 Y160.065 E.01644
G1 X155.641 Y91.935 E2.96511
G1 X155.107 Y91.935 E.01644
G1 X223.237 Y160.065 E2.96511
G1 X222.703 Y160.065 E.01644
G1 X154.573 Y91.935 E2.96511
G1 X154.039 Y91.935 E.01644
G1 X222.169 Y160.065 E2.96511
G1 X221.634 Y160.065 E.01644
G1 X153.505 Y91.935 E2.96511
G1 X152.971 Y91.935 E.01644
G1 X221.1 Y160.065 E2.96511
G1 X220.566 Y160.065 E.01644
G1 X152.437 Y91.935 E2.96511
G1 X151.903 Y91.935 E.01644
G1 X220.032 Y160.065 E2.96511
G1 X219.498 Y160.065 E.01644
G1 X151.369 Y91.935 E2.96511
G1 X150.835 Y91.935 E.01644
G1 X218.964 Y160.065 E2.96511
G1 X218.43 Y160.065 E.01644
G1 X150.301 Y91.935 E2.96511
G1 X149.766 Y91.935 E.01644
G1 X217.896 Y160.065 E2.96511
G1 X217.362 Y160.065 E.01644
G1 X149.232 Y91.935 E2.96511
G1 X148.698 Y91.935 E.01644
G1 X216.828 Y160.065 E2.96511
G1 X216.294 Y160.065 E.01644
G1 X148.164 Y91.935 E2.96511
G1 X147.63 Y91.935 E.01644
G1 X215.759 Y160.065 E2.96511
G1 X215.225 Y160.065 E.01644
G1 X147.096 Y91.935 E2.96511
G1 X146.562 Y91.935 E.01644
G1 X214.691 Y160.065 E2.96511
G1 X214.157 Y160.065 E.01644
G1 X146.028 Y91.935 E2.96511
G1 X145.494 Y91.935 E.01644
G1 X213.623 Y160.065 E2.96511
G1 X213.089 Y160.065 E.01644
G1 X144.96 Y91.935 E2.96511
G1 X144.426 Y91.935 E.01644
G1 X212.555 Y160.065 E2.96511
G1 X212.021 Y160.065 E.01644
G1 X143.891 Y91.935 E2.96511
G1 X143.357 Y91.935 E.01644
G1 X211.487 Y160.065 E2.96511
G1 X210.953 Y160.065 E.01644
G1 X142.823 Y91.935 E2.96511
G1 X142.289 Y91.935 E.01644
G1 X210.419 Y160.065 E2.96511
G1 X209.884 Y160.065 E.01644
G1 X141.755 Y91.935 E2.96511
G1 X141.221 Y91.935 E.01644
G1 X209.35 Y160.065 E2.96511
G1 X208.816 Y160.065 E.01644
G1 X140.687 Y91.935 E2.96511
G1 X140.153 Y91.935 E.01644
G1 X208.282 Y160.065 E2.96511
G1 X207.748 Y160.065 E.01644
G1 X139.619 Y91.935 E2.96511
G1 X139.085 Y91.935 E.01644
G1 X207.214 Y160.065 E2.96511
G1 X206.68 Y160.065 E.01644
G1 X138.551 Y91.935 E2.96511
G1 X138.016 Y91.935 E.01644
G1 X206.146 Y160.065 E2.96511
G1 X205.612 Y160.065 E.01644
G1 X137.482 Y91.935 E2.96511
G1 X136.948 Y91.935 E.01644
G1 X205.078 Y160.065 E2.96511
G1 X204.544 Y160.065 E.01644
G1 X136.414 Y91.935 E2.96511
G1 X135.88 Y91.935 E.01644
G1 X204.009 Y160.065 E2.96511
G1 X203.475 Y160.065 E.01644
G1 X135.346 Y91.935 E2.96511
G1 X134.812 Y91.935 E.01644
G1 X202.941 Y160.065 E2.96511
G1 X202.407 Y160.065 E.01644
G1 X134.278 Y91.935 E2.96511
G1 X133.744 Y91.935 E.01644
G1 X201.873 Y160.065 E2.96511
G1 X201.339 Y160.065 E.01644
G1 X133.21 Y91.935 E2.96511
G1 X132.676 Y91.935 E.01644
G1 X200.805 Y160.065 E2.96511
G1 X200.271 Y160.065 E.01644
G1 X132.141 Y91.935 E2.96511
G1 X131.607 Y91.935 E.01644
G1 X199.737 Y160.065 E2.96511
G1 X199.203 Y160.065 E.01644
G1 X131.073 Y91.935 E2.96511
G1 X130.539 Y91.935 E.01644
G1 X198.669 Y160.065 E2.96511
G1 X198.134 Y160.065 E.01644
G1 X130.005 Y91.935 E2.96511
G1 X129.471 Y91.935 E.01644
G1 X197.6 Y160.065 E2.96511
G1 X197.066 Y160.065 E.01644
G1 X128.937 Y91.935 E2.96511
G1 X128.403 Y91.935 E.01644
G1 X196.532 Y160.065 E2.96511
G1 X195.998 Y160.065 E.01644
G1 X127.869 Y91.935 E2.96511
G1 X127.335 Y91.935 E.01644
G1 X195.464 Y160.065 E2.96511
G1 X194.93 Y160.065 E.01644
G1 X126.801 Y91.935 E2.96511
G1 X126.266 Y91.935 E.01644
G1 X194.396 Y160.065 E2.96511
G1 X193.862 Y160.065 E.01644
G1 X125.732 Y91.935 E2.96511
G1 X125.198 Y91.935 E.01644
G1 X193.328 Y160.065 E2.96511
G1 X192.794 Y160.065 E.01644
G1 X124.664 Y91.935 E2.96511
G1 X124.13 Y91.935 E.01644
G1 X192.259 Y160.065 E2.96511
G1 X191.725 Y160.065 E.01644
G1 X123.596 Y91.935 E2.96511
G1 X123.062 Y91.935 E.01644
G1 X191.191 Y160.065 E2.96511
G1 X190.657 Y160.065 E.01644
G1 X122.528 Y91.935 E2.96511
G1 X121.994 Y91.935 E.01644
G1 X190.123 Y160.065 E2.96511
M73 P82 R9
G1 X189.589 Y160.065 E.01644
G1 X121.46 Y91.935 E2.96511
G1 X120.926 Y91.935 E.01644
G1 X189.055 Y160.065 E2.96511
G1 X188.521 Y160.065 E.01644
G1 X120.391 Y91.935 E2.96511
G1 X119.857 Y91.935 E.01644
G1 X187.987 Y160.065 E2.96511
G1 X187.453 Y160.065 E.01644
G1 X119.323 Y91.935 E2.96511
G1 X118.789 Y91.935 E.01644
G1 X186.919 Y160.065 E2.96511
G1 X186.384 Y160.065 E.01644
G1 X118.255 Y91.935 E2.96511
G1 X117.721 Y91.935 E.01644
G1 X185.85 Y160.065 E2.96511
G1 X185.316 Y160.065 E.01644
G1 X117.187 Y91.935 E2.96511
G1 X116.653 Y91.935 E.01644
G1 X184.782 Y160.065 E2.96511
G1 X184.248 Y160.065 E.01644
G1 X116.119 Y91.935 E2.96511
G1 X115.585 Y91.935 E.01644
G1 X183.714 Y160.065 E2.96511
G1 X183.18 Y160.065 E.01644
G1 X115.051 Y91.935 E2.96511
G1 X114.516 Y91.935 E.01644
G1 X182.646 Y160.065 E2.96511
G1 X182.112 Y160.065 E.01644
G1 X113.982 Y91.935 E2.96511
G1 X113.448 Y91.935 E.01644
G1 X181.578 Y160.065 E2.96511
G1 X181.043 Y160.065 E.01644
G1 X112.914 Y91.935 E2.96511
G1 X112.38 Y91.935 E.01644
G1 X180.509 Y160.065 E2.96511
G1 X179.975 Y160.065 E.01644
G1 X111.846 Y91.935 E2.96511
G1 X111.312 Y91.935 E.01644
G1 X179.441 Y160.065 E2.96511
G1 X178.907 Y160.065 E.01644
G1 X110.778 Y91.935 E2.96511
G1 X110.244 Y91.935 E.01644
G1 X178.373 Y160.065 E2.96511
G1 X177.839 Y160.065 E.01644
G1 X109.71 Y91.935 E2.96511
G1 X109.175 Y91.935 E.01644
G1 X177.305 Y160.065 E2.96511
G1 X176.771 Y160.065 E.01644
G1 X108.641 Y91.935 E2.96511
G1 X108.107 Y91.935 E.01644
G1 X176.237 Y160.065 E2.96511
G1 X175.703 Y160.065 E.01644
G1 X107.573 Y91.935 E2.96511
G1 X107.039 Y91.935 E.01644
G1 X175.168 Y160.065 E2.96511
G1 X174.634 Y160.065 E.01644
G1 X106.505 Y91.935 E2.96511
G1 X105.971 Y91.935 E.01644
G1 X174.1 Y160.065 E2.96511
G1 X173.566 Y160.065 E.01644
G1 X105.437 Y91.935 E2.96511
M73 P82 R8
G1 X104.903 Y91.935 E.01644
G1 X173.032 Y160.065 E2.96511
G1 X172.498 Y160.065 E.01644
G1 X104.369 Y91.935 E2.96511
G1 X103.835 Y91.935 E.01644
G1 X171.964 Y160.065 E2.96511
G1 X171.43 Y160.065 E.01644
G1 X103.3 Y91.935 E2.96511
G1 X102.766 Y91.935 E.01644
G1 X170.896 Y160.065 E2.96511
G1 X170.362 Y160.065 E.01644
G1 X102.232 Y91.935 E2.96511
G1 X101.698 Y91.935 E.01644
G1 X169.828 Y160.065 E2.96511
G1 X169.293 Y160.065 E.01644
G1 X101.164 Y91.935 E2.96511
G1 X100.63 Y91.935 E.01644
G1 X168.759 Y160.065 E2.96511
G1 X168.225 Y160.065 E.01644
G1 X100.096 Y91.935 E2.96511
G1 X99.562 Y91.935 E.01644
G1 X167.691 Y160.065 E2.96511
G1 X167.157 Y160.065 E.01644
G1 X99.028 Y91.935 E2.96511
G1 X98.494 Y91.935 E.01644
G1 X166.623 Y160.065 E2.96511
G1 X166.089 Y160.065 E.01644
G1 X97.96 Y91.935 E2.96511
G1 X97.425 Y91.935 E.01644
G1 X165.555 Y160.065 E2.96511
G1 X165.021 Y160.065 E.01644
G1 X96.891 Y91.935 E2.96511
G1 X96.357 Y91.935 E.01644
G1 X164.487 Y160.065 E2.96511
G1 X163.953 Y160.065 E.01644
G1 X95.823 Y91.935 E2.96511
G1 X95.289 Y91.935 E.01644
G1 X163.418 Y160.065 E2.96511
G1 X162.884 Y160.065 E.01644
G1 X94.755 Y91.935 E2.96511
G1 X94.221 Y91.935 E.01644
G1 X162.35 Y160.065 E2.96511
G1 X161.816 Y160.065 E.01644
G1 X93.687 Y91.935 E2.96511
G1 X93.153 Y91.935 E.01644
G1 X161.282 Y160.065 E2.96511
G1 X160.748 Y160.065 E.01644
G1 X92.619 Y91.935 E2.96511
G1 X92.085 Y91.935 E.01644
G1 X110.214 Y110.065 E.78902
G1 X109.68 Y110.065 E.01644
G1 X91.55 Y91.935 E.78902
G1 X91.016 Y91.935 E.01644
G1 X109.146 Y110.065 E.78902
G1 X108.612 Y110.065 E.01644
G1 X90.482 Y91.935 E.78902
G1 X89.948 Y91.935 E.01644
G1 X108.078 Y110.065 E.78902
G1 X107.543 Y110.065 E.01644
G1 X89.414 Y91.935 E.78902
G1 X88.88 Y91.935 E.01644
G1 X107.009 Y110.065 E.78902
G1 X106.475 Y110.065 E.01644
G1 X88.346 Y91.935 E.78902
G1 X87.812 Y91.935 E.01644
G1 X105.941 Y110.065 E.78902
G1 X105.407 Y110.065 E.01644
G1 X87.278 Y91.935 E.78902
G1 X86.744 Y91.935 E.01644
G1 X104.873 Y110.065 E.78902
G1 X104.339 Y110.065 E.01644
G1 X86.21 Y91.935 E.78902
G1 X85.675 Y91.935 E.01644
G1 X103.805 Y110.065 E.78902
G1 X103.271 Y110.065 E.01644
G1 X85.141 Y91.935 E.78902
G1 X84.607 Y91.935 E.01644
G1 X102.737 Y110.065 E.78902
G1 X102.203 Y110.065 E.01644
G1 X84.073 Y91.935 E.78902
G1 X83.539 Y91.935 E.01644
G1 X101.668 Y110.065 E.78902
G1 X101.134 Y110.065 E.01644
G1 X83.005 Y91.935 E.78902
M73 P83 R8
G1 X82.471 Y91.935 E.01644
G1 X100.6 Y110.065 E.78902
G1 X100.066 Y110.065 E.01644
G1 X81.937 Y91.935 E.78902
G1 X81.403 Y91.935 E.01644
G1 X99.532 Y110.065 E.78902
G1 X99.065 Y110.065 E.01438
G1 X99.065 Y110.131 E.00205
G1 X80.869 Y91.935 E.79192
G1 X80.335 Y91.935 E.01644
G1 X99.065 Y110.665 E.81517
G1 X99.065 Y111.2 E.01644
G1 X79.8 Y91.935 E.83841
G1 X79.266 Y91.935 E.01644
G1 X99.065 Y111.734 E.86166
G1 X99.065 Y112.268 E.01644
G1 X78.732 Y91.935 E.8849
G1 X78.198 Y91.935 E.01644
G1 X99.065 Y112.802 E.90815
G1 X99.065 Y113.336 E.01644
G1 X77.664 Y91.935 E.93139
G1 X77.13 Y91.935 E.01644
G1 X99.065 Y113.87 E.95464
G1 X99.065 Y114.404 E.01644
G1 X76.596 Y91.935 E.97788
G1 X76.062 Y91.935 E.01644
G1 X99.065 Y114.938 E1.00112
G1 X99.065 Y115.472 E.01644
G1 X75.528 Y91.935 E1.02437
G1 X74.994 Y91.935 E.01644
G1 X99.065 Y116.006 E1.04761
G1 X99.065 Y116.54 E.01644
G1 X74.46 Y91.935 E1.07086
G1 X73.925 Y91.935 E.01644
G1 X99.065 Y117.075 E1.0941
G1 X99.065 Y117.609 E.01644
G1 X73.391 Y91.935 E1.11735
G1 X72.857 Y91.935 E.01644
G1 X99.065 Y118.143 E1.14059
G1 X99.065 Y118.677 E.01644
G1 X72.323 Y91.935 E1.16384
G1 X71.789 Y91.935 E.01644
G1 X99.065 Y119.211 E1.18708
G1 X99.065 Y119.745 E.01644
G1 X71.255 Y91.935 E1.21033
G1 X70.721 Y91.935 E.01644
G1 X99.065 Y120.279 E1.23357
G1 X99.065 Y120.813 E.01644
G1 X70.187 Y91.935 E1.25682
G1 X69.653 Y91.935 E.01644
G1 X99.065 Y121.347 E1.28006
G1 X99.065 Y121.881 E.01644
G1 X69.119 Y91.935 E1.3033
G1 X68.585 Y91.935 E.01644
G1 X99.065 Y122.415 E1.32655
G1 X99.065 Y122.95 E.01644
G1 X68.05 Y91.935 E1.34979
G1 X67.516 Y91.935 E.01644
G1 X99.065 Y123.484 E1.37304
G1 X99.065 Y124.018 E.01644
G1 X66.982 Y91.935 E1.39628
G1 X66.448 Y91.935 E.01644
G1 X99.065 Y124.552 E1.41953
G1 X99.065 Y125.086 E.01644
G1 X65.914 Y91.935 E1.44277
G1 X65.38 Y91.935 E.01644
G1 X99.065 Y125.62 E1.46602
G1 X99.065 Y126.154 E.01644
G1 X64.846 Y91.935 E1.48926
G1 X64.312 Y91.935 E.01644
G1 X99.065 Y126.688 E1.51251
G1 X99.065 Y127.222 E.01644
G1 X63.778 Y91.935 E1.53575
G1 X63.244 Y91.935 E.01644
G1 X99.065 Y127.756 E1.559
G1 X99.065 Y128.29 E.01644
G1 X62.709 Y91.935 E1.58224
G1 X62.175 Y91.935 E.01644
G1 X99.065 Y128.825 E1.60548
G1 X99.065 Y129.359 E.01644
G1 X61.641 Y91.935 E1.62873
G1 X61.107 Y91.935 E.01644
G1 X99.065 Y129.893 E1.65197
G1 X99.065 Y130.427 E.01644
G1 X60.573 Y91.935 E1.67522
G1 X60.039 Y91.935 E.01644
G1 X99.065 Y130.961 E1.69846
G1 X99.065 Y131.495 E.01644
G1 X59.505 Y91.935 E1.72171
G1 X58.971 Y91.935 E.01644
G1 X99.065 Y132.029 E1.74495
G1 X99.065 Y132.563 E.01644
G1 X58.437 Y91.935 E1.7682
G1 X57.903 Y91.935 E.01644
G1 X99.065 Y133.097 E1.79144
G1 X99.065 Y133.631 E.01644
G1 X57.369 Y91.935 E1.81469
G1 X56.834 Y91.935 E.01644
G1 X99.065 Y134.165 E1.83793
G1 X99.065 Y134.7 E.01644
G1 X56.3 Y91.935 E1.86117
G1 X55.766 Y91.935 E.01644
G1 X99.065 Y135.234 E1.88442
G1 X99.065 Y135.768 E.01644
G1 X55.232 Y91.935 E1.90766
G1 X54.698 Y91.935 E.01644
G1 X99.065 Y136.302 E1.93091
G1 X99.065 Y136.836 E.01644
G1 X54.164 Y91.935 E1.95415
G1 X53.63 Y91.935 E.01644
G1 X99.065 Y137.37 E1.9774
G1 X99.065 Y137.904 E.01644
G1 X53.096 Y91.935 E2.00064
G1 X52.562 Y91.935 E.01644
G1 X99.065 Y138.438 E2.02389
G1 X99.065 Y138.972 E.01644
G1 X52.028 Y91.935 E2.04713
G1 X51.494 Y91.935 E.01644
G1 X99.065 Y139.506 E2.07038
G1 X99.065 Y140.041 E.01644
G1 X50.959 Y91.935 E2.09362
G1 X50.425 Y91.935 E.01644
G1 X99.065 Y140.575 E2.11687
G1 X99.065 Y141.109 E.01644
G1 X49.891 Y91.935 E2.14011
G1 X49.357 Y91.935 E.01644
G1 X117.487 Y160.065 E2.96511
G1 X118.021 Y160.065 E.01644
G1 X99.891 Y141.935 E.78902
G1 X100.425 Y141.935 E.01644
G1 X118.555 Y160.065 E.78902
G1 X119.089 Y160.065 E.01644
G1 X100.959 Y141.935 E.78902
G1 X101.494 Y141.935 E.01644
G1 X119.623 Y160.065 E.78902
G1 X120.157 Y160.065 E.01644
G1 X102.028 Y141.935 E.78902
G1 X102.562 Y141.935 E.01644
G1 X120.691 Y160.065 E.78902
G1 X121.225 Y160.065 E.01644
G1 X103.096 Y141.935 E.78902
G1 X103.63 Y141.935 E.01644
G1 X121.759 Y160.065 E.78902
G1 X122.293 Y160.065 E.01644
G1 X104.164 Y141.935 E.78902
G1 X104.698 Y141.935 E.01644
G1 X122.827 Y160.065 E.78902
G1 X123.362 Y160.065 E.01644
G1 X105.232 Y141.935 E.78902
G1 X105.766 Y141.935 E.01644
G1 X123.896 Y160.065 E.78902
G1 X124.43 Y160.065 E.01644
G1 X106.3 Y141.935 E.78902
G1 X106.834 Y141.935 E.01644
G1 X124.964 Y160.065 E.78902
G1 X125.498 Y160.065 E.01644
G1 X107.369 Y141.935 E.78902
G1 X107.903 Y141.935 E.01644
G1 X126.032 Y160.065 E.78902
G1 X126.566 Y160.065 E.01644
G1 X108.437 Y141.935 E.78902
G1 X108.971 Y141.935 E.01644
G1 X127.1 Y160.065 E.78902
G1 X127.634 Y160.065 E.01644
G1 X109.505 Y141.935 E.78902
G1 X110.039 Y141.935 E.01644
G1 X128.168 Y160.065 E.78902
G1 X128.702 Y160.065 E.01644
G1 X110.573 Y141.935 E.78902
G1 X110.935 Y141.935 E.01115
G1 X110.935 Y141.763 E.00529
G1 X129.237 Y160.065 E.7965
G1 X129.771 Y160.065 E.01644
G1 X110.935 Y141.229 E.81975
G1 X110.935 Y140.695 E.01644
G1 X130.305 Y160.065 E.84299
G1 X130.839 Y160.065 E.01644
G1 X110.935 Y140.161 E.86624
G1 X110.935 Y139.627 E.01644
G1 X131.373 Y160.065 E.88948
G1 X131.907 Y160.065 E.01644
G1 X110.935 Y139.093 E.91273
G1 X110.935 Y138.559 E.01644
G1 X132.441 Y160.065 E.93597
G1 X132.975 Y160.065 E.01644
G1 X110.935 Y138.025 E.95921
G1 X110.935 Y137.491 E.01644
G1 X133.509 Y160.065 E.98246
G1 X134.043 Y160.065 E.01644
G1 X110.935 Y136.957 E1.0057
G1 X110.935 Y136.422 E.01644
G1 X134.577 Y160.065 E1.02895
G1 X135.112 Y160.065 E.01644
G1 X110.935 Y135.888 E1.05219
G1 X110.935 Y135.354 E.01644
G1 X135.646 Y160.065 E1.07544
G1 X136.18 Y160.065 E.01644
G1 X110.935 Y134.82 E1.09868
G1 X110.935 Y134.286 E.01644
G1 X136.714 Y160.065 E1.12193
G1 X137.248 Y160.065 E.01644
G1 X110.935 Y133.752 E1.14517
G1 X110.935 Y133.218 E.01644
G1 X137.782 Y160.065 E1.16842
G1 X138.316 Y160.065 E.01644
G1 X110.935 Y132.684 E1.19166
G1 X110.935 Y132.15 E.01644
G1 X138.85 Y160.065 E1.21491
G1 X139.384 Y160.065 E.01644
G1 X110.935 Y131.616 E1.23815
G1 X110.935 Y131.082 E.01644
G1 X139.918 Y160.065 E1.26139
G1 X140.453 Y160.065 E.01644
G1 X110.935 Y130.547 E1.28464
G1 X110.935 Y130.013 E.01644
G1 X140.987 Y160.065 E1.30788
G1 X141.521 Y160.065 E.01644
G1 X110.935 Y129.479 E1.33113
G1 X110.935 Y128.945 E.01644
G1 X142.055 Y160.065 E1.35437
G1 X142.589 Y160.065 E.01644
G1 X110.935 Y128.411 E1.37762
G1 X110.935 Y127.877 E.01644
G1 X143.123 Y160.065 E1.40086
G1 X143.657 Y160.065 E.01644
G1 X110.935 Y127.343 E1.42411
G1 X110.935 Y126.809 E.01644
G1 X144.191 Y160.065 E1.44735
G1 X144.725 Y160.065 E.01644
G1 X110.935 Y126.275 E1.4706
G1 X110.935 Y125.741 E.01644
G1 X145.259 Y160.065 E1.49384
G1 X145.793 Y160.065 E.01644
G1 X110.935 Y125.207 E1.51709
G1 X110.935 Y124.672 E.01644
G1 X146.328 Y160.065 E1.54033
G1 X146.862 Y160.065 E.01644
G1 X110.935 Y124.138 E1.56357
G1 X110.935 Y123.604 E.01644
G1 X147.396 Y160.065 E1.58682
G1 X147.93 Y160.065 E.01644
G1 X110.935 Y123.07 E1.61006
G1 X110.935 Y122.536 E.01644
G1 X148.464 Y160.065 E1.63331
G1 X148.998 Y160.065 E.01644
G1 X110.935 Y122.002 E1.65655
G1 X110.935 Y121.468 E.01644
G1 X149.532 Y160.065 E1.6798
G1 X150.066 Y160.065 E.01644
G1 X110.935 Y120.934 E1.70304
G1 X110.935 Y120.4 E.01644
G1 X150.6 Y160.065 E1.72629
G1 X151.134 Y160.065 E.01644
G1 X110.935 Y119.866 E1.74953
G1 X110.935 Y119.332 E.01644
G1 X151.668 Y160.065 E1.77278
G1 X152.203 Y160.065 E.01644
G1 X110.935 Y118.797 E1.79602
G1 X110.935 Y118.263 E.01644
G1 X152.737 Y160.065 E1.81926
G1 X153.271 Y160.065 E.01644
G1 X110.935 Y117.729 E1.84251
G1 X110.935 Y117.195 E.01644
G1 X153.805 Y160.065 E1.86575
G1 X154.339 Y160.065 E.01644
G1 X110.935 Y116.661 E1.889
G1 X110.935 Y116.127 E.01644
G1 X154.873 Y160.065 E1.91224
G1 X155.407 Y160.065 E.01644
G1 X110.935 Y115.593 E1.93549
G1 X110.935 Y115.059 E.01644
G1 X155.941 Y160.065 E1.95873
G1 X156.475 Y160.065 E.01644
G1 X110.935 Y114.525 E1.98198
G1 X110.935 Y113.991 E.01644
G1 X157.009 Y160.065 E2.00522
G1 X157.543 Y160.065 E.01644
G1 X110.935 Y113.457 E2.02847
G1 X110.935 Y112.922 E.01644
G1 X158.078 Y160.065 E2.05171
G1 X158.612 Y160.065 E.01644
G1 X110.935 Y112.388 E2.07496
G1 X110.935 Y111.854 E.01644
G1 X159.146 Y160.065 E2.0982
G1 X159.68 Y160.065 E.01644
G1 X110.935 Y111.32 E2.12144
G1 X110.935 Y110.786 E.01644
G1 X160.384 Y160.234 E2.15207
G1 X29.531 Y160.234 F30000
G1 F15000
G1 X28.935 Y159.639 E.02593
G1 X28.935 Y159.104 E.01644
G1 X29.895 Y160.065 E.04179
G1 X30.43 Y160.065 E.01644
G1 X28.935 Y158.57 E.06503
G1 X28.935 Y158.036 E.01644
G1 X30.964 Y160.065 E.08828
G1 X31.498 Y160.065 E.01644
G1 X28.935 Y157.502 E.11152
G1 X28.935 Y156.968 E.01644
G1 X32.032 Y160.065 E.13477
G1 X32.566 Y160.065 E.01644
M73 P84 R8
G1 X28.935 Y156.434 E.15801
G1 X28.935 Y155.9 E.01644
G1 X33.1 Y160.065 E.18126
G1 X33.634 Y160.065 E.01644
G1 X28.935 Y155.366 E.2045
G1 X28.935 Y154.832 E.01644
G1 X34.168 Y160.065 E.22775
G1 X34.702 Y160.065 E.01644
G1 X28.935 Y154.298 E.25099
G1 X28.935 Y153.764 E.01644
G1 X35.236 Y160.065 E.27423
G1 X35.771 Y160.065 E.01644
G1 X28.935 Y153.229 E.29748
G1 X28.935 Y152.695 E.01644
G1 X36.305 Y160.065 E.32072
G1 X36.839 Y160.065 E.01644
G1 X28.935 Y152.161 E.34397
G1 X28.935 Y151.627 E.01644
G1 X37.373 Y160.065 E.36721
G1 X37.907 Y160.065 E.01644
G1 X28.935 Y151.093 E.39046
G1 X28.935 Y150.559 E.01644
G1 X38.441 Y160.065 E.4137
G1 X38.975 Y160.065 E.01644
G1 X28.935 Y150.025 E.43695
G1 X28.935 Y149.491 E.01644
G1 X39.509 Y160.065 E.46019
G1 X40.043 Y160.065 E.01644
G1 X28.935 Y148.957 E.48344
G1 X28.935 Y148.423 E.01644
G1 X40.577 Y160.065 E.50668
G1 X41.111 Y160.065 E.01644
G1 X28.935 Y147.889 E.52993
G1 X28.935 Y147.354 E.01644
G1 X41.646 Y160.065 E.55317
G1 X42.18 Y160.065 E.01644
G1 X28.935 Y146.82 E.57641
G1 X28.935 Y146.286 E.01644
G1 X42.714 Y160.065 E.59966
G1 X43.248 Y160.065 E.01644
G1 X28.935 Y145.752 E.6229
G1 X28.935 Y145.218 E.01644
G1 X43.782 Y160.065 E.64615
G1 X44.316 Y160.065 E.01644
G1 X28.935 Y144.684 E.66939
G1 X28.935 Y144.15 E.01644
G1 X44.85 Y160.065 E.69264
G1 X45.384 Y160.065 E.01644
G1 X28.935 Y143.616 E.71588
G1 X28.935 Y143.082 E.01644
G1 X45.918 Y160.065 E.73913
G1 X46.452 Y160.065 E.01644
G1 X28.935 Y142.548 E.76237
G1 X28.935 Y142.014 E.01644
G1 X46.986 Y160.065 E.78562
G1 X47.521 Y160.065 E.01644
G1 X28.935 Y141.479 E.80886
G1 X28.935 Y140.945 E.01644
G1 X48.055 Y160.065 E.8321
G1 X48.589 Y160.065 E.01644
G1 X28.935 Y140.411 E.85535
G1 X28.935 Y139.877 E.01644
G1 X49.123 Y160.065 E.87859
G1 X49.657 Y160.065 E.01644
G1 X28.935 Y139.343 E.90184
G1 X28.935 Y138.809 E.01644
G1 X50.191 Y160.065 E.92508
G1 X50.725 Y160.065 E.01644
G1 X28.935 Y138.275 E.94833
G1 X28.935 Y137.741 E.01644
G1 X51.259 Y160.065 E.97157
G1 X51.793 Y160.065 E.01644
G1 X28.935 Y137.207 E.99482
G1 X28.935 Y136.673 E.01644
G1 X52.327 Y160.065 E1.01806
G1 X52.861 Y160.065 E.01644
G1 X28.935 Y136.139 E1.04131
G1 X28.935 Y135.604 E.01644
G1 X53.396 Y160.065 E1.06455
G1 X53.93 Y160.065 E.01644
G1 X28.935 Y135.07 E1.0878
G1 X28.935 Y134.536 E.01644
G1 X54.464 Y160.065 E1.11104
G1 X54.998 Y160.065 E.01644
G1 X28.935 Y134.002 E1.13428
G1 X28.935 Y133.468 E.01644
G1 X55.532 Y160.065 E1.15753
G1 X56.066 Y160.065 E.01644
G1 X28.935 Y132.934 E1.18077
G1 X28.935 Y132.4 E.01644
G1 X56.6 Y160.065 E1.20402
G1 X57.134 Y160.065 E.01644
G1 X28.935 Y131.866 E1.22726
G1 X28.935 Y131.332 E.01644
G1 X57.668 Y160.065 E1.25051
G1 X58.202 Y160.065 E.01644
G1 X28.935 Y130.798 E1.27375
G1 X28.935 Y130.264 E.01644
G1 X58.736 Y160.065 E1.297
G1 X59.271 Y160.065 E.01644
G1 X28.935 Y129.729 E1.32024
G1 X28.935 Y129.195 E.01644
G1 X59.805 Y160.065 E1.34349
G1 X60.339 Y160.065 E.01644
G1 X28.935 Y128.661 E1.36673
G1 X28.935 Y128.127 E.01644
G1 X60.873 Y160.065 E1.38998
G1 X61.407 Y160.065 E.01644
G1 X28.935 Y127.593 E1.41322
G1 X28.935 Y127.059 E.01644
G1 X61.941 Y160.065 E1.43646
G1 X62.475 Y160.065 E.01644
G1 X28.935 Y126.525 E1.45971
G1 X28.935 Y125.991 E.01644
G1 X63.009 Y160.065 E1.48295
G1 X63.543 Y160.065 E.01644
G1 X28.935 Y125.457 E1.5062
G1 X28.935 Y124.923 E.01644
G1 X64.077 Y160.065 E1.52944
G1 X64.611 Y160.065 E.01644
G1 X28.935 Y124.389 E1.55269
G1 X28.935 Y123.854 E.01644
G1 X65.146 Y160.065 E1.57593
G1 X65.68 Y160.065 E.01644
G1 X28.935 Y123.32 E1.59918
G1 X28.935 Y122.786 E.01644
G1 X66.214 Y160.065 E1.62242
G1 X66.748 Y160.065 E.01644
G1 X28.935 Y122.252 E1.64567
G1 X28.935 Y121.718 E.01644
G1 X67.282 Y160.065 E1.66891
G1 X67.816 Y160.065 E.01644
G1 X28.935 Y121.184 E1.69216
G1 X28.935 Y120.65 E.01644
G1 X68.35 Y160.065 E1.7154
G1 X68.884 Y160.065 E.01644
G1 X28.935 Y120.116 E1.73864
G1 X28.935 Y119.582 E.01644
G1 X69.418 Y160.065 E1.76189
M73 P84 R7
G1 X69.952 Y160.065 E.01644
G1 X28.935 Y119.048 E1.78513
G1 X28.935 Y118.514 E.01644
G1 X70.486 Y160.065 E1.80838
G1 X71.021 Y160.065 E.01644
G1 X28.935 Y117.979 E1.83162
G1 X28.935 Y117.445 E.01644
G1 X71.555 Y160.065 E1.85487
G1 X72.089 Y160.065 E.01644
G1 X28.935 Y116.911 E1.87811
G1 X28.935 Y116.377 E.01644
G1 X72.623 Y160.065 E1.90136
G1 X73.157 Y160.065 E.01644
G1 X28.935 Y115.843 E1.9246
G1 X28.935 Y115.309 E.01644
G1 X73.691 Y160.065 E1.94785
G1 X74.225 Y160.065 E.01644
G1 X28.935 Y114.775 E1.97109
G1 X28.935 Y114.241 E.01644
G1 X74.759 Y160.065 E1.99433
G1 X75.293 Y160.065 E.01644
G1 X28.935 Y113.707 E2.01758
G1 X28.935 Y113.173 E.01644
G1 X75.827 Y160.065 E2.04082
G1 X76.361 Y160.065 E.01644
G1 X28.935 Y112.639 E2.06407
G1 X28.935 Y112.104 E.01644
G1 X76.896 Y160.065 E2.08731
G1 X77.43 Y160.065 E.01644
G1 X28.935 Y111.57 E2.11056
G1 X28.935 Y111.036 E.01644
G1 X77.964 Y160.065 E2.1338
G1 X78.498 Y160.065 E.01644
G1 X28.935 Y110.502 E2.15705
G1 X28.935 Y109.968 E.01644
G1 X79.032 Y160.065 E2.18029
G1 X79.566 Y160.065 E.01644
G1 X28.935 Y109.434 E2.20354
G1 X28.935 Y108.9 E.01644
G1 X80.27 Y160.234 E2.23417
G1 X117.122 Y160.234 F30000
G1 F15000
G1 X48.823 Y91.935 E2.97249
G1 X48.289 Y91.935 E.01644
G1 X116.418 Y160.065 E2.96511
G1 X115.884 Y160.065 E.01644
G1 X47.755 Y91.935 E2.96511
G1 X47.221 Y91.935 E.01644
G1 X115.35 Y160.065 E2.96511
G1 X114.816 Y160.065 E.01644
G1 X46.687 Y91.935 E2.96511
G1 X46.153 Y91.935 E.01644
G1 X114.282 Y160.065 E2.96511
G1 X113.748 Y160.065 E.01644
G1 X45.619 Y91.935 E2.96511
G1 X45.084 Y91.935 E.01644
G1 X113.214 Y160.065 E2.96511
G1 X112.68 Y160.065 E.01644
G1 X44.55 Y91.935 E2.96511
G1 X44.016 Y91.935 E.01644
G1 X112.146 Y160.065 E2.96511
G1 X111.612 Y160.065 E.01644
G1 X43.482 Y91.935 E2.96511
G1 X42.948 Y91.935 E.01644
G1 X111.077 Y160.065 E2.96511
G1 X110.543 Y160.065 E.01644
G1 X71.377 Y120.899 E1.70457
G1 X71.742 Y121.643 E.0255
G1 X71.837 Y121.892 E.00821
G1 X110.009 Y160.065 E1.66133
G1 X109.475 Y160.065 E.01644
G1 X72.14 Y122.73 E1.62488
G1 X72.348 Y123.472 E.02371
G1 X108.941 Y160.065 E1.59258
G1 X108.407 Y160.065 E.01644
G1 X72.476 Y124.134 E1.56378
G3 X72.568 Y124.76 I-3.385 J.818 E.01951
G1 X107.873 Y160.065 E1.53653
G1 X107.339 Y160.065 E.01644
G1 X72.622 Y125.348 E1.51095
G3 X72.636 Y125.896 I-2.994 J.351 E.0169
G1 X106.805 Y160.065 E1.48709
G1 X106.271 Y160.065 E.01644
G1 X72.636 Y126.43 E1.46384
G3 X72.597 Y126.925 I-2.731 J.034 E.0153
G1 X105.737 Y160.065 E1.4423
G1 X105.202 Y160.065 E.01644
G1 X72.552 Y127.414 E1.421
G3 X72.475 Y127.871 I-2.539 J-.194 E.01428
G1 X104.668 Y160.065 E1.40111
G1 X104.134 Y160.065 E.01644
G1 X72.392 Y128.322 E1.38148
G3 X72.286 Y128.75 I-2.397 J-.366 E.01359
G1 X103.6 Y160.065 E1.36285
G1 X103.066 Y160.065 E.01644
G1 X72.169 Y129.168 E1.34469
G3 X72.041 Y129.573 I-2.285 J-.501 E.01311
G1 X102.532 Y160.065 E1.32704
G1 X101.998 Y160.065 E.01644
G1 X71.893 Y129.96 E1.31021
G1 X71.746 Y130.347 E.01274
G1 X101.464 Y160.065 E1.29338
G1 X100.93 Y160.065 E.01644
G1 X71.571 Y130.706 E1.27774
G1 X71.395 Y131.064 E.01229
G1 X100.396 Y160.065 E1.26214
G1 X99.862 Y160.065 E.01644
G1 X71.207 Y131.41 E1.24709
G1 X71.005 Y131.742 E.01196
G1 X99.327 Y160.065 E1.23263
G1 X98.793 Y160.065 E.01644
G1 X70.803 Y132.075 E1.21818
G3 X70.578 Y132.384 I-1.809 J-1.082 E.01178
G1 X98.259 Y160.065 E1.20473
G1 X97.725 Y160.065 E.01644
G1 X70.351 Y132.69 E1.19138
G3 X70.116 Y132.99 I-1.754 J-1.135 E.01172
G1 X97.191 Y160.065 E1.17835
G1 X96.657 Y160.065 E.01644
G1 X69.864 Y133.272 E1.16607
G1 X69.612 Y133.554 E.01164
G1 X96.123 Y160.065 E1.15379
G1 X95.589 Y160.065 E.01644
G1 X69.344 Y133.82 E1.14222
G1 X69.068 Y134.078 E.01163
G1 X95.055 Y160.065 E1.131
G1 X94.521 Y160.065 E.01644
G1 X68.791 Y134.335 E1.11982
G1 X68.49 Y134.568 E.01171
G1 X93.987 Y160.065 E1.10966
G1 X93.452 Y160.065 E.01644
G1 X68.189 Y134.801 E1.0995
G3 X67.878 Y135.024 I-1.375 J-1.594 E.0118
G1 X92.918 Y160.065 E1.08981
G1 X92.384 Y160.065 E.01644
G1 X67.552 Y135.233 E1.08074
G1 X67.226 Y135.441 E.0119
G1 X91.85 Y160.065 E1.07167
M73 P85 R7
G1 X91.316 Y160.065 E.01644
G1 X66.878 Y135.627 E1.06357
G1 X66.527 Y135.809 E.01219
G1 X90.782 Y160.065 E1.05564
G1 X90.248 Y160.065 E.01644
G1 X66.165 Y135.982 E1.04812
G1 X65.786 Y136.137 E.01261
G1 X89.714 Y160.065 E1.04139
G1 X89.18 Y160.065 E.01644
G1 X65.406 Y136.291 E1.03466
G3 X65 Y136.419 I-.903 J-2.17 E.01313
G1 X88.646 Y160.065 E1.02911
G1 X88.112 Y160.065 E.01644
G1 X64.59 Y136.544 E1.02368
G3 X64.162 Y136.649 I-.792 J-2.296 E.0136
G1 X87.577 Y160.065 E1.01909
G1 X87.043 Y160.065 E.01644
G1 X63.72 Y136.741 E1.01509
G3 X63.263 Y136.819 I-.654 J-2.46 E.01427
G1 X86.509 Y160.065 E1.01171
G1 X85.975 Y160.065 E.01644
G1 X62.784 Y136.873 E1.00932
G3 X62.291 Y136.915 I-.472 J-2.678 E.01524
G1 X85.441 Y160.065 E1.00753
G1 X84.907 Y160.065 E.01644
G1 X61.769 Y136.926 E1.00701
G3 X61.225 Y136.917 I-.221 J-2.98 E.01674
G1 X84.373 Y160.065 E1.00742
G1 X83.839 Y160.065 E.01644
G1 X60.652 Y136.878 E1.00912
G3 X60.036 Y136.796 I.142 J-3.418 E.01916
G1 X83.305 Y160.065 E1.0127
G1 X82.771 Y160.065 E.01644
G1 X59.389 Y136.683 E1.01763
G1 X58.671 Y136.499 E.0228
G1 X82.236 Y160.065 E1.02561
G1 X81.702 Y160.065 E.01644
G1 X57.865 Y136.228 E1.03742
G3 X56.929 Y135.825 I1.735 J-5.328 E.03141
G1 X81.168 Y160.065 E1.05494
G1 X80.634 Y160.065 E.01644
G1 X55.697 Y135.127 E1.08531
G1 X55.004 Y134.638 E.0261
G3 X52.602 Y132.033 I6.522 J-8.421 E.10956
G1 X28.935 Y108.366 E1.03003
G1 X28.935 Y107.832 E.01644
G1 X51.87 Y130.767 E.99817
G1 X51.472 Y129.834 E.03122
G1 X28.935 Y107.298 E.98082
G1 X28.935 Y106.763 E.01644
G1 X51.209 Y129.037 E.96937
G1 X51.037 Y128.331 E.02237
G1 X28.935 Y106.229 E.96188
G1 X28.935 Y105.695 E.01644
G1 X50.913 Y127.673 E.95652
G1 X50.828 Y127.054 E.01923
G1 X28.935 Y105.161 E.95281
G1 X28.935 Y104.627 E.01644
G1 X50.797 Y126.489 E.95145
G3 X50.778 Y125.935 I3.02 J-.382 E.01707
G1 X28.935 Y104.093 E.95061
G1 X28.935 Y103.559 E.01644
G1 X50.801 Y125.424 E.95163
G3 X50.832 Y124.921 I2.775 J-.083 E.01554
G1 X28.935 Y103.025 E.95296
G1 X28.935 Y102.491 E.01644
G1 X50.896 Y124.452 E.95577
G3 X50.963 Y123.985 I2.593 J.136 E.01453
G1 X28.935 Y101.957 E.9587
G1 X28.935 Y101.423 E.01644
G1 X51.064 Y123.551 E.96308
G1 X51.164 Y123.118 E.0137
G1 X28.935 Y100.888 E.96745
G1 X28.935 Y100.354 E.01644
G1 X51.292 Y122.711 E.97299
G1 X51.424 Y122.309 E.01301
G1 X28.935 Y99.82 E.97876
G1 X28.935 Y99.286 E.01644
G1 X51.571 Y121.922 E.98515
G1 X51.733 Y121.55 E.01249
G1 X28.935 Y98.752 E.99219
G1 X28.935 Y98.218 E.01644
G1 X51.896 Y121.178 E.99927
G1 X52.085 Y120.833 E.01211
G1 X28.935 Y97.684 E1.00749
G1 X28.935 Y97.15 E.01644
G1 X52.273 Y120.488 E1.01572
G3 X52.475 Y120.156 I1.919 J.94 E.01198
G1 X28.935 Y96.616 E1.02451
G1 X28.935 Y96.082 E.01644
G1 X52.69 Y119.837 E1.03385
G1 X52.905 Y119.517 E.01184
G1 X28.935 Y95.548 E1.0432
G1 X28.935 Y95.37 E.00545
G2 X29.731 Y95.809 I1.773 J-2.275 E.02809
G1 X53.143 Y119.221 E1.0189
G1 X53.382 Y118.926 E.01168
G1 X30.385 Y95.929 E1.00088
G1 X30.5 Y95.939 E.00356
G1 X30.894 Y95.904 E.01218
G1 X53.629 Y118.639 E.98945
G1 X53.893 Y118.369 E.01162
G1 X31.32 Y95.796 E.98242
G1 X31.686 Y95.628 E.0124
G1 X54.157 Y118.099 E.97798
G3 X54.437 Y117.845 I1.53 J1.406 E.01165
G1 X32.005 Y95.412 E.9763
G2 X32.281 Y95.155 I-.592 J-.913 E.01169
G1 X54.725 Y117.599 E.97681
G3 X55.015 Y117.354 I1.489 J1.465 E.01168
G1 X32.517 Y94.856 E.97916
G2 X32.708 Y94.514 I-.875 J-.715 E.01214
G1 X55.328 Y117.133 E.98444
G1 X55.641 Y116.912 E.01179
G1 X32.849 Y94.12 E.99194
G2 X32.925 Y93.662 I-1.263 J-.444 E.01437
G1 X55.965 Y116.702 E1.00276
G1 X56.304 Y116.507 E.01203
G1 X32.905 Y93.108 E1.01837
G1 X32.902 Y93.077 E.00096
G2 X32.613 Y92.282 I-2.397 J.422 E.02616
G1 X56.642 Y116.311 E1.04581
G3 X57.005 Y116.14 I1.121 J1.898 E.01236
G1 X32.8 Y91.935 E1.05342
G1 X33.334 Y91.935 E.01644
G1 X57.37 Y115.971 E1.04607
G3 X57.747 Y115.814 I1.046 J1.986 E.01259
G1 X33.869 Y91.935 E1.03925
G1 X34.403 Y91.935 E.01644
G1 X58.141 Y115.674 E1.03316
G3 X58.537 Y115.535 I.965 J2.113 E.01291
G1 X34.937 Y91.935 E1.02711
G1 X35.471 Y91.935 E.01644
G1 X58.962 Y115.426 E1.02237
G1 X59.387 Y115.318 E.01351
G1 X36.005 Y91.935 E1.01764
G1 X36.539 Y91.935 E.01644
G1 X59.839 Y115.236 E1.01407
G1 X60.299 Y115.162 E.01434
G1 X37.073 Y91.935 E1.01085
G1 X37.607 Y91.935 E.01644
G1 X60.785 Y115.113 E1.00873
G1 X61.285 Y115.079 E.01542
G1 X38.141 Y91.935 E1.00724
G1 X38.675 Y91.935 E.01644
G1 X61.815 Y115.075 E1.00706
G1 X62.361 Y115.087 E.01682
G1 X39.209 Y91.935 E1.0076
G1 X39.744 Y91.935 E.01644
G1 X62.954 Y115.146 E1.01017
G3 X63.57 Y115.228 I-.141 J3.413 E.01916
G1 X40.278 Y91.935 E1.01374
G1 X40.812 Y91.935 E.01644
G1 X64.245 Y115.368 E1.01984
G3 X64.988 Y115.578 I-.777 J4.182 E.02381
G1 X41.346 Y91.935 E1.02896
G1 X41.88 Y91.935 E.01644
G1 X65.823 Y115.878 E1.04205
G3 X66.823 Y116.344 I-2.053 J5.712 E.034
G1 X42.244 Y91.766 E1.06971
; WIPE_START
G1 X43.659 Y93.18 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X36.089 Y92.206 Z5 F30000
G1 X31.531 Y91.619 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354373
G1 F15000
G1 X31.192 Y91.559 E.00873
; LINE_WIDTH: 0.327704
G1 X31.026 Y91.537 E.00389
; LINE_WIDTH: 0.281527
G2 X30.841 Y91.514 I-.363 J2.112 E.00363
; LINE_WIDTH: 0.24429
G2 X30.14 Y91.516 I-.336 J5.793 E.0115
; LINE_WIDTH: 0.283908
G1 X29.974 Y91.537 E.00329
; LINE_WIDTH: 0.327676
G1 X29.808 Y91.559 E.00389
; LINE_WIDTH: 0.354342
G1 X29.469 Y91.619 E.00874
G1 X28.619 Y92.469 F30000
; LINE_WIDTH: 0.354373
G1 F15000
G1 X28.559 Y92.808 E.00873
; LINE_WIDTH: 0.327704
G1 X28.537 Y92.974 E.00389
; LINE_WIDTH: 0.281527
G2 X28.514 Y93.159 I2.112 J.363 E.00363
; LINE_WIDTH: 0.244295
G2 X28.516 Y93.86 I5.789 J.336 E.0115
; LINE_WIDTH: 0.283917
G1 X28.537 Y94.026 E.00329
; LINE_WIDTH: 0.327693
G1 X28.559 Y94.192 E.00389
; LINE_WIDTH: 0.354386
G1 X28.619 Y94.531 E.00874
; CHANGE_LAYER
; Z_HEIGHT: 4.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X28.559 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 24/25
; update layer progress
M73 L24
M991 S0 P23 ;notify layer change
G17
G3 Z5 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.602 Y141.21
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y141.602 E.01301
G1 X99.398 Y141.602 E.37166
G1 X99.398 Y110.398 E1.0351
G1 X110.602 Y110.398 E.37166
G1 X110.602 Y141.15 E1.0201
M204 S250
G1 X110.21 Y141.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.9 Y138.966 Z5.2 F30000
G1 X51.288 Y124.062 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X51.502 Y123.139 E.03141
G3 X60.507 Y115.466 I10.209 J2.86 E.41633
G1 X61.47 Y115.4 E.03202
G3 X51.277 Y124.121 I.241 J10.599 E1.72796
M204 S250
G1 X51.669 Y124.151 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X51.67 Y124.151 E.00002
G3 X60.551 Y115.856 I10.041 J1.848 E.39995
G1 X61.479 Y115.792 E.02856
G3 X51.544 Y125.072 I.232 J10.207 E1.51401
G1 X51.661 Y124.211 E.0267
; WIPE_START
M204 S10000
G1 X51.67 Y124.151 E-.02296
G1 X51.879 Y123.245 E-.35324
G1 X52.171 Y122.363 E-.35313
G1 X52.203 Y122.289 E-.03067
; WIPE_END
G1 E-.04 F1800
G1 X59.734 Y121.053 Z5.2 F30000
G1 X223.513 Y94.186 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X223.53 Y94.217 E.00117
G2 X227.227 Y94.688 I1.97 J-.717 E.15229
G1 X227.398 Y94.742 E.00594
G1 X227.398 Y160.398 E2.17792
G1 X28.602 Y160.398 E6.59442
G1 X28.602 Y94.742 E2.17792
G1 X28.773 Y94.688 E.00594
G2 X31.688 Y91.773 I1.727 J-1.188 E.24389
G1 X31.742 Y91.602 E.00594
G1 X224.258 Y91.602 E6.3861
G1 X224.312 Y91.773 E.00594
G2 X223.435 Y93.864 I1.188 J1.727 E.07947
G1 X223.499 Y94.127 E.00899
M204 S250
G1 X223.892 Y94.084 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X223.827 Y93.795 E.00911
G3 X225.237 Y91.812 I1.681 J-.297 E.08321
G3 X225.797 Y91.815 I.272 J1.589 E.0173
G3 X223.921 Y94.126 I-.289 J1.683 E.21851
; WIPE_START
M204 S10000
G1 X223.827 Y93.795 E-.13075
G1 X223.789 Y93.5 E-.11302
G1 X223.815 Y93.203 E-.11331
G1 X223.892 Y92.915 E-.11331
G1 X224.018 Y92.645 E-.11333
G1 X224.189 Y92.4 E-.11334
G1 X224.307 Y92.283 E-.06294
; WIPE_END
G1 E-.04 F1800
G1 X226.688 Y91.773 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X226.742 Y91.602 E.00594
G1 X227.398 Y91.602 E.02176
G1 X227.398 Y92.258 E.02176
G1 X227.227 Y92.312 E.00594
G2 X226.737 Y91.808 I-1.73 J1.192 E.02343
; WIPE_START
G1 X226.742 Y91.602 E-.07812
G1 X227.398 Y91.602 E-.24922
G1 X227.398 Y92.258 E-.24922
G1 X227.227 Y92.312 E-.06805
G1 X227.112 Y92.147 E-.07627
G1 X227.039 Y92.075 E-.03912
; WIPE_END
G1 E-.04 F1800
G1 X219.407 Y92.153 Z5.2 F30000
G1 X32.106 Y94.088 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X31.984 Y94.357 E.00909
G3 X30.237 Y91.812 I-1.476 J-.859 E.21119
G3 X30.797 Y91.815 I.272 J1.589 E.0173
G3 X32.129 Y94.034 I-.289 J1.683 E.09023
; WIPE_START
M204 S10000
G1 X31.984 Y94.357 E-.13451
G1 X31.811 Y94.6 E-.11339
G1 X31.6 Y94.811 E-.11333
G1 X31.355 Y94.982 E-.11332
G1 X31.085 Y95.108 E-.11332
G1 X30.797 Y95.185 E-.11331
G1 X30.643 Y95.198 E-.05882
; WIPE_END
G1 E-.04 F1800
G1 X29.312 Y91.773 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X28.773 Y92.312 I1.192 J1.73 E.02542
G1 X28.602 Y92.258 E.00594
G1 X28.602 Y91.602 E.02176
G1 X29.258 Y91.602 E.02176
G1 X29.294 Y91.716 E.00395
; WIPE_START
G1 X29.147 Y91.888 E-.08592
G1 X28.888 Y92.147 E-.13937
G1 X28.773 Y92.312 E-.07628
G1 X28.602 Y92.258 E-.06805
G1 X28.602 Y91.602 E-.24922
G1 X28.974 Y91.602 E-.14117
; WIPE_END
G1 E-.04 F1800
G1 X36.606 Y91.587 Z5.2 F30000
G1 X227.79 Y91.21 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
; WIPE_START
M204 S10000
G1 X227.732 Y93.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X226.531 Y91.619 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354373
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327686
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281525
G2 X225.841 Y91.514 I-.363 J2.116 E.00363
; LINE_WIDTH: 0.2443
G2 X225.14 Y91.516 I-.336 J5.789 E.0115
; LINE_WIDTH: 0.283928
G1 X224.974 Y91.537 E.00329
; LINE_WIDTH: 0.327696
G1 X224.808 Y91.559 E.00389
; LINE_WIDTH: 0.354364
G1 X224.469 Y91.619 E.00874
; WIPE_START
G1 X224.808 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y92.469 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
G1 F15000
G1 X227.441 Y92.808 E.00873
; LINE_WIDTH: 0.327691
G1 X227.463 Y92.974 E.00389
; LINE_WIDTH: 0.283913
G1 X227.484 Y93.14 E.00329
; LINE_WIDTH: 0.244295
G3 X227.486 Y93.841 I-5.787 J.364 E.0115
; LINE_WIDTH: 0.281523
G3 X227.463 Y94.026 I-2.14 J-.178 E.00363
; LINE_WIDTH: 0.327686
G1 X227.441 Y94.192 E.00389
; LINE_WIDTH: 0.354354
G1 X227.381 Y94.531 E.00873
; WIPE_START
G1 X227.441 Y94.192 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.329 Y101.824 Z5.2 F30000
G1 X226.471 Y160.234 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42058
G1 F15000
G1 X227.065 Y159.641 E.02584
G1 X227.065 Y159.106 E.01644
G1 X226.106 Y160.065 E.0417
G1 X225.572 Y160.065 E.01644
G1 X227.065 Y158.572 E.06495
G1 X227.065 Y158.038 E.01644
G1 X225.038 Y160.065 E.08819
G1 X224.504 Y160.065 E.01644
G1 X227.065 Y157.504 E.11144
G1 X227.065 Y156.97 E.01644
G1 X223.97 Y160.065 E.13468
G1 X223.436 Y160.065 E.01644
G1 X227.065 Y156.436 E.15793
G1 X227.065 Y155.902 E.01644
G1 X222.902 Y160.065 E.18117
G1 X222.368 Y160.065 E.01644
G1 X227.065 Y155.368 E.20442
G1 X227.065 Y154.834 E.01644
G1 X221.834 Y160.065 E.22766
G1 X221.3 Y160.065 E.01644
G1 X227.065 Y154.3 E.25091
G1 X227.065 Y153.766 E.01644
G1 X220.766 Y160.065 E.27415
G1 X220.231 Y160.065 E.01644
G1 X227.065 Y153.231 E.2974
G1 X227.065 Y152.697 E.01644
G1 X219.697 Y160.065 E.32064
G1 X219.163 Y160.065 E.01644
G1 X227.065 Y152.163 E.34388
G1 X227.065 Y151.629 E.01644
G1 X218.629 Y160.065 E.36713
G1 X218.095 Y160.065 E.01644
G1 X227.065 Y151.095 E.39037
G1 X227.065 Y150.561 E.01644
G1 X217.561 Y160.065 E.41362
G1 X217.027 Y160.065 E.01644
G1 X227.065 Y150.027 E.43686
G1 X227.065 Y149.493 E.01644
G1 X216.493 Y160.065 E.46011
G1 X215.959 Y160.065 E.01644
G1 X227.065 Y148.959 E.48335
G1 X227.065 Y148.425 E.01644
G1 X215.425 Y160.065 E.5066
G1 X214.891 Y160.065 E.01644
G1 X227.065 Y147.891 E.52984
G1 X227.065 Y147.356 E.01644
G1 X214.356 Y160.065 E.55309
G1 X213.822 Y160.065 E.01644
G1 X227.065 Y146.822 E.57633
G1 X227.065 Y146.288 E.01644
G1 X213.288 Y160.065 E.59957
G1 X212.754 Y160.065 E.01644
G1 X227.065 Y145.754 E.62282
G1 X227.065 Y145.22 E.01644
G1 X212.22 Y160.065 E.64606
G1 X211.686 Y160.065 E.01644
G1 X227.065 Y144.686 E.66931
G1 X227.065 Y144.152 E.01644
G1 X211.152 Y160.065 E.69255
G1 X210.618 Y160.065 E.01644
G1 X227.065 Y143.618 E.7158
G1 X227.065 Y143.084 E.01644
G1 X210.084 Y160.065 E.73904
G1 X209.55 Y160.065 E.01644
G1 X227.065 Y142.55 E.76229
G1 X227.065 Y142.015 E.01644
G1 X209.015 Y160.065 E.78553
G1 X208.481 Y160.065 E.01644
G1 X227.065 Y141.481 E.80878
G1 X227.065 Y140.947 E.01644
G1 X207.947 Y160.065 E.83202
G1 X207.413 Y160.065 E.01644
G1 X227.065 Y140.413 E.85527
G1 X227.065 Y139.879 E.01644
G1 X206.879 Y160.065 E.87851
G1 X206.345 Y160.065 E.01644
G1 X227.065 Y139.345 E.90175
G1 X227.065 Y138.811 E.01644
G1 X205.811 Y160.065 E.925
G1 X205.277 Y160.065 E.01644
G1 X227.065 Y138.277 E.94824
G1 X227.065 Y137.743 E.01644
G1 X204.743 Y160.065 E.97149
G1 X204.209 Y160.065 E.01644
G1 X227.065 Y137.209 E.99473
G1 X227.065 Y136.675 E.01644
G1 X203.675 Y160.065 E1.01798
G1 X203.14 Y160.065 E.01644
G1 X227.065 Y136.14 E1.04122
G1 X227.065 Y135.606 E.01644
G1 X202.606 Y160.065 E1.06447
G1 X202.072 Y160.065 E.01644
G1 X227.065 Y135.072 E1.08771
G1 X227.065 Y134.538 E.01644
G1 X201.538 Y160.065 E1.11096
G1 X201.004 Y160.065 E.01644
G1 X227.065 Y134.004 E1.1342
G1 X227.065 Y133.47 E.01644
G1 X200.47 Y160.065 E1.15745
G1 X199.936 Y160.065 E.01644
G1 X227.065 Y132.936 E1.18069
G1 X227.065 Y132.402 E.01644
G1 X199.402 Y160.065 E1.20393
M73 P86 R7
G1 X198.868 Y160.065 E.01644
G1 X227.065 Y131.868 E1.22718
G1 X227.065 Y131.334 E.01644
G1 X198.334 Y160.065 E1.25042
G1 X197.8 Y160.065 E.01644
G1 X227.065 Y130.8 E1.27367
G1 X227.065 Y130.265 E.01644
G1 X197.265 Y160.065 E1.29691
G1 X196.731 Y160.065 E.01644
G1 X227.065 Y129.731 E1.32016
G1 X227.065 Y129.197 E.01644
G1 X196.197 Y160.065 E1.3434
G1 X195.663 Y160.065 E.01644
G1 X227.065 Y128.663 E1.36665
G1 X227.065 Y128.129 E.01644
G1 X195.129 Y160.065 E1.38989
G1 X194.595 Y160.065 E.01644
G1 X227.065 Y127.595 E1.41314
G1 X227.065 Y127.061 E.01644
G1 X194.061 Y160.065 E1.43638
G1 X193.527 Y160.065 E.01644
G1 X227.065 Y126.527 E1.45962
G1 X227.065 Y125.993 E.01644
G1 X192.993 Y160.065 E1.48287
G1 X192.459 Y160.065 E.01644
G1 X227.065 Y125.459 E1.50611
G1 X227.065 Y124.925 E.01644
G1 X191.925 Y160.065 E1.52936
G1 X191.39 Y160.065 E.01644
G1 X227.065 Y124.39 E1.5526
G1 X227.065 Y123.856 E.01644
G1 X190.856 Y160.065 E1.57585
G1 X190.322 Y160.065 E.01644
G1 X227.065 Y123.322 E1.59909
G1 X227.065 Y122.788 E.01644
G1 X189.788 Y160.065 E1.62234
G1 X189.254 Y160.065 E.01644
G1 X227.065 Y122.254 E1.64558
G1 X227.065 Y121.72 E.01644
G1 X188.72 Y160.065 E1.66883
G1 X188.186 Y160.065 E.01644
G1 X227.065 Y121.186 E1.69207
G1 X227.065 Y120.652 E.01644
G1 X187.652 Y160.065 E1.71532
G1 X187.118 Y160.065 E.01644
G1 X227.065 Y120.118 E1.73856
G1 X227.065 Y119.584 E.01644
G1 X186.584 Y160.065 E1.7618
G1 X186.05 Y160.065 E.01644
G1 X227.065 Y119.05 E1.78505
G1 X227.065 Y118.515 E.01644
G1 X185.515 Y160.065 E1.80829
G1 X184.981 Y160.065 E.01644
G1 X227.065 Y117.981 E1.83154
G1 X227.065 Y117.447 E.01644
G1 X184.447 Y160.065 E1.85478
G1 X183.913 Y160.065 E.01644
G1 X227.065 Y116.913 E1.87803
G1 X227.065 Y116.379 E.01644
G1 X183.379 Y160.065 E1.90127
G1 X182.845 Y160.065 E.01644
G1 X227.065 Y115.845 E1.92452
G1 X227.065 Y115.311 E.01644
G1 X182.311 Y160.065 E1.94776
G1 X181.777 Y160.065 E.01644
G1 X227.065 Y114.777 E1.97101
G1 X227.065 Y114.243 E.01644
G1 X181.243 Y160.065 E1.99425
G1 X180.709 Y160.065 E.01644
G1 X227.065 Y113.709 E2.0175
G1 X227.065 Y113.175 E.01644
G1 X180.175 Y160.065 E2.04074
G1 X179.64 Y160.065 E.01644
G1 X227.065 Y112.64 E2.06398
G1 X227.065 Y112.106 E.01644
G1 X179.106 Y160.065 E2.08723
G1 X178.572 Y160.065 E.01644
G1 X227.065 Y111.572 E2.11047
G1 X227.065 Y111.038 E.01644
G1 X178.038 Y160.065 E2.13372
G1 X177.504 Y160.065 E.01644
G1 X227.065 Y110.504 E2.15696
G1 X227.065 Y109.97 E.01644
G1 X176.97 Y160.065 E2.18021
G1 X176.436 Y160.065 E.01644
G1 X227.065 Y109.436 E2.20345
G1 X227.065 Y108.902 E.01644
G1 X175.902 Y160.065 E2.2267
G1 X175.368 Y160.065 E.01644
G1 X227.065 Y108.368 E2.24994
G1 X227.065 Y107.834 E.01644
G1 X174.834 Y160.065 E2.27319
G1 X174.3 Y160.065 E.01644
G1 X227.065 Y107.3 E2.29643
G1 X227.065 Y106.765 E.01644
G1 X173.765 Y160.065 E2.31967
G1 X173.231 Y160.065 E.01644
G1 X227.065 Y106.231 E2.34292
G1 X227.065 Y105.697 E.01644
G1 X172.697 Y160.065 E2.36616
G1 X172.163 Y160.065 E.01644
G1 X227.065 Y105.163 E2.38941
G1 X227.065 Y104.629 E.01644
G1 X171.629 Y160.065 E2.41265
M73 P86 R6
G1 X171.095 Y160.065 E.01644
G1 X227.065 Y104.095 E2.4359
G1 X227.065 Y103.561 E.01644
G1 X170.561 Y160.065 E2.45914
G1 X170.027 Y160.065 E.01644
G1 X227.065 Y103.027 E2.48239
G1 X227.065 Y102.493 E.01644
G1 X169.493 Y160.065 E2.50563
G1 X168.959 Y160.065 E.01644
G1 X227.065 Y101.959 E2.52888
G1 X227.065 Y101.425 E.01644
G1 X168.425 Y160.065 E2.55212
G1 X167.89 Y160.065 E.01644
G1 X227.065 Y100.89 E2.57537
G1 X227.065 Y100.356 E.01644
G1 X167.356 Y160.065 E2.59861
G1 X166.822 Y160.065 E.01644
G1 X227.065 Y99.822 E2.62185
G1 X227.065 Y99.288 E.01644
G1 X166.288 Y160.065 E2.6451
G1 X165.754 Y160.065 E.01644
G1 X227.065 Y98.754 E2.66834
G1 X227.065 Y98.22 E.01644
G1 X165.22 Y160.065 E2.69159
G1 X164.686 Y160.065 E.01644
G1 X227.065 Y97.686 E2.71483
G1 X227.065 Y97.152 E.01644
G1 X164.152 Y160.065 E2.73808
G1 X163.618 Y160.065 E.01644
G1 X227.065 Y96.618 E2.76132
G1 X227.065 Y96.084 E.01644
G1 X163.084 Y160.065 E2.78457
G1 X162.549 Y160.065 E.01644
G1 X227.065 Y95.55 E2.80781
G1 X227.065 Y95.37 E.00551
G3 X226.271 Y95.809 I-1.782 J-2.289 E.028
G1 X162.015 Y160.065 E2.79654
G1 X161.481 Y160.065 E.01644
G1 X225.617 Y95.929 E2.79131
G1 X225.5 Y95.939 E.00363
G1 X225.107 Y95.905 E.01213
G1 X160.947 Y160.065 E2.79236
G1 X160.413 Y160.065 E.01644
G1 X224.682 Y95.796 E2.79708
G1 X224.315 Y95.628 E.0124
G1 X159.879 Y160.065 E2.80438
G1 X159.345 Y160.065 E.01644
G1 X223.996 Y95.413 E2.81374
G3 X223.72 Y95.156 I.592 J-.914 E.01169
G1 X158.811 Y160.065 E2.82495
G1 X158.277 Y160.065 E.01644
G1 X223.484 Y94.857 E2.83794
G3 X223.292 Y94.515 I.874 J-.714 E.01214
G1 X157.743 Y160.065 E2.85284
G1 X157.209 Y160.065 E.01644
G1 X223.151 Y94.122 E2.86994
G3 X223.075 Y93.664 I1.262 J-.445 E.01436
G1 X156.674 Y160.065 E2.88988
G1 X156.14 Y160.065 E.01644
G1 X223.095 Y93.11 E2.91399
G1 X223.098 Y93.077 E.00103
G3 X223.386 Y92.285 I2.387 J.42 E.02603
G1 X155.606 Y160.065 E2.94987
G1 X155.072 Y160.065 E.01644
G1 X223.202 Y91.935 E2.96511
G1 X222.667 Y91.935 E.01644
G1 X154.538 Y160.065 E2.96511
G1 X154.004 Y160.065 E.01644
G1 X222.133 Y91.935 E2.96511
G1 X221.599 Y91.935 E.01644
G1 X153.47 Y160.065 E2.96511
G1 X152.936 Y160.065 E.01644
G1 X221.065 Y91.935 E2.96511
G1 X220.531 Y91.935 E.01644
G1 X152.402 Y160.065 E2.96511
G1 X151.868 Y160.065 E.01644
G1 X219.997 Y91.935 E2.96511
G1 X219.463 Y91.935 E.01644
G1 X151.334 Y160.065 E2.96511
G1 X150.799 Y160.065 E.01644
G1 X218.929 Y91.935 E2.96511
G1 X218.395 Y91.935 E.01644
G1 X150.265 Y160.065 E2.96511
G1 X149.731 Y160.065 E.01644
G1 X217.861 Y91.935 E2.96511
G1 X217.327 Y91.935 E.01644
G1 X149.197 Y160.065 E2.96511
G1 X148.663 Y160.065 E.01644
G1 X216.792 Y91.935 E2.96511
G1 X216.258 Y91.935 E.01644
G1 X148.129 Y160.065 E2.96511
G1 X147.595 Y160.065 E.01644
G1 X215.724 Y91.935 E2.96511
G1 X215.19 Y91.935 E.01644
G1 X147.061 Y160.065 E2.96511
G1 X146.527 Y160.065 E.01644
G1 X214.656 Y91.935 E2.96511
G1 X214.122 Y91.935 E.01644
G1 X145.993 Y160.065 E2.96511
G1 X145.459 Y160.065 E.01644
G1 X213.588 Y91.935 E2.96511
G1 X213.054 Y91.935 E.01644
G1 X144.924 Y160.065 E2.96511
G1 X144.39 Y160.065 E.01644
G1 X212.52 Y91.935 E2.96511
G1 X211.986 Y91.935 E.01644
G1 X143.856 Y160.065 E2.96511
G1 X143.322 Y160.065 E.01644
G1 X211.452 Y91.935 E2.96511
G1 X210.917 Y91.935 E.01644
G1 X142.788 Y160.065 E2.96511
G1 X142.254 Y160.065 E.01644
G1 X210.383 Y91.935 E2.96511
G1 X209.849 Y91.935 E.01644
G1 X141.72 Y160.065 E2.96511
G1 X141.186 Y160.065 E.01644
G1 X209.315 Y91.935 E2.96511
G1 X208.781 Y91.935 E.01644
G1 X140.652 Y160.065 E2.96511
M73 P87 R6
G1 X140.118 Y160.065 E.01644
G1 X208.247 Y91.935 E2.96511
G1 X207.713 Y91.935 E.01644
G1 X139.584 Y160.065 E2.96511
G1 X139.049 Y160.065 E.01644
G1 X207.179 Y91.935 E2.96511
G1 X206.645 Y91.935 E.01644
G1 X138.515 Y160.065 E2.96511
G1 X137.981 Y160.065 E.01644
G1 X206.111 Y91.935 E2.96511
G1 X205.577 Y91.935 E.01644
G1 X137.447 Y160.065 E2.96511
G1 X136.913 Y160.065 E.01644
G1 X205.042 Y91.935 E2.96511
G1 X204.508 Y91.935 E.01644
G1 X136.379 Y160.065 E2.96511
G1 X135.845 Y160.065 E.01644
G1 X203.974 Y91.935 E2.96511
G1 X203.44 Y91.935 E.01644
G1 X135.311 Y160.065 E2.96511
G1 X134.777 Y160.065 E.01644
G1 X202.906 Y91.935 E2.96511
G1 X202.372 Y91.935 E.01644
G1 X134.243 Y160.065 E2.96511
G1 X133.709 Y160.065 E.01644
G1 X201.838 Y91.935 E2.96511
G1 X201.304 Y91.935 E.01644
G1 X133.174 Y160.065 E2.96511
G1 X132.64 Y160.065 E.01644
G1 X200.77 Y91.935 E2.96511
G1 X200.236 Y91.935 E.01644
G1 X132.106 Y160.065 E2.96511
G1 X131.572 Y160.065 E.01644
G1 X199.702 Y91.935 E2.96511
G1 X199.167 Y91.935 E.01644
G1 X131.038 Y160.065 E2.96511
G1 X130.504 Y160.065 E.01644
G1 X198.633 Y91.935 E2.96511
G1 X198.099 Y91.935 E.01644
G1 X129.97 Y160.065 E2.96511
G1 X129.436 Y160.065 E.01644
G1 X197.565 Y91.935 E2.96511
G1 X197.031 Y91.935 E.01644
G1 X128.902 Y160.065 E2.96511
G1 X128.368 Y160.065 E.01644
G1 X196.497 Y91.935 E2.96511
G1 X195.963 Y91.935 E.01644
G1 X127.834 Y160.065 E2.96511
G1 X127.299 Y160.065 E.01644
G1 X195.429 Y91.935 E2.96511
G1 X194.895 Y91.935 E.01644
G1 X126.765 Y160.065 E2.96511
G1 X126.231 Y160.065 E.01644
G1 X194.361 Y91.935 E2.96511
G1 X193.827 Y91.935 E.01644
G1 X125.697 Y160.065 E2.96511
G1 X125.163 Y160.065 E.01644
G1 X193.292 Y91.935 E2.96511
G1 X192.758 Y91.935 E.01644
G1 X124.629 Y160.065 E2.96511
G1 X124.095 Y160.065 E.01644
G1 X192.224 Y91.935 E2.96511
G1 X191.69 Y91.935 E.01644
G1 X123.561 Y160.065 E2.96511
G1 X123.027 Y160.065 E.01644
G1 X191.156 Y91.935 E2.96511
G1 X190.622 Y91.935 E.01644
G1 X122.493 Y160.065 E2.96511
G1 X121.958 Y160.065 E.01644
G1 X190.088 Y91.935 E2.96511
G1 X189.554 Y91.935 E.01644
G1 X121.424 Y160.065 E2.96511
G1 X120.89 Y160.065 E.01644
G1 X189.02 Y91.935 E2.96511
G1 X188.486 Y91.935 E.01644
G1 X120.356 Y160.065 E2.96511
G1 X119.822 Y160.065 E.01644
G1 X187.952 Y91.935 E2.96511
G1 X187.417 Y91.935 E.01644
G1 X119.288 Y160.065 E2.96511
G1 X118.754 Y160.065 E.01644
G1 X186.883 Y91.935 E2.96511
G1 X186.349 Y91.935 E.01644
G1 X118.22 Y160.065 E2.96511
G1 X117.686 Y160.065 E.01644
G1 X185.815 Y91.935 E2.96511
G1 X185.281 Y91.935 E.01644
G1 X117.152 Y160.065 E2.96511
G1 X116.618 Y160.065 E.01644
G1 X184.747 Y91.935 E2.96511
G1 X184.213 Y91.935 E.01644
G1 X116.083 Y160.065 E2.96511
G1 X115.549 Y160.065 E.01644
G1 X183.679 Y91.935 E2.96511
G1 X183.145 Y91.935 E.01644
G1 X115.015 Y160.065 E2.96511
G1 X114.481 Y160.065 E.01644
G1 X182.611 Y91.935 E2.96511
G1 X182.077 Y91.935 E.01644
G1 X113.947 Y160.065 E2.96511
G1 X113.413 Y160.065 E.01644
G1 X181.542 Y91.935 E2.96511
G1 X181.008 Y91.935 E.01644
G1 X112.879 Y160.065 E2.96511
G1 X112.345 Y160.065 E.01644
G1 X180.474 Y91.935 E2.96511
G1 X179.94 Y91.935 E.01644
G1 X111.811 Y160.065 E2.96511
G1 X111.277 Y160.065 E.01644
G1 X179.406 Y91.935 E2.96511
G1 X178.872 Y91.935 E.01644
G1 X110.743 Y160.065 E2.96511
G1 X110.208 Y160.065 E.01644
G1 X178.338 Y91.935 E2.96511
G1 X177.804 Y91.935 E.01644
G1 X109.674 Y160.065 E2.96511
G1 X109.14 Y160.065 E.01644
G1 X177.27 Y91.935 E2.96511
G1 X176.736 Y91.935 E.01644
G1 X108.606 Y160.065 E2.96511
G1 X108.072 Y160.065 E.01644
G1 X176.201 Y91.935 E2.96511
G1 X175.667 Y91.935 E.01644
G1 X107.538 Y160.065 E2.96511
G1 X107.004 Y160.065 E.01644
G1 X175.133 Y91.935 E2.96511
G1 X174.599 Y91.935 E.01644
G1 X106.47 Y160.065 E2.96511
G1 X105.936 Y160.065 E.01644
G1 X174.065 Y91.935 E2.96511
G1 X173.531 Y91.935 E.01644
G1 X105.402 Y160.065 E2.96511
G1 X104.868 Y160.065 E.01644
G1 X172.997 Y91.935 E2.96511
G1 X172.463 Y91.935 E.01644
G1 X104.333 Y160.065 E2.96511
G1 X103.799 Y160.065 E.01644
G1 X171.929 Y91.935 E2.96511
G1 X171.395 Y91.935 E.01644
G1 X103.265 Y160.065 E2.96511
G1 X102.731 Y160.065 E.01644
G1 X170.861 Y91.935 E2.96511
G1 X170.326 Y91.935 E.01644
G1 X102.197 Y160.065 E2.96511
G1 X101.663 Y160.065 E.01644
G1 X169.792 Y91.935 E2.96511
M73 P88 R6
G1 X169.258 Y91.935 E.01644
G1 X101.129 Y160.065 E2.96511
G1 X100.595 Y160.065 E.01644
G1 X168.724 Y91.935 E2.96511
G1 X168.19 Y91.935 E.01644
G1 X100.061 Y160.065 E2.96511
G1 X99.527 Y160.065 E.01644
G1 X167.656 Y91.935 E2.96511
G1 X167.122 Y91.935 E.01644
G1 X98.993 Y160.065 E2.96511
G1 X98.458 Y160.065 E.01644
G1 X166.588 Y91.935 E2.96511
G1 X166.054 Y91.935 E.01644
G1 X97.924 Y160.065 E2.96511
G1 X97.39 Y160.065 E.01644
G1 X165.52 Y91.935 E2.96511
G1 X164.986 Y91.935 E.01644
G1 X96.856 Y160.065 E2.96511
G1 X96.322 Y160.065 E.01644
G1 X164.451 Y91.935 E2.96511
G1 X163.917 Y91.935 E.01644
G1 X95.788 Y160.065 E2.96511
G1 X95.254 Y160.065 E.01644
G1 X163.383 Y91.935 E2.96511
G1 X162.849 Y91.935 E.01644
G1 X94.72 Y160.065 E2.96511
G1 X94.186 Y160.065 E.01644
G1 X162.315 Y91.935 E2.96511
G1 X161.781 Y91.935 E.01644
G1 X93.652 Y160.065 E2.96511
G1 X93.118 Y160.065 E.01644
G1 X161.247 Y91.935 E2.96511
G1 X160.713 Y91.935 E.01644
G1 X92.583 Y160.065 E2.96511
G1 X92.049 Y160.065 E.01644
G1 X110.179 Y141.935 E.78902
G1 X109.645 Y141.935 E.01644
G1 X91.515 Y160.065 E.78902
G1 X90.981 Y160.065 E.01644
G1 X109.111 Y141.935 E.78902
M73 P88 R5
G1 X108.576 Y141.935 E.01644
G1 X90.447 Y160.065 E.78902
G1 X89.913 Y160.065 E.01644
G1 X108.042 Y141.935 E.78902
G1 X107.508 Y141.935 E.01644
G1 X89.379 Y160.065 E.78902
G1 X88.845 Y160.065 E.01644
G1 X106.974 Y141.935 E.78902
G1 X106.44 Y141.935 E.01644
G1 X88.311 Y160.065 E.78902
G1 X87.777 Y160.065 E.01644
G1 X105.906 Y141.935 E.78902
G1 X105.372 Y141.935 E.01644
G1 X87.243 Y160.065 E.78902
G1 X86.708 Y160.065 E.01644
G1 X104.838 Y141.935 E.78902
G1 X104.304 Y141.935 E.01644
G1 X86.174 Y160.065 E.78902
G1 X85.64 Y160.065 E.01644
G1 X103.77 Y141.935 E.78902
G1 X103.236 Y141.935 E.01644
G1 X85.106 Y160.065 E.78902
G1 X84.572 Y160.065 E.01644
G1 X102.701 Y141.935 E.78902
G1 X102.167 Y141.935 E.01644
G1 X84.038 Y160.065 E.78902
G1 X83.504 Y160.065 E.01644
G1 X101.633 Y141.935 E.78902
G1 X101.099 Y141.935 E.01644
G1 X82.97 Y160.065 E.78902
G1 X82.436 Y160.065 E.01644
G1 X100.565 Y141.935 E.78902
G1 X100.031 Y141.935 E.01644
G1 X81.902 Y160.065 E.78902
G1 X81.368 Y160.065 E.01644
G1 X99.497 Y141.935 E.78902
G1 X99.065 Y141.935 E.0133
G1 X99.065 Y141.833 E.00314
G1 X80.833 Y160.065 E.79346
G1 X80.299 Y160.065 E.01644
G1 X99.065 Y141.299 E.8167
G1 X99.065 Y140.765 E.01644
G1 X79.765 Y160.065 E.83994
G1 X79.231 Y160.065 E.01644
G1 X99.065 Y140.231 E.86319
G1 X99.065 Y139.697 E.01644
G1 X78.697 Y160.065 E.88643
G1 X78.163 Y160.065 E.01644
G1 X99.065 Y139.163 E.90968
G1 X99.065 Y138.629 E.01644
G1 X77.629 Y160.065 E.93292
G1 X77.095 Y160.065 E.01644
G1 X99.065 Y138.095 E.95617
G1 X99.065 Y137.561 E.01644
G1 X76.561 Y160.065 E.97941
G1 X76.027 Y160.065 E.01644
G1 X99.065 Y137.027 E1.00266
G1 X99.065 Y136.493 E.01644
G1 X75.492 Y160.065 E1.0259
G1 X74.958 Y160.065 E.01644
G1 X99.065 Y135.958 E1.04915
G1 X99.065 Y135.424 E.01644
G1 X74.424 Y160.065 E1.07239
G1 X73.89 Y160.065 E.01644
G1 X99.065 Y134.89 E1.09564
G1 X99.065 Y134.356 E.01644
G1 X73.356 Y160.065 E1.11888
G1 X72.822 Y160.065 E.01644
G1 X99.065 Y133.822 E1.14212
G1 X99.065 Y133.288 E.01644
G1 X72.288 Y160.065 E1.16537
G1 X71.754 Y160.065 E.01644
G1 X99.065 Y132.754 E1.18861
G1 X99.065 Y132.22 E.01644
G1 X71.22 Y160.065 E1.21186
G1 X70.686 Y160.065 E.01644
G1 X99.065 Y131.686 E1.2351
G1 X99.065 Y131.152 E.01644
G1 X70.152 Y160.065 E1.25835
G1 X69.617 Y160.065 E.01644
G1 X99.065 Y130.618 E1.28159
G1 X99.065 Y130.083 E.01644
G1 X69.083 Y160.065 E1.30484
G1 X68.549 Y160.065 E.01644
G1 X99.065 Y129.549 E1.32808
G1 X99.065 Y129.015 E.01644
G1 X68.015 Y160.065 E1.35133
G1 X67.481 Y160.065 E.01644
G1 X99.065 Y128.481 E1.37457
G1 X99.065 Y127.947 E.01644
G1 X66.947 Y160.065 E1.39781
G1 X66.413 Y160.065 E.01644
G1 X99.065 Y127.413 E1.42106
G1 X99.065 Y126.879 E.01644
G1 X65.879 Y160.065 E1.4443
G1 X65.345 Y160.065 E.01644
G1 X99.065 Y126.345 E1.46755
G1 X99.065 Y125.811 E.01644
G1 X64.811 Y160.065 E1.49079
G1 X64.277 Y160.065 E.01644
G1 X99.065 Y125.277 E1.51404
G1 X99.065 Y124.742 E.01644
G1 X63.742 Y160.065 E1.53728
G1 X63.208 Y160.065 E.01644
G1 X99.065 Y124.208 E1.56053
G1 X99.065 Y123.674 E.01644
G1 X62.674 Y160.065 E1.58377
G1 X62.14 Y160.065 E.01644
G1 X99.065 Y123.14 E1.60702
G1 X99.065 Y122.606 E.01644
G1 X61.606 Y160.065 E1.63026
G1 X61.072 Y160.065 E.01644
G1 X99.065 Y122.072 E1.65351
G1 X99.065 Y121.538 E.01644
G1 X60.538 Y160.065 E1.67675
G1 X60.004 Y160.065 E.01644
G1 X99.065 Y121.004 E1.69999
G1 X99.065 Y120.47 E.01644
G1 X59.47 Y160.065 E1.72324
G1 X58.936 Y160.065 E.01644
G1 X99.065 Y119.936 E1.74648
G1 X99.065 Y119.402 E.01644
G1 X58.402 Y160.065 E1.76973
G1 X57.867 Y160.065 E.01644
G1 X99.065 Y118.867 E1.79297
G1 X99.065 Y118.333 E.01644
G1 X57.333 Y160.065 E1.81622
G1 X56.799 Y160.065 E.01644
G1 X99.065 Y117.799 E1.83946
G1 X99.065 Y117.265 E.01644
G1 X56.265 Y160.065 E1.86271
G1 X55.731 Y160.065 E.01644
G1 X99.065 Y116.731 E1.88595
G1 X99.065 Y116.197 E.01644
G1 X55.197 Y160.065 E1.9092
G1 X54.663 Y160.065 E.01644
G1 X99.065 Y115.663 E1.93244
G1 X99.065 Y115.129 E.01644
G1 X54.129 Y160.065 E1.95569
G1 X53.595 Y160.065 E.01644
G1 X99.065 Y114.595 E1.97893
G1 X99.065 Y114.061 E.01644
G1 X53.061 Y160.065 E2.00217
G1 X52.527 Y160.065 E.01644
G1 X99.065 Y113.527 E2.02542
G1 X99.065 Y112.992 E.01644
G1 X51.992 Y160.065 E2.04866
G1 X51.458 Y160.065 E.01644
G1 X99.065 Y112.458 E2.07191
G1 X99.065 Y111.924 E.01644
G1 X50.924 Y160.065 E2.09515
G1 X50.39 Y160.065 E.01644
G1 X99.065 Y111.39 E2.1184
G1 X99.065 Y110.856 E.01644
G1 X49.856 Y160.065 E2.14164
G1 X49.322 Y160.065 E.01644
G1 X117.451 Y91.935 E2.96511
G1 X117.985 Y91.935 E.01644
G1 X99.856 Y110.065 E.78902
G1 X100.39 Y110.065 E.01644
G1 X118.52 Y91.935 E.78902
G1 X119.054 Y91.935 E.01644
G1 X100.924 Y110.065 E.78902
G1 X101.458 Y110.065 E.01644
G1 X119.588 Y91.935 E.78902
G1 X120.122 Y91.935 E.01644
G1 X101.992 Y110.065 E.78902
G1 X102.527 Y110.065 E.01644
G1 X120.656 Y91.935 E.78902
G1 X121.19 Y91.935 E.01644
G1 X103.061 Y110.065 E.78902
G1 X103.595 Y110.065 E.01644
G1 X121.724 Y91.935 E.78902
G1 X122.258 Y91.935 E.01644
G1 X104.129 Y110.065 E.78902
G1 X104.663 Y110.065 E.01644
G1 X122.792 Y91.935 E.78902
G1 X123.326 Y91.935 E.01644
G1 X105.197 Y110.065 E.78902
G1 X105.731 Y110.065 E.01644
G1 X123.86 Y91.935 E.78902
M73 P89 R5
G1 X124.395 Y91.935 E.01644
G1 X106.265 Y110.065 E.78902
G1 X106.799 Y110.065 E.01644
G1 X124.929 Y91.935 E.78902
G1 X125.463 Y91.935 E.01644
G1 X107.333 Y110.065 E.78902
G1 X107.867 Y110.065 E.01644
G1 X125.997 Y91.935 E.78902
G1 X126.531 Y91.935 E.01644
G1 X108.402 Y110.065 E.78902
G1 X108.936 Y110.065 E.01644
G1 X127.065 Y91.935 E.78902
G1 X127.599 Y91.935 E.01644
G1 X109.47 Y110.065 E.78902
G1 X110.004 Y110.065 E.01644
G1 X128.133 Y91.935 E.78902
G1 X128.667 Y91.935 E.01644
G1 X110.538 Y110.065 E.78902
G1 X110.935 Y110.065 E.01223
G1 X110.935 Y110.201 E.00421
G1 X129.201 Y91.935 E.79497
G1 X129.735 Y91.935 E.01644
G1 X110.935 Y110.735 E.81822
G1 X110.935 Y111.27 E.01644
G1 X130.27 Y91.935 E.84146
G1 X130.804 Y91.935 E.01644
G1 X110.935 Y111.804 E.86471
G1 X110.935 Y112.338 E.01644
G1 X131.338 Y91.935 E.88795
G1 X131.872 Y91.935 E.01644
G1 X110.935 Y112.872 E.91119
G1 X110.935 Y113.406 E.01644
G1 X132.406 Y91.935 E.93444
G1 X132.94 Y91.935 E.01644
G1 X110.935 Y113.94 E.95768
G1 X110.935 Y114.474 E.01644
G1 X133.474 Y91.935 E.98093
G1 X134.008 Y91.935 E.01644
G1 X110.935 Y115.008 E1.00417
G1 X110.935 Y115.542 E.01644
G1 X134.542 Y91.935 E1.02742
G1 X135.076 Y91.935 E.01644
G1 X110.935 Y116.076 E1.05066
G1 X110.935 Y116.61 E.01644
G1 X135.611 Y91.935 E1.07391
G1 X136.145 Y91.935 E.01644
G1 X110.935 Y117.145 E1.09715
G1 X110.935 Y117.679 E.01644
G1 X136.679 Y91.935 E1.1204
G1 X137.213 Y91.935 E.01644
G1 X110.935 Y118.213 E1.14364
G1 X110.935 Y118.747 E.01644
G1 X137.747 Y91.935 E1.16689
G1 X138.281 Y91.935 E.01644
G1 X110.935 Y119.281 E1.19013
G1 X110.935 Y119.815 E.01644
G1 X138.815 Y91.935 E1.21337
G1 X139.349 Y91.935 E.01644
G1 X110.935 Y120.349 E1.23662
G1 X110.935 Y120.883 E.01644
G1 X139.883 Y91.935 E1.25986
G1 X140.417 Y91.935 E.01644
G1 X110.935 Y121.417 E1.28311
G1 X110.935 Y121.951 E.01644
G1 X140.951 Y91.935 E1.30635
G1 X141.486 Y91.935 E.01644
G1 X110.935 Y122.486 E1.3296
G1 X110.935 Y123.02 E.01644
G1 X142.02 Y91.935 E1.35284
G1 X142.554 Y91.935 E.01644
G1 X110.935 Y123.554 E1.37609
G1 X110.935 Y124.088 E.01644
G1 X143.088 Y91.935 E1.39933
G1 X143.622 Y91.935 E.01644
G1 X110.935 Y124.622 E1.42258
G1 X110.935 Y125.156 E.01644
G1 X144.156 Y91.935 E1.44582
G1 X144.69 Y91.935 E.01644
G1 X110.935 Y125.69 E1.46907
G1 X110.935 Y126.224 E.01644
G1 X145.224 Y91.935 E1.49231
G1 X145.758 Y91.935 E.01644
G1 X110.935 Y126.758 E1.51555
G1 X110.935 Y127.292 E.01644
G1 X146.292 Y91.935 E1.5388
G1 X146.826 Y91.935 E.01644
G1 X110.935 Y127.826 E1.56204
G1 X110.935 Y128.361 E.01644
G1 X147.361 Y91.935 E1.58529
G1 X147.895 Y91.935 E.01644
G1 X110.935 Y128.895 E1.60853
G1 X110.935 Y129.429 E.01644
G1 X148.429 Y91.935 E1.63178
G1 X148.963 Y91.935 E.01644
G1 X110.935 Y129.963 E1.65502
G1 X110.935 Y130.497 E.01644
G1 X149.497 Y91.935 E1.67827
G1 X150.031 Y91.935 E.01644
G1 X110.935 Y131.031 E1.70151
G1 X110.935 Y131.565 E.01644
G1 X150.565 Y91.935 E1.72476
G1 X151.099 Y91.935 E.01644
G1 X110.935 Y132.099 E1.748
G1 X110.935 Y132.633 E.01644
G1 X151.633 Y91.935 E1.77124
G1 X152.167 Y91.935 E.01644
G1 X110.935 Y133.167 E1.79449
G1 X110.935 Y133.701 E.01644
G1 X152.701 Y91.935 E1.81773
G1 X153.236 Y91.935 E.01644
G1 X110.935 Y134.236 E1.84098
G1 X110.935 Y134.77 E.01644
G1 X153.77 Y91.935 E1.86422
G1 X154.304 Y91.935 E.01644
G1 X110.935 Y135.304 E1.88747
G1 X110.935 Y135.838 E.01644
G1 X154.838 Y91.935 E1.91071
G1 X155.372 Y91.935 E.01644
G1 X110.935 Y136.372 E1.93396
G1 X110.935 Y136.906 E.01644
G1 X155.906 Y91.935 E1.9572
G1 X156.44 Y91.935 E.01644
G1 X110.935 Y137.44 E1.98045
G1 X110.935 Y137.974 E.01644
G1 X156.974 Y91.935 E2.00369
G1 X157.508 Y91.935 E.01644
G1 X110.935 Y138.508 E2.02694
G1 X110.935 Y139.042 E.01644
G1 X158.042 Y91.935 E2.05018
G1 X158.576 Y91.935 E.01644
G1 X110.935 Y139.576 E2.07342
G1 X110.935 Y140.111 E.01644
G1 X159.111 Y91.935 E2.09667
G1 X159.645 Y91.935 E.01644
G1 X110.935 Y140.645 E2.11991
G1 X110.935 Y141.179 E.01644
G1 X160.348 Y91.766 E2.15054
G1 X110.678 Y91.766 F30000
G1 F15000
G1 X71.411 Y131.032 E1.70895
G2 X71.859 Y130.051 I-5.15 J-2.94 E.03324
G1 X109.974 Y91.935 E1.65885
G1 X109.44 Y91.935 E.01644
G1 X72.154 Y129.221 E1.62275
G1 X72.362 Y128.479 E.02371
G1 X108.906 Y91.935 E1.59045
G1 X108.372 Y91.935 E.01644
G1 X72.484 Y127.823 E1.56191
G2 X72.572 Y127.201 I-3.363 J-.792 E.01936
G1 X107.838 Y91.935 E1.53484
G1 X107.304 Y91.935 E.01644
G1 X72.625 Y126.614 E1.50926
G2 X72.636 Y126.069 I-2.979 J-.33 E.01679
G1 X106.77 Y91.935 E1.48555
G1 X106.235 Y91.935 E.01644
G1 X72.636 Y125.535 E1.46231
G2 X72.594 Y125.043 I-2.716 J-.016 E.01522
G1 X105.701 Y91.935 E1.44089
G1 X105.167 Y91.935 E.01644
G1 X72.549 Y124.553 E1.41959
G2 X72.47 Y124.099 I-2.529 J.21 E.01422
G1 X104.633 Y91.935 E1.39982
G1 X104.099 Y91.935 E.01644
G1 X72.386 Y123.648 E1.38019
G2 X72.278 Y123.222 I-2.384 J.379 E.01354
G1 X103.565 Y91.935 E1.36165
G1 X103.031 Y91.935 E.01644
G1 X72.161 Y122.805 E1.34349
G2 X72.031 Y122.401 I-2.277 J.513 E.01307
G1 X102.497 Y91.935 E1.32593
G1 X101.963 Y91.935 E.01644
G1 X71.883 Y122.015 E1.3091
G2 X71.735 Y121.629 I-2.19 J.622 E.01273
G1 X101.429 Y91.935 E1.29232
G1 X100.895 Y91.935 E.01644
G1 X71.559 Y121.27 E1.27671
G1 X71.384 Y120.912 E.01229
G1 X100.36 Y91.935 E1.26111
G1 X99.826 Y91.935 E.01644
G1 X71.194 Y120.568 E1.24613
G1 X70.992 Y120.236 E.01196
G1 X99.292 Y91.935 E1.23168
G1 X98.758 Y91.935 E.01644
G1 X70.79 Y119.903 E1.21722
G2 X70.563 Y119.596 I-1.812 J1.1 E.01177
G1 X98.224 Y91.935 E1.20385
G1 X97.69 Y91.935 E.01644
G1 X70.336 Y119.289 E1.1905
G2 X70.099 Y118.992 I-1.749 J1.147 E.01171
G1 X97.156 Y91.935 E1.17755
G1 X96.622 Y91.935 E.01644
G1 X69.848 Y118.71 E1.16526
G1 X69.596 Y118.427 E.01164
G1 X96.088 Y91.935 E1.15298
G1 X95.554 Y91.935 E.01644
G1 X69.326 Y118.163 E1.14148
G1 X69.05 Y117.905 E.01163
G1 X95.02 Y91.935 E1.13026
G1 X94.485 Y91.935 E.01644
G1 X68.771 Y117.65 E1.11915
G1 X68.47 Y117.417 E.01171
G1 X93.951 Y91.935 E1.10899
G1 X93.417 Y91.935 E.01644
G1 X68.169 Y117.183 E1.09883
G2 X67.856 Y116.962 I-1.366 J1.603 E.01181
G1 X92.883 Y91.935 E1.08921
G1 X92.349 Y91.935 E.01644
G1 X67.531 Y116.754 E1.08014
G1 X67.205 Y116.545 E.0119
G1 X91.815 Y91.935 E1.07107
G1 X91.281 Y91.935 E.01644
G1 X66.855 Y116.361 E1.06305
G1 X66.503 Y116.179 E.01219
G1 X90.747 Y91.935 E1.05512
G1 X90.213 Y91.935 E.01644
G1 X66.14 Y116.008 E1.04767
G1 X65.761 Y115.853 E.01261
G1 X89.679 Y91.935 E1.04094
G1 X89.144 Y91.935 E.01644
G1 X65.381 Y115.698 E1.03421
G2 X64.973 Y115.573 I-.891 J2.174 E.01317
G1 X88.61 Y91.935 E1.02875
G1 X88.076 Y91.935 E.01644
G1 X64.563 Y115.448 E1.02332
G2 X64.133 Y115.345 I-.781 J2.305 E.01365
G1 X87.542 Y91.935 E1.01883
G1 X87.008 Y91.935 E.01644
G1 X63.69 Y115.253 E1.01483
G2 X63.232 Y115.178 I-.642 J2.476 E.01433
G1 X86.474 Y91.935 E1.01155
G1 X85.94 Y91.935 E.01644
G1 X62.752 Y115.123 E1.00916
G2 X62.257 Y115.085 I-.458 J2.696 E.01532
G1 X85.406 Y91.935 E1.0075
G1 X84.872 Y91.935 E.01644
G1 X61.734 Y115.073 E1.00698
G2 X61.188 Y115.085 I-.205 J3 E.01685
G1 X84.338 Y91.935 E1.00753
G1 X83.804 Y91.935 E.01644
G1 X60.614 Y115.125 E1.00923
G2 X59.994 Y115.211 I.162 J3.443 E.0193
G1 X83.269 Y91.935 E1.01299
G1 X82.735 Y91.935 E.01644
G1 X59.341 Y115.329 E1.01815
G1 X58.624 Y115.513 E.0228
G1 X82.201 Y91.935 E1.02614
G1 X81.667 Y91.935 E.01644
G1 X57.811 Y115.792 E1.03827
G1 X57.583 Y115.873 E.00743
G1 X56.864 Y116.205 E.02439
G1 X81.133 Y91.935 E1.05625
G1 X80.599 Y91.935 E.01644
G1 X55.577 Y116.957 E1.08899
G2 X52.922 Y119.491 I5.959 J8.9 E.11352
G1 X52.675 Y119.86 E.01365
G1 X28.935 Y143.599 E1.03318
G1 X28.935 Y144.133 E.01644
G1 X51.902 Y121.166 E.99956
G1 X51.489 Y122.114 E.03181
G1 X28.935 Y144.667 E.98157
G1 X28.935 Y145.201 E.01644
G1 X51.226 Y122.911 E.97013
G2 X51.047 Y123.624 I3.816 J1.336 E.02265
G1 X28.935 Y145.735 E.96235
G1 X28.935 Y146.269 E.01644
G1 X50.919 Y124.286 E.95676
G1 X50.834 Y124.905 E.01923
G1 X28.935 Y146.804 E.95306
G1 X28.935 Y147.338 E.01644
G1 X50.799 Y125.474 E.95153
G2 X50.776 Y126.031 I3.04 J.402 E.01717
G1 X28.935 Y147.872 E.95055
G1 X28.935 Y148.406 E.01644
G1 X50.799 Y126.542 E.95156
G2 X50.827 Y127.048 I2.781 J.1 E.01562
G1 X28.935 Y148.94 E.95278
G1 X28.935 Y149.474 E.01644
G1 X50.892 Y127.518 E.95558
G2 X50.957 Y127.987 I2.594 J-.121 E.01459
G1 X28.935 Y150.008 E.95841
G1 X28.935 Y150.542 E.01644
G1 X51.057 Y128.42 E.96279
G1 X51.158 Y128.854 E.0137
G1 X28.935 Y151.076 E.96716
G1 X28.935 Y151.61 E.01644
G1 X51.283 Y129.263 E.97261
G1 X51.416 Y129.664 E.01301
G1 X28.935 Y152.144 E.97838
G1 X28.935 Y152.679 E.01644
G1 X51.56 Y130.053 E.98469
G1 X51.722 Y130.426 E.01249
G1 X28.935 Y153.213 E.99173
G1 X28.935 Y153.747 E.01644
G1 X51.884 Y130.798 E.99876
M73 P90 R5
G2 X52.072 Y131.144 I1.986 J-.856 E.01214
G1 X28.935 Y154.281 E1.00695
G1 X28.935 Y154.815 E.01644
G1 X52.261 Y131.489 E1.01518
G2 X52.461 Y131.823 I1.929 J-.93 E.012
G1 X28.935 Y155.349 E1.02389
G1 X28.935 Y155.883 E.01644
G1 X52.676 Y132.142 E1.03324
G1 X52.891 Y132.462 E.01184
G1 X28.935 Y156.417 E1.04258
G1 X28.935 Y156.951 E.01644
G1 X53.127 Y132.76 E1.05285
G1 X53.366 Y133.054 E.01168
G1 X28.935 Y157.485 E1.06328
G1 X28.935 Y158.019 E.01644
G1 X53.612 Y133.343 E1.07395
G1 X53.876 Y133.613 E.01162
G1 X28.935 Y158.554 E1.08544
G1 X28.935 Y159.088 E.01644
G1 X54.14 Y133.883 E1.09693
G2 X54.418 Y134.139 I1.537 J-1.396 E.01165
G1 X28.935 Y159.622 E1.10905
G1 X28.935 Y160.065 E.01363
G1 X29.026 Y160.065 E.00281
G1 X54.706 Y134.385 E1.11764
G1 X54.995 Y134.63 E.01166
G1 X29.561 Y160.065 E1.10694
G1 X30.095 Y160.065 E.01644
G1 X55.307 Y134.852 E1.09729
G1 X55.62 Y135.073 E.01179
G1 X30.629 Y160.065 E1.08767
G1 X31.163 Y160.065 E.01644
G1 X55.943 Y135.285 E1.07846
G1 X56.281 Y135.48 E.01203
G1 X31.697 Y160.065 E1.06996
G1 X32.231 Y160.065 E.01644
G1 X56.62 Y135.676 E1.06145
G2 X56.981 Y135.849 I1.13 J-1.888 E.01233
G1 X32.765 Y160.065 E1.0539
G1 X33.299 Y160.065 E.01644
G1 X57.346 Y136.018 E1.04656
G2 X57.721 Y136.177 I1.056 J-1.976 E.01256
G1 X33.833 Y160.065 E1.03965
G1 X34.367 Y160.065 E.01644
G1 X58.115 Y136.317 E1.03356
G1 X58.51 Y136.457 E.01287
G1 X34.902 Y160.065 E1.02746
G1 X35.436 Y160.065 E.01644
G1 X58.934 Y136.566 E1.02269
G1 X59.359 Y136.675 E.01351
G1 X35.97 Y160.065 E1.01795
G1 X36.504 Y160.065 E.01644
G1 X59.809 Y136.759 E1.01428
G1 X60.269 Y136.833 E.01434
G1 X37.038 Y160.065 E1.01106
G1 X37.572 Y160.065 E.01644
G1 X60.752 Y136.885 E1.00883
G1 X61.252 Y136.919 E.01542
G1 X38.106 Y160.065 E1.00734
G1 X38.64 Y160.065 E.01644
G1 X61.779 Y136.926 E1.00702
G1 X62.325 Y136.914 E.01682
G1 X39.174 Y160.065 E1.00757
G1 X39.708 Y160.065 E.01644
G1 X62.914 Y136.859 E1.00997
G2 X63.526 Y136.781 I-.118 J-3.384 E.01899
G1 X40.242 Y160.065 E1.01334
G1 X40.777 Y160.065 E.01644
G1 X64.2 Y136.641 E1.01944
G2 X64.938 Y136.438 I-.745 J-4.141 E.02358
G1 X41.311 Y160.065 E1.02829
G1 X41.845 Y160.065 E.01644
G1 X65.764 Y136.146 E1.04099
G2 X66.75 Y135.693 I-1.983 J-5.627 E.03344
G1 X42.379 Y160.065 E1.06068
G1 X42.913 Y160.065 E.01644
G1 X111.042 Y91.935 E2.96511
G1 X111.576 Y91.935 E.01644
G1 X43.447 Y160.065 E2.96511
G1 X43.981 Y160.065 E.01644
G1 X112.11 Y91.935 E2.96511
G1 X112.645 Y91.935 E.01644
G1 X44.515 Y160.065 E2.96511
G1 X45.049 Y160.065 E.01644
G1 X113.179 Y91.935 E2.96511
G1 X113.713 Y91.935 E.01644
G1 X45.583 Y160.065 E2.96511
G1 X46.117 Y160.065 E.01644
G1 X114.247 Y91.935 E2.96511
G1 X114.781 Y91.935 E.01644
M73 P90 R4
G1 X46.652 Y160.065 E2.96511
G1 X47.186 Y160.065 E.01644
G1 X115.315 Y91.935 E2.96511
G1 X115.849 Y91.935 E.01644
G1 X47.72 Y160.065 E2.96511
G1 X48.254 Y160.065 E.01644
G1 X116.383 Y91.935 E2.96511
G1 X116.917 Y91.935 E.01644
G1 X48.618 Y160.234 E2.97249
G1 X28.766 Y143.235 F30000
G1 F15000
G1 X80.065 Y91.935 E2.23263
G1 X79.531 Y91.935 E.01644
G1 X28.935 Y142.531 E2.202
G1 X28.935 Y141.997 E.01644
G1 X78.997 Y91.935 E2.17876
G1 X78.463 Y91.935 E.01644
G1 X28.935 Y141.463 E2.15552
G1 X28.935 Y140.929 E.01644
G1 X77.929 Y91.935 E2.13227
G1 X77.394 Y91.935 E.01644
G1 X28.935 Y140.394 E2.10903
G1 X28.935 Y139.86 E.01644
G1 X76.86 Y91.935 E2.08578
G1 X76.326 Y91.935 E.01644
G1 X28.935 Y139.326 E2.06254
G1 X28.935 Y138.792 E.01644
G1 X75.792 Y91.935 E2.03929
G1 X75.258 Y91.935 E.01644
G1 X28.935 Y138.258 E2.01605
G1 X28.935 Y137.724 E.01644
G1 X74.724 Y91.935 E1.9928
G1 X74.19 Y91.935 E.01644
G1 X28.935 Y137.19 E1.96956
G1 X28.935 Y136.656 E.01644
G1 X73.656 Y91.935 E1.94631
G1 X73.122 Y91.935 E.01644
G1 X28.935 Y136.122 E1.92307
G1 X28.935 Y135.588 E.01644
G1 X72.588 Y91.935 E1.89982
G1 X72.054 Y91.935 E.01644
G1 X28.935 Y135.054 E1.87658
G1 X28.935 Y134.519 E.01644
G1 X71.519 Y91.935 E1.85334
G1 X70.985 Y91.935 E.01644
G1 X28.935 Y133.985 E1.83009
G1 X28.935 Y133.451 E.01644
G1 X70.451 Y91.935 E1.80685
G1 X69.917 Y91.935 E.01644
G1 X28.935 Y132.917 E1.7836
G1 X28.935 Y132.383 E.01644
G1 X69.383 Y91.935 E1.76036
G1 X68.849 Y91.935 E.01644
G1 X28.935 Y131.849 E1.73711
G1 X28.935 Y131.315 E.01644
G1 X68.315 Y91.935 E1.71387
G1 X67.781 Y91.935 E.01644
G1 X28.935 Y130.781 E1.69062
G1 X28.935 Y130.247 E.01644
G1 X67.247 Y91.935 E1.66738
G1 X66.713 Y91.935 E.01644
G1 X28.935 Y129.713 E1.64413
G1 X28.935 Y129.179 E.01644
G1 X66.179 Y91.935 E1.62089
G1 X65.644 Y91.935 E.01644
G1 X28.935 Y128.644 E1.59764
G1 X28.935 Y128.11 E.01644
G1 X65.11 Y91.935 E1.5744
G1 X64.576 Y91.935 E.01644
G1 X28.935 Y127.576 E1.55116
G1 X28.935 Y127.042 E.01644
G1 X64.042 Y91.935 E1.52791
G1 X63.508 Y91.935 E.01644
G1 X28.935 Y126.508 E1.50467
G1 X28.935 Y125.974 E.01644
G1 X62.974 Y91.935 E1.48142
G1 X62.44 Y91.935 E.01644
G1 X28.935 Y125.44 E1.45818
G1 X28.935 Y124.906 E.01644
G1 X61.906 Y91.935 E1.43493
G1 X61.372 Y91.935 E.01644
G1 X28.935 Y124.372 E1.41169
G1 X28.935 Y123.838 E.01644
G1 X60.838 Y91.935 E1.38844
G1 X60.304 Y91.935 E.01644
G1 X28.935 Y123.304 E1.3652
G1 X28.935 Y122.769 E.01644
G1 X59.769 Y91.935 E1.34195
G1 X59.235 Y91.935 E.01644
G1 X28.935 Y122.235 E1.31871
G1 X28.935 Y121.701 E.01644
G1 X58.701 Y91.935 E1.29546
G1 X58.167 Y91.935 E.01644
G1 X28.935 Y121.167 E1.27222
G1 X28.935 Y120.633 E.01644
G1 X57.633 Y91.935 E1.24898
G1 X57.099 Y91.935 E.01644
G1 X28.935 Y120.099 E1.22573
G1 X28.935 Y119.565 E.01644
G1 X56.565 Y91.935 E1.20249
G1 X56.031 Y91.935 E.01644
G1 X28.935 Y119.031 E1.17924
G1 X28.935 Y118.497 E.01644
G1 X55.497 Y91.935 E1.156
G1 X54.963 Y91.935 E.01644
G1 X28.935 Y117.963 E1.13275
G1 X28.935 Y117.429 E.01644
G1 X54.429 Y91.935 E1.10951
G1 X53.894 Y91.935 E.01644
G1 X28.935 Y116.894 E1.08626
G1 X28.935 Y116.36 E.01644
G1 X53.36 Y91.935 E1.06302
G1 X52.826 Y91.935 E.01644
G1 X28.935 Y115.826 E1.03977
G1 X28.935 Y115.292 E.01644
G1 X52.292 Y91.935 E1.01653
G1 X51.758 Y91.935 E.01644
G1 X28.935 Y114.758 E.99329
G1 X28.935 Y114.224 E.01644
G1 X51.224 Y91.935 E.97004
G1 X50.69 Y91.935 E.01644
G1 X28.935 Y113.69 E.9468
G1 X28.935 Y113.156 E.01644
G1 X50.156 Y91.935 E.92355
G1 X49.622 Y91.935 E.01644
G1 X28.935 Y112.622 E.90031
G1 X28.935 Y112.088 E.01644
G1 X49.088 Y91.935 E.87706
G1 X48.554 Y91.935 E.01644
G1 X28.935 Y111.554 E.85382
G1 X28.935 Y111.019 E.01644
G1 X48.019 Y91.935 E.83057
G1 X47.485 Y91.935 E.01644
G1 X28.935 Y110.485 E.80733
G1 X28.935 Y109.951 E.01644
G1 X46.951 Y91.935 E.78408
G1 X46.417 Y91.935 E.01644
G1 X28.935 Y109.417 E.76084
G1 X28.935 Y108.883 E.01644
G1 X45.883 Y91.935 E.73759
G1 X45.349 Y91.935 E.01644
G1 X28.935 Y108.349 E.71435
G1 X28.935 Y107.815 E.01644
G1 X44.815 Y91.935 E.69111
G1 X44.281 Y91.935 E.01644
G1 X28.935 Y107.281 E.66786
G1 X28.935 Y106.747 E.01644
G1 X43.747 Y91.935 E.64462
G1 X43.213 Y91.935 E.01644
G1 X28.935 Y106.213 E.62137
G1 X28.935 Y105.679 E.01644
G1 X42.678 Y91.935 E.59813
G1 X42.144 Y91.935 E.01644
G1 X28.935 Y105.144 E.57488
G1 X28.935 Y104.61 E.01644
G1 X41.61 Y91.935 E.55164
G1 X41.076 Y91.935 E.01644
G1 X28.935 Y104.076 E.52839
G1 X28.935 Y103.542 E.01644
G1 X40.542 Y91.935 E.50515
G1 X40.008 Y91.935 E.01644
G1 X28.935 Y103.008 E.4819
G1 X28.935 Y102.474 E.01644
G1 X39.474 Y91.935 E.45866
G1 X38.94 Y91.935 E.01644
G1 X28.935 Y101.94 E.43542
G1 X28.935 Y101.406 E.01644
G1 X38.406 Y91.935 E.41217
G1 X37.872 Y91.935 E.01644
G1 X28.935 Y100.872 E.38893
G1 X28.935 Y100.338 E.01644
G1 X37.338 Y91.935 E.36568
G1 X36.803 Y91.935 E.01644
G1 X28.935 Y99.803 E.34244
G1 X28.935 Y99.269 E.01644
G1 X36.269 Y91.935 E.31919
G1 X35.735 Y91.935 E.01644
G1 X28.935 Y98.735 E.29595
G1 X28.935 Y98.201 E.01644
G1 X31.354 Y95.783 E.10526
G1 X31.334 Y95.792 E.00067
G3 X30.679 Y95.923 I-.701 J-1.794 E.02066
G1 X28.935 Y97.667 E.0759
G1 X28.935 Y97.133 E.01644
G1 X30.159 Y95.909 E.05327
G1 X29.726 Y95.808 E.01368
G1 X28.935 Y96.599 E.03442
G1 X28.935 Y96.065 E.01644
G1 X29.354 Y95.646 E.01821
G3 X29.03 Y95.436 I.433 J-1.024 E.01195
G1 X28.766 Y95.7 E.01149
; WIPE_START
G1 X29.03 Y95.436 E-.14187
G1 X29.354 Y95.646 E-.14676
G1 X28.935 Y96.065 E-.22492
G1 X28.935 Y96.599 E-.20295
G1 X29.016 Y96.518 E-.0435
; WIPE_END
M73 P91 R4
G1 E-.04 F1800
G1 X28.619 Y94.531 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354364
G1 F15000
G1 X28.559 Y94.192 E.00874
; LINE_WIDTH: 0.327696
G1 X28.537 Y94.026 E.00389
; LINE_WIDTH: 0.283928
G1 X28.516 Y93.86 E.00329
; LINE_WIDTH: 0.2443
G3 X28.514 Y93.159 I5.787 J-.364 E.0115
; LINE_WIDTH: 0.281525
G3 X28.537 Y92.974 I2.139 J.178 E.00363
; LINE_WIDTH: 0.327686
G1 X28.559 Y92.808 E.00389
; LINE_WIDTH: 0.354373
G1 X28.619 Y92.469 E.00874
G1 X29.469 Y91.619 F30000
; LINE_WIDTH: 0.354364
G1 F15000
G1 X29.808 Y91.559 E.00874
; LINE_WIDTH: 0.327696
G1 X29.974 Y91.537 E.00389
; LINE_WIDTH: 0.283928
G1 X30.14 Y91.516 E.00329
; LINE_WIDTH: 0.2443
G3 X30.841 Y91.514 I.364 J5.788 E.0115
; LINE_WIDTH: 0.281525
G3 X31.026 Y91.537 I-.178 J2.138 E.00363
; LINE_WIDTH: 0.327686
G1 X31.192 Y91.559 E.00389
; LINE_WIDTH: 0.354373
G1 X31.531 Y91.619 E.00874
G1 X32.315 Y92.151 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42058
G1 F15000
G1 X32.531 Y91.935 E.00941
G1 X33.065 Y91.935 E.01644
G1 X32.646 Y92.354 E.01821
G1 X32.808 Y92.726 E.01249
G1 X33.599 Y91.935 E.03442
G1 X34.133 Y91.935 E.01644
G1 X32.909 Y93.159 E.05327
G3 X32.923 Y93.679 I-1.465 J.3 E.01609
G1 X34.667 Y91.935 E.0759
G1 X35.201 Y91.935 E.01644
G1 X32.377 Y94.76 E.12292
; CHANGE_LAYER
; Z_HEIGHT: 5
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X33.791 Y93.345 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 25/25
; update layer progress
M73 L25
M991 S0 P24 ;notify layer change
G17
G3 Z5.2 I1.217 J0 P1  F30000
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END
; OBJECT_ID: 78
G1 X110.21 Y141.21
G1 Z5
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X99.79 Y141.21 E.32018
G1 X99.79 Y110.79 E.93472
G1 X110.21 Y110.79 E.32018
G1 X110.21 Y141.15 E.93288
; WIPE_START
M204 S10000
G1 X108.21 Y141.162 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.901 Y138.963 Z5.4 F30000
G1 X51.669 Y124.151 Z5.4
G1 Z5
G1 E.8 F1800
G1 F12000
M204 S5000
G1 X51.676 Y124.152 E.00019
G3 X60.57 Y115.855 I10.039 J1.845 E.40039
G3 X63.331 Y115.919 I1.115 J11.386 E.08508
G3 X51.549 Y125.072 I-1.617 J10.078 E1.45647
G1 X51.662 Y124.211 E.02669
; WIPE_START
M204 S10000
G1 X51.676 Y124.152 E-.02306
G1 X51.885 Y123.228 E-.36
G1 X52.171 Y122.363 E-.34618
G1 X52.203 Y122.288 E-.03076
; WIPE_END
G1 E-.04 F1800
G1 X47.773 Y116.073 Z5.4 F30000
G1 X32.106 Y94.088 Z5.4
G1 Z5
G1 E.8 F1800
G1 F12000
M204 S5000
G1 X31.976 Y94.359 E.00923
G3 X30.208 Y91.815 I-1.474 J-.862 E.21039
G1 X30.5 Y91.789 E.00899
G3 X32.124 Y94.031 I.002 J1.707 E.0992
; WIPE_START
M204 S10000
G1 X31.976 Y94.359 E-.13646
G1 X31.811 Y94.6 E-.11117
G1 X31.6 Y94.811 E-.11338
G1 X31.355 Y94.982 E-.11322
G1 X31.085 Y95.108 E-.11334
G1 X30.797 Y95.185 E-.11327
G1 X30.642 Y95.198 E-.05916
; WIPE_END
G1 E-.04 F1800
G1 X38.274 Y95.154 Z5.4 F30000
G1 X223.892 Y94.084 Z5.4
G1 Z5
G1 E.8 F1800
G1 F12000
M204 S5000
G1 X223.821 Y93.796 E.00911
G3 X225.208 Y91.815 I1.681 J-.299 E.08258
G1 X225.5 Y91.789 E.00899
G3 X223.918 Y94.133 I.002 J1.707 E.22729
; WIPE_START
M204 S10000
G1 X223.821 Y93.796 E-.13299
G1 X223.789 Y93.5 E-.11327
G1 X223.817 Y93.198 E-.11527
G1 X223.892 Y92.915 E-.1112
G1 X224.018 Y92.645 E-.11336
G1 X224.189 Y92.4 E-.11332
G1 X224.302 Y92.288 E-.06059
; WIPE_END
G1 E-.04 F1800
G1 X227.79 Y91.21 Z5.4 F30000
G1 Z5
G1 E.8 F1800
G1 F12000
M204 S5000
G1 X227.79 Y160.79 E2.138
G1 X28.21 Y160.79 E6.13254
G1 X28.21 Y91.21 E2.138
G1 X227.73 Y91.21 E6.13069
M204 S10000
G1 X226.998 Y91.417 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X227.583 Y92.002 E.02539
G1 X227.317 Y92.27
G1 X226.73 Y91.683 E.0255
M204 S10000
G1 X227.052 Y92.336 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.118454
G1 F15000
G1 X226.664 Y91.948 E.00337
G1 X226.531 Y91.619 F30000
; LINE_WIDTH: 0.354326
G1 F15000
G1 X226.192 Y91.559 E.00874
; LINE_WIDTH: 0.327644
G1 X226.026 Y91.537 E.00389
; LINE_WIDTH: 0.281497
G2 X225.84 Y91.514 I-.363 J2.116 E.00363
; LINE_WIDTH: 0.244159
G2 X225.147 Y91.515 I-.336 J5.72 E.01139
; LINE_WIDTH: 0.283361
G1 X224.978 Y91.537 E.00333
; LINE_WIDTH: 0.327241
G1 X224.809 Y91.559 E.00394
; LINE_WIDTH: 0.35403
G1 X224.469 Y91.619 E.00876
; WIPE_START
G1 X224.809 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.381 Y92.469 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.354384
G1 F15000
G1 X227.441 Y92.808 E.00874
; LINE_WIDTH: 0.327712
G1 X227.463 Y92.974 E.00389
; LINE_WIDTH: 0.283975
G1 X227.484 Y93.14 E.00329
; LINE_WIDTH: 0.244326
G3 X227.486 Y93.84 I-5.793 J.364 E.0115
; LINE_WIDTH: 0.281524
G3 X227.463 Y94.026 I-2.143 J-.178 E.00364
; LINE_WIDTH: 0.327763
G1 X227.441 Y94.193 E.0039
; LINE_WIDTH: 0.354616
G1 X227.381 Y94.531 E.00873
G1 X227.067 Y94.686 F30000
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X227.583 Y95.201 E.02239
G1 X227.583 Y95.734
G1 X226.776 Y94.928 E.03506
G1 X226.47 Y95.155
G1 X227.583 Y96.268 E.04836
G1 X227.583 Y96.801
G1 X226.1 Y95.318 E.06443
G1 X225.654 Y95.405
G1 X227.583 Y97.334 E.08381
G1 X227.583 Y97.868
G1 X225.082 Y95.367 E.10865
; WIPE_START
M204 S10000
G1 X226.496 Y96.781 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X224.313 Y91.932 Z5.4 F30000
G1 Z5
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X223.799 Y91.417 E.02236
G1 X223.266 Y91.417
G1 X224.072 Y92.224 E.03506
G1 X223.845 Y92.53
G1 X222.732 Y91.417 E.04837
G1 X222.199 Y91.417
G1 X223.682 Y92.9 E.06443
G1 X223.595 Y93.346
G1 X221.666 Y91.417 E.08383
G1 X221.132 Y91.417
G1 X223.633 Y93.918 E.10865
; WIPE_START
M204 S10000
G1 X222.219 Y92.504 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X220.599 Y91.417 Z5.4 F30000
G1 Z5
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X227.583 Y98.401 E.30346
G1 X227.583 Y98.934
G1 X220.066 Y91.417 E.32664
G1 X219.533 Y91.417
G1 X227.583 Y99.467 E.34981
G1 X227.583 Y100.001
G1 X218.999 Y91.417 E.37298
G1 X218.466 Y91.417
G1 X227.583 Y100.534 E.39615
G1 X227.583 Y101.067
G1 X217.933 Y91.417 E.41933
G1 X217.4 Y91.417
G1 X227.583 Y101.6 E.4425
G1 X227.583 Y102.134
G1 X216.866 Y91.417 E.46567
G1 X216.333 Y91.417
G1 X227.583 Y102.667 E.48884
G1 X227.583 Y103.2
G1 X215.8 Y91.417 E.51202
G1 X215.267 Y91.417
G1 X227.583 Y103.733 E.53519
G1 X227.583 Y104.267
G1 X214.733 Y91.417 E.55836
G1 X214.2 Y91.417
G1 X227.583 Y104.8 E.58153
G1 X227.583 Y105.333
G1 X213.667 Y91.417 E.60471
G1 X213.134 Y91.417
G1 X227.583 Y105.866 E.62788
G1 X227.583 Y106.4
G1 X212.6 Y91.417 E.65105
G1 X212.067 Y91.417
G1 X227.583 Y106.933 E.67422
G1 X227.583 Y107.466
G1 X211.534 Y91.417 E.6974
G1 X211.001 Y91.417
G1 X227.583 Y107.999 E.72057
G1 X227.583 Y108.533
G1 X210.467 Y91.417 E.74374
G1 X209.934 Y91.417
G1 X227.583 Y109.066 E.76692
G1 X227.583 Y109.599
G1 X209.401 Y91.417 E.79009
G1 X208.868 Y91.417
G1 X227.583 Y110.132 E.81326
G1 X227.583 Y110.666
G1 X208.334 Y91.417 E.83643
G1 X207.801 Y91.417
G1 X227.583 Y111.199 E.85961
G1 X227.583 Y111.732
G1 X207.268 Y91.417 E.88278
G1 X206.735 Y91.417
G1 X227.583 Y112.265 E.90595
G1 X227.583 Y112.799
G1 X206.201 Y91.417 E.92912
G1 X205.668 Y91.417
G1 X227.583 Y113.332 E.9523
G1 X227.583 Y113.865
G1 X205.135 Y91.417 E.97547
G1 X204.601 Y91.417
G1 X227.583 Y114.399 E.99864
G1 X227.583 Y114.932
G1 X204.068 Y91.417 E1.02181
G1 X203.535 Y91.417
G1 X227.583 Y115.465 E1.04499
G1 X227.583 Y115.998
G1 X203.002 Y91.417 E1.06816
G1 X202.468 Y91.417
G1 X227.583 Y116.532 E1.09133
G1 X227.583 Y117.065
G1 X201.935 Y91.417 E1.1145
G1 X201.402 Y91.417
G1 X227.583 Y117.598 E1.13768
G1 X227.583 Y118.131
G1 X200.869 Y91.417 E1.16085
G1 X200.335 Y91.417
G1 X227.583 Y118.665 E1.18402
G1 X227.583 Y119.198
G1 X199.802 Y91.417 E1.2072
G1 X199.269 Y91.417
G1 X227.583 Y119.731 E1.23037
G1 X227.583 Y120.264
G1 X198.736 Y91.417 E1.25354
G1 X198.202 Y91.417
G1 X227.583 Y120.798 E1.27671
G1 X227.583 Y121.331
G1 X197.669 Y91.417 E1.29989
G1 X197.136 Y91.417
G1 X227.583 Y121.864 E1.32306
G1 X227.583 Y122.397
G1 X196.603 Y91.417 E1.34623
G1 X196.069 Y91.417
G1 X227.583 Y122.931 E1.3694
G1 X227.583 Y123.464
G1 X195.536 Y91.417 E1.39258
G1 X195.003 Y91.417
G1 X227.583 Y123.997 E1.41575
G1 X227.583 Y124.53
G1 X194.47 Y91.417 E1.43892
G1 X193.936 Y91.417
G1 X227.583 Y125.064 E1.46209
G1 X227.583 Y125.597
G1 X193.403 Y91.417 E1.48527
G1 X192.87 Y91.417
G1 X227.583 Y126.13 E1.50844
G1 X227.583 Y126.663
G1 X192.337 Y91.417 E1.53161
G1 X191.803 Y91.417
G1 X227.583 Y127.197 E1.55478
G1 X227.583 Y127.73
G1 X191.27 Y91.417 E1.57796
G1 X190.737 Y91.417
G1 X227.583 Y128.263 E1.60113
G1 X227.583 Y128.796
G1 X190.204 Y91.417 E1.6243
G1 X189.67 Y91.417
G1 X227.583 Y129.33 E1.64747
G1 X227.583 Y129.863
G1 X189.137 Y91.417 E1.67065
G1 X188.604 Y91.417
G1 X227.583 Y130.396 E1.69382
G1 X227.583 Y130.929
G1 X188.071 Y91.417 E1.71699
G1 X187.537 Y91.417
G1 X227.583 Y131.463 E1.74017
G1 X227.583 Y131.996
G1 X187.004 Y91.417 E1.76334
G1 X186.471 Y91.417
G1 X227.583 Y132.529 E1.78651
G1 X227.583 Y133.063
G1 X185.937 Y91.417 E1.80968
G1 X185.404 Y91.417
G1 X227.583 Y133.596 E1.83286
G1 X227.583 Y134.129
G1 X184.871 Y91.417 E1.85603
G1 X184.338 Y91.417
G1 X227.583 Y134.662 E1.8792
G1 X227.583 Y135.196
G1 X183.804 Y91.417 E1.90237
G1 X183.271 Y91.417
G1 X227.583 Y135.729 E1.92555
G1 X227.583 Y136.262
G1 X182.738 Y91.417 E1.94872
G1 X182.205 Y91.417
G1 X227.583 Y136.795 E1.97189
G1 X227.583 Y137.329
G1 X181.671 Y91.417 E1.99506
G1 X181.138 Y91.417
G1 X227.583 Y137.862 E2.01824
G1 X227.583 Y138.395
G1 X180.605 Y91.417 E2.04141
G1 X180.072 Y91.417
G1 X227.583 Y138.928 E2.06458
G1 X227.583 Y139.462
G1 X179.538 Y91.417 E2.08775
G1 X179.005 Y91.417
G1 X227.583 Y139.995 E2.11093
G1 X227.583 Y140.528
G1 X178.472 Y91.417 E2.1341
G1 X177.939 Y91.417
G1 X227.583 Y141.061 E2.15727
G1 X227.583 Y141.595
G1 X177.405 Y91.417 E2.18044
G1 X176.872 Y91.417
G1 X227.583 Y142.128 E2.20362
G1 X227.583 Y142.661
G1 X176.339 Y91.417 E2.22679
G1 X175.806 Y91.417
G1 X227.583 Y143.194 E2.24996
G1 X227.583 Y143.728
G1 X175.272 Y91.417 E2.27314
G1 X174.739 Y91.417
G1 X227.583 Y144.261 E2.29631
G1 X227.583 Y144.794
G1 X174.206 Y91.417 E2.31948
G1 X173.673 Y91.417
G1 X227.583 Y145.327 E2.34265
G1 X227.583 Y145.861
G1 X173.139 Y91.417 E2.36583
G1 X172.606 Y91.417
G1 X227.583 Y146.394 E2.389
G1 X227.583 Y146.927
G1 X172.073 Y91.417 E2.41217
G1 X171.54 Y91.417
G1 X227.583 Y147.46 E2.43534
G1 X227.583 Y147.994
G1 X171.006 Y91.417 E2.45852
G1 X170.473 Y91.417
G1 X227.583 Y148.527 E2.48169
G1 X227.583 Y149.06
G1 X169.94 Y91.417 E2.50486
G1 X169.406 Y91.417
G1 X227.583 Y149.593 E2.52803
G1 X227.583 Y150.127
G1 X168.873 Y91.417 E2.55121
M73 P92 R4
G1 X168.34 Y91.417
G1 X227.583 Y150.66 E2.57438
G1 X227.583 Y151.193
G1 X167.807 Y91.417 E2.59755
G1 X167.273 Y91.417
G1 X227.583 Y151.727 E2.62072
G1 X227.583 Y152.26
G1 X166.74 Y91.417 E2.6439
G1 X166.207 Y91.417
G1 X227.583 Y152.793 E2.66707
G1 X227.583 Y153.326
G1 X165.674 Y91.417 E2.69024
G1 X165.14 Y91.417
G1 X227.583 Y153.86 E2.71342
G1 X227.583 Y154.393
G1 X164.607 Y91.417 E2.73659
G1 X164.074 Y91.417
G1 X227.583 Y154.926 E2.75976
G1 X227.583 Y155.459
G1 X163.541 Y91.417 E2.78293
G1 X163.007 Y91.417
G1 X227.583 Y155.993 E2.80611
G1 X227.583 Y156.526
G1 X162.474 Y91.417 E2.82928
G1 X161.941 Y91.417
G1 X227.583 Y157.059 E2.85245
M73 P92 R3
G1 X227.583 Y157.592
G1 X161.408 Y91.417 E2.87562
G1 X160.874 Y91.417
G1 X227.583 Y158.126 E2.8988
G1 X227.583 Y158.659
G1 X160.341 Y91.417 E2.92197
G1 X159.808 Y91.417
G1 X227.583 Y159.192 E2.94514
G1 X227.583 Y159.725
G1 X159.275 Y91.417 E2.96831
G1 X158.741 Y91.417
G1 X227.583 Y160.259 E2.99149
G1 X227.373 Y160.583
G1 X158.208 Y91.417 E3.00557
G1 X157.675 Y91.417
G1 X226.84 Y160.583 E3.00557
G1 X226.307 Y160.583
G1 X157.142 Y91.417 E3.00557
G1 X156.608 Y91.417
G1 X225.774 Y160.583 E3.00557
G1 X225.24 Y160.583
G1 X156.075 Y91.417 E3.00557
G1 X155.542 Y91.417
G1 X224.707 Y160.583 E3.00557
G1 X224.174 Y160.583
G1 X155.009 Y91.417 E3.00557
G1 X154.475 Y91.417
G1 X223.641 Y160.583 E3.00557
G1 X223.107 Y160.583
G1 X153.942 Y91.417 E3.00557
G1 X153.409 Y91.417
G1 X222.574 Y160.583 E3.00557
G1 X222.041 Y160.583
G1 X152.876 Y91.417 E3.00557
G1 X152.342 Y91.417
G1 X221.508 Y160.583 E3.00557
G1 X220.974 Y160.583
G1 X151.809 Y91.417 E3.00557
G1 X151.276 Y91.417
G1 X220.441 Y160.583 E3.00557
G1 X219.908 Y160.583
G1 X150.742 Y91.417 E3.00557
G1 X150.209 Y91.417
G1 X219.374 Y160.583 E3.00557
G1 X218.841 Y160.583
G1 X149.676 Y91.417 E3.00557
G1 X149.143 Y91.417
G1 X218.308 Y160.583 E3.00557
G1 X217.775 Y160.583
G1 X148.609 Y91.417 E3.00557
G1 X148.076 Y91.417
G1 X217.241 Y160.583 E3.00557
G1 X216.708 Y160.583
G1 X147.543 Y91.417 E3.00557
G1 X147.01 Y91.417
G1 X216.175 Y160.583 E3.00557
G1 X215.642 Y160.583
G1 X146.476 Y91.417 E3.00557
G1 X145.943 Y91.417
G1 X215.108 Y160.583 E3.00557
G1 X214.575 Y160.583
G1 X145.41 Y91.417 E3.00557
G1 X144.877 Y91.417
G1 X214.042 Y160.583 E3.00557
G1 X213.509 Y160.583
G1 X144.343 Y91.417 E3.00557
G1 X143.81 Y91.417
G1 X212.975 Y160.583 E3.00557
G1 X212.442 Y160.583
G1 X143.277 Y91.417 E3.00557
G1 X142.744 Y91.417
G1 X211.909 Y160.583 E3.00557
G1 X211.376 Y160.583
G1 X142.21 Y91.417 E3.00557
G1 X141.677 Y91.417
G1 X210.842 Y160.583 E3.00557
G1 X210.309 Y160.583
G1 X141.144 Y91.417 E3.00557
G1 X140.611 Y91.417
G1 X209.776 Y160.583 E3.00557
G1 X209.243 Y160.583
G1 X140.077 Y91.417 E3.00557
G1 X139.544 Y91.417
G1 X208.709 Y160.583 E3.00557
G1 X208.176 Y160.583
G1 X139.011 Y91.417 E3.00557
G1 X138.478 Y91.417
G1 X207.643 Y160.583 E3.00557
M73 P93 R3
G1 X207.11 Y160.583
G1 X137.944 Y91.417 E3.00557
G1 X137.411 Y91.417
G1 X206.576 Y160.583 E3.00557
G1 X206.043 Y160.583
G1 X136.878 Y91.417 E3.00557
G1 X136.345 Y91.417
G1 X205.51 Y160.583 E3.00557
G1 X204.977 Y160.583
G1 X135.811 Y91.417 E3.00557
G1 X135.278 Y91.417
G1 X204.443 Y160.583 E3.00557
G1 X203.91 Y160.583
G1 X134.745 Y91.417 E3.00557
G1 X134.212 Y91.417
G1 X203.377 Y160.583 E3.00557
G1 X202.843 Y160.583
G1 X133.678 Y91.417 E3.00557
G1 X133.145 Y91.417
G1 X202.31 Y160.583 E3.00557
G1 X201.777 Y160.583
G1 X132.612 Y91.417 E3.00557
G1 X132.078 Y91.417
G1 X201.244 Y160.583 E3.00557
G1 X200.71 Y160.583
G1 X131.545 Y91.417 E3.00557
G1 X131.012 Y91.417
G1 X200.177 Y160.583 E3.00557
G1 X199.644 Y160.583
G1 X130.479 Y91.417 E3.00557
G1 X129.945 Y91.417
G1 X199.111 Y160.583 E3.00557
G1 X198.577 Y160.583
G1 X129.412 Y91.417 E3.00557
G1 X128.879 Y91.417
G1 X198.044 Y160.583 E3.00557
G1 X197.511 Y160.583
G1 X128.346 Y91.417 E3.00557
G1 X127.812 Y91.417
G1 X196.978 Y160.583 E3.00557
G1 X196.444 Y160.583
G1 X127.279 Y91.417 E3.00557
G1 X126.746 Y91.417
G1 X195.911 Y160.583 E3.00557
G1 X195.378 Y160.583
G1 X126.213 Y91.417 E3.00557
G1 X125.679 Y91.417
G1 X194.845 Y160.583 E3.00557
G1 X194.311 Y160.583
G1 X125.146 Y91.417 E3.00557
G1 X124.613 Y91.417
G1 X193.778 Y160.583 E3.00557
G1 X193.245 Y160.583
G1 X124.08 Y91.417 E3.00557
G1 X123.546 Y91.417
G1 X192.712 Y160.583 E3.00557
G1 X192.178 Y160.583
G1 X123.013 Y91.417 E3.00557
G1 X122.48 Y91.417
G1 X191.645 Y160.583 E3.00557
G1 X191.112 Y160.583
G1 X121.947 Y91.417 E3.00557
G1 X121.413 Y91.417
G1 X190.579 Y160.583 E3.00557
G1 X190.045 Y160.583
G1 X120.88 Y91.417 E3.00557
G1 X120.347 Y91.417
G1 X189.512 Y160.583 E3.00557
G1 X188.979 Y160.583
G1 X119.814 Y91.417 E3.00557
G1 X119.28 Y91.417
G1 X188.446 Y160.583 E3.00557
G1 X187.912 Y160.583
G1 X118.747 Y91.417 E3.00557
G1 X118.214 Y91.417
G1 X187.379 Y160.583 E3.00557
G1 X186.846 Y160.583
G1 X117.681 Y91.417 E3.00557
G1 X117.147 Y91.417
G1 X186.313 Y160.583 E3.00557
G1 X185.779 Y160.583
G1 X116.614 Y91.417 E3.00557
G1 X116.081 Y91.417
G1 X185.246 Y160.583 E3.00557
G1 X184.713 Y160.583
G1 X115.547 Y91.417 E3.00557
G1 X115.014 Y91.417
G1 X184.179 Y160.583 E3.00557
G1 X183.646 Y160.583
G1 X114.481 Y91.417 E3.00557
G1 X113.948 Y91.417
G1 X183.113 Y160.583 E3.00557
G1 X182.58 Y160.583
G1 X113.414 Y91.417 E3.00557
G1 X112.881 Y91.417
G1 X182.046 Y160.583 E3.00557
G1 X181.513 Y160.583
G1 X112.348 Y91.417 E3.00557
G1 X111.815 Y91.417
G1 X180.98 Y160.583 E3.00557
G1 X180.447 Y160.583
G1 X111.281 Y91.417 E3.00557
M73 P94 R3
G1 X110.748 Y91.417
G1 X179.913 Y160.583 E3.00557
G1 X179.38 Y160.583
G1 X110.215 Y91.417 E3.00557
G1 X109.682 Y91.417
G1 X178.847 Y160.583 E3.00557
G1 X178.314 Y160.583
G1 X109.148 Y91.417 E3.00557
G1 X108.615 Y91.417
G1 X177.78 Y160.583 E3.00557
G1 X177.247 Y160.583
G1 X108.082 Y91.417 E3.00557
G1 X107.549 Y91.417
G1 X176.714 Y160.583 E3.00557
G1 X176.181 Y160.583
G1 X107.015 Y91.417 E3.00557
M73 P94 R2
G1 X106.482 Y91.417
G1 X175.647 Y160.583 E3.00557
G1 X175.114 Y160.583
G1 X105.949 Y91.417 E3.00557
G1 X105.416 Y91.417
G1 X174.581 Y160.583 E3.00557
G1 X174.048 Y160.583
G1 X104.882 Y91.417 E3.00557
G1 X104.349 Y91.417
G1 X173.514 Y160.583 E3.00557
G1 X172.981 Y160.583
G1 X103.816 Y91.417 E3.00557
G1 X103.283 Y91.417
G1 X172.448 Y160.583 E3.00557
G1 X171.915 Y160.583
G1 X102.749 Y91.417 E3.00557
G1 X102.216 Y91.417
G1 X171.381 Y160.583 E3.00557
G1 X170.848 Y160.583
G1 X101.683 Y91.417 E3.00557
G1 X101.15 Y91.417
G1 X170.315 Y160.583 E3.00557
G1 X169.782 Y160.583
G1 X100.616 Y91.417 E3.00557
G1 X100.083 Y91.417
G1 X169.248 Y160.583 E3.00557
G1 X168.715 Y160.583
G1 X99.55 Y91.417 E3.00557
G1 X99.017 Y91.417
G1 X168.182 Y160.583 E3.00557
G1 X167.649 Y160.583
G1 X98.483 Y91.417 E3.00557
G1 X97.95 Y91.417
G1 X167.115 Y160.583 E3.00557
G1 X166.582 Y160.583
G1 X97.417 Y91.417 E3.00557
G1 X96.883 Y91.417
G1 X166.049 Y160.583 E3.00557
G1 X165.515 Y160.583
G1 X96.35 Y91.417 E3.00557
G1 X95.817 Y91.417
G1 X164.982 Y160.583 E3.00557
G1 X164.449 Y160.583
G1 X95.284 Y91.417 E3.00557
G1 X94.75 Y91.417
G1 X163.916 Y160.583 E3.00557
G1 X163.382 Y160.583
G1 X94.217 Y91.417 E3.00557
G1 X93.684 Y91.417
G1 X162.849 Y160.583 E3.00557
G1 X162.316 Y160.583
G1 X93.151 Y91.417 E3.00557
G1 X92.617 Y91.417
G1 X161.783 Y160.583 E3.00557
G1 X161.249 Y160.583
G1 X92.084 Y91.417 E3.00557
G1 X91.551 Y91.417
G1 X160.716 Y160.583 E3.00557
G1 X160.183 Y160.583
G1 X110.417 Y110.817 E2.16255
G1 X110.417 Y111.35
G1 X159.65 Y160.583 E2.13938
G1 X159.116 Y160.583
G1 X110.417 Y111.884 E2.11621
G1 X110.417 Y112.417
G1 X158.583 Y160.583 E2.09304
G1 X158.05 Y160.583
G1 X110.417 Y112.95 E2.06986
G1 X110.417 Y113.483
G1 X157.517 Y160.583 E2.04669
G1 X156.983 Y160.583
G1 X110.417 Y114.017 E2.02352
G1 X110.417 Y114.55
G1 X156.45 Y160.583 E2.00034
G1 X155.917 Y160.583
G1 X110.417 Y115.083 E1.97717
G1 X110.417 Y115.616
G1 X155.384 Y160.583 E1.954
G1 X154.85 Y160.583
G1 X110.417 Y116.15 E1.93083
G1 X110.417 Y116.683
G1 X154.317 Y160.583 E1.90765
G1 X153.784 Y160.583
G1 X110.417 Y117.216 E1.88448
G1 X110.417 Y117.749
G1 X153.251 Y160.583 E1.86131
M73 P95 R2
G1 X152.717 Y160.583
G1 X110.417 Y118.283 E1.83814
G1 X110.417 Y118.816
G1 X152.184 Y160.583 E1.81496
G1 X151.651 Y160.583
G1 X110.417 Y119.349 E1.79179
G1 X110.417 Y119.882
G1 X151.118 Y160.583 E1.76862
G1 X150.584 Y160.583
G1 X110.417 Y120.416 E1.74545
G1 X110.417 Y120.949
G1 X150.051 Y160.583 E1.72227
G1 X149.518 Y160.583
G1 X110.417 Y121.482 E1.6991
G1 X110.417 Y122.015
G1 X148.984 Y160.583 E1.67593
G1 X148.451 Y160.583
G1 X110.417 Y122.549 E1.65276
G1 X110.417 Y123.082
G1 X147.918 Y160.583 E1.62958
G1 X147.385 Y160.583
G1 X110.417 Y123.615 E1.60641
G1 X110.417 Y124.149
G1 X146.851 Y160.583 E1.58324
G1 X146.318 Y160.583
G1 X110.417 Y124.682 E1.56007
G1 X110.417 Y125.215
G1 X145.785 Y160.583 E1.53689
G1 X145.252 Y160.583
G1 X110.417 Y125.748 E1.51372
G1 X110.417 Y126.282
G1 X144.718 Y160.583 E1.49055
G1 X144.185 Y160.583
G1 X110.417 Y126.815 E1.46737
G1 X110.417 Y127.348
G1 X143.652 Y160.583 E1.4442
G1 X143.119 Y160.583
G1 X110.417 Y127.881 E1.42103
G1 X110.417 Y128.415
G1 X142.585 Y160.583 E1.39786
G1 X142.052 Y160.583
G1 X110.417 Y128.948 E1.37468
G1 X110.417 Y129.481
G1 X141.519 Y160.583 E1.35151
G1 X140.986 Y160.583
G1 X110.417 Y130.014 E1.32834
G1 X110.417 Y130.548
G1 X140.452 Y160.583 E1.30517
G1 X139.919 Y160.583
G1 X110.417 Y131.081 E1.28199
G1 X110.417 Y131.614
G1 X139.386 Y160.583 E1.25882
G1 X138.853 Y160.583
G1 X110.417 Y132.147 E1.23565
G1 X110.417 Y132.681
G1 X138.319 Y160.583 E1.21248
G1 X137.786 Y160.583
G1 X110.417 Y133.214 E1.1893
G1 X110.417 Y133.747
G1 X137.253 Y160.583 E1.16613
G1 X136.72 Y160.583
G1 X110.417 Y134.28 E1.14296
G1 X110.417 Y134.814
G1 X136.186 Y160.583 E1.11979
G1 X135.653 Y160.583
G1 X110.417 Y135.347 E1.09661
G1 X110.417 Y135.88
G1 X135.12 Y160.583 E1.07344
G1 X134.587 Y160.583
G1 X110.417 Y136.413 E1.05027
G1 X110.417 Y136.947
G1 X134.053 Y160.583 E1.0271
G1 X133.52 Y160.583
G1 X110.417 Y137.48 E1.00392
G1 X110.417 Y138.013
G1 X132.987 Y160.583 E.98075
G1 X132.454 Y160.583
G1 X110.417 Y138.546 E.95758
G1 X110.417 Y139.08
G1 X131.92 Y160.583 E.9344
G1 X131.387 Y160.583
G1 X110.417 Y139.613 E.91123
G1 X110.417 Y140.146
G1 X130.854 Y160.583 E.88806
G1 X130.32 Y160.583
G1 X110.417 Y140.68 E.86489
G1 X110.417 Y141.213
G1 X129.787 Y160.583 E.84171
G1 X129.254 Y160.583
G1 X110.089 Y141.417 E.83282
G1 X109.555 Y141.417
G1 X128.721 Y160.583 E.83282
G1 X128.187 Y160.583
G1 X109.022 Y141.417 E.83282
G1 X108.489 Y141.417
G1 X127.654 Y160.583 E.83282
G1 X127.121 Y160.583
G1 X107.956 Y141.417 E.83282
G1 X107.422 Y141.417
G1 X126.588 Y160.583 E.83282
G1 X126.054 Y160.583
G1 X106.889 Y141.417 E.83282
G1 X106.356 Y141.417
G1 X125.521 Y160.583 E.83282
G1 X124.988 Y160.583
G1 X105.823 Y141.417 E.83282
G1 X105.289 Y141.417
G1 X124.455 Y160.583 E.83282
G1 X123.921 Y160.583
G1 X104.756 Y141.417 E.83282
G1 X104.223 Y141.417
G1 X123.388 Y160.583 E.83282
G1 X122.855 Y160.583
G1 X103.69 Y141.417 E.83282
G1 X103.156 Y141.417
G1 X122.322 Y160.583 E.83282
G1 X121.788 Y160.583
G1 X102.623 Y141.417 E.83282
G1 X102.09 Y141.417
G1 X121.255 Y160.583 E.83282
G1 X120.722 Y160.583
G1 X101.557 Y141.417 E.83282
G1 X101.023 Y141.417
G1 X120.189 Y160.583 E.83282
G1 X119.655 Y160.583
G1 X100.49 Y141.417 E.83282
G1 X99.957 Y141.417
G1 X119.122 Y160.583 E.83282
; WIPE_START
M204 S10000
G1 X117.708 Y159.168 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X116.54 Y151.626 Z5.4 F30000
G1 X110.183 Y110.583 Z5.4
G1 Z5
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X91.018 Y91.417 E.83282
G1 X90.484 Y91.417
G1 X109.65 Y110.583 E.83282
G1 X109.116 Y110.583
G1 X89.951 Y91.417 E.83282
G1 X89.418 Y91.417
G1 X108.583 Y110.583 E.83282
G1 X108.05 Y110.583
G1 X88.885 Y91.417 E.83282
G1 X88.351 Y91.417
G1 X107.517 Y110.583 E.83282
G1 X106.983 Y110.583
G1 X87.818 Y91.417 E.83282
G1 X87.285 Y91.417
G1 X106.45 Y110.583 E.83282
G1 X105.917 Y110.583
G1 X86.752 Y91.417 E.83282
G1 X86.218 Y91.417
G1 X105.384 Y110.583 E.83282
G1 X104.85 Y110.583
G1 X85.685 Y91.417 E.83282
G1 X85.152 Y91.417
G1 X104.317 Y110.583 E.83282
G1 X103.784 Y110.583
G1 X84.619 Y91.417 E.83282
G1 X84.085 Y91.417
G1 X103.251 Y110.583 E.83282
M73 P96 R2
G1 X102.717 Y110.583
G1 X83.552 Y91.417 E.83282
G1 X83.019 Y91.417
G1 X102.184 Y110.583 E.83282
G1 X101.651 Y110.583
G1 X82.486 Y91.417 E.83282
G1 X81.952 Y91.417
G1 X101.118 Y110.583 E.83282
G1 X100.584 Y110.583
G1 X81.419 Y91.417 E.83282
G1 X80.886 Y91.417
G1 X100.051 Y110.583 E.83282
G1 X99.583 Y110.647
G1 X80.352 Y91.417 E.83564
G1 X79.819 Y91.417
G1 X99.583 Y111.181 E.85881
G1 X99.583 Y111.714
G1 X79.286 Y91.417 E.88199
G1 X78.753 Y91.417
G1 X99.583 Y112.247 E.90516
G1 X99.583 Y112.781
G1 X78.219 Y91.417 E.92833
G1 X77.686 Y91.417
G1 X99.583 Y113.314 E.9515
G1 X99.583 Y113.847
G1 X77.153 Y91.417 E.97468
G1 X76.62 Y91.417
G1 X99.583 Y114.38 E.99785
G1 X99.583 Y114.914
G1 X76.086 Y91.417 E1.02102
M73 P96 R1
G1 X75.553 Y91.417
G1 X99.583 Y115.447 E1.0442
G1 X99.583 Y115.98
G1 X75.02 Y91.417 E1.06737
G1 X74.487 Y91.417
G1 X99.583 Y116.513 E1.09054
G1 X99.583 Y117.047
G1 X73.953 Y91.417 E1.11371
G1 X73.42 Y91.417
G1 X99.583 Y117.58 E1.13689
G1 X99.583 Y118.113
G1 X72.887 Y91.417 E1.16006
G1 X72.354 Y91.417
G1 X99.583 Y118.646 E1.18323
G1 X99.583 Y119.18
G1 X71.82 Y91.417 E1.2064
G1 X71.287 Y91.417
G1 X99.583 Y119.713 E1.22958
G1 X99.583 Y120.246
G1 X70.754 Y91.417 E1.25275
G1 X70.221 Y91.417
G1 X99.583 Y120.779 E1.27592
G1 X99.583 Y121.313
G1 X69.687 Y91.417 E1.29909
G1 X69.154 Y91.417
G1 X99.583 Y121.846 E1.32227
G1 X99.583 Y122.379
G1 X68.621 Y91.417 E1.34544
G1 X68.088 Y91.417
G1 X99.583 Y122.912 E1.36861
G1 X99.583 Y123.446
G1 X67.554 Y91.417 E1.39178
G1 X67.021 Y91.417
G1 X99.583 Y123.979 E1.41496
G1 X99.583 Y124.512
G1 X66.488 Y91.417 E1.43813
G1 X65.955 Y91.417
G1 X99.583 Y125.045 E1.4613
G1 X99.583 Y125.579
G1 X65.421 Y91.417 E1.48448
G1 X64.888 Y91.417
G1 X99.583 Y126.112 E1.50765
G1 X99.583 Y126.645
G1 X64.355 Y91.417 E1.53082
G1 X63.822 Y91.417
G1 X99.583 Y127.178 E1.55399
G1 X99.583 Y127.712
G1 X63.288 Y91.417 E1.57717
G1 X62.755 Y91.417
G1 X99.583 Y128.245 E1.60034
G1 X99.583 Y128.778
G1 X62.222 Y91.417 E1.62351
G1 X61.688 Y91.417
G1 X99.583 Y129.311 E1.64668
G1 X99.583 Y129.845
G1 X61.155 Y91.417 E1.66986
G1 X60.622 Y91.417
G1 X99.583 Y130.378 E1.69303
G1 X99.583 Y130.911
G1 X60.089 Y91.417 E1.7162
G1 X59.555 Y91.417
G1 X99.583 Y131.445 E1.73937
G1 X99.583 Y131.978
G1 X59.022 Y91.417 E1.76255
G1 X58.489 Y91.417
G1 X99.583 Y132.511 E1.78572
G1 X99.583 Y133.044
G1 X57.956 Y91.417 E1.80889
G1 X57.422 Y91.417
G1 X99.583 Y133.578 E1.83206
G1 X99.583 Y134.111
G1 X56.889 Y91.417 E1.85524
G1 X56.356 Y91.417
G1 X99.583 Y134.644 E1.87841
G1 X99.583 Y135.177
G1 X55.823 Y91.417 E1.90158
G1 X55.289 Y91.417
G1 X99.583 Y135.711 E1.92475
G1 X99.583 Y136.244
G1 X54.756 Y91.417 E1.94793
G1 X54.223 Y91.417
G1 X99.583 Y136.777 E1.9711
G1 X99.583 Y137.31
G1 X53.69 Y91.417 E1.99427
G1 X53.156 Y91.417
G1 X99.583 Y137.844 E2.01745
G1 X99.583 Y138.377
G1 X52.623 Y91.417 E2.04062
G1 X52.09 Y91.417
G1 X99.583 Y138.91 E2.06379
G1 X99.583 Y139.443
G1 X51.557 Y91.417 E2.08696
G1 X51.023 Y91.417
G1 X99.583 Y139.977 E2.11014
G1 X99.583 Y140.51
G1 X50.49 Y91.417 E2.13331
G1 X49.957 Y91.417
G1 X99.583 Y141.043 E2.15648
; WIPE_START
M204 S10000
G1 X98.168 Y139.629 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X103.495 Y145.095 Z5.4 F30000
G1 X118.589 Y160.583 Z5.4
G1 Z5
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X49.424 Y91.417 E3.00557
G1 X48.89 Y91.417
G1 X118.056 Y160.583 E3.00557
G1 X117.522 Y160.583
G1 X48.357 Y91.417 E3.00557
G1 X47.824 Y91.417
G1 X116.989 Y160.583 E3.00557
G1 X116.456 Y160.583
G1 X47.291 Y91.417 E3.00557
G1 X46.757 Y91.417
G1 X115.923 Y160.583 E3.00557
G1 X115.389 Y160.583
G1 X46.224 Y91.417 E3.00557
G1 X45.691 Y91.417
G1 X114.856 Y160.583 E3.00557
G1 X114.323 Y160.583
G1 X45.157 Y91.417 E3.00557
G1 X44.624 Y91.417
G1 X113.789 Y160.583 E3.00557
G1 X113.256 Y160.583
G1 X44.091 Y91.417 E3.00557
G1 X43.558 Y91.417
G1 X112.723 Y160.583 E3.00557
G1 X112.19 Y160.583
G1 X43.024 Y91.417 E3.00557
G1 X42.491 Y91.417
G1 X111.656 Y160.583 E3.00557
G1 X111.123 Y160.583
G1 X41.958 Y91.417 E3.00557
G1 X41.425 Y91.417
G1 X67.101 Y117.094 E1.11578
; WIPE_START
M204 S10000
G1 X65.687 Y115.68 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X65.973 Y116.499 Z5.4 F30000
G1 Z5
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X40.891 Y91.417 E1.08991
G1 X40.358 Y91.417
G1 X65.092 Y116.151 E1.07479
G1 X64.324 Y115.917
G1 X39.825 Y91.417 E1.06462
G1 X39.292 Y91.417
G1 X63.647 Y115.773 E1.05837
G1 X63.015 Y115.674
G1 X38.758 Y91.417 E1.05408
G1 X38.225 Y91.417
G1 X62.414 Y115.606 E1.05113
G1 X61.868 Y115.594
G1 X37.692 Y91.417 E1.05059
G1 X37.159 Y91.417
G1 X61.336 Y115.594 E1.05061
G1 X60.836 Y115.628
G1 X36.625 Y91.417 E1.05209
G1 X36.092 Y91.417
G1 X60.354 Y115.679 E1.05428
G1 X59.894 Y115.752
G1 X35.559 Y91.417 E1.05746
G1 X35.026 Y91.417
M73 P97 R1
G1 X59.446 Y115.837 E1.06117
G1 X59.021 Y115.946
G1 X34.492 Y91.417 E1.06589
G1 X33.959 Y91.417
G1 X58.602 Y116.06 E1.07085
G1 X58.208 Y116.2
G1 X33.426 Y91.417 E1.07693
G1 X32.893 Y91.417
G1 X57.815 Y116.34 E1.083
G1 X57.448 Y116.506
G1 X32.359 Y91.417 E1.09021
G1 X31.826 Y91.417
G1 X57.083 Y116.674 E1.09753
G1 X56.733 Y116.857
G1 X31.705 Y91.829 E1.08759
; WIPE_START
M204 S10000
G1 X33.119 Y93.243 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X32.346 Y93.004 Z5.4 F30000
G1 Z5
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X56.395 Y117.052 E1.04502
G1 X56.06 Y117.251
G1 X32.41 Y93.601 E1.02768
G1 X32.33 Y94.055
G1 X55.747 Y117.471 E1.01756
G1 X55.434 Y117.692
G1 X32.174 Y94.432 E1.01078
G1 X31.956 Y94.747
G1 X55.138 Y117.928 E1.00734
G1 X54.85 Y118.174
G1 X31.682 Y95.006 E1.00675
G1 X31.354 Y95.211
G1 X54.565 Y118.422 E1.00864
G1 X54.301 Y118.692
G1 X30.964 Y95.355 E1.01412
G1 X30.495 Y95.418
G1 X54.038 Y118.962 E1.02307
G1 X53.789 Y119.246
G1 X29.847 Y95.304 E1.04041
G1 X28.731 Y94.722
G1 X53.55 Y119.54 E1.07849
G1 X53.314 Y119.837
G1 X28.417 Y94.941 E1.08187
G1 X28.417 Y95.474
G1 X53.099 Y120.156 E1.07255
G1 X52.885 Y120.475
G1 X28.417 Y96.008 E1.06324
G1 X28.417 Y96.541
G1 X52.687 Y120.811 E1.05465
G1 X52.499 Y121.155
G1 X28.417 Y97.074 E1.04645
G1 X28.417 Y97.607
G1 X52.316 Y121.506 E1.03853
G1 X52.155 Y121.878
G1 X28.417 Y98.141 E1.03151
G1 X28.417 Y98.674
G1 X51.993 Y122.25 E1.0245
G1 X51.858 Y122.648
G1 X28.417 Y99.207 E1.01861
G1 X28.417 Y99.74
G1 X51.726 Y123.049 E1.01286
G1 X51.615 Y123.471
G1 X28.417 Y100.274 E1.00806
G1 X28.417 Y100.807
G1 X51.514 Y123.904 E1.00367
G1 X51.432 Y124.355
G1 X28.417 Y101.34 E1.0001
G1 X28.417 Y101.873
G1 X51.368 Y124.824 E.99731
G1 X51.324 Y125.314
G1 X28.417 Y102.407 E.99542
G1 X28.417 Y102.94
G1 X51.301 Y125.824 E.99441
G1 X51.31 Y126.366
G1 X28.417 Y103.473 E.99479
G1 X28.417 Y104.006
G1 X51.335 Y126.924 E.99589
G1 X51.418 Y127.54
G1 X28.417 Y104.54 E.99948
G1 X28.417 Y105.073
G1 X51.536 Y128.192 E1.00462
G1 X51.708 Y128.897
G1 X28.417 Y105.606 E1.01208
G1 X28.417 Y106.139
G1 X51.97 Y129.692 E1.02349
G1 X52.389 Y130.644
G1 X28.417 Y106.673 E1.04169
G1 X28.417 Y107.206
G1 X53.19 Y131.979 E1.0765
; WIPE_START
M204 S10000
G1 X51.776 Y130.564 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X58.522 Y126.995 Z5.4 F30000
G1 X70.607 Y120.6 Z5.4
G1 Z5
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X110.59 Y160.583 E1.73744
G1 X110.057 Y160.583
G1 X71.211 Y121.737 E1.68802
G1 X71.56 Y122.619
G1 X109.523 Y160.583 E1.64972
G1 X108.99 Y160.583
G1 X71.783 Y123.376 E1.61681
G1 X71.936 Y124.062
G1 X108.457 Y160.583 E1.58701
G1 X107.924 Y160.583
G1 X72.043 Y124.702 E1.5592
G1 X72.096 Y125.288
G1 X107.39 Y160.583 E1.5337
G1 X106.857 Y160.583
G1 X72.118 Y125.843 E1.50959
G1 X72.118 Y126.377
G1 X106.324 Y160.583 E1.48641
G1 X105.791 Y160.583
G1 X72.081 Y126.873 E1.46483
G1 X72.037 Y127.362
G1 X105.257 Y160.583 E1.44359
G1 X104.724 Y160.583
G1 X71.958 Y127.817 E1.42383
G1 X71.875 Y128.267
G1 X104.191 Y160.583 E1.40426
G1 X103.658 Y160.583
G1 X71.765 Y128.69 E1.38591
G1 X71.647 Y129.105
G1 X103.124 Y160.583 E1.36783
G1 X102.591 Y160.583
G1 X71.513 Y129.504 E1.35051
G1 X71.365 Y129.89
G1 X102.058 Y160.583 E1.33373
G1 X101.525 Y160.583
G1 X71.209 Y130.267 E1.31735
G1 X71.034 Y130.625
G1 X100.991 Y160.583 E1.3018
G1 X100.458 Y160.583
G1 X70.859 Y130.983 E1.28624
G1 X70.658 Y131.316
G1 X99.925 Y160.583 E1.27177
G1 X99.392 Y160.583
G1 X70.457 Y131.648 E1.25736
G1 X70.242 Y131.967
G1 X98.858 Y160.583 E1.2435
G1 X98.325 Y160.583
G1 X70.015 Y132.273 E1.23019
G1 X69.788 Y132.579
G1 X97.792 Y160.583 E1.21689
G1 X97.259 Y160.583
G1 X69.537 Y132.861 E1.20465
G1 X69.285 Y133.143
G1 X96.725 Y160.583 E1.1924
G1 X96.192 Y160.583
G1 X69.022 Y133.412 E1.18069
G1 X68.746 Y133.67
G1 X95.659 Y160.583 E1.1695
G1 X95.125 Y160.583
G1 X68.47 Y133.927 E1.15831
G1 X68.17 Y134.161
G1 X94.592 Y160.583 E1.14817
G1 X94.059 Y160.583
G1 X67.87 Y134.394 E1.13804
G1 X67.557 Y134.614
G1 X93.526 Y160.583 E1.12845
G1 X92.992 Y160.583
G1 X67.232 Y134.822 E1.11941
G1 X66.906 Y135.029
G1 X92.459 Y160.583 E1.11042
G1 X91.926 Y160.583
G1 X66.555 Y135.211 E1.10251
G1 X66.203 Y135.393
G1 X91.393 Y160.583 E1.0946
G1 X90.859 Y160.583
G1 X65.834 Y135.558 E1.08746
G1 X65.456 Y135.712
G1 X90.326 Y160.583 E1.08075
G1 X89.793 Y160.583
G1 X65.067 Y135.857 E1.07446
G1 X64.658 Y135.981
G1 X89.26 Y160.583 E1.06905
G1 X88.726 Y160.583
G1 X64.246 Y136.102 E1.06378
G1 X63.805 Y136.194
G1 X88.193 Y160.583 E1.05979
G1 X87.66 Y160.583
G1 X63.363 Y136.286 E1.05581
G1 X62.885 Y136.341
G1 X87.127 Y160.583 E1.05343
G1 X86.593 Y160.583
G1 X62.405 Y136.394 E1.05112
G1 X61.883 Y136.406
G1 X86.06 Y160.583 E1.0506
G1 X85.527 Y160.583
G1 X61.351 Y136.407 E1.05056
G1 X60.779 Y136.368
G1 X84.994 Y160.583 E1.05226
M73 P98 R1
G1 X84.46 Y160.583
G1 X60.171 Y136.293 E1.0555
G1 X59.528 Y136.184
G1 X83.927 Y160.583 E1.06025
G1 X83.394 Y160.583
G1 X58.81 Y135.999 E1.0683
G1 X58.006 Y135.728
G1 X82.861 Y160.583 E1.08005
G1 X82.327 Y160.583
G1 X57.06 Y135.315 E1.09798
; WIPE_START
M204 S10000
G1 X58.474 Y136.73 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X55.724 Y134.512 Z5.4 F30000
M73 P98 R0
G1 Z5
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X81.794 Y160.583 E1.13288
G1 X81.261 Y160.583
G1 X28.417 Y107.739 E2.2963
G1 X28.417 Y108.272
G1 X80.728 Y160.583 E2.27313
G1 X80.194 Y160.583
G1 X28.417 Y108.806 E2.24996
G1 X28.417 Y109.339
G1 X79.661 Y160.583 E2.22678
G1 X79.128 Y160.583
G1 X28.417 Y109.872 E2.20361
G1 X28.417 Y110.405
G1 X78.595 Y160.583 E2.18044
G1 X78.061 Y160.583
G1 X28.417 Y110.939 E2.15727
G1 X28.417 Y111.472
G1 X77.528 Y160.583 E2.13409
G1 X76.995 Y160.583
G1 X28.417 Y112.005 E2.11092
G1 X28.417 Y112.539
G1 X76.461 Y160.583 E2.08775
G1 X75.928 Y160.583
G1 X28.417 Y113.072 E2.06458
G1 X28.417 Y113.605
G1 X75.395 Y160.583 E2.0414
G1 X74.862 Y160.583
G1 X28.417 Y114.138 E2.01823
G1 X28.417 Y114.672
G1 X74.328 Y160.583 E1.99506
G1 X73.795 Y160.583
G1 X28.417 Y115.205 E1.97189
G1 X28.417 Y115.738
G1 X73.262 Y160.583 E1.94871
G1 X72.729 Y160.583
G1 X28.417 Y116.271 E1.92554
G1 X28.417 Y116.805
G1 X72.195 Y160.583 E1.90237
G1 X71.662 Y160.583
G1 X28.417 Y117.338 E1.8792
G1 X28.417 Y117.871
G1 X71.129 Y160.583 E1.85602
G1 X70.596 Y160.583
G1 X28.417 Y118.404 E1.83285
G1 X28.417 Y118.938
G1 X70.062 Y160.583 E1.80968
G1 X69.529 Y160.583
G1 X28.417 Y119.471 E1.7865
G1 X28.417 Y120.004
G1 X68.996 Y160.583 E1.76333
G1 X68.463 Y160.583
G1 X28.417 Y120.537 E1.74016
G1 X28.417 Y121.071
G1 X67.929 Y160.583 E1.71699
G1 X67.396 Y160.583
G1 X28.417 Y121.604 E1.69381
G1 X28.417 Y122.137
G1 X66.863 Y160.583 E1.67064
G1 X66.33 Y160.583
G1 X28.417 Y122.67 E1.64747
G1 X28.417 Y123.204
G1 X65.796 Y160.583 E1.6243
G1 X65.263 Y160.583
G1 X28.417 Y123.737 E1.60112
G1 X28.417 Y124.27
G1 X64.73 Y160.583 E1.57795
G1 X64.197 Y160.583
G1 X28.417 Y124.803 E1.55478
G1 X28.417 Y125.337
G1 X63.663 Y160.583 E1.53161
G1 X63.13 Y160.583
G1 X28.417 Y125.87 E1.50843
G1 X28.417 Y126.403
G1 X62.597 Y160.583 E1.48526
G1 X62.064 Y160.583
G1 X28.417 Y126.936 E1.46209
G1 X28.417 Y127.47
G1 X61.53 Y160.583 E1.43892
G1 X60.997 Y160.583
G1 X28.417 Y128.003 E1.41574
G1 X28.417 Y128.536
G1 X60.464 Y160.583 E1.39257
G1 X59.93 Y160.583
G1 X28.417 Y129.07 E1.3694
G1 X28.417 Y129.603
G1 X59.397 Y160.583 E1.34623
G1 X58.864 Y160.583
G1 X28.417 Y130.136 E1.32305
G1 X28.417 Y130.669
G1 X58.331 Y160.583 E1.29988
G1 X57.797 Y160.583
G1 X28.417 Y131.203 E1.27671
G1 X28.417 Y131.736
G1 X57.264 Y160.583 E1.25353
G1 X56.731 Y160.583
G1 X28.417 Y132.269 E1.23036
G1 X28.417 Y132.802
G1 X56.198 Y160.583 E1.20719
G1 X55.664 Y160.583
G1 X28.417 Y133.336 E1.18402
G1 X28.417 Y133.869
G1 X55.131 Y160.583 E1.16084
G1 X54.598 Y160.583
G1 X28.417 Y134.402 E1.13767
G1 X28.417 Y134.935
G1 X54.065 Y160.583 E1.1145
G1 X53.531 Y160.583
G1 X28.417 Y135.469 E1.09133
G1 X28.417 Y136.002
G1 X52.998 Y160.583 E1.06815
G1 X52.465 Y160.583
G1 X28.417 Y136.535 E1.04498
G1 X28.417 Y137.068
G1 X51.932 Y160.583 E1.02181
G1 X51.398 Y160.583
G1 X28.417 Y137.602 E.99864
G1 X28.417 Y138.135
G1 X50.865 Y160.583 E.97546
G1 X50.332 Y160.583
G1 X28.417 Y138.668 E.95229
G1 X28.417 Y139.201
G1 X49.799 Y160.583 E.92912
G1 X49.265 Y160.583
G1 X28.417 Y139.735 E.90595
G1 X28.417 Y140.268
G1 X48.732 Y160.583 E.88277
G1 X48.199 Y160.583
G1 X28.417 Y140.801 E.8596
G1 X28.417 Y141.334
G1 X47.666 Y160.583 E.83643
G1 X47.132 Y160.583
G1 X28.417 Y141.868 E.81325
G1 X28.417 Y142.401
G1 X46.599 Y160.583 E.79008
G1 X46.066 Y160.583
G1 X28.417 Y142.934 E.76691
G1 X28.417 Y143.467
G1 X45.533 Y160.583 E.74374
G1 X44.999 Y160.583
G1 X28.417 Y144.001 E.72056
G1 X28.417 Y144.534
G1 X44.466 Y160.583 E.69739
G1 X43.933 Y160.583
G1 X28.417 Y145.067 E.67422
G1 X28.417 Y145.6
G1 X43.4 Y160.583 E.65105
G1 X42.866 Y160.583
G1 X28.417 Y146.134 E.62787
G1 X28.417 Y146.667
G1 X42.333 Y160.583 E.6047
G1 X41.8 Y160.583
G1 X28.417 Y147.2 E.58153
G1 X28.417 Y147.734
G1 X41.266 Y160.583 E.55836
G1 X40.733 Y160.583
G1 X28.417 Y148.267 E.53518
G1 X28.417 Y148.8
G1 X40.2 Y160.583 E.51201
G1 X39.667 Y160.583
G1 X28.417 Y149.333 E.48884
G1 X28.417 Y149.867
G1 X39.133 Y160.583 E.46567
G1 X38.6 Y160.583
G1 X28.417 Y150.4 E.44249
G1 X28.417 Y150.933
G1 X38.067 Y160.583 E.41932
M73 P99 R0
G1 X37.534 Y160.583
G1 X28.417 Y151.466 E.39615
G1 X28.417 Y152
G1 X37 Y160.583 E.37298
G1 X36.467 Y160.583
G1 X28.417 Y152.533 E.3498
G1 X28.417 Y153.066
G1 X35.934 Y160.583 E.32663
G1 X35.401 Y160.583
G1 X28.417 Y153.599 E.30346
G1 X28.417 Y154.133
G1 X34.867 Y160.583 E.28028
G1 X34.334 Y160.583
G1 X28.417 Y154.666 E.25711
G1 X28.417 Y155.199
G1 X33.801 Y160.583 E.23394
G1 X33.268 Y160.583
G1 X28.417 Y155.732 E.21077
G1 X28.417 Y156.266
G1 X32.734 Y160.583 E.18759
G1 X32.201 Y160.583
G1 X28.417 Y156.799 E.16442
G1 X28.417 Y157.332
G1 X31.668 Y160.583 E.14125
G1 X31.135 Y160.583
G1 X28.417 Y157.865 E.11808
G1 X28.417 Y158.399
G1 X30.601 Y160.583 E.0949
G1 X30.068 Y160.583
G1 X28.417 Y158.932 E.07173
G1 X28.417 Y159.465
G1 X29.535 Y160.583 E.04856
G1 X29.002 Y160.583
G1 X28.417 Y159.998 E.02539
; WIPE_START
M204 S10000
G1 X29.002 Y160.583 E-.31395
G1 X29.535 Y160.583 E-.20264
G1 X29.082 Y160.13 E-.24342
; WIPE_END
G1 E-.04 F1800
G1 X35.607 Y156.17 Z5.4 F30000
G1 X110.53 Y110.704 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.100662
G1 F15000
G1 X110.296 Y110.47 E.00156
; WIPE_START
G1 X110.53 Y110.704 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X103.599 Y113.899 Z5.4 F30000
G1 X56.998 Y135.377 Z5.4
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.206735
G1 F15000
G1 X56.888 Y135.3 E.0018
; LINE_WIDTH: 0.179602
G1 X56.771 Y135.21 E.00164
; LINE_WIDTH: 0.143026
G1 X56.654 Y135.12 E.0012
; LINE_WIDTH: 0.106451
G1 X56.537 Y135.03 E.00076
; WIPE_START
G1 X56.654 Y135.12 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X57.94 Y135.794 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.149572
G1 F15000
G1 X57.764 Y135.678 E.00183
; LINE_WIDTH: 0.133478
G1 X57.684 Y135.622 E.00072
; LINE_WIDTH: 0.103267
G1 X57.604 Y135.566 E.00048
; WIPE_START
G1 X57.684 Y135.622 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X63.011 Y130.155 Z5.4 F30000
G1 X71.273 Y121.676 Z5.4
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.195161
G1 F15000
G1 X71.176 Y121.54 E.00207
; LINE_WIDTH: 0.152361
G1 X71.079 Y121.404 E.00149
; LINE_WIDTH: 0.109562
G1 X70.981 Y121.268 E.00091
G1 X70.668 Y120.539 F30000
; LINE_WIDTH: 0.203554
G1 F15000
G1 X70.525 Y120.356 E.00304
; LINE_WIDTH: 0.158691
G1 X70.378 Y120.17 E.00223
; LINE_WIDTH: 0.112104
G1 X70.152 Y119.908 E.00195
; WIPE_START
G1 X70.378 Y120.17 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X67.768 Y117.525 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.0906043
G1 F15000
G1 X67.721 Y117.483 E.00024
; LINE_WIDTH: 0.115726
G1 X67.535 Y117.333 E.00142
; LINE_WIDTH: 0.160674
G1 X67.348 Y117.183 E.0023
; LINE_WIDTH: 0.205622
G1 X67.162 Y117.033 E.00317
G1 X66.445 Y116.732 F30000
; LINE_WIDTH: 0.108319
G1 F15000
G1 X66.333 Y116.649 E.00074
; LINE_WIDTH: 0.148616
G1 X66.22 Y116.567 E.0012
; LINE_WIDTH: 0.197898
G1 X66.106 Y116.484 E.00179
G1 X65.961 Y116.51 E.00186
; WIPE_START
G1 X66.106 Y116.484 E-.38763
G1 X66.22 Y116.567 E-.37237
; WIPE_END
G1 E-.04 F1800
G1 X60.602 Y115.661 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.0952791
G1 F15000
G1 X60.431 Y115.601 E.00077
; WIPE_START
G1 X60.602 Y115.661 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X58.774 Y115.966 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.0939856
G1 F15000
G2 X58.639 Y116.048 I1.764 J3.055 E.00066
; WIPE_START
G1 X58.774 Y115.966 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X55.933 Y123.05 Z5.4 F30000
G1 X52.677 Y131.171 Z5.4
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.110344
G1 F15000
G1 X52.56 Y131.016 E.00107
; LINE_WIDTH: 0.154681
G1 X52.444 Y130.861 E.00177
; LINE_WIDTH: 0.199018
G1 X52.328 Y130.706 E.00247
; WIPE_START
G1 X52.444 Y130.861 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X55.663 Y134.573 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.216384
G1 F15000
G1 X55.481 Y134.419 E.00338
; LINE_WIDTH: 0.183351
G1 X55.293 Y134.261 E.0028
; LINE_WIDTH: 0.14784
G1 X54.945 Y133.94 E.00405
; LINE_WIDTH: 0.101058
G1 X54.596 Y133.617 E.00225
G1 X53.928 Y132.942 E.0045
; LINE_WIDTH: 0.126348
G1 X53.611 Y132.59 E.00322
; LINE_WIDTH: 0.175259
G1 X53.289 Y132.233 E.00519
; LINE_WIDTH: 0.218722
G1 X53.13 Y132.039 E.00359
; WIPE_START
G1 X53.289 Y132.233 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X49.707 Y125.493 Z5.4 F30000
G1 X32.41 Y92.94 Z5.4
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.184382
G1 F15000
G1 X32.343 Y92.823 E.00155
; LINE_WIDTH: 0.14903
G1 X32.269 Y92.719 E.00111
; LINE_WIDTH: 0.108461
G1 X32.196 Y92.614 E.00068
; WIPE_START
G1 X32.269 Y92.719 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X39.902 Y92.688 Z5.4 F30000
G1 X224.337 Y91.959 Z5.4
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.101039
G1 F15000
G1 X224.199 Y92.085 E.00088
; WIPE_START
G1 X224.337 Y91.959 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X223.754 Y94.279 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.120887
G1 F15000
G3 X223.562 Y93.989 I3.233 J-2.346 E.00221
; WIPE_START
G1 X223.754 Y94.279 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X225.012 Y95.438 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.120652
G1 F15000
G3 X224.72 Y95.245 I1.962 J-3.282 E.00221
; WIPE_START
G1 X225.012 Y95.438 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X227.041 Y94.662 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.100129
G1 F15000
G1 X226.915 Y94.8 E.00087
; WIPE_START
G1 X227.041 Y94.662 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X219.408 Y94.667 Z5.4 F30000
G1 X28.655 Y94.798 Z5.4
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.132048
G1 F15000
G1 X28.583 Y94.775 E.00055
G1 X28.399 Y94.789 E.00134
G1 X28.619 Y94.531 F30000
; LINE_WIDTH: 0.354416
G1 F15000
G1 X28.559 Y94.192 E.00874
; LINE_WIDTH: 0.327737
G1 X28.537 Y94.026 E.00389
; LINE_WIDTH: 0.28397
G1 X28.516 Y93.86 E.00329
; LINE_WIDTH: 0.244654
G3 X28.515 Y93.153 I5.718 J-.361 E.01162
; LINE_WIDTH: 0.282664
G3 X28.538 Y92.971 I2.152 J.181 E.00359
; LINE_WIDTH: 0.328028
G1 X28.559 Y92.808 E.00383
; LINE_WIDTH: 0.35433
G1 X28.619 Y92.469 E.00874
; WIPE_START
G1 X28.559 Y92.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X28.627 Y91.417 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X29.253 Y92.044 E.02722
G1 X28.994 Y92.318
G1 X28.417 Y91.741 E.02505
; WIPE_START
M204 S10000
G1 X28.994 Y92.318 E-.30983
G1 X29.253 Y92.044 E-.14335
G1 X28.682 Y91.473 E-.30682
; WIPE_END
G1 E-.04 F1800
G1 X29.469 Y91.619 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.354037
G1 F15000
G1 X29.809 Y91.559 E.00876
; LINE_WIDTH: 0.327241
G1 X29.978 Y91.537 E.00394
; LINE_WIDTH: 0.283361
G1 X30.147 Y91.515 E.00333
; LINE_WIDTH: 0.244159
G3 X30.841 Y91.514 I.358 J5.719 E.01139
; LINE_WIDTH: 0.281497
G3 X31.026 Y91.537 I-.178 J2.14 E.00363
; LINE_WIDTH: 0.327644
G1 X31.192 Y91.559 E.00389
; LINE_WIDTH: 0.35433
G1 X31.531 Y91.619 E.00874
; close powerlost recovery
M1003 S0
; WIPE_START
G1 F15000
G1 X31.192 Y91.559 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z5.4 I1.217 J0 P1  F30000
M106 S0
M106 P2 S0
M981 S0 P20000 ; close spaghetti detector
; FEATURE: Custom
; MACHINE_END_GCODE_START
; filament end gcode 

;===== date: 20230428 =====================
M400 ; wait for buffer to clear
G92 E0 ; zero the extruder
G1 E-0.8 F1800 ; retract
G1 Z5.5 F900 ; lower z a little
G1 X65 Y245 F12000 ; move to safe pos 
G1 Y265 F3000

G1 X65 Y245 F12000
G1 Y265 F3000
M140 S0 ; turn off bed
M106 S0 ; turn off fan
M106 P2 S0 ; turn off remote part cooling fan
M106 P3 S0 ; turn off chamber cooling fan

G1 X100 F12000 ; wipe
; pull back filament to AMS
M620 S255
G1 X20 Y50 F12000
G1 Y-3
T255
G1 X65 F12000
G1 Y265
G1 X100 F12000 ; wipe
M621 S255
M104 S0 ; turn off hotend

M622.1 S1 ; for prev firware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
    M400 ; wait all motion done
    M991 S0 P-1 ;end smooth timelapse at safe pos
    M400 S3 ;wait for last picture to be taken
M623; end of "timelapse_record_flag"

M400 ; wait all motion done
M17 S
M17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom

    G1 Z105 F600
    G1 Z103

M400 P100
M17 R ; restore z current

M220 S100  ; Reset feedrate magnitude
M201.2 K1.0 ; Reset acc magnitude
M73.2   R1.0 ;Reset left time magnitude
M1002 set_gcode_claim_speed_level : 0

M17 X0.8 Y0.8 Z0.5 ; lower motor current to 45% power
M73 P100 R0
; EXECUTABLE_BLOCK_END

